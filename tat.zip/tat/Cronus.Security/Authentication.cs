﻿using System.Collections.Generic;
using System.Web;

namespace Cronus.Security
{
    public class Authentication
    {
        public static readonly Dictionary<string, long> AuthenticatedDomainDictionary = new Dictionary<string, long>();
        public static readonly List<string> BlockedDomainList = new List<string>();
        public static void AuthenticateDomain()
        {
            var appKey = HttpContext.Current.Request.Headers["Authorization"];
            var domain = HttpContext.Current.Request.Headers["Origin"];
            if (domain != null)
            {
                domain = domain.ToLower();
            }
            EnableCrossDomainAjaxCall(domain);
        }

        private static void EnableCrossDomainAjaxCall(string domain)
        {            
            if (domain != null)
            {
                HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                HttpContext.Current.Response.Cache.SetNoStore();
                //HttpContext.Current.Response.AddHeader("Access-Control-Allow-Origin", "http://pubsdev");
                //HttpContext.Current.Response.AddHeader("Access-Control-Allow-Origin", "*");
                HttpContext.Current.Response.AddHeader("Access-Control-Allow-Origin", domain);
                HttpContext.Current.Response.AddHeader("Access-Control-Allow-Credentials", "true");
                if (HttpContext.Current.Request.HttpMethod == "OPTIONS")
                {
                    HttpContext.Current.Response.AddHeader("Access-Control-Allow-Methods", "GET, POST");
                    HttpContext.Current.Response.AddHeader("Access-Control-Allow-Headers",
                        "Content-Type, Authorization, Accept, X-Requested-With");
                    HttpContext.Current.Response.AddHeader("Access-Control-Max-Age", "1728000");
                    HttpContext.Current.Response.End();
                }
            }
        }
    }
}