﻿using System;
using System.Collections.Generic;
using Cronus.BO;

namespace Cronus.Bll
{
    public interface ICronusBaseBll : ICloneable
    {
        string ScreenName();
        ResponseBO FetchDropDownData(DropDownRequestBO req);
        ResponseBO FetchCycleAndPreviosDate();
        ResponseBO FetchResults(ResultMessageBO req);
        ResponseBO UpdateDB(RequestBO req);
        ResponseBO FetchDataForTable(TableDataRequestBO req);
        ResponseBO FetchDataForQB(TableDataRequestBO req);
        ResponseBO Commit(RequestBO req);
        ResponseBO Rollback(RequestBO req);
        ResponseBO CancelAjax(RequestBO req);
        ResponseBO CustomFunction(CustomFunctionBO req);        
    }
}

