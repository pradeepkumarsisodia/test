﻿using System;
using System.Collections.Generic;
using System.Linq;
using log4net;
using Cronus.BO;
using Cronus.Bo.FesConfig;
using Cronus.Bll.Helper;
using System.Web.Script.Serialization;
using System.Collections.Specialized;

namespace Cronus.Bll.FesConfig
{
    class AnalyticIdConfig : CronusBaseBll
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        string QueryLog = string.Empty;

        public override object Clone() { return new AnalyticIdConfig(); }

        public override string ScreenName()
        {
            return Constants.AnalyticIdConfiguration;
        }

        private List<KeyValuePair<string, string>> GetCacheData(string key)
        {
            List<KeyValuePair<string, string>> retVal = new List<KeyValuePair<string, string>>();
            var dbHelper = this.OracleDbHelper;

            string query;
            switch (key)
            {
                case "ALL":
                    query = string.Format(@"SELECT distinct key, value FROM cronus_own.CONFIG WHERE ScreenID = '{0}' and Context = 'DropDownData'
                                    Union 
                                    select distinct 'INVOCATION_ID' key, invocation_id value from SEC_ANALYTICS_OWN.Model_Invocations where class_id is not null ORDER BY key, value", ScreenName());
                    break;
                case "AppField":
                    query = string.Format(@"SELECT b.value, column_name 
                                    FROM all_tab_columns a join cronus_own.CONFIG b on OWNER = substr(b.value, 1, instr(upper(trim(b.value)), '.') -1 ) and a.table_name = substr(b.value, instr(upper(trim(b.value)), '.') + 1) 
                                    WHERE ScreenID = '{0}' and Context = 'DropDownData' and key = 'MAIN_TABLE' ORDER BY 1 ", ScreenName());
                    break;
                case "LiveTable":
                    query = string.Format(@"SELECT upper(trim(main_table)), upper(trim(audit_table)) From sec_analytics_own.risk_audit_mapping ORDER BY 1 ", ScreenName());
                    break;
                default:
                    throw new Exception(string.Format("Unknown RequestType {0}", key));
            }

            var data = dbHelper.ExecuteSelectQuery(query);
            foreach (var row in data.rows)
            {
                retVal.Add(new KeyValuePair<string, string>(row[0].ToString(), row[1].ToString()));
            }

            return retVal;
        }

        private void updateAnalyticIdMetadata(DatabaseHelper dbHelper, AnalyticIdConfigBO.ConfigInputData data, AnalyticIdConfigBO.ConfigInputData inputData)
        {
            if (inputData == null)
            {
                //The analytic_id does not exists in sec_analytics_own.analytic_id_metadata table. So inserting a row
                /*   var insertQuery = string.Format(@"Insert into SEC_ANALYTICS_OWN.ANALYTIC_ID_METADATA (ANALYTIC_ID, MODEL_FIELD_NAME, DATATYPE, PROVIDER_ID, CURVE_TYPE, CURVE_ID, PRODUCT
                                                       , MODEL_OUTPUT_TYPE, DESCRIPTION, SCENARIO_CONFIG_FILE, SENSITIVITY_CONFIG_FILE) 
                                                       VALUES('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}')"
                                                  , data.analyticId, data.modelFieldName, data.dataType, data.providerId, data.curveType, data.curveId, data.product
                                                  , data.modelOutputType, data.description, data.scenarioConfigFile, data.sensitivityConfigFile);
                 * */
                if (!string.IsNullOrEmpty(data.previousAnayticId))
                {
                    RemoveOldLabelEntry(data.previousAnayticId, "SEC_ANALYTICS_OWN.ANALYTIC_ID_METADATA", "ANALYTIC_ID");
                }
                QueryLog += "I SEC_ANALYTICS_OWN.ANALYTIC_ID_METADATA ANALYTIC_ID : " + data.analyticId + " MODEL_FIELD_NAME : " + data.modelFieldName + " DATATYPE : " + data.dataType + " DESCRIPTION :  " + data.description + " | ";
                var insertQuery = string.Format(@"Insert into SEC_ANALYTICS_OWN.ANALYTIC_ID_METADATA (ANALYTIC_ID, MODEL_FIELD_NAME, DATATYPE, DESCRIPTION) 
                                                    VALUES('{0}', '{1}', '{2}', '{3}')"
                                               , data.analyticId, data.modelFieldName, data.dataType, data.description);
                dbHelper.ExecuteNonQuery(insertQuery);

                //update label columns
                foreach (var label in data.lableList)
                {
                    QueryLog += "U SEC_ANALYTICS_OWN.ANALYTIC_ID_METADATA " + label + " : " + label.Remove(label.LastIndexOf("LABEL")) + "Where  analytic_id : " + data.analyticId + " | ";
                    var updateQuery = string.Format("Update SEC_ANALYTICS_OWN.ANALYTIC_ID_METADATA set {1} = '{2}' where analytic_id = '{0}'", data.analyticId, label, label.Remove(label.LastIndexOf("LABEL")).ToLower());
                    dbHelper.ExecuteNonQuery(updateQuery);
                }
            }
            else
            {
                //update analytic_id entry in sec_analytics_own.analytic_id_metadata table
                var updateQuery = "";
                if (inputData.modelFieldName != data.modelFieldName) updateQuery += string.Format(" MODEL_FIELD_NAME = '{0}', ", data.modelFieldName);
                if (inputData.dataType != data.dataType) updateQuery += string.Format(" DATATYPE = '{0}', ", data.dataType);
                if (inputData.description != data.description) updateQuery += string.Format(" DESCRIPTION = '{0}', ", data.description);
                /*  if (inputData.providerId != data.providerId) updateQuery += string.Format(" PROVIDER_ID = '{0}', ", data.providerId);
                  if (inputData.curveType != data.curveType) updateQuery += string.Format(" CURVE_TYPE = '{0}', ", data.curveType);
                  //if (inputData.curveId != data.curveId) updateQuery += string.Format(" CURVE_ID = '{0}', ", data.curveId);
                  if (inputData.product != data.product) updateQuery += string.Format(" PRODUCT = '{0}', ", data.product);
                  if (inputData.modelOutputType != data.modelOutputType) updateQuery += string.Format(" MODEL_OUTPUT_TYPE = '{0}', ", data.modelOutputType);
                  if (inputData.scenarioConfigFile != data.scenarioConfigFile) updateQuery += string.Format(" SCENARIO_CONFIG_FILE = '{0}', ", data.scenarioConfigFile);
                  if (inputData.sensitivityConfigFile != data.sensitivityConfigFile) updateQuery += string.Format(" SENSITIVITY_CONFIG_FILE = '{0}', ", data.sensitivityConfigFile);
                  */

                //update label columns
                foreach (var label in data.lableList)
                {
                    //if label not found the input data update the label column
                    if (!inputData.lableList.Contains(label)) updateQuery += string.Format(" {0} = '{1}', ", label, label.ToLower().Remove(label.ToLower().LastIndexOf("label")));
                }

                foreach (var label in inputData.lableList)
                {
                    //if label not found the input data update the label column
                    if (!data.lableList.Contains(label)) updateQuery += string.Format(" {0} = null, ", label);
                }

                //Create final update query
                if (!string.IsNullOrWhiteSpace(updateQuery))
                {
                    QueryLog += "U SEC_ANALYTICS_OWN.ANALYTIC_ID_METADATA " + updateQuery.Remove(updateQuery.LastIndexOf(",")).Replace("=", ":") + string.Format(" where analytic_id : '{0}'", data.analyticId) + " | ";
                    updateQuery = string.Format("Update SEC_ANALYTICS_OWN.ANALYTIC_ID_METADATA set ") + updateQuery.Remove(updateQuery.LastIndexOf(",")) + string.Format(" where analytic_id = '{0}'", data.analyticId);
                    dbHelper.ExecuteNonQuery(updateQuery);
                }
            }
        }

        private void updateRiskMeasuresToApp(DatabaseHelper dbHelper, AnalyticIdConfigBO.ConfigInputData data, AnalyticIdConfigBO.ConfigInputData inputData)
        {
            //Update risk_measures_to_app table
            foreach (var riskMeasuresToAppData in data.riskMeasuresToAppList)
            {
                var inputRiskMeasuresToAppData = inputData == null ? null : inputData.riskMeasuresToAppList.Find(x =>
                        x.analyticIdToStage == riskMeasuresToAppData.analyticIdToStage
                        && x.appField == riskMeasuresToAppData.appField
                        && x.mainTable == riskMeasuresToAppData.mainTable);
                if (inputRiskMeasuresToAppData != null)
                {
                    var updateQuery = "";
                    if (riskMeasuresToAppData.modelSrmDiffThreshold != inputRiskMeasuresToAppData.modelSrmDiffThreshold) updateQuery += string.Format(" MODEL_SRM_DIFF_THRESHOLD = {0}, ", riskMeasuresToAppData.modelSrmDiffThreshold);
                    if (riskMeasuresToAppData.dataType != inputRiskMeasuresToAppData.dataType) updateQuery += string.Format(" DATATYPE = '{0}', ", riskMeasuresToAppData.dataType);
                    if (riskMeasuresToAppData.isApplicable != inputRiskMeasuresToAppData.isApplicable) updateQuery += string.Format(" IS_APPLICABLE = '{0}', ", riskMeasuresToAppData.isApplicable ? "Y" : "N");
                    if (riskMeasuresToAppData.description != inputRiskMeasuresToAppData.description) updateQuery += string.Format(" DESCRIPTION = '{0}', ", riskMeasuresToAppData.description);
                    if (!string.IsNullOrWhiteSpace(updateQuery))
                    {
                        QueryLog += "U SEC_ANALYTICS_OWN.RISK_MEASURES_TO_APP " + updateQuery.Remove(updateQuery.LastIndexOf(",")).Replace("=", ":")
                         + string.Format(" where analytic_id_to_Stage : '{0}' and upper(trim(app_name)) : '{1}' and upper(trim(app_field)) : '{2}'"
                         , riskMeasuresToAppData.analyticIdToStage, riskMeasuresToAppData.mainTable.ToUpper().Trim(), riskMeasuresToAppData.appField.ToUpper().Trim()) + " | ";


                        updateQuery = string.Format("Update SEC_ANALYTICS_OWN.RISK_MEASURES_TO_APP set ") + updateQuery.Remove(updateQuery.LastIndexOf(","))
                            + string.Format(" where analytic_id_to_Stage = '{0}' and upper(trim(app_name)) = '{1}' and upper(trim(app_field)) = '{2}'"
                            , riskMeasuresToAppData.analyticIdToStage, riskMeasuresToAppData.mainTable.ToUpper().Trim(), riskMeasuresToAppData.appField.ToUpper().Trim());
                        dbHelper.ExecuteNonQuery(updateQuery);
                    }
                }
                else
                {
                    if (!string.IsNullOrEmpty(data.previousAnayticId))
                    {
                        RemoveOldLabelEntry(data.previousAnayticId, "SEC_ANALYTICS_OWN.RISK_MEASURES_TO_APP", "ANALYTIC_ID_TO_STAGE");
                    }
                    string isApplicable = riskMeasuresToAppData.isApplicable ? "Y" : "N";
                    QueryLog += "I SEC_ANALYTICS_OWN.RISK_MEASURES_TO_APP APP_NAME : " + riskMeasuresToAppData.mainTable + " , APP_FIELD : " + riskMeasuresToAppData.appField + " , ANALYTIC_ID_TO_STAGE : " + riskMeasuresToAppData.analyticIdToStage + " , DATATYPE : " + riskMeasuresToAppData.dataType + " , DESCRIPTION : " + riskMeasuresToAppData.description +
                        ", IS_APPLICABLE : " + isApplicable + " , MODEL_SRM_DIFF_THRESHOLD : " + riskMeasuresToAppData.modelSrmDiffThreshold + " | ";
                    var insertQuery = string.Format(@"Insert into SEC_ANALYTICS_OWN.RISK_MEASURES_TO_APP (APP_NAME, APP_FIELD, ANALYTIC_ID_TO_STAGE, DATATYPE, DESCRIPTION, IS_APPLICABLE, MODEL_SRM_DIFF_THRESHOLD) 
                                                    VALUES('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', {6})"
                                        , riskMeasuresToAppData.mainTable, riskMeasuresToAppData.appField, riskMeasuresToAppData.analyticIdToStage
                                        , riskMeasuresToAppData.dataType, riskMeasuresToAppData.description, isApplicable, riskMeasuresToAppData.modelSrmDiffThreshold);
                    dbHelper.ExecuteNonQuery(insertQuery);
                }
            }
            if (inputData != null)
            {
                foreach (var inputRiskMeasuresToAppData in inputData.riskMeasuresToAppList)
                {
                    var riskMeasuresToAppData = data.riskMeasuresToAppList.Find(x =>
                            x.analyticIdToStage == inputRiskMeasuresToAppData.analyticIdToStage
                            && x.appField == inputRiskMeasuresToAppData.appField
                            && x.mainTable == inputRiskMeasuresToAppData.mainTable);
                    if (riskMeasuresToAppData == null)
                    {
                        QueryLog += "D SEC_ANALYTICS_OWN.RISK_MEASURES_TO_APP where analytic_id_to_Stage : " + inputRiskMeasuresToAppData.analyticIdToStage + " and upper(trim(app_name)) : " + inputRiskMeasuresToAppData.mainTable.ToUpper().Trim() + " and upper(trim(app_field)) : " + inputRiskMeasuresToAppData.appField.ToUpper().Trim() + " | ";
                        var delete_query = string.Format("delete  from SEC_ANALYTICS_OWN.RISK_MEASURES_TO_APP where analytic_id_to_Stage = '{0}' and upper(trim(app_name)) = '{1}' and upper(trim(app_field)) = '{2}' "
                                                        , inputRiskMeasuresToAppData.analyticIdToStage, inputRiskMeasuresToAppData.mainTable.ToUpper().Trim(), inputRiskMeasuresToAppData.appField.ToUpper().Trim());
                        dbHelper.ExecuteNonQuery(delete_query);
                    }
                }
            }
        }

        private void updateRiskAuditMapping(DatabaseHelper dbHelper, AnalyticIdConfigBO.ConfigInputData data, AnalyticIdConfigBO.ConfigInputData inputData)
        {
            //Update risk_measures_to_app table
            Dictionary<string, string> mainTableAuditTableCache = new Dictionary<string, string>();
            var query = String.Format("select distinct upper(trim(main_table)), upper(trim(audit_table)) from SEC_ANALYTICS_OWN.RISK_AUDIT_MAPPING");
            var mainTableLiveTableData = dbHelper.ExecuteSelectQuery(query);
            foreach (var row in mainTableLiveTableData.rows)
            {
                mainTableAuditTableCache[row[0].ToString()] = row[1].ToString();
            }
            foreach (var riskMeasuresToAppData in data.riskMeasuresToAppList)
            {
                //check entry of live_table and main_table in risk_audit_mapping table
                if (!mainTableAuditTableCache.ContainsKey(riskMeasuresToAppData.mainTable))
                {
                    QueryLog += "I SEC_ANALYTICS_OWN.RISK_AUDIT_MAPPING MAIN_TABLE : " + riskMeasuresToAppData.mainTable + " , AUDIT_TABLE : " + riskMeasuresToAppData.liveTable + " | ";
                    var insertQuery = string.Format(@"Insert into SEC_ANALYTICS_OWN.RISK_AUDIT_MAPPING (MAIN_TABLE, AUDIT_TABLE) VALUES('{0}', '{1}')", riskMeasuresToAppData.mainTable, riskMeasuresToAppData.liveTable);
                    dbHelper.ExecuteNonQuery(insertQuery);
                }
            }
        }

        private void updateInvocationIdMetadata(DatabaseHelper dbHelper, AnalyticIdConfigBO.ConfigInputData data, AnalyticIdConfigBO.ConfigInputData inputData)
        {
            //Update invocation_metadata table
            foreach (var riskMeasuresToInvocation in data.riskMeasuresToInvocationList)
            {
                var inputRiskMeasuresToInvocation = inputData == null ? null : inputData.riskMeasuresToInvocationList.Find(x => x.analyticIdToStage == riskMeasuresToInvocation.analyticIdToStage);
                if (!string.IsNullOrEmpty(data.previousAnayticId))
                {
                    RemoveOldLabelEntry(data.previousAnayticId, "SEC_ANALYTICS_OWN.INVOCATION_METADATA", "ANALYTIC_ID");
                }
                if (inputRiskMeasuresToInvocation != null)
                {
                    foreach (var invocationId in riskMeasuresToInvocation.invocationList)
                    {
                        if (!inputRiskMeasuresToInvocation.invocationList.Contains(invocationId))
                        {
                            QueryLog += "I SEC_ANALYTICS_OWN.INVOCATION_METADATA ANALYTIC_ID : " + riskMeasuresToInvocation.analyticIdToStage + " , INVOCATION_ID : " + invocationId + " | ";
                            var insertQuery = string.Format("Insert into SEC_ANALYTICS_OWN.INVOCATION_METADATA (ANALYTIC_ID, INVOCATION_ID) VALUES('{0}', '{1}')", riskMeasuresToInvocation.analyticIdToStage, invocationId);
                            dbHelper.ExecuteNonQuery(insertQuery);
                        }
                    }

                }
                else
                {
                    foreach (var invocationId in riskMeasuresToInvocation.invocationList)
                    {
                        QueryLog += "I SEC_ANALYTICS_OWN.INVOCATION_METADATA ANALYTIC_ID : " + riskMeasuresToInvocation.analyticIdToStage + " , INVOCATION_ID : " + invocationId + " | ";
                        var insertQuery = string.Format("Insert into SEC_ANALYTICS_OWN.INVOCATION_METADATA (ANALYTIC_ID, INVOCATION_ID) VALUES('{0}', '{1}')", riskMeasuresToInvocation.analyticIdToStage, invocationId);
                        dbHelper.ExecuteNonQuery(insertQuery);
                    }
                }
            }
            if (inputData != null)
            {
                foreach (var inputRiskMeasuresToInvocation in inputData.riskMeasuresToInvocationList)
                {
                    var riskMeasuresToInvocation = data.riskMeasuresToInvocationList.Find(x => x.analyticIdToStage == inputRiskMeasuresToInvocation.analyticIdToStage);
                    if (riskMeasuresToInvocation != null)
                    {
                        foreach (var invocationId in inputRiskMeasuresToInvocation.invocationList)
                        {
                            if (!riskMeasuresToInvocation.invocationList.Contains(invocationId))
                            {
                                QueryLog += "D  SEC_ANALYTICS_OWN.INVOCATION_METADATA where analytic_id : " + inputRiskMeasuresToInvocation.analyticIdToStage + " and invocation_id : " + invocationId + " | ";
                                var delete_query = string.Format("delete from SEC_ANALYTICS_OWN.INVOCATION_METADATA where analytic_id = '{0}' and invocation_id = '{1}'", inputRiskMeasuresToInvocation.analyticIdToStage, invocationId);
                                dbHelper.ExecuteNonQuery(delete_query);
                            }
                        }

                    }
                    else
                    {
                        QueryLog += "D  SEC_ANALYTICS_OWN.INVOCATION_METADATA where analytic_id : " + inputRiskMeasuresToInvocation.analyticIdToStage + " | ";
                        var delete_query = string.Format("delete from SEC_ANALYTICS_OWN.INVOCATION_METADATA where analytic_id = '{0}' ", inputRiskMeasuresToInvocation.analyticIdToStage);
                        dbHelper.ExecuteNonQuery(delete_query);
                    }
                }
            }
        }

        public override ResponseBO UpdateDB(RequestBO req)
        {
            Log.Debug("Enter");
            var retval = new AnalyticIdConfigBO.ConfigUpdateResponse();
            var dbHelper = this.OracleDbHelper;

            try
            {
                var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                var data = json.Deserialize<AnalyticIdConfigBO.ConfigInputData>(req.data.ToString());
                if (data == null)
                    throw new Exception("Failed in Json Deserialization");

                /*Process data */
                dbHelper.BeginTransaction();

                Log.Info(string.Format("Request by User: {0}, Processing {1}", User, data.analyticId));

                var auditId = LogActionToAudit(new OrderedDictionary() { { "analytic_id", data.analyticId }, { "model_field_name", data.modelFieldName } });

                try
                {
                    //First find data in database
                    AnalyticIdConfigBO.ConfigInputData inputData = null;
                    if (string.IsNullOrEmpty(data.previousAnayticId))
                    {
                        inputData = SearchAnalyticId(data.analyticId);
                    }

                    //compare data from database and cronus UI and update the database accordingly
                    updateAnalyticIdMetadata(dbHelper, data, inputData);
                    updateRiskMeasuresToApp(dbHelper, data, inputData);
                    updateRiskAuditMapping(dbHelper, data, inputData);
                    updateInvocationIdMetadata(dbHelper, data, inputData);

                    retval.message = "Data Save Successfully";
                }
                catch (Exception ex)
                {
                    Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                    dbHelper.Rollback();

                    LogActionToAudit(new OrderedDictionary() { { "Action", QueryLog }, { "status", "Fail" } }, auditId);
                    throw;
                }

                dbHelper.Commit();
                LogActionToAudit(new OrderedDictionary() { { "Action", QueryLog }, { "status", "Success" } }, auditId);
            }
            catch (Exception ex)
            {
                retval.errorMessage = string.Format("Exception: {0}", ex.Message);
                Log.Error(retval.errorMessage, ex);
            }
            finally
            {
                Log.Debug("Exit");
            }
            return retval;
        }

        private AnalyticIdConfigBO.ConfigInputData SearchAnalyticId(string analyticId)
        {
            var dbHelper = this.OracleDbHelper;
            AnalyticIdConfigBO.ConfigInputData analytcIdData = null;

            //get all label columns
            //add _label info
            var whereClause = "";
            var labelQuery = String.Format(@"select * from SEC_ANALYTICS_OWN.ANALYTIC_ID_METADATA where 1 = 2");
            var queryResult = dbHelper.ExecuteSelectQuery(labelQuery);
            foreach (var columnName in queryResult.columns)
            {
                if (columnName.Contains("_LABEL"))
                {
                    whereClause += string.Format("OR {0} || ANALYTIC_ID = '{1}' ", columnName, analyticId);
                }
            }

            //Query data from analytic_id_metadata table
            var query = String.Format(@"select * from SEC_ANALYTICS_OWN.ANALYTIC_ID_METADATA where analytic_id = '{0}' {1}", analyticId, whereClause);
            var queryData = dbHelper.ExecuteSelectQuery(query);
            List<string> validAnalyticIds = new List<string>();
            if (queryData.rows.Count != 0)
            {
                analytcIdData = new AnalyticIdConfigBO.ConfigInputData();
                analytcIdData.analyticId = queryData.rows[0][queryData.columns.IndexOf("ANALYTIC_ID")].ToString().Trim();
                analytcIdData.modelFieldName = queryData.rows[0][queryData.columns.IndexOf("MODEL_FIELD_NAME")].ToString().Trim();
                analytcIdData.dataType = queryData.rows[0][queryData.columns.IndexOf("DATATYPE")].ToString().Trim().ToUpper();
                analytcIdData.description = queryData.rows[0][queryData.columns.IndexOf("DESCRIPTION")].ToString().Trim();
                /* analytcIdData.providerId = queryData.rows[0][queryData.columns.IndexOf("PROVIDER_ID")].ToString().Trim();
                 analytcIdData.curveType = queryData.rows[0][queryData.columns.IndexOf("CURVE_TYPE")].ToString().Trim();
                 analytcIdData.curveId = queryData.rows[0][queryData.columns.IndexOf("CURVE_ID")].ToString().Trim();
                 analytcIdData.product = queryData.rows[0][queryData.columns.IndexOf("PRODUCT")].ToString().Trim();
                 analytcIdData.modelOutputType = queryData.rows[0][queryData.columns.IndexOf("MODEL_OUTPUT_TYPE")].ToString().Trim();
                 analytcIdData.scenarioConfigFile = queryData.rows[0][queryData.columns.IndexOf("SCENARIO_CONFIG_FILE")].ToString().Trim();
                 analytcIdData.sensitivityConfigFile = queryData.rows[0][queryData.columns.IndexOf("SENSITIVITY_CONFIG_FILE")].ToString().Trim();
                 */
                validAnalyticIds.Add(analytcIdData.analyticId);

                //add _label info
                analytcIdData.lableList = new List<string>();
                foreach (var columnName in queryData.columns)
                {
                    if (columnName.Contains("_LABEL") && !string.IsNullOrWhiteSpace(queryData.rows[0][queryData.columns.IndexOf(columnName)].ToString()))
                    {
                        analytcIdData.lableList.Add(columnName);

                        validAnalyticIds.Add(queryData.rows[0][queryData.columns.IndexOf(columnName)].ToString().Trim() + analytcIdData.analyticId);
                    }
                }


                //Get data form risk_measures_to_app and risk_audit_mapping
                query = String.Format(@"select ANALYTIC_ID_TO_STAGE, APP_NAME, APP_FIELD, DATATYPE, MODEL_SRM_DIFF_THRESHOLD, IS_APPLICABLE, DESCRIPTION, AUDIT_TABLE
                                            from SEC_ANALYTICS_OWN.RISK_MEASURES_TO_APP a LEFT JOIN SEC_ANALYTICS_OWN.RISK_AUDIT_MAPPING b on upper(trim(a.app_name)) = upper(trim(b.main_table)) 
                                            where analytic_id_to_Stage in({0})", string.Join(",", validAnalyticIds.Select(s => "'" + s.Trim() + "'")));
                queryData = dbHelper.ExecuteSelectQuery(query);

                analytcIdData.riskMeasuresToAppList = new List<AnalyticIdConfigBO.RiskMeasuresToApp>();
                foreach (var row in queryData.rows)
                {
                    AnalyticIdConfigBO.RiskMeasuresToApp riskMeasuresToAppData = new AnalyticIdConfigBO.RiskMeasuresToApp();
                    riskMeasuresToAppData.analyticIdToStage = row[queryData.columns.IndexOf("ANALYTIC_ID_TO_STAGE")].ToString().Trim();
                    riskMeasuresToAppData.mainTable = row[queryData.columns.IndexOf("APP_NAME")].ToString().Trim().ToUpper();
                    riskMeasuresToAppData.liveTable = row[queryData.columns.IndexOf("AUDIT_TABLE")].ToString().Trim().ToUpper();
                    riskMeasuresToAppData.appField = row[queryData.columns.IndexOf("APP_FIELD")].ToString().Trim().ToUpper();
                    riskMeasuresToAppData.dataType = row[queryData.columns.IndexOf("DATATYPE")].ToString().Trim().ToUpper();
                    if (!string.IsNullOrWhiteSpace(row[queryData.columns.IndexOf("MODEL_SRM_DIFF_THRESHOLD")].ToString()))
                        riskMeasuresToAppData.modelSrmDiffThreshold = Convert.ToDouble(row[queryData.columns.IndexOf("MODEL_SRM_DIFF_THRESHOLD")]);
                    riskMeasuresToAppData.isApplicable = row[queryData.columns.IndexOf("IS_APPLICABLE")].ToString().Trim().ToUpper() == "Y";
                    riskMeasuresToAppData.description = row[queryData.columns.IndexOf("DESCRIPTION")].ToString().Trim();
                    analytcIdData.riskMeasuresToAppList.Add(riskMeasuresToAppData);
                }

                //Get data form invocation_metadata
                query = String.Format(@"select ANALYTIC_ID, INVOCATION_ID
                                from SEC_ANALYTICS_OWN.INVOCATION_METADATA 
                                where analytic_id in ({0}) order by 1", string.Join(",", validAnalyticIds.Select(s => "'" + s.Trim() + "'")));
                queryData = dbHelper.ExecuteSelectQuery(query);

                analytcIdData.riskMeasuresToInvocationList = new List<AnalyticIdConfigBO.RiskMeasuresToInvocation>();
                AnalyticIdConfigBO.RiskMeasuresToInvocation invocationMetadata = null;
                foreach (var row in queryData.rows)
                {
                    var analyticIdToStage = row[queryData.columns.IndexOf("ANALYTIC_ID")].ToString().Trim();
                    var invocationId = row[queryData.columns.IndexOf("INVOCATION_ID")].ToString().Trim();
                    if (invocationMetadata == null || invocationMetadata.analyticIdToStage != analyticIdToStage)
                    {
                        if (invocationMetadata != null)
                            analytcIdData.riskMeasuresToInvocationList.Add(invocationMetadata);

                        invocationMetadata = new AnalyticIdConfigBO.RiskMeasuresToInvocation();
                        invocationMetadata.analyticIdToStage = analyticIdToStage;
                        invocationMetadata.invocationList = new List<string>();
                    }
                    invocationMetadata.invocationList.Add(row[queryData.columns.IndexOf("INVOCATION_ID")].ToString().Trim());
                }
                if (invocationMetadata != null)
                    analytcIdData.riskMeasuresToInvocationList.Add(invocationMetadata);
            }
            return analytcIdData;
        }

        public override ResponseBO CustomFunction(CustomFunctionBO req)
        {
            ResponseBO retval = new ResponseBO();
            try
            {
                var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                var data = json.Deserialize<AnalyticIdConfigBO.SearchRequestBO>(req.data.ToString());
                if (data == null)
                    throw new Exception("Failed in Json Deserialization");

                if (req.functionName == "GetCache")
                {
                    AnalyticIdConfigBO.CacheDataResponse cacheData = new AnalyticIdConfigBO.CacheDataResponse();
                    cacheData.data = GetCacheData(data.value);
                    retval = cacheData;
                }
                else if (req.functionName == "AnalyticIdSearch")
                {
                    AnalyticIdConfigBO.SearchResponseBO searchData = new AnalyticIdConfigBO.SearchResponseBO();
                    searchData.data = SearchAnalyticId(data.value);
                    retval = searchData;
                }

            }
            catch (Exception ex)
            {
                retval.errorMessage = string.Format("Exception: {0}", ex.Message);
                Log.Error(retval.errorMessage, ex);
            }
            finally
            {
                Log.Debug("Exit");
            }
            return retval;
        }

        private void RemoveOldLabelEntry(string previousAnayticId, string tableName, string columnName)
        {
            string labelstring = string.Empty;
            var dbHelper = this.OracleDbHelper;
            var delete_query = string.Empty;
            if (tableName == "SEC_ANALYTICS_OWN.ANALYTIC_ID_METADATA")
            {
                delete_query += string.Format("delete from {0} where {1} = '{2}' ", tableName, columnName, previousAnayticId);
                dbHelper.ExecuteNonQuery(delete_query);
            }
            else
            {
                string query = "select Value from cronus_own.CONFIG where screenid = 'Analytic Id Configuration' and key = 'LABEL'";
                var queryData = dbHelper.ExecuteSelectQuery(query);
                if (queryData != null)
                {
                    foreach (var label in queryData.rows)
                    {
                        delete_query += string.Format("delete from {0} where {1} = '{2}' ", tableName, columnName, label[0].ToString().Replace("label", previousAnayticId));
                        dbHelper.ExecuteNonQuery(delete_query);
                    }
                }
            }
        }
    }
}

