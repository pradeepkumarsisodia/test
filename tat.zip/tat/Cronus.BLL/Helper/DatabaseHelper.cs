﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using log4net;
using System.Data.Common;
using System.Data;
using Cronus.BO;
using Oracle.DataAccess.Client;
using Sybase.Data.AseClient;

namespace Cronus.Bll.Helper
{
    public class DatabaseHelper
    {
        public enum Database { ORACLE, SYBASE, UNKNOWN };

        protected string ConnectionStr;
        private static readonly Dictionary<string, TransactionQuery> TransactinDict = new Dictionary<string, TransactionQuery>();
        private static readonly Dictionary<string, DbConnection> DbConnectionDict = new Dictionary<string, DbConnection>();

        static int _queryTimeout = 10 * 60; // seconds
        static int _transactionTimeout = 30; // mins
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        protected Database DBType;
        DbCommand _cmd;
        readonly string _transKey;
        bool _CacheConnection = false;
        public string printOutput = "";
        static DatabaseHelper()
        {
            //this thread will rollback all the pending transaction which are not commited/rolledback from 10 mins
            var timeoutTransThread = new Thread(RollBackTimeOutTrans);
            timeoutTransThread.Start();
        }

        protected DatabaseHelper(string key)
        {
            _transKey = key;
            DBType = Database.UNKNOWN;
        }

        ~DatabaseHelper()
        {
            try
            {
                lock (DbConnectionDict)
                {
                    if (!DbConnectionDict.ContainsKey(_transKey))
                    {
                        if (_cmd != null && _cmd.Connection != null)
                        {
                            _cmd.Connection.Dispose();
                            //   _cmd.Connection.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Exception: {0}", ex.Message), ex);
            }
        }

        private static void RollBackTimeOutTrans()
        {
            try
            {
                //a infinite while loop which will rollack all the timeout transactions
                while (true)
                {
                    //first findout the timeout transction and put this in list
                    var timeoutTrans = new List<string>();
                    lock (TransactinDict)
                    {
                        foreach (var key in TransactinDict.Keys)
                        {
                            if (TransactinDict[key].TransStartTime.AddMinutes(_transactionTimeout) <= DateTime.Now)
                                timeoutTrans.Add(key);
                        }
                    }
                    //Rollback all timeout transactions and remove from dictionary.
                    foreach (var key in timeoutTrans)
                    {
                        DbTransaction trans = null;
                        lock (TransactinDict)
                        {
                            trans = TransactinDict[key].Transaction;
                        }
                        if (trans != null)
                        {
                            Log.InfoFormat("Force rollback for {0}", key);
                            trans.Rollback();
                        }
                        ClearCache(key);
                    }

                    //sleeping for 30 second
                    Thread.Sleep(30 * 1000);
                }
            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                throw;
            }
        }

        public void CacheConnection(bool shoudCache = false)
        {
            _CacheConnection = shoudCache;
        }

        protected virtual DbCommand GetDbComamnd()
        {
            return null;
        }

        protected virtual DbConnection GetDbConnectionFromCache()
        {
            DbConnection dbConnection = null;
            if (_CacheConnection)
            {
                lock (DbConnectionDict)
                {
                    if (DbConnectionDict.ContainsKey(_transKey))
                        dbConnection = DbConnectionDict[_transKey];
                    else
                    {
                        dbConnection = GetDbConnection();
                        dbConnection.Open();
                        DbConnectionDict[_transKey] = dbConnection;
                    }
                }
            }
            else
            {
                dbConnection = GetDbConnection();
                dbConnection.Open();
            }
            return dbConnection;
        }

        protected virtual DbConnection GetDbConnection()
        {
            return null;
        }

        protected virtual DbDataAdapter GetDbDataAdapter(DbCommand cmd)
        {
            return null;
        }

        protected virtual DbTransaction BeginTransaction(DbConnection conn)
        {
            return conn.BeginTransaction(IsolationLevel.ReadCommitted);
        }

        protected virtual DbTransaction GetTransaction()
        {
            DbTransaction dbTrans = null;
            lock (TransactinDict)
            {
                if (TransactinDict.ContainsKey(_transKey))
                    dbTrans = TransactinDict[_transKey].Transaction;
            }
            if (dbTrans != null && dbTrans.Connection != null)
            {
                lock (TransactinDict)
                {
                    TransactinDict[_transKey].TransStartTime = DateTime.Now;
                }
            }
            else
            {
                var transQuery = new TransactionQuery();
                transQuery.Transaction = GetDbConnectionFromCache().BeginTransaction(IsolationLevel.ReadCommitted);
                transQuery.TransStartTime = DateTime.Now;
                dbTrans = transQuery.Transaction;
                lock (TransactinDict)
                {
                    TransactinDict[_transKey] = transQuery;
                }
            }

            return dbTrans;
        }

        public Database GetDBType() { return DBType; }

        public void BeginTransaction()
        {
            _cmd = GetDbComamnd();
            _cmd.CommandTimeout = _queryTimeout;
            var trans = GetTransaction();
            _cmd.Transaction = trans;
            _cmd.Connection = trans.Connection;
        }

        protected virtual void SetParameters(DbCommand cmd, Dictionary<string, KeyValuePair<object, object>> inParamsList = null,
            Dictionary<string, KeyValuePair<object, object>> outParamsList = null)
        {
            if (inParamsList != null)
            {
                foreach (var name in inParamsList.Keys)
                {
                    var param = cmd.CreateParameter();
                    param.ParameterName = name;
                    param.DbType = (DbType) inParamsList[name].Key;
                    param.Value = inParamsList[name].Value;
                    cmd.Parameters.Add(param);
                }
            }

            if (outParamsList != null)
            {
                foreach (var key in outParamsList.Keys)
                {
                    var param = cmd.CreateParameter();
                    param.ParameterName = key;
                    param.DbType = (DbType) outParamsList[key].Key;
                    param.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(param);
                }
            }
        }

        public void InitDbCommand()
        {
            if (_cmd == null)
            {
                _cmd = GetDbComamnd();
                _cmd.CommandTimeout = _queryTimeout;
                _cmd.Connection = GetDbConnectionFromCache();
            }
        }

        protected virtual int ExecuteDMLQuery(DbCommand cmd, Dictionary<string, KeyValuePair<object, object>> inParamsList = null,
            Dictionary<string, KeyValuePair<object, object>> outParamsList = null, long thresholdRowCount = 0)
        {
            return 0;
        }

        public int ExecuteDDLQuery(string query, Dictionary<string, KeyValuePair<object, object>> inParamsList = null,
            Dictionary<string, KeyValuePair<object, object>> outParamsList = null)
        {
            InitDbCommand();
            lock (TransactinDict)
            {
                if (TransactinDict.ContainsKey(_transKey))
                {
                    TransactinDict[_transKey].ActiveTransaction = true;
                    TransactinDict[_transKey].Command = _cmd;
                }
            }
            _cmd.CommandText = query;
            _cmd.Parameters.Clear();
            SetParameters(_cmd, inParamsList, outParamsList);

            Log.InfoFormat("Executing Query:- {0}", query);
            var retval = _cmd.ExecuteNonQuery();
            Log.InfoFormat("Rows affected: {0}", retval);
            if (outParamsList != null)
            {
                foreach (DbParameter key in _cmd.Parameters)
                {
                    if (key.Direction == ParameterDirection.Output || key.Direction == ParameterDirection.InputOutput)
                    {
                        var value = new KeyValuePair<object, object>(key.DbType, key.Value);
                        outParamsList[key.ParameterName] = value;
                    }
                }
            }
            lock (TransactinDict)
            {
                if (TransactinDict.ContainsKey(_transKey))
                    TransactinDict[_transKey].Command = null;
            }

            return retval;
        }

        public int ExecuteNonQuery(string query, Dictionary<string, object> columnsDataMap)
        {
            InitDbCommand();
            _cmd.CommandText = query;
            _cmd.Parameters.Clear();
            Log.InfoFormat("Executing Query:- {0}", query);
            foreach (var columnName in columnsDataMap)
            {
                var param = _cmd.CreateParameter();
                param.ParameterName = columnName.Key;
                param.Value = columnName.Value;
                _cmd.Parameters.Add(param);
                Log.InfoFormat("Parameter:- {0} : {1}", columnName.Key, columnName.Value);
            }
                        
            var retval = _cmd.ExecuteNonQuery();
            Log.InfoFormat("Rows affected: {0}", retval);
            return retval;
        }

        public int ExecuteNonQuery(string query, Dictionary<string, KeyValuePair<object, object>> inParamsList = null,
            Dictionary<string, KeyValuePair<object, object>> outParamsList = null, long thresholdRowCount = 0)
        {
            InitDbCommand();
            lock (TransactinDict)
            {
                if (TransactinDict.ContainsKey(_transKey))
                {
                    TransactinDict[_transKey].ActiveTransaction = true;
                    TransactinDict[_transKey].Command = _cmd;
                }
            }
            _cmd.CommandText = query;
            _cmd.Parameters.Clear();

            Log.InfoFormat("Executing Query:- {0}", query);
            var retval = ExecuteDMLQuery(_cmd, inParamsList, outParamsList, thresholdRowCount);
            Log.InfoFormat("Rows affected: {0}", retval);
            if (outParamsList != null)
            {
                foreach (DbParameter key in _cmd.Parameters)
                {
                    if (key.Direction == ParameterDirection.Output || key.Direction == ParameterDirection.InputOutput)
                    {
                        var value = new KeyValuePair<object, object>(key.DbType, key.Value);
                        outParamsList[key.ParameterName] = value;
                    }
                }
            }
            lock (TransactinDict)
            {
                if (TransactinDict.ContainsKey(_transKey))
                    TransactinDict[_transKey].Command = null;
            }
            return retval;
        }

        public bool IsActiveTransaction()
        {
            lock (TransactinDict)
            {
                return TransactinDict.ContainsKey(_transKey) && TransactinDict[_transKey].ActiveTransaction;
            }
        }

        protected virtual List<TableDataResponseBO> ExecuteProcedureInDB(string query, DbCommand cmd)
        {
            throw new NotImplementedException();
        }

        public virtual List<TableDataResponseBO> ExecuteProcedure(string query)
        {

            InitDbCommand();

            Log.InfoFormat("Executing Query:- {0}", query);
            List<TableDataResponseBO> retval = ExecuteProcedureInDB(query, _cmd);
            return retval;
        }

        public TableDataResponseBO ExecuteSelectQuery(string query, Dictionary<string, object> columnsDataMap, bool selectLimitedRows = false)
        {
            InitDbCommand();

            _cmd.CommandText = query;
            _cmd.Parameters.Clear();
            foreach (var columnName in columnsDataMap)
            {
                var param = _cmd.CreateParameter();
                param.ParameterName = columnName.Key;
                param.Value = columnName.Value;
                _cmd.Parameters.Add(param);
            }
            lock (TransactinDict)
            {
                if (TransactinDict.ContainsKey(_transKey))
                {
                    TransactinDict[_transKey].Command = _cmd;
                }
            }
            Log.InfoFormat("Executing Query:- {0}", query);
            var retval = ExecuteCommand(_cmd, selectLimitedRows);
            lock (TransactinDict)
            {
                if (TransactinDict.ContainsKey(_transKey))
                {
                    TransactinDict[_transKey].Command = null;
                }
            }

            return retval;

        }

        public TableDataResponseBO ExecuteSelectQuery(string query, bool selectLimitedRows = false)
        {
            InitDbCommand();

            _cmd.CommandText = query;

            lock (TransactinDict)
            {
                if (TransactinDict.ContainsKey(_transKey))
                {
                    TransactinDict[_transKey].Command = _cmd;
                }
            }
            Log.InfoFormat("Executing Query:- {0}", query);
            _cmd.Parameters.Clear();
            var retval = ExecuteCommand(_cmd, selectLimitedRows);
            lock (TransactinDict)
            {
                if (TransactinDict.ContainsKey(_transKey))
                {
                    TransactinDict[_transKey].Command = null;
                }
            }

            return retval;
        }

        protected TableDataResponseBO ExecuteCommand(DbCommand cmd, bool selectLimitedRows)
        {

            var sData = new TableDataResponseBO() { columns = new List<string>() };
            var dtResult = new DataTable();
            var da = GetDbDataAdapter(cmd);

            if (selectLimitedRows)
                da.Fill(0, Constants.MaxSelectedRows, dtResult);
            else
                da.Fill(dtResult);

            //populate the columns
            foreach (DataColumn column in dtResult.Columns)
                sData.columns.Add(column.ColumnName);

            //populate the rows
            Log.InfoFormat("Rows Selected {0}", dtResult.Rows.Count);
            var noOfRows = dtResult.Rows.Count;

            sData.rows = new List<List<object>>();
            for (var i = 0; i < noOfRows; i++)
                sData.rows.Add(dtResult.Rows[i].ItemArray.ToList());
            return sData;
        }

        public static void ClearCache(string key)
        {
            Log.InfoFormat("Clear Cache for transkey {0}", key);

            lock (DbConnectionDict)
            {
                if (DbConnectionDict.ContainsKey(key))
                {
                    DbConnection connection = DbConnectionDict[key];
                    if (connection != null)
                        connection.Dispose();
                    DbConnectionDict.Remove(key);
                }
            }

            lock (TransactinDict)
            {
                if (TransactinDict.ContainsKey(key))
                    TransactinDict.Remove(key);
            }
        }

        public void CloseConnection()
        {
            ClearCache(_transKey);
        }

        public bool Commit()
        {
            Log.InfoFormat("Commit for transkey {0}", _transKey);
            DbTransaction dbTrans = null;
            lock (TransactinDict)
            {
                if (TransactinDict.ContainsKey(_transKey))
                    dbTrans = TransactinDict[_transKey].Transaction;
            }
            if (dbTrans != null)
                dbTrans.Commit();
            lock (TransactinDict)
            {
                if (TransactinDict.ContainsKey(_transKey))
                    TransactinDict.Remove(_transKey);
            }
            return true;
        }
        public bool Rollback()
        {
            Log.InfoFormat("Rollback for transkey {0}", _transKey);
            DbCommand dbCommand = null;
            DbTransaction dbTrans = null;
            lock (TransactinDict)
            {
                if (TransactinDict.ContainsKey(_transKey))
                {
                    dbCommand = TransactinDict[_transKey].Command;
                    dbTrans = TransactinDict[_transKey].Transaction;
                }
            }

            //cancl already running query if any
            if (dbCommand != null)
                dbCommand.Cancel();

            if (dbTrans != null)
                dbTrans.Rollback();
            lock (TransactinDict)
            {
                if (TransactinDict.ContainsKey(_transKey))
                    TransactinDict.Remove(_transKey);
            }
            return true;
        }
        public bool Cancel()
        {
            Log.InfoFormat("Cancel for transkey {0}", _transKey);
            DbCommand dbCommand = null;
            lock (TransactinDict)
            {
                if (TransactinDict.ContainsKey(_transKey))
                    dbCommand = TransactinDict[_transKey].Command;
            }
            if (dbCommand != null)
                dbCommand.Cancel();
            return true;
        }

        public virtual List<string> GetUniqueIndexColumns(string tableName)
        {
            return null;
        }
    }

    public class SybaseDatabaseHelper : DatabaseHelper
    {
        public SybaseDatabaseHelper(string connectionString, string key)
            : base(key + "_%_SYBASE")
        {
            ConnectionStr = connectionString;
            DBType = Database.SYBASE;
        }

        protected override DbCommand GetDbComamnd()
        {
            AseCommand retval = new AseCommand();
            return retval;
        }

        protected override DbTransaction BeginTransaction(DbConnection conn)
        {
            var aseConnection = conn as AseConnection;
            return aseConnection != null ? aseConnection.BeginTransaction(IsolationLevel.ReadCommitted) : null;
        }

        void SybaseDatabaseHelper_InfoMessage(object sender, AseInfoMessageEventArgs e)
        {
            if (!e.Message.StartsWith("Changed client character set setting to 'iso_1'."))
                printOutput += string.Format("{0} </br>", e.Message);
        }

        protected override DbConnection GetDbConnection()
        {
            AseConnection retval = new AseConnection(ConnectionStr);
            retval.InfoMessage += new AseInfoMessageEventHandler(SybaseDatabaseHelper_InfoMessage);


            return retval;
        }

        protected override DbDataAdapter GetDbDataAdapter(DbCommand cmd)
        {
            return new AseDataAdapter(cmd as AseCommand);
        }

        protected override int ExecuteDMLQuery(DbCommand cmd, Dictionary<string, KeyValuePair<object, object>> inParamsList = null,
            Dictionary<string, KeyValuePair<object, object>> outParamsList = null, long thresholdRowCount = 0)
        {
            SetParameters(cmd, inParamsList, outParamsList);
            //as ExecuteNonQuery return the rows affected include rows update by trigger as well so change the query so that we get rowcount afftected by query only
            cmd.CommandText = string.Format("set nocount on \n set rowcount {0} \n {1} \n select @@rowcount \n set rowcount 0", thresholdRowCount, cmd.CommandText);
            return (int)ExecuteCommand(cmd, false).rows[0][0];
        }

        protected override List<TableDataResponseBO> ExecuteProcedureInDB(string query, DbCommand cmd)
        {
            List<TableDataResponseBO> retval = new List<TableDataResponseBO>();
            try
            {
                //check status for proc not for anonymous proc
                if(query.ToLower().StartsWith("exec") || query.ToLower().StartsWith("execute"))
                    cmd.CommandText = string.Format("declare @proc_status int \n exec @proc_status = {0} \n select @proc_status ", query.Substring(query.IndexOf(' ')));
                else
                   cmd.CommandText = query;
                AseDataAdapter da = (AseDataAdapter)GetDbDataAdapter(cmd);
                da.RowUpdated += new AseRowUpdatedEventHandler(da_RowUpdated);

                DbDataReader dbReader = cmd.ExecuteReader();
                int proc_status = 0;
                object firstValue = null;
                //Read the resultSet and get the value of last resultSet which will be the status of procedure

                do
                {
                    TableDataResponseBO sData = new TableDataResponseBO() { columns = new List<string>() };
                    bool firstRow = true;
                    while (dbReader.Read())
                    {
                        if (firstRow)
                        {
                            //populate the columns
                            for (int i = 0; i < dbReader.FieldCount; i++)
                                sData.columns.Add(dbReader.GetName(i));
                            //populate the rows
                            sData.rows = new List<List<object>>();
                            firstRow = false;
                        }
                        object[] row = new object[dbReader.FieldCount];
                        dbReader.GetValues(row);
                        sData.rows.Add(row.ToList<object>());

                        if (sData.rows.Count > 0 && sData.rows[0].Count > 0)
                        {
                            firstValue = sData.rows[0][0];
                        }
                    }
                    retval.Add(sData);
                } while (dbReader.NextResult());

                //anonymous proc does not return any value
                if (firstValue != null && (query.ToLower().StartsWith("exec") || query.ToLower().StartsWith("execute")))
                {
                    //if the status of procedure is not 0 throw exception.
                    proc_status = (int)firstValue;
                    if (proc_status != 0)
                    {
                        throw new Exception(string.Format("Procedure Exit with status {0} </br> {1}", proc_status, printOutput));
                    }
                    //Remove the last select result
                    retval.RemoveAt(retval.Count - 1);
                }
            }
            catch (AseException aseEx)
            {
                string errorMessage = "";

                int errorCount = 1;

                foreach (AseError error in aseEx.Errors)
                {
                    errorMessage += string.Format("({0}) {1} at line number \"{2}\" \n Exception - \"{3}\" \n", errorCount++, error.ProcName, error.LineNum, error.Message);
                }
                if (string.IsNullOrWhiteSpace(errorMessage))
                    errorMessage = string.Format("{0}", aseEx.Message);
                throw new Exception(string.Format("Exception: {0}", errorMessage));
            }
            return retval;
        }

        void da_RowUpdated(object sender, AseRowUpdatedEventArgs e)
        {
            int x = e.RecordsAffected;
        }
        public override List<string> GetUniqueIndexColumns(string tableName)
        {
            var columnList = new List<string>();

            var splitTableName = tableName.Split('.').ToList();
            if (splitTableName.Count <= 1)
                throw new Exception(string.Format("Schema name missing from table {0}", tableName));
            var schemaName = splitTableName[0];
            var table = splitTableName[splitTableName.Count - 1];

            //status & 2 <> 0 --> For unique index
            //status & 2048 <> 0 --> For primary key
            //status & 4096 <> 0 --> For unique key
            var query = string.Format(@"select index_col('{0}..' + a.name, b.indid,1),
                                                case when b.keycnt > 1  then index_col(a.name, b.indid,2 ) else null end,
                                                case when b.keycnt > 2  then index_col(a.name, b.indid,3 ) else null end,
                                                case when b.keycnt > 3  then index_col(a.name, b.indid,4 ) else null end,
                                                case when b.keycnt > 4  then index_col(a.name, b.indid,5 ) else null end,
                                                case when b.keycnt > 5  then index_col(a.name, b.indid,6 ) else null end,
                                                case when b.keycnt > 6  then index_col(a.name, b.indid,7 ) else null end,
                                                case when b.keycnt > 7  then index_col(a.name, b.indid,8 ) else null end,
                                                case when b.keycnt > 8  then index_col(a.name, b.indid,9 ) else null end,
                                                case when b.keycnt > 9  then index_col(a.name, b.indid,10) else null end,
                                                case when b.keycnt > 10 then index_col(a.name, b.indid,11) else null end,
                                                case when b.keycnt > 11 then index_col(a.name, b.indid,12) else null end,
                                                case when b.keycnt > 12 then index_col(a.name, b.indid,13) else null end,
                                                case when b.keycnt > 13 then index_col(a.name, b.indid,14) else null end,
                                                case when b.keycnt > 14 then index_col(a.name, b.indid,15) else null end
                                            from {0}..sysobjects a join {0}..sysindexes b on a.id = b.id 
                                            where type = 'U' and b.indid > 0 and a.name = '{1}' 
                                                and (status & 2 <> 0 or status & 2048 <> 0 or status & 4096 <> 0)"
                , schemaName, table);

            var data = ExecuteSelectQuery(query);
            foreach (var row in data.rows)
                foreach (var value in row)
                    if (!string.IsNullOrWhiteSpace(value.ToString()))
                        columnList.Add(value.ToString());
            return columnList;
        }

    }

    public class OracleDatabaseHelper : DatabaseHelper
    {
        public OracleDatabaseHelper(string connectionString, string key)
            : base(key + "_%_ORACLE")
        {
            ConnectionStr = connectionString;
            DBType = Database.ORACLE;
        }

        protected override DbCommand GetDbComamnd()
        {
            return new OracleCommand();
        }
        protected override DbTransaction BeginTransaction(DbConnection conn)
        {
            var oracleConnection = conn as OracleConnection;
            return oracleConnection != null ? oracleConnection.BeginTransaction(IsolationLevel.ReadCommitted) : null;
        }

        protected override DbConnection GetDbConnection()
        {
            return new OracleConnection(ConnectionStr);
        }

        protected override DbDataAdapter GetDbDataAdapter(DbCommand cmd)
        {
            return new OracleDataAdapter(cmd as OracleCommand);
        }

        protected override List<TableDataResponseBO> ExecuteProcedureInDB(string query, DbCommand cmd)
        {
            //check status for proc not for anonymous proc
            if (query.ToLower().StartsWith("exec") || query.ToLower().StartsWith("execute"))
                cmd.CommandText = "begin " + query.Substring(query.IndexOf(' ')) + "; end;";
            else 
                cmd.CommandText = query;

            cmd.ExecuteNonQuery();
            return new List<TableDataResponseBO>();
        }

        protected override int ExecuteDMLQuery(DbCommand cmd, Dictionary<string, KeyValuePair<object, object>> inParamsList = null,
            Dictionary<string, KeyValuePair<object, object>> outParamsList = null, long thresholdRowCount = 0)
        {
            string rowcount = ":num";
            //change the command text as executenonquery return -1 from merge query;
            cmd.CommandText = string.Format("begin {0}\n; :num := sql%ROWCOUNT; end;", cmd.CommandText, rowcount);

            if (outParamsList == null) outParamsList = new Dictionary<string, KeyValuePair<object, object>>();
            outParamsList[":num"] = new KeyValuePair<object, object>(OracleDbType.Int64, null);
            SetParameters(cmd, inParamsList, outParamsList);
            cmd.ExecuteNonQuery();

            return Convert.ToInt32(((Oracle.DataAccess.Types.OracleDecimal)(((Oracle.DataAccess.Client.OracleParameterCollection)(cmd.Parameters))[rowcount].Value)).Value);
        }

        protected override void SetParameters(DbCommand cmd, Dictionary<string, KeyValuePair<object, object>> inParamsList = null,
            Dictionary<string, KeyValuePair<object, object>> outParamsList = null)
        {
            if (inParamsList != null)
            {
                foreach (var name in inParamsList.Keys)
                {
                    OracleParameter inputParam = new OracleParameter(name, (OracleDbType) inParamsList[name].Key,ParameterDirection.Input);
                    inputParam.Value = inParamsList[name].Value;
                    cmd.Parameters.Add(inputParam); 
                }
            }

            if (outParamsList != null)
            {
                foreach (var name in outParamsList.Keys)
                {
                    cmd.Parameters.Add(new OracleParameter(name, (OracleDbType) outParamsList[name].Key, ParameterDirection.Output)); 
                }
            }
        }
        public override List<string> GetUniqueIndexColumns(string tableName)
        {
            var splitTableName = tableName.Split('.').ToList();
            if (splitTableName.Count <= 1)
                throw new Exception(string.Format("Schema name missing from table {0}", tableName));
            var schemaName = splitTableName[0];
            var table = splitTableName[splitTableName.Count - 1];

            var query = string.Format(@"SELECT b.COLUMN_NAME FROM ALL_INDEXES a JOIN ALL_IND_COLUMNS b on a.OWNER = b.TABLE_OWNER and a.INDEX_NAME = b.INDEX_NAME
                                        WHERE a.TABLE_OWNER = '{0}' and a.TABLE_NAME = '{1}' and a.UNIQUENESS = 'UNIQUE' and INDEX_TYPE = 'NORMAL'"
                , schemaName.ToUpper(), table.ToUpper());

            var data = ExecuteSelectQuery(query);
            var columnList = data.rows.Select(row => row[0].ToString()).ToList();
            columnList = columnList.Distinct().ToList();
            return columnList;
        }
    }
}
