﻿using log4net;
using System;

namespace Cronus.Bll.Helper
{
    public class ConfigHelper
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public static class Env
        {
            public static string Prod = "prod";
            public static string Delta = "delta";
            public static string Delta2 = "delta2";
            public static string Beta = "beta";
            public static string Dev = "dev";
            public static string Localhost = "localhost";

        }

        public string Url { get; set; }

        public ConfigHelper(string url)
        {
            Url = url;
        }

        public string GetEnv()
        {
            return System.Configuration.ConfigurationManager.AppSettings[Url].ToUpper();
        }

        public string GetJiraUrl()
        {
            return System.Configuration.ConfigurationManager.AppSettings["jira_URL"];
        }

        public string GetJiraUser()
        {
            return System.Configuration.ConfigurationManager.AppSettings["jira_USER"];
        }

        public string GetJiraPswd()
        {
            return AES.Decrypt(System.Configuration.ConfigurationManager.AppSettings["jira_PSWD"], "CRONUS");
        }

        public string GetConnectionStr(string db)
        {
            var connectionString = System.Configuration.ConfigurationManager.ConnectionStrings[db].ConnectionString;
            if (connectionString == null)
                throw new Exception(string.Format("Connection String missing for {0}", db));

            var user = System.Configuration.ConfigurationManager.AppSettings[db + "_USER"];
            if (user == null)
                throw new Exception(string.Format("Key missing for {0}_USER", db));

            var pswd = System.Configuration.ConfigurationManager.AppSettings[db + "_PSWD"];
            if (pswd == null)
                throw new Exception(string.Format("Key missing for {0}_PSWD", db));

            return string.Format(connectionString, user, AES.Decrypt(pswd, "CRONUS"), Url, Url, Url);
        }

        public string GetConnectionStr(string connectionString, string user, string pswd, bool pswdEncripted)
        {
            if (pswdEncripted)
                return string.Format(connectionString, user, AES.Decrypt(pswd, "CRONUS"), Url, Url, Url);
            else
                return string.Format(connectionString, user, pswd, Url, Url, Url);
        }

        public string GetSybaseConnectionStr()
        {
            string db = System.Configuration.ConfigurationManager.AppSettings["SYBDB"];

            return GetConnectionStr(db);
        }

        public string GetSybaseConnectionStr(string runOnEnviroment)
        {
            string db = System.Configuration.ConfigurationManager.AppSettings["SYBDB_" + runOnEnviroment];

            return GetConnectionStr(db);
        }

        public string GetOracleConnectionStr()
        {
            string db = System.Configuration.ConfigurationManager.AppSettings["ORADB"];

            return GetConnectionStr(db);
        }
        
        public string GetOracleConnectionStr(string runOnEnviroment)
        {
            string db = System.Configuration.ConfigurationManager.AppSettings["ORADB_" + runOnEnviroment];

            return GetConnectionStr(db);
        }

        public string GetSendEmailFrom()
        {
            var sendFrom = System.Configuration.ConfigurationManager.AppSettings["SendFrom"];
            return sendFrom;
        }

        public string GetSendEmailTo(string key)
        {
            var sendTo = System.Configuration.ConfigurationManager.AppSettings[key];
            Log.InfoFormat("Url : {0} SendTo : {1}", Url, sendTo);
            return sendTo;
        }
    }
}
