﻿using System;
using System.Linq;
using log4net;

namespace Cronus.Bll.Helper
{
    public class Compliance
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        
        static public bool IsActionAllowed(string user, string screenName, string actionName, string url, string runOnEnviroment)
        {
            try
            {
                var configManager = new ConfigHelper(url);
                string db = configManager.GetOracleConnectionStr(runOnEnviroment);
                var _oracleDbHelper = new OracleDatabaseHelper(db, string.Format("{0}_%_{1}_%_{2}", user, "Compliance", Guid.NewGuid()));
                string query = string.Format("select IS_ACTIVE  from  CRONUS_OWN.GROUP_ACTION_PERMISSION where Group_ID in (select Distinct GROUP_ID from CRONUS_OWN.USER_GROUP where UPPER(USER_ID) = '{0}' and IS_ACTIVE = 'Y') and ACTION_ID = (select ACTION_ID from CRONUS_OWN.ACTION where UPPER(ACTION_NAME) = '{1}' and (SCREEN_ID) = '{2}')  and IS_ACTIVE = 'Y' and rownum <= 1 ", user.ToUpper(), actionName.ToUpper(), screenName.ToUpper());
                var data = _oracleDbHelper.ExecuteSelectQuery(query);
                if (data != null && data.rows.Count > 0)
                {
                    var isActive = Convert.ToString(data.rows[0][0]);
                    return isActive == "Y";
                }

            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                throw;
            }
            return false;
        }
    }
}
