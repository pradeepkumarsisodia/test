﻿using Cronus.Bo.Admin;
using Cronus.BO;
using log4net;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;

namespace Cronus.Bll.Helper
{
    public class Utility
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private static Dictionary<string, List<ACTION_BO>> userEntillementData = new Dictionary<string, List<ACTION_BO>>();

        public static ResponseBO FetchActionsForUser(string userId, string url, string runEnviroment)
        {
            Log.Debug("Enter");
            var retVal = new ActionPermittedResponseBO() { actionPermittedList = new List<ACTION_BO>() };

            try
            {
               
                if (userEntillementData.ContainsKey(userId))
                    userEntillementData.Remove(userId);

                var IsEnableEntitlement = Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings["IsEntitlementEnable"]);
                if (IsEnableEntitlement == true)
                {
                    retVal.actionPermittedList = FetchActionsForUserFromEntitlement(userId);


                }
                else
                {
                    retVal.actionPermittedList = FetchActionsForUserFromCronusDb(userId, url, runEnviroment);
                }
            }
            catch (Exception ex)
            {
                Log.Error("Exception : " + ex.Message, ex);
                retVal.errorMessage = ex.Message;
            }
            finally
            {
                Log.Debug("Exit");
            }
            return retVal;
        }

        public static List<ACTION_BO> FetchActionsForUserFromCronusDb(string userId, string url, string runEnviroment)
        {
            Log.Debug("Enter");
            List<ACTION_BO> actionslist = new List<ACTION_BO>();
            try
            {
                var configManager = new ConfigHelper(url);
                var _oracleDbHelper = new OracleDatabaseHelper(configManager.GetOracleConnectionStr(runEnviroment), string.Format("{0}_%_{1}_%_{2}", userId, "Common", Guid.NewGuid()));

                var actionQuery = string.Format("select  A.ACTION_ID, UPPER(A.ACTION_NAME) ACTION_NAME ,A.DESCRIPTION, UPPER( A.SCREEN_ID)SCREEN_ID from CRONUS_OWN.GROUP_ACTION_PERMISSION GAP inner join  CRONUS_OWN.ACTION A on GAP.ACTION_ID = A.ACTION_ID where GAP.IS_ACTIVE = 'Y' and GAP.GROUP_ID in(select distinct GROUP_ID from CRONUS_OWN.USER_GROUP  where USER_ID =  '{0}' and IS_ACTIVE = 'Y' ) order by SCREEN_ID", userId);
                var data = _oracleDbHelper.ExecuteSelectQuery(actionQuery);
                if (data != null && data.rows.Count > 0)
                {


                    foreach (var action in data.rows)
                    {
                        var objAction = new ACTION_BO();

                        objAction.ACTION_ID = Convert.ToInt64(action[0]);
                        objAction.ACTION_NAME = Convert.ToString(action[1]).ToUpperInvariant();
                        objAction.DESCRIPTION = Convert.ToString(action[2]);
                        objAction.SCREEN_ID = Convert.ToString(action[3]).ToUpperInvariant();
                        objAction.IS_PERMITTED = true;

                        actionslist.Add(objAction);

                    }
                    userEntillementData.Add(userId, actionslist);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                Log.Debug("Exit");
            }
            return actionslist;
        }

        public static List<ACTION_BO> FetchActionsForUserFromEntitlement(string userId)
        {
            List<ACTION_BO> actionslist = new List<ACTION_BO>();
            try
            {
                var url = System.Configuration.ConfigurationManager.AppSettings["EntitlementServerUrl"] + userId.ToLower();

                HttpWebRequest request = WebRequest.Create(url) as HttpWebRequest;
                request.ContentType = "application/json; charset=utf-8";
                request.Method = "GET";
                var data = string.Empty;
                var response = (HttpWebResponse)request.GetResponse();

                using (var sr = new StreamReader(response.GetResponseStream()))
                {
                    data = sr.ReadToEnd();
                }

                var entitlementServiceData = JsonConvert.DeserializeObject<EntitlementBO>(data);
                if (entitlementServiceData.user.roles.Count > 0 && entitlementServiceData.user.roles[0].permissions.Any())
                {
                    var entitlement = entitlementServiceData.user.roles[0].permissions.Where(t => t.permissionInd == "ALLOW");
                    foreach (var action in entitlement)
                    {
                        var objAction = new ACTION_BO();

                        objAction.ACTION_ID = Convert.ToInt64(action.permissionId);
                        objAction.ACTION_NAME = Convert.ToString(action.permissionName).Split('_')[1].ToUpperInvariant();
                        objAction.DESCRIPTION = string.Empty;
                        objAction.SCREEN_ID = Convert.ToString(action.permissionName).Split('_')[0].ToUpperInvariant();
                        objAction.IS_PERMITTED = true;

                        actionslist.Add(objAction);
                    }
                    userEntillementData.Add(userId, actionslist);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                Log.Debug("Exit");
            }
            return actionslist;
        }

        static public bool IsActionAllowed(string user, string screenName, string actionName, string url, string runOnEnviroment)
        {

            return true;
        }
    }
}
