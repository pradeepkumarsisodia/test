﻿using System;
using System.Data.Common;

namespace Cronus.Bll.Helper
{
    public class TransactionQuery
    {
        public int RowsAffectedCount { get; set; }
        public DbTransaction Transaction { get; set; }
        public DbCommand Command { get; set; }
        public DateTime TransStartTime { get; set; }
        public bool ActiveTransaction = false;
    }

    public class AseTransactionQuery : TransactionQuery
    {
        public long AuditTrailId { get; set; }
        public Sybase.Data.AseClient.AseTransaction AseTransaction { get; set; }
    }
    public class OracleTransactionQuery : TransactionQuery
    {
        public long AuditTrailId { get; set; }
        public Oracle.DataAccess.Client.OracleTransaction OracleTransaction { get; set; }
    }
}
