﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.IO;
using log4net;
using System.Reflection;
using Newtonsoft.Json.Linq;

namespace Cronus.Bll.Helper
{
    public class JiraHelper
    {
        public static class JiraStatus
        {
            public const string Open = "Open";
            public const string InProgress = "In Progress";
            public const string Approved = "Approved";
            public const string Invalid = "Invalid";
            public const string PendingApproval = "Pending Approval";
            public const string Closed = "Closed";
            public const string Reopen = "Reopen";
            public const string Rejected = "Rejected";
            public const string Executed = "Executed";
        }
        public static class JiraKeys
        {
            public const string Fields = "fields";
            public const string Id = "id";
            public const string Transitions = "transitions";
            public const string Transition = "transition";
            public const string Project = "project";
            public const string Key = "key";
            public const string Summary = "summary";
            public const string Description = "description";
            public const string IssueType = "issuetype";
            public const string Name = "name";
            public const string Update = "update";
            public const string Add = "add";
            public const string Remove = "remove";
            public const string Assignee = "assignee";
            public const string Value = "value";
            public const string Child = "child";
            public const string Body = "body";
            public const string Labels = "labels";
            public const string Comment = "comment";
            public const string Status = "status";
            public const string Components = "components";
            public const string RequestType = "customfield_13301";
            public const string TeamResponsible = "customfield_12701";
            public const string Customfield_13202 = "customfield_13202";

        }
        private static readonly ILog Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        public static string CreateJiraItem(string projectKey, string summary, string description, string issueType, string assignee, string component, List<string> labels, string requestType, string team, string teamResponsibile, string environment)
        {
            JObject obj = new JObject(
                                new JProperty(JiraKeys.Fields,
                                       new JObject(
                                           new JProperty(JiraKeys.Project,
                                               new JObject(
                                                   new JProperty(JiraKeys.Key, projectKey))),
                                            new JProperty(JiraKeys.Summary, summary),
                                            new JProperty(JiraKeys.Description, description),
                                            new JProperty(JiraKeys.IssueType,
                                                new JObject(
                                                    new JProperty(JiraKeys.Name, issueType))))));
            if (!string.IsNullOrWhiteSpace(requestType))
                obj[JiraKeys.Fields][JiraKeys.RequestType] = new JObject(new JProperty(JiraKeys.Value, requestType));
            if (!string.IsNullOrWhiteSpace(team))
            {
                obj[JiraKeys.Fields][JiraKeys.TeamResponsible] = new JObject(new JProperty(JiraKeys.Value, team));
                if (!string.IsNullOrWhiteSpace(teamResponsibile))
                    obj[JiraKeys.Fields][JiraKeys.TeamResponsible][JiraKeys.Child] = new JObject(new JProperty(JiraKeys.Value, teamResponsibile));
            }
            if (!string.IsNullOrWhiteSpace(environment))
                obj[JiraKeys.Fields][JiraKeys.Customfield_13202] = new JObject(new JProperty(JiraKeys.Value, environment));
            if (labels != null)
            {
                obj[JiraKeys.Fields][JiraKeys.Labels] = new JArray(labels.ToArray());
            }
            if (!string.IsNullOrWhiteSpace(component))
                obj[JiraKeys.Fields][JiraKeys.Components] = new JArray(new JObject(new JProperty(JiraKeys.Name, component)));
            
            string result = RunQuery(null, obj.ToString(), "POST");
            
            return result;
        }

        public static bool SaveJiraItem(string jiraNumber, string summary, string description, string assignee, string requestType, string team, string teamResponsibile)
        {
            JObject obj = new JObject(
                                new JProperty(JiraKeys.Fields,
                                       new JObject(
                                            new JProperty(JiraKeys.Summary, summary),
                                            new JProperty(JiraKeys.Description, description))));
            if (!string.IsNullOrWhiteSpace(requestType))
                obj[JiraKeys.Fields][JiraKeys.RequestType] = new JObject(new JProperty(JiraKeys.Value, requestType));
            if (!string.IsNullOrWhiteSpace(team))
            {
                obj[JiraKeys.Fields][JiraKeys.TeamResponsible] = new JObject(new JProperty(JiraKeys.Value, team));
                if (!string.IsNullOrWhiteSpace(teamResponsibile))
                    obj[JiraKeys.Fields][JiraKeys.TeamResponsible][JiraKeys.Child] = new JObject(new JProperty(JiraKeys.Value, teamResponsibile));
            }

            RunQuery(jiraNumber, obj.ToString(), "PUT");

            return true;
        }

        public static bool UpdateAssignee(string jiraNumber, string assignee)
        {
            try
            {
                JObject obj = new JObject(
                                new JProperty(JiraKeys.Fields,
                                       new JObject(
                                            new JProperty(JiraKeys.Assignee, 
                                                new JObject( 
                                                    new JProperty(JiraKeys.Name,  assignee))))));

                RunQuery(string.Format("{0}", jiraNumber), obj.ToString(), "PUT");
            }
            catch (Exception ex) 
            {
                Log.Error("Exception : " + ex.Message, ex);
                return false;
            }
            return true;
        }

        public static bool AddLabel(string jiraNumber, string label)
        {
            try
            {
                JObject obj = new JObject(
                                new JProperty(JiraKeys.Update,
                                       new JObject(
                                            new JProperty(JiraKeys.Labels,
                                                new JArray(
                                                    new JObject(
                                                        new JProperty(JiraKeys.Add, label)))))));

                RunQuery(string.Format("{0}", jiraNumber), obj.ToString(), "PUT");
            }
            catch (Exception ex) 
            {
                Log.Error("Exception : " + ex.Message, ex);
                return false;
            }
            return true;
        }

        public static bool ChangeStatus(string jiraNumber, string jiraStatus)
        {
            try
            {
                string retvalJson = RunQuery(string.Format("{0}/transitions", jiraNumber), null, "GET");

                var jiraTransStats = JObject.Parse(retvalJson);
                var transArray = (JArray)jiraTransStats[JiraKeys.Transitions];
                Int64 tranId = 0;
                for(int i = 0; i< transArray.Count; i++)
                {
                    if ((string)jiraTransStats[JiraKeys.Transitions][i][JiraKeys.Name] == jiraStatus)
                        tranId = Convert.ToInt64((string)jiraTransStats[JiraKeys.Transitions][i][JiraKeys.Id]);
                }
                JObject obj = new JObject(
                                new JProperty(JiraKeys.Transition,
                                    new JObject(
                                        new JProperty(JiraKeys.Id, tranId))));
                RunQuery(string.Format("{0}/transitions", jiraNumber), obj.ToString(), "POST");
            }
            catch (Exception ex)
            {
                Log.Error("Exception : " + ex.Message, ex);
                return false;
            }
            return true;
        }

        public static bool RemoveLabel(string jiraNumber, string label)
        {
            try
            {
                JObject obj = new JObject(
                                new JProperty(JiraKeys.Update,
                                   new JObject(
                                        new JProperty(JiraKeys.Labels,
                                            new JArray(
                                                new JObject(
                                                    new JProperty(JiraKeys.Remove, label)))))));

                RunQuery(string.Format("{0}", jiraNumber), obj.ToString(), "PUT");
            }
            catch (Exception ex)
            {
                Log.Error("Exception : " + ex.Message, ex);
                return false;
            }
            return true;
        }

        public static bool UpdateDesc(string jiraNumber, string desc)
        {
            try
            {
                JObject obj = new JObject(
                                new JProperty(JiraKeys.Fields,
                                   new JObject(
                                        new JProperty(JiraKeys.Description, desc))));
                RunQuery(string.Format("{0}", jiraNumber), obj.ToString(), "PUT");
            }
            catch (Exception ex)
            {
                Log.Error("Exception : " + ex.Message, ex);
                return false;
            }
            return true;
        }

        public static bool AddWatchers(string jiraNumber, string user)
        {
            string data = "\"" + user + "\"";
            RunQuery(string.Format("{0}/watchers", jiraNumber), data, "POST");

            return true;
        }

        public static bool AddComment(string jiraNumber, string comment)
        {
            try
            {
                JObject obj = new JObject(
                                new JProperty(JiraKeys.Update,
                                   new JObject(
                                        new JProperty(JiraKeys.Comment, 
                                            new JArray(
                                                new JObject(
                                                    new JProperty(JiraKeys.Add,
                                                        new JObject(
                                                            new JProperty(JiraKeys.Body,  comment.Replace("</br>", "\\n"))))))))));
                RunQuery(string.Format("{0}", jiraNumber), obj.ToString(), "PUT");
            }
            catch (Exception ex)
            {
                Log.Error("Exception : " + ex.Message, ex);
                return false;
            }

            return true;
        }

        public static string GetJiraItemDetail(string jiraNumber)
        {
            string result = RunQuery(jiraNumber);
            return result;
        }

        public static string GetStatus(string jiraNumber)
        {
            string status = "";
            try
            {
                string jiraDetail = GetJiraItemDetail(jiraNumber);
                var jiraItem = JObject.Parse(jiraDetail);
                if (jiraItem[JiraKeys.Fields][JiraKeys.Status].HasValues)
                    status = (string)jiraItem[JiraKeys.Fields][JiraKeys.Status][JiraKeys.Name];
            }
            catch (Exception ex)
            {
                Log.Error("Exception : " + ex.Message, ex);
            }
            return status;
        }
        
        public static string RunQuery(string argument = null, string data = null, string method = "GET")
        {
            ConfigHelper configHelper = new ConfigHelper("");
            string url = configHelper.GetJiraUrl();

            if (argument != null)
            {
                url = string.Format("{0}{1}/", url, argument);
            } 

            Log.InfoFormat("Jira Url: {0}, data {1}, method: {2}", url, data, method);

            HttpWebRequest request = WebRequest.Create(url) as HttpWebRequest;
            request.ContentType = "application/json";
            request.Method = method;

            if (data != null)
            {
                using (StreamWriter writer = new StreamWriter(request.GetRequestStream()))
                {
                    writer.Write(data);
                }
            }

            string base64Credentials = GetEncodedCredentials(configHelper.GetJiraUser(), configHelper.GetJiraPswd());
            request.Headers.Add("Authorization", "Basic " + base64Credentials);

            HttpWebResponse response = request.GetResponse() as HttpWebResponse;

            string result = string.Empty;
            using (StreamReader reader = new StreamReader(response.GetResponseStream()))
            {
                result = reader.ReadToEnd();
            }

            return result;
        }

        private static string GetEncodedCredentials(string user, string pswd)
        {
            string mergedCredentials = string.Format("{0}:{1}", user, pswd);
            byte[] byteCredentials = UTF8Encoding.UTF8.GetBytes(mergedCredentials);
            return Convert.ToBase64String(byteCredentials);
        }
    }
}
