﻿using System;
using System.Collections.Generic;
using Cronus.Bll.Fes;
using Cronus.Bll.TimeSeries;
using Cronus.Bll.Admin;
using log4net;
using Cronus.Bll.FesConfig;


namespace Cronus.Bll
{
    public class CronusBllFactory
    {
        readonly Dictionary<string, ICronusBaseBll> _dic = new Dictionary<string, ICronusBaseBll>();
        readonly List<ICronusBaseBll> _bllList = new List<ICronusBaseBll>();
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private CronusBllFactory()
        {
            RegisterBll();

            foreach (ICronusBaseBll bll in _bllList)
            {
                _dic[bll.ScreenName().ToUpper()] = bll;
            }
        }

        private void RegisterBll()
        {
            //Fes
            _bllList.Add(new QueryBuilder());
            _bllList.Add(new CreditEntityAttributes());
            _bllList.Add(new AgencyModelMap());
            _bllList.Add(new ImportToDatabase());
            _bllList.Add(new SubstituteCusips());
            _bllList.Add(new RejectedCusips());
            _bllList.Add(new RiskAttribution());
            _bllList.Add(new RiskMeasureOverride());
            _bllList.Add(new RiskMeasuresLive());
            _bllList.Add(new Regression());
            _bllList.Add(new SecAnalyticsOverride());
            _bllList.Add(new OttiRun());
            _bllList.Add(new StaleRiskMeasures());
            _bllList.Add(new SecurityStaleNotes());

            //Admin            
            _bllList.Add(new UserManagement());
            _bllList.Add(new Settings());
            _bllList.Add(new Dashboard());

            //Reporting
            _bllList.Add(new Reporting());
            _bllList.Add(new ModelSummaryReport());

            //TimeSeries            
            _bllList.Add(new TSDefintion());
            _bllList.Add(new ManageMasterTables());
            _bllList.Add(new BackFilling());

            //Fes Config
            _bllList.Add(new AnalyticIdConfig());
            //Query Executer
            _bllList.Add(new QueryExecuter());
            _bllList.Add(new DataManipulation());

        }
        
        public ICronusBaseBll GetBll(string screenName, string user, string url, string runOnEnviroment)
        {
            ICronusBaseBll ret = null;
            if (_dic.ContainsKey(screenName.ToUpper()))
            {
                ret = _dic[screenName.ToUpper()].Clone() as ICronusBaseBll;
                if (ret != null)
                {
                    ((CronusBaseBll)ret).User = user;
                    ((CronusBaseBll)ret).Url = url;
                    ((CronusBaseBll)ret).RunOnEnviroment = runOnEnviroment;
                }
                else
                    throw new Exception(string.Format("Object null for ScreeenName : {0}", screenName));
            }
            else
            {
                Log.ErrorFormat("Invalid ScreenName {0}", screenName);
                throw new Exception(string.Format("Invalid ScreenName {0}", screenName));
            }

            return ret;
        }

        private static CronusBllFactory _instance = new CronusBllFactory();

        public static CronusBllFactory GetInstance()
        {
            return _instance;
        }

    }
}
