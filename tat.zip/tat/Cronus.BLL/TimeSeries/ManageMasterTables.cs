﻿﻿using System;
﻿using Cronus.BO.TimeSeries;
using Cronus.BO;
using log4net;
﻿using System.Web.Script.Serialization;
using Cronus.Bll.Helper;
﻿using System.Collections.Specialized;

namespace Cronus.Bll.TimeSeries
{
    public class ManageMasterTables : CronusBaseBll
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public override string ScreenName() { return Constants.ManageMasterTables; }
        public override object Clone() { return new ManageMasterTables(); }

        protected override string GetTableQuery(TableDataRequestBO requestData, out DatabaseType dbType)
        {
            dbType = DatabaseType.ORACLE;

            //Permission Check
            if (!Compliance.IsActionAllowed(User, requestData.screenName, Constants.ManageMasterTablesView, Url,requestData.runEnviroment))
                throw new Exception("Permission denied");

            var tableName = requestData.tableName;
            string sql;
            switch (tableName)
            {
                case Constants.TSGroups:
                    sql = "SELECT ID,CLASS_ID,SUBCLASS_ID,Replace(Replace(QC,'>','&gt'),'<','&lt') QC,QC_SWITCH,STALE_SWITCH,Replace(Replace(QC_HIST,'>','&gt'),'<','&lt') QC_HIST FROM PROTEUS_OWN.TS_GROUPS";
                    break;
                case Constants.TSFrequency:
                    sql = "SELECT ID, DESCRIPTION,LAST_DATE_ADJ,DAY_TO_RUN,COMMENTS FROM PROTEUS_OWN.TS_FREQUENCY";
                    break;
                case Constants.TSGroupClass:
                    sql = "SELECT ID,CLASS FROM PROTEUS_OWN.TS_GROUP_CLASS";
                    break;
                case Constants.TSGroupSubclass:
                    sql = "select ID,SUBCLASS,PRIORITY from PROTEUS_OWN.ts_group_subclass";
                    break;
                case Constants.TSDefinitions:
                    //sql = "select  ID,GROUP_ID,SID,DESCRIPTION,FREQUENCY_ID,PARENT_ID,STRKEY1,STRKEY2,STRKEY3,STRKEY4,STRKEY5,NUMKEY1,NUMKEY2,NUMKEY3,NUMKEY4,NUMKEY5 from proteus_own.te_time_series_def";
                    sql = "select   ID,GROUP_ID,SID,DESCRIPTION,FREQUENCY_ID,PARENT_ID,STRKEY1,STRKEY2,STRKEY3,STRKEY4,STRKEY5,NUMKEY1, NUMKEY2,NUMKEY3,NUMKEY4,NUMKEY5 , (select case when count(*) = 1 then 1 else 0 end from  proteus_own.ts_def_relations b where b.def_id = a.id and a.numkey1 = b.parent_id) p_numkey1 , (select case when count(*) = 1 then 1 else 0 end from  proteus_own.ts_def_relations b where b.def_id = a.id and a.numkey2 = b.parent_id) as p_numkey2, (select case when count(*) = 1 then 1 else 0 end from  proteus_own.ts_def_relations b where b.def_id = a.id and a.numkey3 = b.parent_id) as p_numkey3, (select case when count(*) = 1 then 1 else 0 end from  proteus_own.ts_def_relations b where b.def_id = a.id and a.numkey4 = b.parent_id) as p_numkey4, (select case when count(*) = 1 then 1 else 0 end from  proteus_own.ts_def_relations b where b.def_id = a.id and a.numkey5 = b.parent_id) as p_numkey5 from proteus_own.te_time_series_def  a";
                    break;
                default:
                    throw new Exception(string.Format("Unknown tableName {0}", tableName));
            }

            return sql;
        }


        private static void ManageTS_FREQUENCY(DatabaseHelper dbHelper, ManageMasterTablesBO.FrequencyData data, string action)
        {
            string query;
            switch (action)
            {
                case "I":
                    query = string.Format("insert into proteus_own.ts_frequency(DESCRIPTION ,LAST_DATE_ADJ ,DAY_TO_RUN ,COMMENTS) values ('{0}', {1}, '{2}', '{3}')",
                        data.DESCRIPTION.Replace("'", "''"), data.LAST_DATE_ADJ, data.DAY_TO_RUN.Replace("'", "''"), data.COMMENTS.Replace("'", "''"));
                    break;
                case "U":
                    query = string.Format("update proteus_own.ts_frequency set DESCRIPTION = '{0}', LAST_DATE_ADJ = {1}, DAY_TO_RUN = '{2}', COMMENTS = '{3}' where ID = {4}",
                        data.DESCRIPTION.Replace("'", "''"), data.LAST_DATE_ADJ, data.DAY_TO_RUN.Replace("'", "''"), data.COMMENTS.Replace("'", "''"), data.ID);
                    break;
                default:
                    throw new Exception(string.Format("Unknown action {0}", action));
            }

            dbHelper.ExecuteNonQuery(query);
        }

        private void ManageTS_GROUPS(DatabaseHelper dbHelper, ManageMasterTablesBO.GROUPSData data, string action)
        {
            string query;

            switch (action)
            {
                case "I":
                    query = string.Format("insert into proteus_own.ts_groups(CLASS_ID ,SUBCLASS_ID ,QC ,QC_SWITCH, STALE_SWITCH, QC_HIST, LAST_CHG_USER) values ({0}, {1}, '{2}', '{3}', '{4}', '{5}', '{6}')",
                        data.CLASS_ID, data.SUBCLASS_ID, data.QC.Replace("'", "''").Replace("&lt", "<").Replace("&gt", ">"), data.QC_SWITCH, data.STALE_SWITCH, data.QC_HIST.Replace("'", "''").Replace("&lt", "<").Replace("&gt", ">"), User);
                    break;
                case "U":
                    query = string.Format("update proteus_own.ts_groups set CLASS_ID = {0}, SUBCLASS_ID ={1}, QC = '{2}', QC_SWITCH = '{3}', STALE_SWITCH='{4}', QC_HIST= '{5}', LAST_CHG_USER = '{6}' where ID = {7}",
                        data.CLASS_ID, data.SUBCLASS_ID, data.QC.Replace("'", "''").Replace("&lt", "<").Replace("&gt", ">"), data.QC_SWITCH, data.STALE_SWITCH, data.QC_HIST.Replace("'", "''"), User, data.ID);
                    break;
                default:
                    throw new Exception(string.Format("Unknown action {0}", action));
            }

            dbHelper.ExecuteNonQuery(query);
        }


        private static void ManageTS_GROUP_CLASS(DatabaseHelper dbHelper, ManageMasterTablesBO.GROUP_CLASSData data, string action)
        {
            string query;
            switch (action)
            {
                case "I":
                    query = string.Format("insert into proteus_own.ts_group_class(CLASS) values ('{0}')", data.CLASS.Replace("'", "''"));
                    break;
                case "U":
                    query = string.Format("update proteus_own.ts_group_class set CLASS = '{0}'  where ID = {1}", data.CLASS.Replace("'", "''"), data.ID);
                    break;
                default:
                    throw new Exception(string.Format("Unknown action {0}", action));
            }
            dbHelper.ExecuteNonQuery(query);
        }

        private static void ManageTS_GROUP_SUBCLASS(DatabaseHelper dbHelper, ManageMasterTablesBO.GROUP_SUBCLASSData data, string action)
        {
            string query;
            switch (action)
            {
                case "I":
                    query = string.Format("insert into proteus_own.ts_group_subclass(SUBCLASS ,PRIORITY) values ('{0}', {1})", data.SUBCLASS.Replace("'", "''"), data.PRIORITY);
                    break;
                case "U":
                    query = string.Format("update proteus_own.ts_group_subclass set SUBCLASS = '{0}' ,PRIORITY ={1} where ID = {2}", data.SUBCLASS.Replace("'", "''"), data.PRIORITY, data.ID);
                    break;
                default:
                    throw new Exception(string.Format("Unknown action {0}", action));
            }
            dbHelper.ExecuteNonQuery(query);
        }


        private static void ManageTS_DEFINITIONS(DatabaseHelper dbHelper, ManageMasterTablesBO.DEFINITIONSData data, string action)
        {
            string query;
            switch (action)
            {
                case "I":
                    query = "insert into PROTEUS_OWN.TE_TIME_SERIES_DEF (GROUP_ID,SID,DESCRIPTION,FREQUENCY_ID,PARENT_ID,STRKEY1,STRKEY2,STRKEY3,STRKEY4,STRKEY5,NUMKEY1,NUMKEY2,NUMKEY3,NUMKEY4,NUMKEY5)";
                    query += string.Format("values({0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14})",
                        data.GROUP_ID,
                        data.SID,
                        string.IsNullOrEmpty(data.DESCRIPTION) ? "NULL" : "'" + data.DESCRIPTION.Replace("'", "''").Trim() + "'",
                        data.FREQUENCY_ID,
                        string.IsNullOrEmpty(data.PARENT_ID) ? "NULL" : data.PARENT_ID.Trim(),
                        string.IsNullOrEmpty(data.STRKEY1) ? "NULL" : "'" + data.STRKEY1.Trim() + "'",
                        string.IsNullOrEmpty(data.STRKEY2) ? "NULL" : "'" + data.STRKEY2.Trim() + "'",
                        string.IsNullOrEmpty(data.STRKEY3) ? "NULL" : "'" + data.STRKEY3.Trim() + "'",
                        string.IsNullOrEmpty(data.STRKEY4) ? "NULL" : "'" + data.STRKEY4.Trim() + "'",
                        string.IsNullOrEmpty(data.STRKEY5) ? "NULL" : "'" + data.STRKEY5.Trim() + "'",
                        string.IsNullOrEmpty(data.NUMKEY1) ? "NULL" : data.NUMKEY1.Trim(),
                        string.IsNullOrEmpty(data.NUMKEY2) ? "NULL" : data.NUMKEY2.Trim(),
                        string.IsNullOrEmpty(data.NUMKEY3) ? "NULL" : data.NUMKEY3.Trim(),
                        string.IsNullOrEmpty(data.NUMKEY4) ? "NULL" : data.NUMKEY4.Trim(),
                        string.IsNullOrEmpty(data.NUMKEY5) ? "NULL" : data.NUMKEY5.Trim());
                    break;
                case "U":
                    query = string.Format("update  PROTEUS_OWN.TE_TIME_SERIES_DEF set GROUP_ID ={0}, SID ={1},  DESCRIPTION = {2}, FREQUENCY_ID = {3}," +
                                          " PARENT_ID = {4}, " +
                                          "STRKEY1 = {5}, STRKEY2 = {6}, STRKEY3 = {7}, STRKEY4 = {8}, STRKEY5 = {9},  " +
                                          "NUMKEY1 = {10}, NUMKEY2 = {11},NUMKEY3 = {12},NUMKEY4 = {13},NUMKEY5 = {14}" +
                                          " where ID = {15}",
                        data.GROUP_ID, data.SID,
                        string.IsNullOrEmpty(data.DESCRIPTION) ? "NULL" : "'" + data.DESCRIPTION.Replace("'", "''").Trim() + "'",
                        data.FREQUENCY_ID,
                        string.IsNullOrEmpty(data.PARENT_ID) ? "NULL" : "'" + data.PARENT_ID.Trim() + "'",
                        string.IsNullOrEmpty(data.STRKEY1) ? "NULL" : "'" + data.STRKEY1.Trim() + "'",
                        string.IsNullOrEmpty(data.STRKEY2) ? "NULL" : "'" + data.STRKEY2.Trim() + "'",
                        string.IsNullOrEmpty(data.STRKEY3) ? "NULL" : "'" + data.STRKEY3.Trim() + "'",
                        string.IsNullOrEmpty(data.STRKEY4) ? "NULL" : "'" + data.STRKEY4.Trim() + "'",
                        string.IsNullOrEmpty(data.STRKEY5) ? "NULL" : "'" + data.STRKEY5.Trim() + "'",
                        string.IsNullOrEmpty(data.NUMKEY1) ? "NULL" : data.NUMKEY1.Trim(),
                        string.IsNullOrEmpty(data.NUMKEY2) ? "NULL" : data.NUMKEY2.Trim(),
                        string.IsNullOrEmpty(data.NUMKEY3) ? "NULL" : data.NUMKEY3.Trim(),
                        string.IsNullOrEmpty(data.NUMKEY4) ? "NULL" : data.NUMKEY4.Trim(),
                        string.IsNullOrEmpty(data.NUMKEY5) ? "NULL" : data.NUMKEY5.Trim(),
                        data.ID
                        );
                    break;
                default:
                    throw new Exception(string.Format("Unknown action {0}", action));
            }

            dbHelper.ExecuteNonQuery(query);

            // Update PROTEUS_OWN.TS_DEF_RELATIONS if NUMKEYs are behaving as parent key
            ManageDefRelations(dbHelper, data.ID, data.NUMKEY1, data.P_NUMKEY1);
            ManageDefRelations(dbHelper, data.ID, data.NUMKEY2, data.P_NUMKEY2);
            ManageDefRelations(dbHelper, data.ID, data.NUMKEY3, data.P_NUMKEY3);
            ManageDefRelations(dbHelper, data.ID, data.NUMKEY4, data.P_NUMKEY4);
            ManageDefRelations(dbHelper, data.ID, data.NUMKEY5, data.P_NUMKEY5);
        }
        public override ResponseBO UpdateDB(RequestBO req)
        {
            // Here you to pass table name and opertaion(add/edit) and data
            Log.Debug("Enter");
            var retval = new ResponseBO();
            var dbHelper = OracleDbHelper;
            long auditId = 0;
            try
            {
                //Permission Check
                if (!Compliance.IsActionAllowed(User, req.screenName, Constants.ManageMasterTablesView, Url,req.runEnviroment))
                    throw new Exception("Permission denied");

                dbHelper.BeginTransaction();
                var json = new JavaScriptSerializer() { MaxJsonLength = Int32.MaxValue };
                var reqData = json.Deserialize<ManageMasterTablesBO.UpdateRequestBO>(req.data.ToString());
                if (reqData == null)
                    throw new Exception("Failed in Json Deserialization");
                var masterTable = reqData.TableName;
                Log.InfoFormat("Update Request by User: {0}, {1}", User, reqData.TableName);

                auditId = LogActionToAudit(reqData.ToOrderedDictionary());
                switch (masterTable)
                {
                    case "TS_FREQUENCY":
                        ManageTS_FREQUENCY(dbHelper, reqData.FreqData, reqData.Action);
                        break;
                    case "TS_GROUPS":
                        ManageTS_GROUPS(dbHelper, reqData.GrpData, reqData.Action);
                        break;
                    case "TS_GROUP_CLASS":
                        ManageTS_GROUP_CLASS(dbHelper, reqData.ClassData, reqData.Action);
                        break;
                    case "TS_GROUP_SUBCLASS":
                        ManageTS_GROUP_SUBCLASS(dbHelper, reqData.SubClassData, reqData.Action);
                        break;
                    case "TS_DEFINITIONS":
                        ManageTS_DEFINITIONS(dbHelper, reqData.DefinitionsData, reqData.Action);

                        break;
                    default:
                        throw new Exception(string.Format("Unknown Master Table: {0}", masterTable));
                }

                dbHelper.Commit();
                LogActionToAudit(new OrderedDictionary() { { "status", "Success" } }, auditId);

            }
            catch (Exception ex)
            {
                retval.errorMessage = string.Format("Exception: {0}", ex.Message);
                Log.Error(retval.errorMessage, ex);
                dbHelper.Rollback();
                LogActionToAudit(new OrderedDictionary() { { "status", "Fail" } }, auditId);
            }
            finally
            {
                Log.Debug("Exit");
            }
            return retval;
        }

        
        private static void ManageDefRelations(DatabaseHelper dbHelper, long defId, string numKey, bool isChecked)
        {
            if (string.IsNullOrEmpty(numKey))
                return;            
            var query = string.Format("DELETE  PROTEUS_OWN.TS_DEF_RELATIONS WHERE DEF_ID = {0} and PARENT_ID = {1}", defId, numKey);
            dbHelper.ExecuteNonQuery(query);

            if (!isChecked) return;
            query = string.Format("insert into proteus_own.ts_def_relations(DEF_ID ,PARENT_ID) values ({0}, {1})", defId, numKey);
            dbHelper.ExecuteNonQuery(query);
        }

    }
}
