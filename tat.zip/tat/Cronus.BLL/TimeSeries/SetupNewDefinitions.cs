﻿﻿using System;
using System.Collections.Generic;
﻿using log4net;
﻿using System.Web.Script.Serialization;
using Cronus.Bll.Helper;
﻿using Cronus.BO;
using Cronus.BO.TimeSeries;
using System.Collections.Specialized;
using Oracle.DataAccess.Client;

namespace Cronus.Bll.TimeSeries
{
    public class TSDefintion : CronusBaseBll
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public override object Clone() { return new TSDefintion(); }

        public override string ScreenName()
        {
            return Constants.TSDefinition;
        }

        protected override string GetTableQuery(TableDataRequestBO requestData, out DatabaseType dbType)
        {
            //Permission Check
            if (!Compliance.IsActionAllowed(User, requestData.screenName, Constants.TSDefinitionView, Url,requestData.runEnviroment))
                throw new Exception("Permission denied");

            dbType = DatabaseType.ORACLE;
            return "select Id, description from PROTEUS_OWN.ts_frequency";
        }

        protected override string GetDropDownDataQuery(string fieldName, DropDownRequestBO requestData, out DatabaseType dbType)
        {
            //Permission Check
            if (!Compliance.IsActionAllowed(User, requestData.screenName, Constants.TSDefinitionView, Url,requestData.runEnviroment))
                throw new Exception("Permission denied");

            dbType = DatabaseType.ORACLE;
            return "select Grps.Id, class , subclass from PROTEUS_OWN.ts_group_class GrpClass, PROTEUS_OWN.ts_group_subclass GrpSubClass, PROTEUS_OWN.ts_groups Grps where GrpClass.Id = grps.class_id and grpsubclass.id = grps.subclass_id";
        }

        private void InsertDefRelations(DatabaseHelper dbHelper, Int64 defId, string numKey)
        {
            var query = string.Format("insert into proteus_own.ts_def_relations(DEF_ID ,PARENT_ID) values ({0}, {1})", defId, numKey);
            var result = dbHelper.ExecuteNonQuery(query);

            if (result == 0)
                Log.Error("Error while inserting data ");
        }

        public override ResponseBO UpdateDB(RequestBO req)
        {
            Log.Debug("Enter");
            var retval = new ResponseBO();
            var dbHelper = OracleDbHelper;
            var auditIds = new List<long>();
            try
            {
                //Permission Check
                if (!Compliance.IsActionAllowed(User, req.screenName, Constants.TSDefinitionSubmit, Url,req.runEnviroment))
                    throw new Exception("Permission denied");

                dbHelper.BeginTransaction();
                var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                var submitRequestObj = json.Deserialize<TSDefinitionsBO.SubmitRequestBO>(req.data.ToString());
                if (submitRequestObj == null)
                    throw new Exception("Failed in Json Deserialization");

                Log.InfoFormat("User: {0}, Updating database", User);
                foreach (var data in submitRequestObj.definitionDataList)
                {
                    Log.InfoFormat("User: {0}, Processing {1}", User, data);

                    auditIds.Add(LogActionToAudit(new OrderedDictionary
                    { {"GroupId", data.GROUP_ID}, {"SID", data.SID}, {"Description", data.DESCRIPTION}
                                                                             , {"FrequencyId", data.FREQUENCY_ID}, {"StrKey1", data.STRKEY1}, {"StrKey2", data.STRKEY2}
                                                                             , {"StrKey3", data.STRKEY3}, {"StrKey4", data.STRKEY4}, {"StrKey5", data.STRKEY5}
                                                                             , {"NumKey1", data.NUMKEY1}, {"NumKey2", data.NUMKEY2}
                                                                             , {"NumKey3", data.NUMKEY3}, {"NumKey4", data.NUMKEY4}, {"NumKey5", data.NUMKEY5} }));

                    var query = "insert into proteus_own.te_time_series_def (GROUP_ID,SID,DESCRIPTION,FREQUENCY_ID,PARENT_ID,STRKEY1,STRKEY2,STRKEY3,STRKEY4,STRKEY5,NUMKEY1,NUMKEY2,NUMKEY3,NUMKEY4,NUMKEY5)";
                    query += string.Format("values({0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14})",
                        data.GROUP_ID,
                        data.SID,
                        string.IsNullOrEmpty(data.DESCRIPTION) ? "NULL" : "'" + data.DESCRIPTION.Replace("'", "''").Trim() + "'",
                        data.FREQUENCY_ID,
                        string.IsNullOrEmpty(data.PARENT_ID) ? "NULL" : data.PARENT_ID.Trim(),
                        string.IsNullOrEmpty(data.STRKEY1) ? "NULL" : "'" + data.STRKEY1.Trim() + "'",
                        string.IsNullOrEmpty(data.STRKEY2) ? "NULL" : "'" + data.STRKEY2.Trim() + "'",
                        string.IsNullOrEmpty(data.STRKEY3) ? "NULL" : "'" + data.STRKEY3.Trim() + "'",
                        string.IsNullOrEmpty(data.STRKEY4) ? "NULL" : "'" + data.STRKEY4.Trim() + "'",
                        string.IsNullOrEmpty(data.STRKEY5) ? "NULL" : "'" + data.STRKEY5.Trim() + "'",
                        string.IsNullOrEmpty(data.NUMKEY1) ? "NULL" : data.NUMKEY1.Trim(),
                        string.IsNullOrEmpty(data.NUMKEY2) ? "NULL" : data.NUMKEY2.Trim(),
                        string.IsNullOrEmpty(data.NUMKEY3) ? "NULL" : data.NUMKEY3.Trim(),
                        string.IsNullOrEmpty(data.NUMKEY4) ? "NULL" : data.NUMKEY4.Trim(),
                        string.IsNullOrEmpty(data.NUMKEY5) ? "NULL" : data.NUMKEY5.Trim());

                    query = query + " returning id into :id";
                    var outParamsList = new Dictionary<string, KeyValuePair<object, object>>();
                    outParamsList[":id"] = new KeyValuePair<object, object>(OracleDbType.Int64, null);

                    dbHelper.ExecuteNonQuery(query, null, outParamsList);
                    var defId = Convert.ToInt64(((Oracle.DataAccess.Types.OracleDecimal)(outParamsList[":id"].Value)).Value);

                    if (!string.IsNullOrEmpty(data.PARENT_ID))
                        InsertDefRelations(dbHelper, defId, data.PARENT_ID);

                    if (submitRequestObj.numKeyChecked["NUMKEY1"])
                        InsertDefRelations(dbHelper, defId, data.NUMKEY1);

                    if (submitRequestObj.numKeyChecked["NUMKEY2"])
                        InsertDefRelations(dbHelper, defId, data.NUMKEY2);

                    if (submitRequestObj.numKeyChecked["NUMKEY3"])
                        InsertDefRelations(dbHelper, defId, data.NUMKEY3);

                    if (submitRequestObj.numKeyChecked["NUMKEY4"])
                        InsertDefRelations(dbHelper, defId, data.NUMKEY4);

                    if (submitRequestObj.numKeyChecked["NUMKEY5"])
                        InsertDefRelations(dbHelper, defId, data.NUMKEY5);
                }
                dbHelper.Commit();

                foreach (var auditId in auditIds)
                    LogActionToAudit(new OrderedDictionary { { "Status", "Success" } }, auditId);
            }
            catch (Exception ex)
            {
                retval.errorMessage = string.Format("Exception: {0}", ex.Message);
                Log.Error(retval.errorMessage, ex);
                dbHelper.Rollback();

                foreach (var auditId in auditIds)
                    LogActionToAudit(new OrderedDictionary { { "Status", "Fail" } }, auditId);
            }
            finally
            {
                Log.Debug("Exit");
            }

            return retval;
        }
    }
}
