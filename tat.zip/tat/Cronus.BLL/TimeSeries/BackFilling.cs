﻿﻿using System;
using Cronus.BO.TimeSeries;
using Cronus.BO;
using System.Collections.Generic;
using log4net;
using System.Web.Script.Serialization;
using Cronus.Bll.Helper;
using System.Collections.Specialized;
﻿using System.Linq;

namespace Cronus.Bll.TimeSeries
{
    public class BackFilling : CronusBaseBll
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public override string ScreenName() { return Constants.BackFilling; }
        public override object Clone() { return new BackFilling(); }


        private void MergeTimeSeries(BackFillingBO.FileDataBO data)
        {
            long auditId = 0;
            DatabaseHelper dbHelper = OracleDbHelper;
            Log.Debug("Enter");
            try
            {
                dbHelper.BeginTransaction();
                auditId = LogActionToAudit(new OrderedDictionary { { "FileName", data.FileName } });
                var columns = data.Columns;
                var priceDate = "";
                foreach (List<string> row in data.DefinitionDataList)
                {
                    for (var i = 0; i < row.Count; i++)
                    {
                        if (columns[i] == "AsofDate")
                        {
                            priceDate = row[i];
                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(priceDate))
                            {
                                var defId = Convert.ToInt64(columns[i]);
                                var value = Convert.ToDouble(row[i]);
                                var query = string.Format("merge into proteus_own.te_time_series a " +
                                                             "using (select {0} id, to_date('{1}','DD-Mon-YYYY') asof_date, {2} value from dual)b " +
                                                             "on (a.id=b.id and a.asof_date=b.asof_date) " +
                                                             "when matched then update set a.value=b.value  " +
                                                             "when not matched then  insert(id,asof_date,value,stale_id) values(b.id,b.asof_date,b.value,0)"
                                    , defId, priceDate, value);

                                dbHelper.ExecuteNonQuery(query);
                                priceDate = "";
                            }
                            else
                            {
                                if ((!string.IsNullOrEmpty(priceDate) && string.IsNullOrEmpty(row[i])) || (string.IsNullOrEmpty(priceDate) && !string.IsNullOrEmpty(row[i])))
                                    throw new Exception(string.Format("value is null at row number {0} for priceDate = {1} ", i + 1, priceDate));
                            }
                        }
                    }
                }
                dbHelper.Commit();
                LogActionToAudit(new OrderedDictionary { { "status", "Success" } }, auditId);
            }
            catch (Exception ex)
            {
                Log.Error("Exception, Message : " + ex.Message, ex);
                dbHelper.Rollback();
                LogActionToAudit(new OrderedDictionary { { "status", "Fail" } }, auditId);
                throw;
            }
            finally
            {
                Log.Debug("Exit");
            }
        }


        public override ResponseBO UpdateDB(RequestBO req)
        {
            ResponseBO retval = new ResponseBO();
            try
            {
                var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                var reqData = json.Deserialize<BackFillingBO.FileDataBO>(req.data.ToString());
                if (reqData == null)
                    throw new Exception("Failed in Json Deserialization");

                Log.InfoFormat("Update Request by User: {0}, FileName {1}", User, reqData.FileName);

                switch (reqData.Tab)
                {
                    case "E":
                        ////Permission Check
                        if (!Compliance.IsActionAllowed(User, req.screenName, Constants.BackFillingSave, Url,req.runEnviroment))
                            throw new Exception("Permission denied");

                        MergeTimeSeries(reqData);
                        break;
                    case "S":
                        //Permission Check
                        if (!Compliance.IsActionAllowed(User, req.screenName, Constants.BackFillingSave, Url,req.runEnviroment))
                            throw new Exception("Permission denied");

                        SendRequestTimeSeries(reqData);
                        break;
                    default:
                        throw new Exception(string.Format("Unknown Tab: {0}", reqData.Tab));
                }

            }
            catch (Exception ex)
            {
                retval.errorMessage = string.Format("Error found in request: {0}", ex.Message);
                Log.Error(retval.errorMessage, ex);
            }
            return retval;
        }

        private void SendRequestTimeSeries(BackFillingBO.FileDataBO reqData)
        {
            var groupIdarr = reqData.GroupIds.Split(',').ToList();
            string groupIdsWithQuotes = string.Join(",", groupIdarr.Select(s => "'" + s.Trim() + "'"));
            string query = string.Format("SELECT ID FROM PROTEUS_OWN.TS_GROUPS where ID in ({0})", groupIdsWithQuotes);
            var result = OracleDbHelper.ExecuteSelectQuery(query);
            if (result.rows.Count != groupIdarr.Count)
                throw new Exception("1 or more Group Ids are not valid");

            var defIdarr = reqData.DefIds.Split(',').ToList();
            string defIdsWithQuotes = string.Join(",", defIdarr.Select(s => "'" + s.Trim() + "'"));
            query = string.Format("SELECT ID FROM PROTEUS_OWN.te_time_series_def where ID in ({0})", defIdsWithQuotes);
            result = OracleDbHelper.ExecuteSelectQuery(query);
            if (result.rows.Count != defIdarr.Count)
                throw new Exception("1 or more def Ids are not valid");
            // Here we need to validate group id and Definition Ids list
            //throw new Exception("Def IDs and Group Ids are within range");
            //Now pass these parameters to fesserver
        }

    }
}
