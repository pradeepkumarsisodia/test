﻿using System;
using System.Collections.Generic;
using System.Linq;
using Cronus.BO;
using log4net;
//using Cronus.Model.Oracle;
using Cronus.Bll.Helper;
using System.Net.Mail;
using System.Collections.Specialized;
using Oracle.DataAccess.Client;

namespace Cronus.Bll
{
    public class CronusBaseBll : ICronusBaseBll
    {
        public enum DatabaseType { ORACLE, SYBASE };

        private string _user;
        private string _url;
        private ConfigHelper _configManager;
        private DatabaseHelper _sybaseDbHelper;
        private DatabaseHelper _oracleDbHelper;
        private string _runOnEnviroment;
        public string User
        {
            get { return _user; }
            set { _user = value; }
        }

        public string Url
        {
            get { return _url; }
            set { _url = value; }
        }

        public string RunOnEnviroment
        {
            get { return _runOnEnviroment; }
            set { _runOnEnviroment = value; }
        }

        protected ConfigHelper ConfigManager
        {
            get
            {
                if (_configManager == null)
                    _configManager = new ConfigHelper(Url);
                return _configManager;
            }
        }

        protected DatabaseHelper SybaseDbHelper
        {
            get
            {
                if (_sybaseDbHelper != null) return _sybaseDbHelper;
                _sybaseDbHelper = new SybaseDatabaseHelper(ConfigManager.GetSybaseConnectionStr(RunOnEnviroment), GetKey());

                return _sybaseDbHelper;
            }
        }

        protected DatabaseHelper OracleDbHelper
        {
            get
            {
                if (_oracleDbHelper != null) return _oracleDbHelper;
                _oracleDbHelper = new OracleDatabaseHelper(ConfigManager.GetOracleConnectionStr(RunOnEnviroment), GetKey());

                return _oracleDbHelper;
            }

        }

        protected virtual string GetKey()
        {
            return string.Format("{0}_%_{1}_%_{2}", User, ScreenName(), Guid.NewGuid());
        }

        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public virtual object Clone() { return null; }

        public virtual string ScreenName()
        {
            return "Base";
        }

        protected virtual string GetDropDownDataQuery(string fieldName, DropDownRequestBO requestData, out DatabaseType dbType)
        {
            dbType = DatabaseType.ORACLE;
            return "UNKNOWN";
        }

        protected virtual string GetTableQuery(TableDataRequestBO requestData, out DatabaseType dbType)
        {
            dbType = DatabaseType.ORACLE;
            return "UNKNOWN";
        }

        protected string GetMailIdOfUser(string user)
        {
            string retval = "";
            string query = string.Format("Select email_id From TLC_BI_OWN.LDAP_USERS_VW Where upper(login_id) in ('{0}')", User.ToUpper());
            var mailIds = OracleDbHelper.ExecuteSelectQuery(query);
            if (mailIds.rows.Count > 0)
                retval = mailIds.rows[0][0].ToString();

            if (string.IsNullOrWhiteSpace(retval))
                retval = string.Format("{0}@pimco.com", User);
            return retval;
        }

        protected List<string> GetMailIdOfScreen(string environment, string team = "")
        {
            List<string> retval = new List<string>();
            string query = string.Format("Select value From cronus_own.config Where screenId = '{0}' and context = 'MAIL' and key = '{1}' and (environment is null or environement = '{2}')", ScreenName(), team, environment);
            if (string.IsNullOrWhiteSpace(team))
                query = string.Format("Select value From cronus_own.config Where screenId = '{0}' and context = 'MAIL' and (environment is null or environment = '{1}')", ScreenName(), environment);
            var mailIds = OracleDbHelper.ExecuteSelectQuery(query);
            if (mailIds.rows.Count > 0)
                retval.Add(mailIds.rows[0][0].ToString());

            return retval;
        }

        public static void SendEmail(string subject, string body, string to, string from)
        {
            Log.Debug("Enter");
            const string server = "mailhost.pimco.imswest.sscims.com";
            var message = new MailMessage(from, to)
            {
                Subject = subject,
                IsBodyHtml = true,
                Body = body
            };
            // "Using the new SMTP client.";

            //@"Using this new feature, you can send an e-mail message from an application very easily.";
            var client = new SmtpClient(server) { UseDefaultCredentials = true };
            // Credentials are necessary if the server requires the client  
            // to authenticate before it will send e-mail on the client's behalf.
            try
            {
                Log.InfoFormat("Sending mail to {0} : Subject {1}", to, subject);
                client.Send(message);
            }
            catch (Exception ex)
            {
                Log.Error("Exception : " + ex.Message, ex);
                throw;
            }
            finally
            {
                Log.Debug("Exit");
            }
        }

        public static UserInformation FetchUserInformation(string user, string url, string runEnviroment)
        {
            Log.Debug("Enter");
            try
            {
                var userInfomation = new UserInformation();
                var configManager = new ConfigHelper(url);
                //var db = configManager.GetOracleConnectionStr(runEnviroment);
                // var _oracleDbHelper = new OracleDatabaseHelper(configManager.GetOracleConnectionStr(runEnviroment), string.Format("{0}_%_{1}_%_{2}", user, "Common", Guid.NewGuid()));
                var _oracleDbHelper = new OracleDatabaseHelper(configManager.GetOracleConnectionStr(runEnviroment), string.Format("{0}_%_{1}_%_{2}", user, "Common", Guid.NewGuid()));

                //using (var entity = new EntitiesModel(db))
                //{
                //    var userObj = entity.USERs.ToList().FirstOrDefault(a => string.Equals(a.USER_ID, user, StringComparison.InvariantCultureIgnoreCase));
                var query = string.Format("Select * from CRONUS_OWN.Users where UPPER(user_id) = '{0}'", user.ToUpperInvariant());
                var userObj = _oracleDbHelper.ExecuteSelectQuery(query);
                if (userObj != null && userObj.rows.Count > 0)
                //if (userObj != null)
                {
                    //  if (string.IsNullOrEmpty(userObj.DESCRIPTION)) return userInfomation;
                    if (string.IsNullOrEmpty(Convert.ToString(userObj.rows[0][2]))) return userInfomation;
                    //var desc = userObj.DESCRIPTION.Split(',');
                    var desc = Convert.ToString(userObj.rows[0][2]).Split(',');
                    if (desc.Length > 1)
                    {
                        userInfomation.CronusUserName = desc[0];
                        userInfomation.CronusUserEmail = desc[1];
                        return userInfomation;
                    }
                    else if (desc.Length > 0)
                    {
                        userInfomation.CronusUserName = desc[0];
                        return userInfomation;
                    }
                    else
                    {
                        Log.Error(string.Format("User Description not found for user = {0} in db = {1}.", user, _oracleDbHelper));
                    }
                }
                else
                {
                    userInfomation.CronusUserEmail = string.Empty;
                    userInfomation.CronusUserName = string.Empty;
                }
                return userInfomation;
                // }
            }
            catch (Exception ex)
            {
                Log.Error("Exception in Method " + System.Reflection.MethodBase.GetCurrentMethod().Name + ", Message : "
                            + ex.Message + ". Current User = " + user, ex);
                return new UserInformation();
            }
            finally
            {
                Log.Debug("Exit");
            }
        }

        public static ResponseBO FetchActionsForUser(string userId, string url, string runEnviroment)
        {
            Log.Debug("Enter");
            var retVal = new ActionPermittedResponseBO() { actionPermittedList = new List<ACTION_BO>() };
            try
            {
                var configManager = new ConfigHelper(url);
                // var db = configManager.GetOracleConnectionStr(runEnviroment);
                var _oracleDbHelper = new OracleDatabaseHelper(configManager.GetOracleConnectionStr(runEnviroment), string.Format("{0}_%_{1}_%_{2}", userId, "Common", Guid.NewGuid()));


                var actionQuery = string.Format("select  A.ACTION_ID, UPPER(A.ACTION_NAME) ACTION_NAME ,A.DESCRIPTION, UPPER( A.SCREEN_ID)SCREEN_ID from CRONUS_OWN.GROUP_ACTION_PERMISSION GAP inner join  CRONUS_OWN.ACTION A on GAP.ACTION_ID = A.ACTION_ID where GAP.IS_ACTIVE = 'Y' and GAP.GROUP_ID in(select distinct GROUP_ID from CRONUS_OWN.USER_GROUP  where USER_ID =  '{0}' and IS_ACTIVE = 'Y' ) order by SCREEN_ID", userId);
                var data = _oracleDbHelper.ExecuteSelectQuery(actionQuery);
                if (data != null && data.rows.Count > 0)
                {
                    List<ACTION_BO> actionslist = new List<ACTION_BO>();

                    // ACTION_BO objAction;
                    foreach (var action in data.rows)
                    {
                        var objAction = new ACTION_BO();

                        objAction.ACTION_ID = Convert.ToInt64(action[0]);
                        objAction.ACTION_NAME = Convert.ToString(action[1]).ToUpperInvariant();
                        objAction.DESCRIPTION = Convert.ToString(action[2]);
                        objAction.SCREEN_ID = Convert.ToString(action[3]).ToUpperInvariant();
                        objAction.IS_PERMITTED = true;

                        actionslist.Add(objAction);
                    }

                    retVal.actionPermittedList = actionslist;
                }

                //using (var entity = new EntitiesModel(db))
                //{
                //    //write logic
                //    //find all the group where user belongs
                //    var groups = entity.USER_GROUPs.Where(t => t.USER_ID == userId && t.IS_ACTIVE == 'Y').Select(t => t.GROUP_ID).Distinct();
                //    //var groups = string.Format("select USER_ID from CRONUS_OWN.USER_GROUP  where USER_ID = '{0}' and IS_ACTIVE = 'Y'", userId);
                //    if (groups.Any())
                //    {
                //        //var actionQuery = string.Format("select A.ACTION_ID, UPPER(A.ACTION_NAME) ACTION_NAME ,A.DESCRIPTION, UPPER( A.SCREEN_ID)SCREEN_ID from CRONUS_OWN.GROUP_ACTION_PERMISSION GAP inner join  CRONUS_OWN.ACTION A on GAP.ACTION_ID = A.ACTION_ID where GAP.IS_ACTIVE = 'Y' and GAP.GROUP_ID in({0})", "");
                //        var actions = entity.GROUP_ACTION_PERMISSIONs.Where(t => t.IS_ACTIVE == 'Y' && groups.Contains(t.GROUP_ID)).Select(t => new ACTION_BO
                //        {
                //            ACTION_ID = t.ACTION.ACTION_ID,
                //            ACTION_NAME = t.ACTION.ACTION_NAME.ToUpperInvariant(),
                //            DESCRIPTION = t.ACTION.DESCRIPTION,
                //            SCREEN_ID = t.ACTION.SCREEN_ID.ToUpperInvariant(),
                //            IS_PERMITTED = true
                //        }).OrderBy(t => t.SCREEN_ID).ToList();

                //        /*var screenIdList = actions.Where(t => t.ACTION_NAME.ToUpperInvariant() != "VIEW").GroupBy(t => t.SCREEN_ID).Select(t => t.First());

                //        foreach (var screenId in screenIdList)
                //        {
                //            actions.Add(new ACTION_BO
                //            {
                //                ACTION_NAME = "VIEW",
                //                SCREEN_ID = screenId.SCREEN_ID,
                //                IS_PERMITTED = true
                //            });
                //        }
                //        */
                //        retVal.actionPermittedList = actions;
                //    }
                //}
            }
            catch (Exception ex)
            {
                Log.Error("Exception : " + ex.Message, ex);
                retVal.errorMessage = ex.Message;
            }
            finally
            {
                Log.Debug("Exit");
            }
            return retVal;
        }

        public virtual ResponseBO FetchCycleAndPreviosDate()
        {
            Log.Debug("Enter");
            var resultDates = new CycleDateAndPreviousDateBo();
            try
            {
                const string cycleDateQuery = "SELECT date_value FROM pimco..smarts_dates WHERE region_code = 'U' AND row_no = 16";
                var cycleDateresult = SybaseDbHelper.ExecuteSelectQuery(cycleDateQuery);
                if (cycleDateresult.rows.Count > 0)
                    resultDates.CycleDate = cycleDateresult.rows[0][0].ToString();
                else
                    throw new Exception("Current Cycle Date not found in DB (No row in pimco..smarts_dates table for Region_code = U and row_no 16)");

                const string previousCycleDateQuery = "SELECT date_value FROM pimco..smarts_dates WHERE region_code = 'U' AND row_no = 15";
                var previousCycleDateresult = SybaseDbHelper.ExecuteSelectQuery(previousCycleDateQuery);
                if (previousCycleDateresult.rows.Count > 0)
                    resultDates.PreviousDate = previousCycleDateresult.rows[0][0].ToString();
                else
                    throw new Exception("Previous Cycle Date not found in DB (No row in pimco..smarts_dates table for Region_code = U and row_no 15)");
            }
            catch (Exception ex)
            {
                resultDates.errorMessage = ex.Message;
                Log.Error("Exception : " + ex.Message, ex);
            }
            finally
            {
                Log.Debug("Exit");
            }
            return resultDates;
        }

        public virtual ResponseBO FetchDropDownData(DropDownRequestBO req)
        {
            var resultList = new DropDownResponseBo();
            var fieldName = req.fieldName;
            Log.Debug("Enter");
            Log.InfoFormat("fieldName : {0}", fieldName);
            try
            {
                DatabaseType dbType;

                var query = GetDropDownDataQuery(fieldName, req, out dbType);

                var dbHelper = (dbType == DatabaseType.ORACLE ? OracleDbHelper : SybaseDbHelper);

                var result = dbHelper.ExecuteSelectQuery(query);
                var dropDownList = new List<DataValueBo>();
                if (result.rows.Count > 0)
                {
                    for (var i = 0; i < result.rows.Count; i++)
                    {
                        var resultData = "";
                        for (var j = 0; j < result.columns.Count; j++)
                        {
                            if (j == 0)
                                resultData = result.rows[i][j].ToString();
                            else
                                resultData += Constants.DropdownSeperator + result.rows[i][j];
                        }
                        var datavalue = new DataValueBo
                        {
                            data = result.rows[i][0].ToString(),
                            value = resultData
                        };
                        dropDownList.Add(datavalue);
                    }
                }
                else
                    Log.InfoFormat("No Data fieldName : {0}", fieldName);
                resultList.dropDownData = dropDownList;
            }
            catch (Exception ex)
            {
                resultList.errorMessage = ex.Message;
                Log.Error("Exception : " + ex.Message, ex);
            }
            finally
            {
                Log.Debug("Exit");
            }

            return resultList;
        }

        public virtual ResponseBO FetchDataForTable(TableDataRequestBO requestData)
        {
            var retval = new TableDataResponseBO();
            try
            {
                DatabaseType dbType;
                var query = GetTableQuery(requestData, out dbType);

                var dbHelper = (dbType == DatabaseType.ORACLE ? OracleDbHelper : SybaseDbHelper);

                retval = dbHelper.ExecuteSelectQuery(query);
                retval.tableName = requestData.tableName;
            }
            catch (Exception ex)
            {
                retval.errorMessage = string.Format("Exception: {0}", ex.Message);
                Log.Error("Exception : " + ex.Message, ex);
            }

            return retval;
        }

        public virtual ResponseBO FetchResults(ResultMessageBO req) { return null; }
        public virtual ResponseBO FetchDataForQB(TableDataRequestBO req) { return null; }
        public virtual ResponseBO Commit(RequestBO req) { return null; }
        public virtual ResponseBO Rollback(RequestBO req) { return null; }
        public virtual ResponseBO CancelAjax(RequestBO req) { return null; }
        public virtual ResponseBO UpdateDB(RequestBO req) { return null; }
        public virtual Dictionary<string, object> Subscribe(Dictionary<string, object> args) { return new Dictionary<string, object>(); }
        public virtual ResponseBO CustomFunction(CustomFunctionBO req) { return null; }

        protected long LogActionToAudit(OrderedDictionary dataDic, long auditTrailId = 0)
        {
            Log.Debug("Enter");

            long auditId = auditTrailId;
            try
            {
                DatabaseHelper dbHelper = OracleDbHelper;
                //Get the description from dataDic
                var desc = "";
                foreach (var field in dataDic.Keys)
                {
                    if (desc != "")
                        desc += ", ";

                    desc += string.Format("<b>{0}</b>: [{1}]", field, dataDic[field] == null ? " " : string.IsNullOrEmpty(dataDic[field].ToString()) ? " " : dataDic[field]);
                }

                //if auditTrailId > 0 means we need to update existing row in audit_trail tables. So get the description for the given auditTrailId
                if (auditTrailId > 0)
                {
                    string descInDb = "";
                    string selectquery = string.Format("select DESCRIPTION, FULL_DESCRIPTION From cronus_own.audit_trail Where Audit_trail_id = {0}", auditTrailId);
                    var sData = dbHelper.ExecuteSelectQuery(selectquery, true);
                    if (sData.rows.Count > 0)
                    {
                        //If Full_description column has not null value take that as descrition else take description column
                        if (!string.IsNullOrWhiteSpace(sData.rows[0][1] as string))
                            descInDb = (string)sData.rows[0][1];
                        else
                            descInDb = (string)sData.rows[0][0];
                    }
                    //Append the description got from table with the passed value
                    desc = (descInDb + ", " + desc);
                }

                //The query will be executed with bind variable as one of the field is clob. So input bind variables are for description column and full_description column. 
                //The full_description column will be ppopulated only if description value exceed max varchar2 length that is 4000. else it will be null.
                //If full_description column populate the description column of the table will have first 3997 char and three dotes.
                Dictionary<string, KeyValuePair<object, object>> inParamsList = new Dictionary<string, KeyValuePair<object, object>>();
                Dictionary<string, KeyValuePair<object, object>> outParamsList = new Dictionary<string, KeyValuePair<object, object>>();
                string query = "";
                string description = (desc.Length > 4000) ? desc.Substring(0, 4000 - 4) + "..." : desc;
                string full_description = (desc.Length > 4000) ? desc : null;
                inParamsList[":description"] = new KeyValuePair<object, object>(OracleDbType.Varchar2, description);
                inParamsList[":full_description"] = new KeyValuePair<object, object>(OracleDbType.Clob, full_description);

                if (auditTrailId == 0)
                {
                    query = string.Format("Insert into cronus_own.audit_trail (SCREEN_ID, USER_ID, DESCRIPTION, FULL_DESCRIPTION) values('{0}', '{1}', {2}, {3})"
                            , ScreenName().ToUpper(), _user, ":description", ":full_description");
                    query = query + " returning Audit_trail_id into :Audit_trail_id";
                    outParamsList[":Audit_trail_id"] = new KeyValuePair<object, object>(OracleDbType.Int64, null);
                }
                else
                {
                    query = string.Format("Update cronus_own.audit_trail set DESCRIPTION = {0}, FULL_DESCRIPTION = {1} where Audit_trail_id = {2}", ":description", ":full_description"
                        , auditTrailId);
                }
                dbHelper.ExecuteNonQuery(query, inParamsList, outParamsList);

                //Get the auditTailId in case of insert query.
                if (outParamsList.ContainsKey(":Audit_trail_id"))
                    auditId = Convert.ToInt64(((Oracle.DataAccess.Types.OracleDecimal)(outParamsList[":Audit_trail_id"].Value)).Value);

                Log.Debug("Exit");
            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Eating this Exception: {0}", ex.Message), ex);
            }
            finally
            {
                Log.Debug("Exit");
            }
            return auditId;
        }

        public static string FetchFeSeverUrl(string runEnviroment)
        {
            Log.Debug("Enter FetchFeServerUrl");
            string returnUrl = string.Empty;
            var configManager = new ConfigHelper("");
            var _oracleDbHelper = new OracleDatabaseHelper(configManager.GetOracleConnectionStr(runEnviroment), string.Format("{0}_%_{1}", "FeServer", Guid.NewGuid()));
            try
            {
                string query = "select Value from CRONUS_OWN.CONFIG WHERE ScreenID = 'Home' and Key = 'FeServer' and environment  = '" + runEnviroment + "' ";
                var configData = _oracleDbHelper.ExecuteSelectQuery(query);
                if (configData.rows.Count > 0)
                    returnUrl = configData.rows[0][0].ToString();
                else
                    throw new Exception("No row in CRONUS_OWN.CONFIG  table for environment = " + runEnviroment + " and Key = FeServer)");

            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Eating this Exception: {0}", ex.Message), ex);
            }
            finally
            {
                Log.Debug("Exit");
            }

            return returnUrl;
        }
    }
}
