﻿using System;
using System.Collections.Generic;
using System.Linq;
using log4net;
using Cronus.BO;
using Cronus.Bll.Helper;
using System.Web.Script.Serialization;
using Cronus.BO.Fes;
using System.Collections.Specialized;
using System.Configuration;
using System.IO;

namespace Cronus.Bll.Fes
{
    class SecAnalyticsOverride : CronusBaseBll
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private Dictionary<string, string> analytic_id_datatype_cache = new Dictionary<string, string>();
        private Dictionary<string, Dictionary<string, string>> analytic_id_app_field_cache = new Dictionary<string, Dictionary<string, string>>();

        public override object Clone() { return new SecAnalyticsOverride(); }

        public override string ScreenName()
        {
            return Constants.SecAnalyticsOverride;
        }
        protected override string GetTableQuery(TableDataRequestBO requestData, out DatabaseType dbType)
        {
            dbType = DatabaseType.ORACLE;

            var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
            var data = json.Deserialize<SecAnalyticsOverrideBO.AddUpdateRequestBO>(requestData.data.ToString());
            if (data == null)
                throw new Exception("Failed in Json Deserialization");

            string query = string.Format(@"Select SSM_ID,ANALYTIC_ID,case when  RISK_VAL is null then RISK_VAL_STR else TO_CHAR(RISK_VAL) end as value,BACKUP_METRIC,  note   
                                        From SEC_ANALYTICS_OWN.SEC_ANALYTICS_OVERRIDES Where 1= 1");

            if (!string.IsNullOrEmpty(data.ssm_id))
                query += string.Format(" and ssm_id in ({0}) "
                                    , string.Join(",", data.ssm_id.Split(',').ToList<string>().Select(s => "'" + s.Trim() + "'")));

            query += " Order by 1, 2";

            return query;
        }

        protected override string GetDropDownDataQuery(string fieldName, DropDownRequestBO requestData, out DatabaseType dbType)
        {
            dbType = DatabaseType.ORACLE;
            string query = "";
            if (fieldName == "ANALYTIC_ID")
                query = "select analytic_id from sec_analytics_own.analytic_id_metadata where analytic_id like 'manual_%'";
            return query;
        }

        private string GetDataType(string analytic_id)
        {
            var retval = string.Empty;
            if (!analytic_id_datatype_cache.ContainsKey(analytic_id))
            {
                var select_query = string.Format("select datatype from pm_own.analytic_id_metadata where srm_label || analytic_id = '{0}' or analytic_id = '{0}' ", analytic_id.Replace("'", "''"));
                var selected_rows = this.OracleDbHelper.ExecuteSelectQuery(select_query);
                if (selected_rows.rows.Count == 0)
                    throw new Exception(string.Format("Analytic_id {0} is not a valid. Please enter valid analytic_id", analytic_id));

                analytic_id_datatype_cache[analytic_id] = selected_rows.rows[0][0].ToString();
            }
            return analytic_id_datatype_cache[analytic_id];
        }

        private Dictionary<string, string> GetAppField(string analytic_id)
        {
            var retval = string.Empty;
            if (!analytic_id_app_field_cache.ContainsKey(analytic_id))
            {
                var app_name_app_field_dic = new Dictionary<string, string>();
                var select_query = string.Format("select distinct App_name, APP_Field from PM_OWN.risk_measures_to_app where analytic_id_TO_Stage = '{0}'", analytic_id.Replace("'", "''"));
                var selected_rows = this.OracleDbHelper.ExecuteSelectQuery(select_query);
                if (selected_rows.rows.Count > 0)
                {
                    foreach (var row in selected_rows.rows)
                    {
                        app_name_app_field_dic[row[0].ToString()] = row[1].ToString();
                    }
                }
                analytic_id_app_field_cache[analytic_id] = app_name_app_field_dic;
            }
            return analytic_id_app_field_cache[analytic_id];
        }

        private void ValidateSecAnalyticsData(List<SecAnalyticsOverrideBO.AddUpdateRequestBO> data)
        {
            foreach (var sec_analytic in data)
            {
                if (sec_analytic.action == "D") continue;

                if (string.IsNullOrEmpty(sec_analytic.ssm_id))
                    throw new Exception("SSM_ID can not be null");
                if (string.IsNullOrEmpty(sec_analytic.analytic_id))
                    throw new Exception("Analytic Id can not be null");
                if (string.IsNullOrEmpty(sec_analytic.value))
                    throw new Exception("Value can not be null");
                if (string.IsNullOrEmpty(sec_analytic.backUp_Metric))
                    throw new Exception("backUp Metric can not be null");

                var datatype = GetDataType(sec_analytic.analytic_id);
                if (datatype.Trim().ToUpper() == "DOUBLE")
                {
                    double num;
                    if (!double.TryParse(sec_analytic.value, out num))
                    {
                        throw new Exception(string.Format("Datatype of analytic id {0} is double, so the value {1} should be number", sec_analytic.analytic_id, sec_analytic.value));
                    }
                }
            }
        }

        public override ResponseBO UpdateDB(RequestBO req)
        {
            Log.Debug("Enter");
            var retval = new SecAnalyticsOverrideBO.AddUpdateResponseBO();
            var dbHelper = this.OracleDbHelper;
            var dbHelperSybase = this.SybaseDbHelper;

            try
            {
                if (!Compliance.IsActionAllowed(User, req.screenName, Constants.SecAnalyticsOverride_Submit, Url, req.runEnviroment))
                    throw new Exception("Permission denied");

                var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                var a = req.data.ToString();
                var data = json.Deserialize<List<SecAnalyticsOverrideBO.AddUpdateRequestBO>>(req.data.ToString());
                if (data == null)
                    throw new Exception("Failed in Json Deserialization");

                /*Validate data */
                ValidateSecAnalyticsData(data);

                /*Process data */
                dbHelper.BeginTransaction();
                dbHelperSybase.BeginTransaction();
                var auditIds = new List<long>();
                var filedata = string.Empty;
                var price_date = string.Empty;
                foreach (var sec_analytic in data)
                {
                    Log.Info(string.Format("Request by User: {0}, Processing {1}", User, sec_analytic));
                    var action = sec_analytic.action;
                    var ssm_id = sec_analytic.ssm_id;
                    var analytic_id = sec_analytic.analytic_id;
                    price_date = sec_analytic.price_date.ToString("MM/dd/yyyy");
                    var value = sec_analytic.value;
                    var note = sec_analytic.note;
                    var backUpMetric = sec_analytic.backUp_Metric;
                    if (string.IsNullOrWhiteSpace(retval.message))
                        retval.message = string.Format("Action = {0}\n\n", action);

                    auditIds.Add(LogActionToAudit(new OrderedDictionary() {
                               { "action", action }, { "ssm_id", ssm_id }, { "analytic_id", analytic_id }, { "value", value }, { "backUp_Metric", backUpMetric }, { "note", note }, { "price_date", price_date } }));
                    try
                    {
                        if (action == "D")
                        {
                            var deleteQuery = string.Format(@"delete from SEC_ANALYTICS_OWN.SEC_ANALYTICS_OVERRIDES where ssm_id = '{0}'", ssm_id);

                            if (!string.IsNullOrWhiteSpace(analytic_id))
                                deleteQuery += string.Format(" and analytic_id ='{0}' ", analytic_id);

                            dbHelper.ExecuteNonQuery(deleteQuery);

                            deleteQuery = string.Format(@"delete from pm..sec_analytics_overrides where ssm_id = '{0}'", ssm_id);

                            if (!string.IsNullOrWhiteSpace(analytic_id))
                                deleteQuery += string.Format(" and analytic_id ='{0}' ", analytic_id);

                            dbHelperSybase.ExecuteNonQuery(deleteQuery);
                        }
                        else
                        {
                            filedata += string.Format("{0},{1},{2}", ssm_id, analytic_id, value);
                            filedata += Environment.NewLine;
                            var datatype = GetDataType(analytic_id);
                            var risk_val = "NULL";
                            var risk_val_str = "";
                            if (datatype.Trim().ToUpper() == "DOUBLE")
                                risk_val = value;
                            else
                                risk_val_str = value;
                            //Oracla
                            var update_query = string.Format(@"
                                Merge into SEC_ANALYTICS_OWN.SEC_ANALYTICS_OVERRIDES sao Using
                                    (select to_date('{0}', 'MM/DD/YYYY') price_date, '{1}' ssm_id, '{2}' analytic_id, {3} risk_val, '{4}' risk_val_str,'{5}' backup_metric, '{6}' note, '{7}' last_chg_user, '{8}' last_chg_date from dual) a 
                                    on (a.ssm_id = sao.ssm_id and a.analytic_id = sao.analytic_id)
                                    When Matched Then
                                        Update Set sao.price_date = a.price_date, sao.risk_val = a.risk_val, sao.risk_val_str = a.risk_val_str, sao.backup_metric = a.backup_metric, sao.note = a.note, sao.last_chg_user = a.last_chg_user, sao.last_chg_date = a.last_chg_date
                                    When Not Matched Then 
                                        Insert (sao.price_date, sao.ssm_id, sao.analytic_id, sao.risk_val, sao.risk_val_str,sao.backup_metric, sao.note, sao.last_chg_user, sao.last_chg_date) 
                                            Values(a.price_date, a.ssm_id, a.analytic_id, a.risk_val, a.risk_val_str,  a.backup_metric,a.note, a.last_chg_user, a.last_chg_date)"
                                    , price_date, ssm_id, analytic_id.Replace("'", "''"), risk_val, risk_val_str.Replace("'", "''").Replace("'", "''"), backUpMetric.Replace("'", "''"), note.Replace("'", "''"), User, DateTime.Now);
                            dbHelper.ExecuteNonQuery(update_query);
                            //Syabase
                            var update_query_Sybase = string.Format(@"
                                Merge into pm..sec_analytics_overrides sao Using
                                    (select  convert(date, '{0}', 101) price_date, '{1}' ssm_id, '{2}' analytic_id, {3} risk_val, '{4}' risk_val_str,'{5}' backup_metric, '{6}' note, '{7}' last_chg_user, '{8}' last_chg_date) a 
                                    on (a.ssm_id = sao.ssm_id and a.analytic_id = sao.analytic_id)
                                    When Matched Then
                                        Update Set sao.price_date = a.price_date, sao.risk_val = a.risk_val, sao.risk_val_str = a.risk_val_str, sao.backup_metric = a.backup_metric, sao.note = a.note, sao.last_chg_user = a.last_chg_user, sao.last_chg_date = a.last_chg_date
                                    When Not Matched Then 
                                        Insert (sao.price_date, sao.ssm_id, sao.analytic_id, sao.risk_val, sao.risk_val_str,sao.backup_metric, sao.note, sao.last_chg_user, sao.last_chg_date) 
                                            Values(a.price_date, a.ssm_id, a.analytic_id, a.risk_val, a.risk_val_str,  a.backup_metric,a.note, a.last_chg_user, a.last_chg_date)"
                                , price_date, ssm_id, analytic_id.Replace("'", "''"), risk_val, risk_val_str.Replace("'", "''").Replace("'", "''"), backUpMetric.Replace("'", "''"), note.Replace("'", "''"), User, DateTime.Now);
                            dbHelperSybase.ExecuteNonQuery(update_query_Sybase);
                        }
                        retval.message += string.Format("ssm_id = {0}, analytic_id = {1}, value = {2}, backUp_Metric = {3},  Note = {4} \n", ssm_id, analytic_id, value, backUpMetric, note);

                    }
                    catch (Exception ex)
                    {
                        Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                        dbHelper.Rollback();
                        dbHelperSybase.Rollback();
                        foreach (var auditId in auditIds)
                            LogActionToAudit(new OrderedDictionary() { { "status", "Fail" } }, auditId);
                        throw;
                    }
                }

                dbHelper.Commit();
                dbHelperSybase.Commit();
                foreach (var auditId in auditIds)
                    LogActionToAudit(new OrderedDictionary() { { "status", "Success" } }, auditId);
                if (!string.IsNullOrWhiteSpace(filedata))
                {
                    filedata = string.Format("{0},{1},{2},{3}", "#ssm_id", "key", "value", Environment.NewLine) + filedata;                    
                    SaveFile(filedata, price_date, req.runEnviroment);
                }

                SendMail(retval.message);
            }
            catch (Exception ex)
            {
                retval.errorMessage = string.Format("Exception: {0}", ex.Message);
                Log.Error(retval.errorMessage, ex);
                dbHelper.Rollback();
                dbHelperSybase.Rollback();
            }
            finally
            {
                Log.Debug("Exit");
            }
            return retval;
        }

        public string ReadFiles(string runEnvironment)
        {
            var filesWIthTimeStamp = new List<string>();
            var fileDir = ConfigurationManager.AppSettings["AnalyticsDirPath_" + runEnvironment] + DateTime.Now.ToString("MMddyyyy") + "\\";
            bool exists = Directory.Exists(fileDir);
            if (exists)
            {
                var fileEntries =
                    new DirectoryInfo(fileDir).GetFiles()
                        .OrderByDescending(p => p.CreationTime)
                        .ToList();


                foreach (var file in fileEntries)
                {

                    var createdTime = File.GetCreationTime(fileDir + file.Name);
                    filesWIthTimeStamp.Add(fileDir + file.Name + "|" + createdTime);
                }
                if (filesWIthTimeStamp.Count >= 10)
                {
                    return string.Join(",", filesWIthTimeStamp.GetRange(0, 10));
                }
                return string.Join(",", filesWIthTimeStamp);
            }
            return string.Empty;

        }
        public bool SaveFile(string data, string pricedate, string runEnvironment)
        {
            bool status;

            try
            {
                var uniquId = Guid.NewGuid();
                var date = Convert.ToDateTime(pricedate).ToString("MMddyyyy");
                // File name should be of the format, sec_analytics.<price_date>.<cronus id>.txt
                var fileDir = ConfigurationManager.AppSettings["AnalyticsDirPath_" + runEnvironment] + DateTime.Now.ToString("MMddyyyy") + "\\";
                //var fileDir = @"C:\Users\ggupta\Downloads\cronus\Myfiles\" + DateTime.Now.ToString("MMddyyyy") + "\\";
                var fileName = "sec_analytics." + date + "." + uniquId + ".txt";
                var filePath = fileDir + fileName;


                bool exists = Directory.Exists(fileDir);
                if (!exists)
                {
                    Directory.CreateDirectory(fileDir);
                }


                File.WriteAllText(filePath, data);

                status = true;
            }

            catch (Exception ex)
            {
                if (ex.InnerException != null) Log.Error(ex.InnerException.Message);
                throw;
            }

            return status;

        }

        private void SendMail(string message)
        {
            try
            {

                // Send email confirmation after successful substitution of cusip.             
                string subject = string.Format("[{0}] Sec Analytic Override", ConfigManager.GetEnv());
                string body = string.Format("<b>Sec Analytic Override details</b>: <br/><br/><b>Result:</b><br/>");
                body += message.Replace("\n", "<br/>");

                body += "<br/>Thanks,<br/>Cronus<br/><br/>";

                List<string> mailIds = new List<string>();
                string to = GetMailIdOfUser(User);
                if (string.IsNullOrWhiteSpace(to))
                    to = string.Format("{0}@pimco.com", User);

                mailIds.Add(to);

                mailIds.AddRange(GetMailIdOfScreen(RunOnEnviroment));

                SendEmail(subject, body, string.Join(",", mailIds), ConfigManager.GetSendEmailFrom());
            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Exception: {0}", ex.Message), ex);
            }
        }

        public override ResponseBO CustomFunction(CustomFunctionBO req)
        {
            var retval = new TableDataResponseBO();
            //var retval = new TableDataResponseBO();
            try
            {
                var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                switch (req.functionName)
                {
                    case "FetchFIles":
                        {
                            retval.tableName = ReadFiles(req.runEnviroment);
                            break;
                        }

                    case "AnalyticSearch":
                        {
                            var data = json.Deserialize<List<SecAnalyticsOverrideBO.AddUpdateRequestBO>>(req.data.ToString());
                            if (data == null)
                                throw new Exception("Failed in Json Deserialization");

                            /*Validate data */
                            ValidateSecAnalyticsData(data);

                            var dbHelper = this.OracleDbHelper;
                            var erroMessage = string.Empty;
                            foreach (var sec_analytic in data)
                            {
                                var analytic_id = sec_analytic.analytic_id.Replace("manual_", "srm_");
                                var app_name_app_field_dic = GetAppField(analytic_id);
                                foreach (var app_name in app_name_app_field_dic.Keys)
                                {
                                    var query = String.Format("Select '{0}' Ssm_Id, '{1}' Analytic_Id, (Select {2} From {3} Where ssm_id = '{0}') as OldValue, '{4}' as NewValue,  '{5}' as backUp_Metric  , '{6}' as Note From dual"
                                    , sec_analytic.ssm_id, analytic_id.Replace("'", "''"), app_name_app_field_dic[app_name], app_name, sec_analytic.value.Replace("'", "''"), sec_analytic.backUp_Metric.Replace("'", "''"), sec_analytic.note.Replace("'", "''"));

                                    var query_data = dbHelper.ExecuteSelectQuery(query);
                                    foreach (var row in query_data.rows)
                                    {
                                        if (retval.rows == null) retval.rows = new List<List<object>>();
                                        retval.rows.Add(row);
                                    }
                                    retval.columns = query_data.columns;
                                }
                                if (app_name_app_field_dic.Count == 0)
                                {
                                    var query = String.Format("Select '{0}' Ssm_Id, '{1}' Analytic_Id, '' as OldValue, '{2}' as NewValue, '{3}' BackUp_Metric, '{4}' Note From dual"
                                    , sec_analytic.ssm_id, analytic_id.Replace("'", "''"), sec_analytic.value.Replace("'", "''"), sec_analytic.backUp_Metric.Replace("'", "''"), sec_analytic.note.Replace("'", "''"));

                                    var query_data = dbHelper.ExecuteSelectQuery(query);
                                    foreach (var row in query_data.rows)
                                    {
                                        if (retval.rows == null) retval.rows = new List<List<object>>();
                                        retval.rows.Add(row);
                                    }
                                    retval.columns = query_data.columns;
                                }
                            }


                            break;
                        }




                    default:
                        throw new Exception(string.Format("Unknown functionName {0}", req.functionName));

                }


            }
            catch (Exception ex)
            {

                retval.errorMessage = string.Format("Exception: {0}", ex.Message);
                Log.Error(retval.errorMessage, ex);
            }
            finally
            {
                Log.Debug("Exit");
            }
            return retval;
        }

    }
}
