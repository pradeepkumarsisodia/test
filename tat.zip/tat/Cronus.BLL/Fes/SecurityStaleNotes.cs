﻿﻿using System;
﻿using Cronus.BO.Fes;
using Cronus.BO;
using log4net;
﻿using System.Web.Script.Serialization;
using Cronus.Bll.Helper;
﻿using System.Collections.Specialized;

namespace Cronus.Bll.Fes
{
    public class SecurityStaleNotes : CronusBaseBll
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public override string ScreenName() { return Constants.SecurityStaleNotes; }
        public override object Clone() { return new SecurityStaleNotes(); }

        protected override string GetTableQuery(TableDataRequestBO requestData, out DatabaseType dbType)
        {
            dbType = DatabaseType.SYBASE;

            //Permission Check
            if (!Compliance.IsActionAllowed(User, requestData.screenName, Constants.SecurityStaleNotes_View, Url, requestData.runEnviroment))
                throw new Exception("Permission denied");


            var sql = "select ssm_id, app_user_id, code1, code2, code3, risk1, risk2, ref_tag, intex_problems, bb_problems, alt_sw, notes, last_chg_user, last_chg_date, expiration_date from pm..sec_notes";

            return sql;
        }


        private static void ManageSEC_NOTES(DatabaseHelper dbHelper, SecurityStaleNotesBO.SEC_NOTESData data, string action, string user)
        {
            string query;
            switch (action)
            {
                case "I":
                    query = string.Format("insert into pm..sec_notes( ssm_id, app_user_id, code1, code2, code3, risk1, risk2, ref_tag, intex_problems, bb_problems, " +
                                          "alt_sw, notes, last_chg_user, expiration_date)" +
                                          " values ('{0}' , {1} , {2} ,{3} , {4} , {5} , {6} , '{7}' , '{8}' , '{9}', '{10}', '{11}', '{12}', {13} )",
                                          data.SSMId.Replace("'", "''"), data.AppUserId,
                                          string.IsNullOrWhiteSpace(data.Code1) ? "0" : data.Code1,
                                         string.IsNullOrWhiteSpace(data.Code2) ? "0" : data.Code2,
                                         string.IsNullOrWhiteSpace(data.Code3) ? "0" : data.Code3,
                                         string.IsNullOrWhiteSpace(data.Risk1) ? "0" : data.Risk1,
                                         string.IsNullOrWhiteSpace(data.Risk2) ? "0" : data.Risk2,
                                         string.IsNullOrWhiteSpace(data.RefTag) ? "" : data.RefTag,
                                         string.IsNullOrWhiteSpace(data.IntexProblems) ? "" : data.IntexProblems,
                                         string.IsNullOrWhiteSpace(data.BBProblems) ? "" : data.BBProblems,
                                         string.IsNullOrWhiteSpace(data.AltSw) ? "" : data.AltSw,
                                         string.IsNullOrWhiteSpace(data.Notes) ? "" : data.Notes,
                                         user,
                                         string.IsNullOrWhiteSpace(data.ExpirationDate) ? "null" : "'" + data.ExpirationDate + "'");

                    break;
                case "U":
                    query = string.Format("update pm..sec_notes set code1 = {0}  , code2 = {1} , code3 = {2} , risk1 = {3} , risk2 = {4} , ref_tag = '{5}'" +
                                          " , intex_problems = '{6}' , bb_problems = '{7}' ,  alt_sw = '{8}' , notes = '{9}' , expiration_date = {10} , last_chg_user = '{11}'  " +
                                          "  where ssm_id = '{12}' and  app_user_id = {13}",
                         string.IsNullOrWhiteSpace(data.Code1) ? "0" : data.Code1,
                         string.IsNullOrWhiteSpace(data.Code2) ? "0" : data.Code2,
                         string.IsNullOrWhiteSpace(data.Code3) ? "0" : data.Code3,
                         string.IsNullOrWhiteSpace(data.Risk1) ? "0" : data.Risk1,
                         string.IsNullOrWhiteSpace(data.Risk2) ? "0" : data.Risk2,
                        string.IsNullOrWhiteSpace(data.RefTag) ? "" : data.RefTag,
                        string.IsNullOrWhiteSpace(data.IntexProblems) ? "" : data.IntexProblems,
                        string.IsNullOrWhiteSpace(data.BBProblems) ? "" : data.BBProblems,
                        string.IsNullOrWhiteSpace(data.AltSw) ? "" : data.AltSw,
                        string.IsNullOrWhiteSpace(data.Notes) ? "" : data.Notes,
                        string.IsNullOrWhiteSpace(data.ExpirationDate) ? "null" : "'" + data.ExpirationDate + "'",
                         user, data.SSMId, data.AppUserId);
                    break;

                case "D":
                    query = string.Format("delete from pm..sec_notes where  ssm_id = '{0}' and  app_user_id = {1} ", data.SSMId, data.AppUserId);
                    break;
                default:
                    throw new Exception(string.Format("Unknown action {0}", action));
            }
            dbHelper.ExecuteNonQuery(query);
        }


        public override ResponseBO UpdateDB(RequestBO req)
        {
            // Here you to pass table name and opertaion(add/edit) and data
            Log.Debug("Enter");
            var retval = new ResponseBO();
            var dbHelper = SybaseDbHelper;
            long auditId = 0;
            try
            {
                //Permission Check
                if (!Compliance.IsActionAllowed(User, req.screenName, Constants.ManageMasterTablesView, Url, req.runEnviroment))
                    throw new Exception("Permission denied");

                dbHelper.BeginTransaction();
                var json = new JavaScriptSerializer() { MaxJsonLength = Int32.MaxValue };
                var reqData = json.Deserialize<SecurityStaleNotesBO.UpdateRequestBO>(req.data.ToString());
                if (reqData == null)
                    throw new Exception("Failed in Json Deserialization");

                Log.InfoFormat("Update Request by User: {0}, {1}", User, reqData.TableName);

                auditId = LogActionToAudit(reqData.ToOrderedDictionary());
                ManageSEC_NOTES(dbHelper, reqData.SecNotesData, reqData.Action, User);
                dbHelper.Commit();
                LogActionToAudit(new OrderedDictionary() { { "status", "Success" } }, auditId);

            }
            catch (Exception ex)
            {
                retval.errorMessage = string.Format("Exception: {0}", ex.Message);
                Log.Error(retval.errorMessage, ex);
                dbHelper.Rollback();
                LogActionToAudit(new OrderedDictionary() { { "status", "Fail" } }, auditId);
            }
            finally
            {
                Log.Debug("Exit");
            }
            return retval;
        }

    }
}
