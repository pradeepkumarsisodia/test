﻿using System;
using System.Collections.Generic;
using System.Linq;
using log4net;
using Cronus.BO;
using Cronus.Bll.Helper;
using System.Web.Script.Serialization;
using Cronus.BO.Fes;
using System.Collections.Specialized;

namespace Cronus.Bll.Fes
{
    public class RiskMeasureOverride : CronusBaseBll
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public override object Clone() { return new RiskMeasureOverride(); }

        private Dictionary<string, string> riskMeasuresAnalyticIdMappingDic = new Dictionary<string, string>();

        public override string ScreenName()
        {
            return Constants.RiskMeasureOverride;
        }

        protected override string GetTableQuery(TableDataRequestBO requestData, out DatabaseType dbType)
        {
            dbType = DatabaseType.SYBASE;

            var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
            RiskMeasureOverrideBO.SearchRequestBO data = json.Deserialize<RiskMeasureOverrideBO.SearchRequestBO>(requestData.data.ToString());

            string ssmId = data.ssmId;
            string tab = data.tab;

            log.Info(string.Format("Select Request for ssm_id = {0}", ssmId));
            string cusipWithQuotes = string.Join(",", ssmId.Split(',').ToList<string>().Select(s => "'" + s.Trim() + "'"));

            string query;
            switch (tab)
            {
                case "B":
                    //Permission Check
                    if (!Compliance.IsActionAllowed(User, requestData.screenName, Constants.RiskMeasureOverrideViewAnalytics, Url, requestData.runEnviroment))
                        throw new Exception("Permission denied to view data for analytics");

                    query = string.Format("select  ssm_id as cusip, duration, f1 as delta,  case when f2 = 1 then 'Y' else 'N' end as backup_metric, notes, init_bum_class_code as bum_code, init_bum_sub_code as bum_sub_code,  init_ind_country as country, init_ind_code1 as code1, init_ind_code2 as code2, init_ind_code3 as code3  from pm..manual_durations_stage Where ssm_id in ({0})", cusipWithQuotes);
                    break;
                case "S":
                    //Permission Check
                    if (!Compliance.IsActionAllowed(User, requestData.screenName, Constants.RiskMeasureOverrideViewAnalytics, Url, requestData.runEnviroment))
                        throw new Exception("Permission denied to view data for analytics");

                    query = string.Format("select  cusip, duration,  curve_type, provider_id,  backup_metric, '' as notes, oas_is_input, ytm, ytw,oas, price, convert(varchar(20),price_date, 101) as price_date, convexity from pm..manual_scen_durations Where cusip in ({0})", cusipWithQuotes);
                    break;
                case "T":
                    //Permission Check
                    if (!Compliance.IsActionAllowed(User, requestData.screenName, Constants.RiskMeasureOverrideViewTraders, Url, requestData.runEnviroment))
                        throw new Exception("Permission denied to view data for traders");

                    Dictionary<string, string> cusipIsinDict = GetIsinCusipMapping(ssmId.Split(',').ToList());
                    if (cusipIsinDict.Values.Count > 0)
                        cusipWithQuotes += "," + string.Join(",", cusipIsinDict.Values.Select(s => "'" + s.Trim() + "'"));
                    query = "select t1.cusip, isnull(sc.isin,'') isin, t1.price, t1.duration, t2.duration spread_duration, t1.oas, t2.provider_id, t1.backup_metric from "
                            + " (select a.cusip, a.duration, a.oas, a.price, a.backup_metric from pm..manual_scen_durations a "
                            + " where (exists (select 1 from pm..beta_corp_by_security b where a.cusip = b.ssm_id and a.curve_type = b.curve_type) "
                            + " or not exists (select 1 from pm..beta_corp_by_security b where a.cusip = b.ssm_id)) and a.cusip in (" + cusipWithQuotes + ") "
                            + " and a.provider_id = 'BASE') t1 "
                            + " join "
                            + " (select a.cusip, a.duration, a.provider_id from pm..manual_scen_durations a "
                            + " where (exists (select 1 from pm..beta_corp_by_security b where a.cusip = b.ssm_id and a.curve_type = b.curve_type) "
                            + " or not exists (select 1 from pm..beta_corp_by_security b where a.cusip = b.ssm_id)) and a.cusip in (" + cusipWithQuotes + ") "
                            + " and a.provider_id in ('SPRD', 'NSPRD') ) t2 "
                            + " on (t1.cusip = t2.cusip) "
                            + " left join taps..ssm_core sc on (sc.ssm_id = t2.cusip)";
                    break;
                default:
                    throw new Exception("Unknown tab");
            }

            return query;
        }

        private Dictionary<string, string> GetIsinCusipMapping(List<string> isinList)
        {
            log.Debug("Enter");
            Dictionary<string, string> isinCusipDic = new Dictionary<string, string>();
            string isinWithQuotes = string.Join(",", isinList.Where(s => !string.IsNullOrEmpty(s)).Select(s => "'" + s.Trim() + "'"));
            //check if atleast one isin is present
            if (string.IsNullOrEmpty(isinWithQuotes))
                return isinCusipDic;

            string query = string.Format("select isin, cusip from taps..ssm_core where isin in ({0})", isinWithQuotes);
            var result = this.SybaseDbHelper.ExecuteSelectQuery(query);

            //Starting from first as first row is header row.
            for (int i = 0; i < result.rows.Count; i++)
            {
                string isin = Convert.ToString(result.rows[i][0]);
                string cusip = Convert.ToString(result.rows[i][1]);
                //for one isin there can be more than 1 cusips
                if (isinCusipDic.ContainsKey(isin))
                    isinCusipDic[isin] = isinCusipDic[isin] + "," + cusip;
                else
                    isinCusipDic[isin] = cusip;
            }

            log.Debug("Exit");

            return isinCusipDic;
        }

        private List<string> GetValidCuipList(List<string> cusipList)
        {
            log.Debug("Enter");
            var validCusips = new List<string>();
            string cusipWithQuotes = string.Join(",", cusipList.Where(s => !string.IsNullOrEmpty(s)).Select(s => "'" + s.Trim() + "'"));
            //check if atleast one isin is present
            if (string.IsNullOrEmpty(cusipWithQuotes))
                return validCusips;

            string query = string.Format("select cusip from taps..ssm_core where cusip in ({0})", cusipWithQuotes);
            var result = SybaseDbHelper.ExecuteSelectQuery(query);

            //Starting from first as first row is header row.
            for (var i = 0; i < result.rows.Count; i++)
            {
                validCusips.Add(Convert.ToString(result.rows[i][0]));
            }

            log.Debug("Exit");

            return validCusips;
        }

        private string GetAnalyticId(string providerId, string riskMeasure)
        {
            string retVal = string.Empty;

            string key = providerId + "_" + riskMeasure;
            if (!riskMeasuresAnalyticIdMappingDic.ContainsKey(key))
            {
                if (riskMeasuresAnalyticIdMappingDic.Count() == 0)
                {
                    string query = string.Format("SELECT distinct key, value FROM CRONUS_OWN.CONFIG WHERE ScreenID = '{0}' and Context = '{1}' ORDER BY key "
                    , ScreenName(), "ANALYTIC_ID_MAPPING");
                    var result = this.OracleDbHelper.ExecuteSelectQuery(query);

                    //Starting from first as first row is header row.
                    for (var i = 0; i < result.rows.Count; i++)
                    {
                        riskMeasuresAnalyticIdMappingDic[Convert.ToString(result.rows[i][0])] = Convert.ToString(result.rows[i][1]);
                    }
                }
            }

            if (riskMeasuresAnalyticIdMappingDic.ContainsKey(key)) retVal = riskMeasuresAnalyticIdMappingDic[key];

            return retVal;

        }

        private void ManageScenarioRiskMeasures(List<RiskMeasureOverrideBO.ScenarioRiskMeasureBO> riskMeasureOverrideList, string action)
        {
            log.Debug("Enter");
            string errorMessage = "";
            try
            {
                //validate cusips for which isin is not populated
                List<string> cusipList = new List<string>();
                foreach (var obj in riskMeasureOverrideList)
                {
                    if (!cusipList.Contains(obj.CUSIP))
                        cusipList.Add(obj.CUSIP);
                }
                if (action != "D")
                {
                    //get the isin for each cusip
                    List<string> validCusip = GetValidCuipList(cusipList);
                    ////iterate the tradersRiskMeasureOverrideList and validate for each isin.
                    ////if cusip is populated & isin is null, isin should exists in cusipIsinDic.
                    foreach (var obj in riskMeasureOverrideList)
                    {
                        if (!validCusip.Contains(obj.CUSIP))
                            errorMessage += string.Format("Invalid cusip {0} \n", obj.CUSIP);
                    }
                }

                if (string.IsNullOrEmpty(errorMessage))
                {
                    var auditIds = new List<long>();
                    SybaseDbHelper.BeginTransaction();
                    try
                    {
                        foreach (var riskMeasures in riskMeasureOverrideList)
                        {

                            var auditId = LogActionToAudit(new OrderedDictionary
                            { { "Action", action }, { "SSM_ID", riskMeasures.CUSIP }, { "ProviderId", riskMeasures.PROVIDER_ID }
                                                                                    , { "CurveType", riskMeasures.CURVE_TYPE }, {"Duration", riskMeasures.DURATION}, {"Price", riskMeasures.PRICE } 
                                                                                    , {"PriceDate", riskMeasures.PRICE_DATE}, {"Convexity", riskMeasures.CONVEXITY}, {"Oas", riskMeasures.OAS} 
                                                                                    , {"Ytm", riskMeasures.YTM}, {"Ytw", riskMeasures.YTW}, {"BackupMetric", riskMeasures.BACKUP_MATRIC}, {"Note", riskMeasures.NOTES}});
                            auditIds.Add(auditId);

                            double price = string.IsNullOrEmpty(riskMeasures.PRICE) ? GetPrice(riskMeasures.CUSIP, riskMeasures.PRICE_DATE) : Convert.ToDouble(riskMeasures.PRICE);
                            double duration = string.IsNullOrEmpty(riskMeasures.DURATION) ? 0 : Convert.ToDouble(riskMeasures.DURATION);
                            double convexity = string.IsNullOrEmpty(riskMeasures.CONVEXITY) ? 0 : Convert.ToDouble(riskMeasures.CONVEXITY);
                            double oas = string.IsNullOrEmpty(riskMeasures.OAS) ? 0 : Convert.ToDouble(riskMeasures.OAS);
                            double ytm = string.IsNullOrEmpty(riskMeasures.YTM) ? 0 : Convert.ToDouble(riskMeasures.YTM);
                            double ytw = string.IsNullOrEmpty(riskMeasures.YTW) ? 0 : Convert.ToDouble(riskMeasures.YTW);
                            DateTime priceDate = string.IsNullOrEmpty(riskMeasures.PRICE_DATE) ? DateTime.Now : Convert.ToDateTime(riskMeasures.PRICE_DATE);

                            UpdateManualScenDurations(action, riskMeasures.BACKUP_MATRIC
                                                , riskMeasures.CUSIP, riskMeasures.PROVIDER_ID, Convert.ToInt32(riskMeasures.CURVE_TYPE), riskMeasures.OAS_IS_INPUT
                                                , duration, price, priceDate, convexity, oas, ytm, ytw);

                            //Get analytic_id correspond to provider_id and risk measures
                            var analytic_id = GetAnalyticId(riskMeasures.PROVIDER_ID, "DURATION");
                            if (!string.IsNullOrWhiteSpace(analytic_id)) UpdateSecAnalyticsOverride(action, riskMeasures.CUSIP, analytic_id, duration, "", riskMeasures.BACKUP_MATRIC, riskMeasures.NOTES);
                            analytic_id = GetAnalyticId(riskMeasures.PROVIDER_ID, "OAS");
                            if (!string.IsNullOrWhiteSpace(analytic_id)) UpdateSecAnalyticsOverride(action, riskMeasures.CUSIP, analytic_id, oas, "", riskMeasures.BACKUP_MATRIC, riskMeasures.NOTES);
                            analytic_id = GetAnalyticId(riskMeasures.PROVIDER_ID, "YTM");
                            if (!string.IsNullOrWhiteSpace(analytic_id)) UpdateSecAnalyticsOverride(action, riskMeasures.CUSIP, analytic_id, ytm, "", riskMeasures.BACKUP_MATRIC, riskMeasures.NOTES);
                            analytic_id = GetAnalyticId(riskMeasures.PROVIDER_ID, "YTW");
                            if (!string.IsNullOrWhiteSpace(analytic_id)) UpdateSecAnalyticsOverride(action, riskMeasures.CUSIP, analytic_id, ytw, "", riskMeasures.BACKUP_MATRIC, riskMeasures.NOTES);
                            analytic_id = GetAnalyticId(riskMeasures.PROVIDER_ID, "CONVEXITY");
                            if (!string.IsNullOrWhiteSpace(analytic_id)) UpdateSecAnalyticsOverride(action, riskMeasures.CUSIP, analytic_id, convexity, "", riskMeasures.BACKUP_MATRIC, riskMeasures.NOTES);
                            analytic_id = GetAnalyticId(riskMeasures.PROVIDER_ID, "PRICE");
                            if (!string.IsNullOrWhiteSpace(analytic_id)) UpdateSecAnalyticsOverride(action, riskMeasures.CUSIP, analytic_id, price, "", riskMeasures.BACKUP_MATRIC, riskMeasures.NOTES);
                        }
                        foreach (long auditId in auditIds)
                            LogActionToAudit(new OrderedDictionary { { "Status", "Success" } }, auditId);
                        this.SybaseDbHelper.Commit();
                        this.OracleDbHelper.Commit();
                    }
                    catch (Exception ex)
                    {
                        log.Error("Exception Message : " + ex.Message, ex);
                        this.SybaseDbHelper.Rollback();
                        this.OracleDbHelper.Rollback();
                        foreach (long auditId in auditIds)
                            LogActionToAudit(new OrderedDictionary { { "Status", "Fail" } }, auditId);
                        throw;
                    }
                }
                else
                {
                    throw new Exception(errorMessage);
                }
            }
            catch (Exception ex)
            {
                log.Error("Exception Message : " + ex.Message, ex);
                throw;
            }
            finally
            {
                log.Debug("Exit");
            }
        }

        private void ManageBaseRiskMeasures(List<RiskMeasureOverrideBO.BaseRiskMeasureBO> baseRiskMeasureOverrideList, string action)
        {
            log.Debug("Enter");
            string errorMessage = "";
            try
            {
                //validate cusips for which isin is not populated
                List<string> cusipList = new List<string>();
                foreach (var obj in baseRiskMeasureOverrideList)
                {
                    if (!cusipList.Contains(obj.SSM_ID))
                        cusipList.Add(obj.SSM_ID);
                }
                if (action != "D")
                {
                    //get the isin for each cusip
                    List<string> validCusip = GetValidCuipList(cusipList);

                    ////iterate the tradersRiskMeasureOverrideList and validate for each isin.
                    ////if cusip is populated & isin is null, isin should exists in cusipIsinDic.
                    foreach (var obj in baseRiskMeasureOverrideList)
                    {
                        if (!validCusip.Contains(obj.SSM_ID))
                            errorMessage += string.Format("Invalid cusip {0} \n", obj.SSM_ID);
                    }
                }

                if (string.IsNullOrEmpty(errorMessage))
                {
                    this.SybaseDbHelper.BeginTransaction();
                    List<long> auditIds = new List<long>();
                    try
                    {
                        foreach (var baseRiskMeasures in baseRiskMeasureOverrideList)
                        {
                            auditIds.Add(LogActionToAudit(new OrderedDictionary
                            { { "Action", action }, { "SSM_ID", baseRiskMeasures.SSM_ID }, { "Duration", baseRiskMeasures.DURATION }
                                                                                    , { "Delta", baseRiskMeasures.DELTA }, { "BackupMetrix", baseRiskMeasures.BACKUP_MATRIC }, { "Note", baseRiskMeasures.NOTES } }));

                            UpdateManualDurations(action, baseRiskMeasures.BACKUP_MATRIC
                                                , baseRiskMeasures.SSM_ID, Convert.ToDouble(baseRiskMeasures.DURATION)
                                                , string.IsNullOrEmpty(baseRiskMeasures.DELTA) ? 0 : Convert.ToDouble(baseRiskMeasures.DELTA));

                            //update oracle sec_analytics_override table.
                            var analytic_id = GetAnalyticId("", "DURATION");
                            if (!string.IsNullOrWhiteSpace(analytic_id)) UpdateSecAnalyticsOverride(action, baseRiskMeasures.SSM_ID, analytic_id, Convert.ToDouble(baseRiskMeasures.DURATION), "", baseRiskMeasures.BACKUP_MATRIC, baseRiskMeasures.NOTES);
                            analytic_id = GetAnalyticId("", "OPTION_DELTA");
                            if (!string.IsNullOrWhiteSpace(analytic_id)) UpdateSecAnalyticsOverride(action, baseRiskMeasures.SSM_ID, analytic_id, Convert.ToDouble(baseRiskMeasures.DELTA), "", baseRiskMeasures.BACKUP_MATRIC, baseRiskMeasures.NOTES);

                        }

                        foreach (long auditId in auditIds)
                            LogActionToAudit(new OrderedDictionary { { "Status", "Success" } }, auditId);

                        this.SybaseDbHelper.Commit();
                        this.OracleDbHelper.Commit();
                    }
                    catch (Exception ex)
                    {
                        log.Error("Exception Message : " + ex.Message, ex);
                        this.SybaseDbHelper.Rollback();
                        this.OracleDbHelper.Rollback();
                        foreach (long auditId in auditIds)
                            LogActionToAudit(new OrderedDictionary { { "Status", "Fail" } }, auditId);

                        throw;
                    }
                }
                else
                {
                    throw new Exception(errorMessage);
                }
            }
            catch (Exception ex)
            {
                log.Error("Exception, Message : " + ex.Message, ex);
                throw;
            }
            finally
            {
                log.Debug("Exit");
            }
        }

        private string ValidaTradeRiskMeasures(List<RiskMeasureOverrideBO.TradersRiskMeasureBO> tradersRiskMeasureOverrideList)
        {
            string errorMessage = "";
            List<string> isinList = new List<string>();

            //Validate isin first
            foreach (var tradersRiskMeasures in tradersRiskMeasureOverrideList)
            {
                isinList.Add(tradersRiskMeasures.ISIN);
            }
            //get the cusips for each isin. in case of multiple cusips cusip will be sepearted by ,
            Dictionary<string, string> isinCusipDic = GetIsinCusipMapping(isinList);

            //iterate the tradersRiskMeasureOverrideList and validate for each isin.
            //if isin is populated & cuips is null, isin should exists in isinCusipDic and there should be only one cusip assigned to it.
            //if isin is populated & cuips is populated, isin should exists in isinCusipDic and cusip should assign to it.
            foreach (var tradersRiskMeasures in tradersRiskMeasureOverrideList)
            {
                if (!string.IsNullOrEmpty(tradersRiskMeasures.ISIN) && isinCusipDic.ContainsKey(tradersRiskMeasures.ISIN))
                {
                    if (string.IsNullOrEmpty(tradersRiskMeasures.SSM_ID) && isinCusipDic[tradersRiskMeasures.ISIN].Contains(','))
                        errorMessage += string.Format("Multiple cusips for isin {0} \n", tradersRiskMeasures.ISIN);
                    if (!string.IsNullOrEmpty(tradersRiskMeasures.SSM_ID) && !isinCusipDic[tradersRiskMeasures.ISIN].Contains(tradersRiskMeasures.SSM_ID))
                        errorMessage += string.Format("Not a valid cusips {0} and isin {1} combination\n", tradersRiskMeasures.SSM_ID, tradersRiskMeasures.ISIN);
                }
                else if (!string.IsNullOrEmpty(tradersRiskMeasures.ISIN))
                    errorMessage += string.Format("Invalid isin {0} \n", tradersRiskMeasures.ISIN);
            }

            //validate cusips for which isin is not populated
            //List<string> cusipList = new List<string>();
            //foreach (var tradersRiskMeasures in tradersRiskMeasureOverrideList)
            //{
            //    if (string.IsNullOrEmpty(tradersRiskMeasures.ISIN))
            //        cusipList.Add(tradersRiskMeasures.SSM_ID);
            //}
            //get the isin for each cusip
            //List<string> validCusip = GetValidCuipList(cusipList);

            //iterate the tradersRiskMeasureOverrideList and validate for each isin.
            //if cusip is populated & isin is null, isin should exists in cusipIsinDic.
            //foreach (var tradersRiskMeasures in tradersRiskMeasureOverrideList)
            //{
            //    if (!string.IsNullOrEmpty(tradersRiskMeasures.SSM_ID) && !validCusip.Contains(tradersRiskMeasures.SSM_ID) && cusipList.Contains(tradersRiskMeasures.SSM_ID))
            //        errorMessage += string.Format("Invalid cusip {0} \n", tradersRiskMeasures.SSM_ID);
            //}
            return errorMessage;
        }

        // retrun should be string as return can be error or success AMJAIN
        private void ManageTradersRiskMeasures(List<RiskMeasureOverrideBO.TradersRiskMeasureBO> tradersRiskMeasureOverrideList, string action)
        {
            log.Debug("Enter");
            try
            {
                var errorMessage = ValidaTradeRiskMeasures(tradersRiskMeasureOverrideList);
                if (string.IsNullOrEmpty(errorMessage))
                {
                    //manual_scen_duration rows and manual_durations_stage rows
                    //Row for provider_id BASE and curve_type 0
                    //Row for provider_id BASE and curve_type 100
                    //Row for provider_id if mortgage NSPRD else SPRD and curve_type 0
                    //Row for provider_id if mortgage NSPRD else SPRD and curve_type 100
                    this.SybaseDbHelper.BeginTransaction();
                    List<long> auditIds = new List<long>();
                    try
                    {
                        foreach (var tradersRiskMeasures in tradersRiskMeasureOverrideList)
                        {
                            auditIds.Add(LogActionToAudit(new OrderedDictionary
                            {{ "Action", action }, { "SSM_ID", tradersRiskMeasures.SSM_ID }, { "Isin", tradersRiskMeasures.ISIN }
                                                                                    , { "Price", tradersRiskMeasures.PRICE }, {"Duration", tradersRiskMeasures.DURATION}, {"SpreadDuration", tradersRiskMeasures.SPREAD_DURATION } 
                                                                                    , {"Oas", tradersRiskMeasures.OAS}, {"Mortgage", tradersRiskMeasures.IS_MORTGAGE_SECURITY}, {"HardDuration", tradersRiskMeasures.HARD_DURATION} }));

                            var cusip = tradersRiskMeasures.SSM_ID;
                            if (string.IsNullOrEmpty(cusip))
                            {
                                List<string> tmp = new List<string>();
                                tmp.Add(tradersRiskMeasures.ISIN);
                                cusip = GetIsinCusipMapping(tmp)[tradersRiskMeasures.ISIN];

                            }
                            DeleteFromManualScenDurations(cusip);
                            switch (action)
                            {
                                case "D":
                                    UpdateManualDurations(action, (tradersRiskMeasures.HARD_DURATION == "Y" ? "N" : "Y")
                                        , cusip, Convert.ToDouble(tradersRiskMeasures.DURATION));
                                    UpdateSecAnalyticsOverride(action, cusip, "", 0, "", "", "");
                                    break;
                                case "U":
                                    double price = string.IsNullOrEmpty(tradersRiskMeasures.PRICE) ? 100 : Convert.ToDouble(tradersRiskMeasures.PRICE);

                                    UpdateManualScenDurations(action, (tradersRiskMeasures.HARD_DURATION == "Y" ? "N" : "Y")
                                        , cusip, "BASE", 0, "N", Convert.ToDouble(tradersRiskMeasures.DURATION), price, DateTime.Now, 0, Convert.ToDouble(tradersRiskMeasures.OAS));

                                    UpdateManualScenDurations(action, (tradersRiskMeasures.HARD_DURATION == "Y" ? "N" : "Y")
                                        , cusip, "BASE", 100, "N", Convert.ToDouble(tradersRiskMeasures.DURATION), price, DateTime.Now, 0, Convert.ToDouble(tradersRiskMeasures.OAS));

                                    UpdateManualScenDurations(action, (tradersRiskMeasures.HARD_DURATION == "Y" ? "N" : "Y")
                                        , cusip, (tradersRiskMeasures.IS_MORTGAGE_SECURITY == "Y" ? "SPRD" : "NSPRD"), 0, "N"
                                        , (tradersRiskMeasures.IS_MORTGAGE_SECURITY == "Y" ? Convert.ToDouble(tradersRiskMeasures.SPREAD_DURATION) : Convert.ToDouble(tradersRiskMeasures.SPREAD_DURATION))
                                        , price, DateTime.Now, 0, Convert.ToDouble(tradersRiskMeasures.OAS));

                                    UpdateManualScenDurations(action, (tradersRiskMeasures.HARD_DURATION == "Y" ? "N" : "Y")
                                        , cusip, (tradersRiskMeasures.IS_MORTGAGE_SECURITY == "Y" ? "SPRD" : "NSPRD"), 100, "N"
                                        , (tradersRiskMeasures.IS_MORTGAGE_SECURITY == "Y" ? Convert.ToDouble(tradersRiskMeasures.SPREAD_DURATION) : Convert.ToDouble(tradersRiskMeasures.SPREAD_DURATION))
                                        , price, DateTime.Now, 0, Convert.ToDouble(tradersRiskMeasures.OAS));

                                    UpdateManualDurations(action, (tradersRiskMeasures.HARD_DURATION == "Y" ? "N" : "Y")
                                        , cusip, Convert.ToDouble(tradersRiskMeasures.DURATION));

                                    //update oracle sec_analytics_override table.
                                    //Duration
                                    var analytic_id = GetAnalyticId("", "DURATION");
                                    if (!string.IsNullOrWhiteSpace(analytic_id)) UpdateSecAnalyticsOverride(action, cusip, analytic_id, Convert.ToDouble(tradersRiskMeasures.DURATION), "", tradersRiskMeasures.HARD_DURATION == "Y" ? "N" : "Y");
                                    //Base Duration
                                    analytic_id = GetAnalyticId("BASE", "DURATION");
                                    if (!string.IsNullOrWhiteSpace(analytic_id)) UpdateSecAnalyticsOverride(action, cusip, analytic_id, Convert.ToDouble(tradersRiskMeasures.DURATION), "", tradersRiskMeasures.HARD_DURATION == "Y" ? "N" : "Y");
                                    //Spread Duration
                                    analytic_id = GetAnalyticId((tradersRiskMeasures.IS_MORTGAGE_SECURITY == "Y" ? "SPRD" : "NSPRD"), "DURATION");
                                    if (!string.IsNullOrWhiteSpace(analytic_id)) UpdateSecAnalyticsOverride(action, cusip, analytic_id, Convert.ToDouble(tradersRiskMeasures.SPREAD_DURATION), "", tradersRiskMeasures.HARD_DURATION == "Y" ? "N" : "Y");
                                    //OAS
                                    analytic_id = GetAnalyticId("BASE", "OAS");
                                    if (!string.IsNullOrWhiteSpace(analytic_id)) UpdateSecAnalyticsOverride(action, cusip, analytic_id, Convert.ToDouble(tradersRiskMeasures.OAS), "", tradersRiskMeasures.HARD_DURATION == "Y" ? "N" : "Y");
                                    //PRICE
                                    analytic_id = GetAnalyticId("BASE", "PRICE");
                                    if (!string.IsNullOrWhiteSpace(analytic_id)) UpdateSecAnalyticsOverride(action, cusip, analytic_id, price, "", tradersRiskMeasures.HARD_DURATION == "Y" ? "N" : "Y");

                                    break;
                                default:
                                    throw new Exception("Invalid Action");
                            }



                        }
                        foreach (long auditId in auditIds)
                            LogActionToAudit(new OrderedDictionary { { "Status", "Success" } }, auditId);
                        this.SybaseDbHelper.Commit();
                        this.OracleDbHelper.Commit();
                    }
                    catch (Exception ex)
                    {
                        log.Error("Exception Message : " + ex.Message, ex);
                        this.SybaseDbHelper.Rollback();
                        this.OracleDbHelper.Rollback();
                        foreach (long auditId in auditIds)
                            LogActionToAudit(new OrderedDictionary { { "Status", "Fail" } }, auditId);
                        throw;
                    }
                }
                else
                {
                    throw new Exception(errorMessage);
                }
            }
            catch (Exception ex)
            {
                log.Error("Exception Message : " + ex.Message, ex);
                throw;
            }
            finally
            {
                log.Debug("Exit");
            }
        }

        private double GetPrice(string ssmId, string priceDate)
        {
            log.Debug("Enter");
            var price = 0.0;
            try
            {
                string query = "select price from pimco..prh where cusip = '" + ssmId + "'   and provider_id = 'PIMCO' and price_date = '" + priceDate + "' ";
                var result = SybaseDbHelper.ExecuteSelectQuery(query);
                if (result.rows.Count > 0)
                {
                    price = Convert.ToDouble(result.rows[0][0]);
                    log.InfoFormat("Price {0}  for CUSIP {1}", price, ssmId);
                }
                else
                {
                    query = "select price from pm..sec_master where ssm_id = '" + ssmId + "' ";
                    result = SybaseDbHelper.ExecuteSelectQuery(query);
                    if (result.rows.Count > 0)
                    {
                        price = Convert.ToDouble(result.rows[0][0]);
                        log.InfoFormat("Price {0}  for ssm_id {1}", price, ssmId);
                    }
                    else
                        throw new Exception("Price not found neither in pimco..prh nor in  pm..sec_master ");
                }
            }
            catch (Exception ex)
            {
                log.Error("Exception : " + ex.Message, ex);
                throw;
            }
            finally
            {
                log.Debug("Exit");
            }
            return price;
        }

        protected override string GetDropDownDataQuery(string fieldName, DropDownRequestBO requestData, out DatabaseType dbType)
        {
            dbType = DatabaseType.SYBASE;
            string query = "";
            if (fieldName == "PROVIDER_ID")
                query = "select alias, risk_attribute from pm..risk_attributes";
            else if (fieldName == "CURVE_TYPE")
            {
                query = "select ssm_id, curve_type from pm..beta_corp_by_security";
                JavaScriptSerializer json = new JavaScriptSerializer();
                json.MaxJsonLength = Int32.MaxValue;
                RiskMeasureOverrideBO.SearchRequestBO data = json.Deserialize<RiskMeasureOverrideBO.SearchRequestBO>(requestData.data.ToString());
                if (data == null)
                    throw new Exception("Failed in Json Deserialization");

                string ssmIds = data.ssmId;
                if (!string.IsNullOrEmpty(ssmIds))
                {
                    string cusipWithQuotes = string.Join(",", ssmIds.Split(',').ToList<string>().Select(s => "'" + s.Trim() + "'"));
                    query += string.Format(" where ssm_id in ({0})", cusipWithQuotes);
                }
            }
            else
                throw new Exception(string.Format("Wrong fieldName: {0}", fieldName));

            return query;
        }

        private void GetValuesFromSmAndSrm(string ssmId, out int initBumClassCode, out int initBumSubCode,
                                      out int initIndCountry, out int initIndCode1, out int initIndCode2, out int initIndCode3)
        {
            log.Debug("Enter");
            initIndCountry = 0;
            initBumSubCode = 0;
            initBumClassCode = 0;
            initIndCode1 = 0;
            initIndCode2 = 0;
            initIndCode3 = 0;
            try
            {
                string sql = "select industry_code1,industry_code2,industry_code3, industry_country from pm..sec_master where ssm_id='" + ssmId + "'";
                var result = this.SybaseDbHelper.ExecuteSelectQuery(sql);
                if (result.rows.Count > 0)
                {
                    initIndCode1 = Convert.ToInt32(result.rows[0][0]);
                    initIndCode2 = Convert.ToInt32(result.rows[0][1]);
                    initIndCode3 = Convert.ToInt32(result.rows[0][2]);
                    initIndCode3 = Convert.ToInt32(result.rows[0][3]);
                    log.InfoFormat("SSM_ID {0} Industry_code1 {1} Industry_code2 {2} Industry_code3 {3} Industry_country {4}",
                                ssmId, initIndCode1, initIndCode2, initIndCode3, initIndCountry);
                }
                else
                {
                    log.InfoFormat("SSM_ID {0} Not found in pm..sec_master", ssmId);
                }

                sql = "select bum_class_code,bum_sub_code from pm..sec_risk_measures where ssm_id ='" + ssmId + "'";
                result = this.SybaseDbHelper.ExecuteSelectQuery(sql);
                if (result.rows.Count > 0)
                {
                    initBumClassCode = Convert.ToInt32(result.rows[0][0]);
                    initBumSubCode = Convert.ToInt32(result.rows[0][1]);
                    log.InfoFormat("SSM_ID {0} Bum_Class_Code {1} Bum,_Sub_code {2}", ssmId, initBumClassCode, initBumSubCode);
                }
                else
                {
                    log.InfoFormat("SSM_ID {0} Not found in pm..sec_risk_measures", ssmId);
                }
            }
            catch (Exception ex)
            {
                log.Error("Exception : " + ex.Message, ex);
                throw;
            }
            finally
            {
                log.Debug("Exit");
            }
        }


        private void DeleteFromManualScenDurations(string cusip)
        {
            log.Debug("Enter");

            string queryDelete = string.Format("delete pm..manual_scen_durations  from  pm..manual_scen_durations where cusip = '{0}' ", cusip);

            this.SybaseDbHelper.ExecuteNonQuery(queryDelete);

            log.Debug("Exit");
        }

        private void DeleteFromManualDurations(string cusip)
        {
            log.Debug("Enter");

            string queryDelete = string.Format("delete pm..manual_durations_stage  from  pm..manual_durations_stage where ssm_id = '{0}' ", cusip);

            this.SybaseDbHelper.ExecuteNonQuery(queryDelete);

            log.Debug("Exit");
        }

        private void UpdateManualScenDurations(string action, string backupMetric, string cusip, string providerId
                                                    , int curveType, string oasIsInput, double duration, double price
            , DateTime priceDate = new DateTime(), double convexity = 0.00, double oas = 0.00, double ytm = 0.00, double ytw = 0.00)
        {
            log.Debug("Enter");

            //Delete from manual_durations_stage
            string queryDelete = string.Format("delete pm..manual_scen_durations  from  pm..manual_scen_durations " +
                " where cusip = '{0}' and provider_id = '{1}' and curve_type = {2} and oas_is_input = '{3}'", cusip, providerId, curveType, oasIsInput);
            this.SybaseDbHelper.ExecuteNonQuery(queryDelete);

            if (action == "U")
            {
                string queryInsert = string.Format("insert into pm..manual_scen_durations( " +
                      "price_date, cusip, curve_type, provider_id, oas_is_input, price, duration, backup_metric, convexity, oas, ytm, ytw, source_code, last_chg_user)" +
                      "values('{0}','{1}',{2},'{3}','{4}',{5},{6},'{7}',{8},{9},{10},{11},'{12}','{13}')"
                      , priceDate.Equals(new DateTime()) ? DateTime.Now.Date.ToShortDateString() : priceDate.Date.ToShortDateString()
                      , cusip, curveType, providerId, oasIsInput, price, duration, backupMetric, convexity, oas, ytm, ytw, "CRONS", User);
                this.SybaseDbHelper.ExecuteNonQuery(queryInsert);
            }

            log.Debug("Exit");
        }

        private void UpdateManualDurations(string action, string backupMetric, string cusip
            , double duration, double optionDelta = double.NaN, string notes = "")
        {
            log.Debug("Enter");
            int bkupMetrc = backupMetric == "N" ? 0 : 1;
            if (action == "D")
            {
                DeleteFromManualDurations(cusip);
            }
            else if (action == "U")
            {
                //update first if no row return do insert
                string queryUpdate = string.Format("update pm..manual_durations_stage set duration = {0}, f2 = {1}, last_chg_user = '{2}' ,last_chg_date =  getdate() where ssm_id = '{3}'", duration, bkupMetrc, User, cusip);
                if (!optionDelta.Equals(double.NaN))
                    queryUpdate = string.Format("update pm..manual_durations_stage set duration = {0}, f1 = {1}, f2 = {2}, last_chg_user = '{3}', last_chg_date =  getdate()  where ssm_id = '{4}'", duration, optionDelta, bkupMetrc, User, cusip);
                int retRows = this.SybaseDbHelper.ExecuteNonQuery(queryUpdate);
                if (retRows == 0)
                {
                    int initIndCountry = 0;
                    int initBumSubCode, initBumClassCode, initIndCode1, initIndCode2, initIndCode3 = 0;

                    GetValuesFromSmAndSrm(cusip, out initBumClassCode, out initBumSubCode, out initIndCountry, out initIndCode1, out initIndCode2, out initIndCode3);

                    string queryInsert = string.Format("insert into pm..manual_durations_stage(" +
                     " ssm_id, duration, init_bum_class_code, init_bum_sub_code, notes, init_ind_country, init_ind_code1, init_ind_code2, init_ind_code3, f1, f2, f3, f4, f5, f6, opcode,last_chg_user )" +
                     " values('{0}',{1},{2},{3},'{4}',{5},{6},{7},{8},{9},{10},0,0,0,0,0,'{11}')"
                     , cusip, duration, initBumClassCode, initBumSubCode, notes, initIndCountry, initIndCode1, initIndCode2, initIndCode3
                     , optionDelta.Equals(double.NaN) ? 0 : optionDelta, bkupMetrc, User);

                    this.SybaseDbHelper.ExecuteNonQuery(queryInsert);
                }
            }
            else
            {
                throw new Exception(string.Format("Invalid Action {0}", action));
            }

            log.Debug("Exit");
        }

        private void UpdateSecAnalyticsOverride(string action, string cusip, string analytic_id
            , double risk_val, string risk_val_str, string bkupMetrc, string notes = "")
        {
            log.Debug("Enter");

            var price_date = (FetchCycleAndPreviosDate() as CycleDateAndPreviousDateBo).CycleDate.Split(' ')[0];
            if (action == "D")
            {
                var deleteQuery = string.Format(@"delete from SEC_ANALYTICS_OWN.SEC_ANALYTICS_OVERRIDES where ssm_id = '{0}'", cusip);

                if (!string.IsNullOrWhiteSpace(analytic_id))
                    deleteQuery += string.Format(" and analytic_id ='{0}' ", analytic_id);

                this.OracleDbHelper.ExecuteNonQuery(deleteQuery);

                deleteQuery = string.Format(@"delete from pm..sec_analytics_overrides where ssm_id = '{0}'", cusip);

                if (!string.IsNullOrWhiteSpace(analytic_id))
                    deleteQuery += string.Format(" and analytic_id ='{0}' ", analytic_id);

                this.SybaseDbHelper.ExecuteNonQuery(deleteQuery);
            }
            else if (action == "U")
            {
                //update first if no row return do insert
                var updateQuery = string.Format(@"
                                Merge into SEC_ANALYTICS_OWN.SEC_ANALYTICS_OVERRIDES sao Using
                                    (select to_date('{0}', 'MM/DD/YYYY') price_date, '{1}' ssm_id, '{2}' analytic_id, {3} risk_val, '{4}' risk_val_str, '{5}' backup_metric, '{6}' note, '{7}' last_chg_user, '{8}' last_chg_date from dual) a 
                                    on (a.ssm_id = sao.ssm_id and a.analytic_id = sao.analytic_id)
                                    When Matched Then
                                        Update Set sao.price_date = a.price_date, sao.risk_val = a.risk_val, sao.risk_val_str = a.risk_val_str, sao.backup_metric = a.backup_metric, sao.note = a.note, sao.last_chg_user = a.last_chg_user, sao.last_chg_date = a.last_chg_date
                                    When Not Matched Then 
                                        Insert (sao.price_date, sao.ssm_id, sao.analytic_id, sao.risk_val, sao.risk_val_str,sao.backup_metric, sao.note, sao.last_chg_user, sao.last_chg_date) 
                                            Values(a.price_date, a.ssm_id, a.analytic_id, a.risk_val, a.risk_val_str, a.backup_metric, a.note, a.last_chg_user, a.last_chg_date)"
                                                , price_date, cusip, analytic_id, risk_val, "", bkupMetrc, notes, User, DateTime.Now);
                this.OracleDbHelper.ExecuteNonQuery(updateQuery);
                //Syabase
                var update_query_Sybase = string.Format(@"
                                Merge into pm..sec_analytics_overrides sao Using
                                    (select  convert(date, '{0}', 101) price_date, '{1}' ssm_id, '{2}' analytic_id, {3} risk_val, '{4}' risk_val_str,'{5}' backup_metric, '{6}' note, '{7}' last_chg_user, '{8}' last_chg_date) a 
                                    on (a.ssm_id = sao.ssm_id and a.analytic_id = sao.analytic_id)
                                    When Matched Then
                                        Update Set sao.price_date = a.price_date, sao.risk_val = a.risk_val, sao.risk_val_str = a.risk_val_str, sao.backup_metric = a.backup_metric, sao.note = a.note, sao.last_chg_user = a.last_chg_user, sao.last_chg_date = a.last_chg_date
                                    When Not Matched Then 
                                        Insert (sao.price_date, sao.ssm_id, sao.analytic_id, sao.risk_val, sao.risk_val_str,sao.backup_metric, sao.note, sao.last_chg_user, sao.last_chg_date) 
                                            Values(a.price_date, a.ssm_id, a.analytic_id, a.risk_val, a.risk_val_str,  a.backup_metric,a.note, a.last_chg_user, a.last_chg_date)"
                    , price_date, cusip, analytic_id, risk_val, "", bkupMetrc, notes, User, DateTime.Now);
                this.SybaseDbHelper.ExecuteNonQuery(update_query_Sybase);
            }
            else
            {
                throw new Exception(string.Format("Invalid Action {0}", action));
            }
            log.Debug("Exit");
        }

        public override ResponseBO UpdateDB(RequestBO requestData)
        {
            ResponseBO retval = new ResponseBO();
            try
            {
                JavaScriptSerializer json = new JavaScriptSerializer();
                json.MaxJsonLength = Int32.MaxValue;
                RiskMeasureOverrideBO.SubmitRequestBO data = json.Deserialize<RiskMeasureOverrideBO.SubmitRequestBO>(requestData.data.ToString());
                if (data == null)
                    throw new Exception("Failed in Json Deserialization");
                if (data.tab == "B")
                {
                    //Permission Check
                    if (!Compliance.IsActionAllowed(User, requestData.screenName, Constants.RiskMeasureOverrideSubmitBase, Url, requestData.runEnviroment))
                        throw new Exception("Permission denied");

                    ManageBaseRiskMeasures(data.baseRiskMeasureObj, data.action);
                }
                else if (data.tab == "S")
                {
                    //Permission Check
                    if (!Compliance.IsActionAllowed(User, requestData.screenName, Constants.RiskMeasureOverrideSubmitScenarios, Url, requestData.runEnviroment))
                        throw new Exception("Permission denied");

                    ManageScenarioRiskMeasures(data.scenarioRiskMeasureObj, data.action);
                }
                else if (data.tab == "T")
                {
                    //Permission Check
                    if (!Compliance.IsActionAllowed(User, requestData.screenName, Constants.RiskMeasureOverrideSubmitTraders, Url, requestData.runEnviroment))
                        throw new Exception("Permission denied");

                    ManageTradersRiskMeasures(data.tradersRiskMeasureObj, data.action);
                }
                else
                    throw new Exception(string.Format("Unknown Tab: {0}", data.tab));

            }
            catch (Exception ex)
            {
                retval.errorMessage = string.Format("Error found in request: {0}", ex.Message);
                log.Error(retval.errorMessage, ex);
            }
            return retval;
        }

    }
}
