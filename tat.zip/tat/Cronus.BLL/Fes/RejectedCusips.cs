﻿using System;
using System.Collections.Generic;
using System.Linq;
using log4net;
using Cronus.BO;
using System.Web.Script.Serialization;
using Cronus.Bll.Helper;
using Cronus.BO.Fes;
using System.Collections.Specialized;

namespace Cronus.Bll.Fes
{
    class RejectedCusips : CronusBaseBll
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public override object Clone() { return new RejectedCusips(); }

        public override string ScreenName()
        {
            return Constants.RejectedCusips;
        }

        protected override string GetDropDownDataQuery(string fieldName, DropDownRequestBO requestData, out DatabaseType dbType)
        {
            dbType = DatabaseType.SYBASE;
            string query = "select distinct rejection_context, rejection_header from pm..rejection_info order by rejection_context";

            return query;
        }

        public override ResponseBO FetchDataForTable(TableDataRequestBO requestData)
        {
            var retval = new TableDataResponseBO();
            try
            {
                JavaScriptSerializer json = new JavaScriptSerializer();
                json.MaxJsonLength = Int32.MaxValue;
                List<RejectedCusipsBO.SearchRequestBO> data = json.Deserialize<List<RejectedCusipsBO.SearchRequestBO>>(requestData.data.ToString());
                if (data == null)
                    throw new Exception("Failed in Json Deserialization");

                //First execute for sybase
                DatabaseType dbType = DatabaseType.SYBASE;
                var query = GetQuery(requestData, dbType);
                var dbHelper = SybaseDbHelper;
                retval = dbHelper.ExecuteSelectQuery(query);

                //Then execute for Oracle
                dbType = DatabaseType.ORACLE;
                query = GetQuery(requestData, dbType);
                dbHelper = OracleDbHelper;
                var retvalData = dbHelper.ExecuteSelectQuery(query);

                //Combine the result
                foreach (var row in retvalData.rows)
                {
                    if (data[0].tab == "S")
                    {

                        if (retval.rows == null) retval.rows = new List<List<object>>();
                        bool found = false;
                        foreach (var rejectedRow in retval.rows)
                        {
                            if (rejectedRow[1].ToString() == row[1].ToString())
                            {
                                rejectedRow[4] += "|NRF";
                                found = true;
                                break;
                            }
                        }
                        //if context has been selected by user do not show oracle only rejection. As oracle does not have context info
                        if (!found && string.IsNullOrWhiteSpace(data[0].context)) retval.rows.Add(row);
                    }
                    else
                    {
                        retval.rows.Add(row);
                    }
                }

                retval.tableName = requestData.tableName;
            }
            catch (Exception ex)
            {
                retval.errorMessage = string.Format("Exception: {0}", ex.Message);
                log.Error("Exception : " + ex.Message, ex);
            }

            return retval;
        }

        protected string GetQuery(TableDataRequestBO requestData, DatabaseType dbType)
        {
            //Permission Check
            if (!Compliance.IsActionAllowed(User, requestData.screenName, Constants.RejectedCusipsView, Url,requestData.runEnviroment))
                throw new Exception("Permission denied");

            JavaScriptSerializer json = new JavaScriptSerializer();
            json.MaxJsonLength = Int32.MaxValue;
            List<RejectedCusipsBO.SearchRequestBO> data = json.Deserialize<List<RejectedCusipsBO.SearchRequestBO>>(requestData.data.ToString());
            if (data == null)
                throw new Exception("Failed in Json Deserialization");

            string query = "";
            if (data.Count <= 0)
                throw new Exception("Data Missing");

            if (data[0].tab == "S")
            {
                //data will have only one row.
                query = GetQueryForCusipsData(data[0], dbType);
            }
            else
            {
                //Permission Check
                if (!Compliance.IsActionAllowed(User, requestData.screenName, Constants.RejectedCusipsShowDetails, Url,requestData.runEnviroment))
                    throw new Exception("Permission denied");
                query = GetCusipsDetails(requestData, dbType);
            }

            return query;

        }

        private string GetCusipsDetails(TableDataRequestBO requestData, DatabaseType dbType)
        {
            JavaScriptSerializer json = new JavaScriptSerializer();
            json.MaxJsonLength = Int32.MaxValue;
            List<RejectedCusipsBO.SearchRequestBO> data = json.Deserialize<List<RejectedCusipsBO.SearchRequestBO>>(requestData.data.ToString());
            string priceDate = "";
            string cusipInList = "";
            string contextInList = "";
            foreach (RejectedCusipsBO.SearchRequestBO obj in data)
            {
                if (string.IsNullOrEmpty(contextInList))
                    cusipInList = string.Format("'{0}'", obj.cusip);
                else
                    cusipInList += string.Format(", '{0}'", obj.cusip);
                if (string.IsNullOrEmpty(contextInList))
                    contextInList = string.Format("'{0}'", obj.context);
                else
                    contextInList += string.Format(", '{0}'", obj.context);
                priceDate = obj.priceDate;
            }
            string query = string.Empty;
            if (dbType == DatabaseType.SYBASE)
            {
                query = string.Format(@"select ssm_id, pimco_desc, comp_sec_type_code, coupon, maturity_date, bum_class_code, bum_sub_code,bumcode_desc, calc_ind,
                                                    curve_type, provider_id, oas_is_input,source_code, new_source_code, prev_price, new_price, prev_dur, 
                                                    new_dur, diff_dur, p_diff_dur, prev_oas, new_oas, diff_oas, p_diff_oas, null reason, last_chg_date               
                                            from pm..port_stats_reject
                                            where asof_date = '{0}' and ssm_id in ({1}) and context in ({2}) 
                                         union 
                                            select ssm_id, null, null, null, null, null, null, null, null, null, null, null, null, null, 
                                                a.prev_price, a.today_price, a.prev_val, a.new_val, a.diff_val, a.p_diff_val, null, null, null, null, a.reason, a.last_chg_date 
                                            from pm..sec_analytics_rejected a 
                                            inner join pm..analytic_id_metadata am on a.analytic_id_int = am.analytic_id_int 
                                            inner join pm..model_inv_details c on  a.invocation_id_int = c.invocation_id_int 
                                            inner join pm..rejection_info r on c.rejection_context = r.rejection_context 
                                            where am.analytic_id in ('duration','option_delta') and a.today_price is not null 
                                            and a.price_date = '{0}'
                                            and a.ssm_id in ({1})"
                                            , priceDate, cusipInList, contextInList);
            }
            else
            {
                query = string.Format(@"select distinct ssm_id, null, null, null, null, null, null, null, null, null, a.analytic_id, null, null, null, 
                                                a.prev_price, a.price, a.prev_val, a.curr_val, null, null, null, null, null, null, a.reason, a.last_chg_date 
                                        from pm_own.sec_analytics_rejected a 
                                        inner join pm_own.invocation_metadata im on a.curr_invocation_id = im.invocation_id and a.analytic_id = im.analytic_id 
                                        and a.price_date = '{0}'
                                        and a.ssm_id in ({1})"
                                        , priceDate, cusipInList);
            }

            return query;
        }

        private string GetQueryForCusipsData(RejectedCusipsBO.SearchRequestBO data, DatabaseType dbType)
        {
            string query = "";
            log.Info(string.Format("Select Request for ssm_id = {0}, price_date = {1}, context = {2}, reloadFlag = {3}",
                data.cusip, data.priceDate, data.context, data.reloadFlag));

            string cusipList = string.Join(",", data.cusip.Split(',').ToList<string>().Select(s => "'" + s.Trim() + "'"));

            if (dbType == DatabaseType.SYBASE)
            {
                query = string.Format(@"select convert(date,price_date) as 'Price Date', cusip as 'Cusip',context as 'Context', region_code as 'Region Code',rejection_rule as 'Rejection Rule' 
                                    from pm..rejected_cusips where price_date = '{0}'", data.priceDate);

                if (data.context != "")
                    query += " and context = '" + data.context + "' ";

                if (cusipList != "''")
                    query += " and cusip in (" + cusipList + " ) ";

                query += " and reload_flag = '" + (data.reloadFlag ? "Y" : "N") + "'";
            }
            else
            {
                query = string.Format(@"select distinct price_date as PriceDate, ssm_id as Cusip, '' as Context, '' as RegionCode,'NRF' as RejectionRule from pm_own.sec_analytics_rejected sar 
                                    Join pm_own.invocation_metadata im on sar.curr_invocation_id = im.invocation_id and sar.analytic_id = im.analytic_id
                                    where price_date = '{0}' and Reason not in ('I','U','ID')", data.priceDate);
                if (cusipList != "''")
                    query += " and ssm_id in (" + cusipList + " ) ";

                query += " and reload_status = '" + (data.reloadFlag ? "Y" : "N") + "'";
            }

            return query;
        }

        public override ResponseBO UpdateDB(RequestBO req)
        {
            log.Debug("Enter");
            RejectedCusipsBO.NotifyResponseBO retval = new RejectedCusipsBO.NotifyResponseBO();
            DatabaseHelper dbHelper = SybaseDbHelper;

            try
            {
                JavaScriptSerializer json = new JavaScriptSerializer();
                json.MaxJsonLength = Int32.MaxValue;
                RejectedCusipsBO.NotifyRequestBO data = json.Deserialize<RejectedCusipsBO.NotifyRequestBO>(req.data.ToString());
                if (data == null)
                    throw new Exception("Failed in Json Deserialization");

                string priceDate = data.priceDate;
                bool reloadFlag = data.reloadFlag;
                //Permission Check
                if (reloadFlag)
                {
                    if (!Compliance.IsActionAllowed(User, req.screenName, Constants.RejectedCusipsNotifyForReload, Url,req.runEnviroment))
                        throw new Exception("Permission denied");
                }
                else
                {
                    if (!Compliance.IsActionAllowed(User, req.screenName, Constants.RejectedCusipsNotifyForRejection, Url,req.runEnviroment))
                        throw new Exception("Permission denied");
                }

                string query = GetQueryForCusipsData(new RejectedCusipsBO.SearchRequestBO() { priceDate = priceDate, reloadFlag = true, context = "", cusip = "" }, DatabaseType.SYBASE);

                TableDataResponseBO reloadData = dbHelper.ExecuteSelectQuery(query);
                Dictionary<string, string> reloadCusipDic = new Dictionary<string, string>();
                foreach (List<object> row in reloadData.rows)
                {
                    reloadCusipDic[row[1].ToString()] = row[2].ToString();
                }

                //Validate data
                foreach (RejectedCusipsBO.CusipContextBO obj in data.cusipContextData)
                {
                    if (string.IsNullOrEmpty(obj.cusip))
                        throw new Exception("ssm_id can not be null or empty");
                    //if (string.IsNullOrEmpty(obj.context))
                    //    throw new Exception("context can not be null or empty");
                    if (reloadFlag && reloadCusipDic.ContainsKey(obj.cusip) && obj.context != "null")
                        throw new Exception(string.Format("cusip {0} is already marked / marking for reload for context {1}", obj.cusip, obj.context));
                    else
                        reloadCusipDic[obj.cusip] = obj.context;
                }
                if (string.IsNullOrEmpty(priceDate))
                    throw new Exception("priceDate can not be null or empty");

                dbHelper.BeginTransaction();
                List<long> auditIds = new List<long>();
                retval.message = "Mark for ";
                if (reloadFlag)
                    retval.message += " Reload\n";
                else
                    retval.message += " Rejection\n";
                retval.message += "PriceDate = " + priceDate + "\n";

                foreach (RejectedCusipsBO.CusipContextBO obj in data.cusipContextData)
                {
                    string cusip = obj.cusip;
                    string context = obj.context;
                    string analyticIds = string.Join(",", obj.analyticIds.ToList<string>().Select(s => "'" + s.Trim() + "'"));

                    log.Info(string.Format("Update Request by User: {0} Processing {1}", User, obj));

                    auditIds.Add(LogActionToAudit(new OrderedDictionary() { { "Cusip", cusip }, { "Context", context }, { "AnalylticId", analyticIds }, { "PriceDate", priceDate }, { "ReloadFlag", reloadFlag } }));

                    try
                    {
                        string queryUpdate = "update pm..rejected_cusips set reload_flag = '" + (reloadFlag ? "Y" : "N") + "' , last_chg_user = '" + User + "' ";
                        queryUpdate = queryUpdate + "where price_date = '" + priceDate + "' and context = '" + context + "' and cusip = '" + cusip + "'";

                        var rowsAffected = dbHelper.ExecuteNonQuery(queryUpdate);
                        log.InfoFormat("Rows affected in Sybase {0}", rowsAffected);

                        //queryUpdate = "update sec_analytics_own.sec_analytics_rejected set reload_status = '" + (reloadFlag ? "Y" : "N") + "' , last_chg_user = '" + User + "' ";
                        //queryUpdate = queryUpdate + " where price_date = '" + priceDate + "' and ssm_id = '" + cusip + "' and analytic_id = 'srm_duration'";
                        if (!string.IsNullOrEmpty(analyticIds))
                        {
                            queryUpdate = "update sec_analytics_own.sec_analytics_rejected set reload_status = '" + (reloadFlag ? "Y" : "N") + "' , last_chg_user = '" + User + "' ";
                            queryUpdate = queryUpdate + " where price_date = '" + priceDate + "' and ssm_id = '" + cusip + "' and analytic_id in (" + analyticIds + ") ";
                            rowsAffected = OracleDbHelper.ExecuteNonQuery(queryUpdate);
                            log.InfoFormat("Rows affected in Oracle {0}", rowsAffected);

                        }

                        retval.message += string.Format("Cusip = {0}, Context = {1},PriceDate = {2},Status = {3} \n", cusip, context, priceDate, "Success");
                    }
                    catch (Exception ex)
                    {
                        log.Error(string.Format("Exception: {0}", ex.Message), ex);
                        dbHelper.Rollback();
                        foreach (long auditid in auditIds)
                            LogActionToAudit(new OrderedDictionary() { { "status", "Fail" } }, auditid);
                        throw;
                    }
                }
                dbHelper.Commit();
                foreach (long auditId in auditIds)
                    LogActionToAudit(new OrderedDictionary() { { "status", "Success" } }, auditId);
            }
            catch (Exception ex)
            {
                retval.errorMessage = string.Format("Exception: {0}", ex.Message);
                log.Error(retval.errorMessage, ex);
            }
            finally
            {
                log.Debug("Exit");
            }
            return retval;
        }

        public override ResponseBO CustomFunction(CustomFunctionBO req)
        {
            var retval = new TableDataResponseBO();
            try
            {
                var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                RejectedCusipsBO.NotifyRequestBO data = json.Deserialize<RejectedCusipsBO.NotifyRequestBO>(req.data.ToString());
                if (data == null)
                    throw new Exception("Failed in Json Deserialization");


                var dbHelper = this.OracleDbHelper;
                var erroMessage = string.Empty;
                var priceDate = Convert.ToDateTime(data.priceDate).ToString("MM/dd/yyyy");
                string cusipList = string.Empty;
                var reloadFlag = data.reloadFlag ? "Y" : "N";
                foreach (RejectedCusipsBO.CusipContextBO obj in data.cusipContextData)
                {
                    cusipList += string.Format("'{0}',", obj.cusip);
                }

                var query = string.Format("select * from sec_analytics_own.sec_analytics_rejected where ssm_id in ({0}) and price_date = '{1}' and reload_status = '{2}' and Reason not in ('I','U','ID')", cusipList.TrimEnd(','), priceDate, reloadFlag);
                retval = dbHelper.ExecuteSelectQuery(query);

            }
            catch (Exception ex)
            {

                retval.errorMessage = string.Format("Exception: {0}", ex.Message);
                log.Error(retval.errorMessage, ex);
            }
            finally
            {
                log.Debug("Exit");
            }
            return retval;
        }
    }
}
