﻿using System;
using System.Collections.Generic;
using log4net;
using System.Web.Script.Serialization;
using Cronus.Bo.Fes;
using Cronus.BO;
using System.Collections.Specialized;
using Cronus.Bll.Helper;

namespace Cronus.Bll.Fes
{
    public class ModelSummaryReport : CronusBaseBll
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public override object Clone() { return new ModelSummaryReport(); }

        public override string ScreenName()
        {
            return Constants.ModelSummaryReport;
        }

        protected override string GetDropDownDataQuery(string fieldName, DropDownRequestBO requestData, out DatabaseType dbType)
        {
            dbType = DatabaseType.ORACLE;
            string query = "";
            if (fieldName == "INVOCATION_ID")
            {
                query = "SELECT DISTINCT INVOCATION_ID FROM PM_OWN.MODEL_INVOCATIONS WHERE class_id is not null";
            }
            return query;

        }

        protected override string GetTableQuery(TableDataRequestBO requestData, out DatabaseType dbType)
        {
            //Permission Check
            if (!Compliance.IsActionAllowed(User, requestData.screenName, Constants.ModelSummaryReportView, Url, requestData.runEnviroment))
                throw new Exception("Permission denied");

            dbType = DatabaseType.ORACLE;
            string query = "";
            if (requestData.tableName == "SUBSCRIBE")
                query = string.Format("select model_inv.INVOCATION_ID, NVL(inv_sub.SUBSCRIBE, 'N' ) as SUBSCRIBE   from  PM_OWN.MODEL_INVOCATIONS model_inv " +
                                            "left join sec_analytics_own.invocation_subscriptions inv_sub  " +
                                            "on (model_inv.INVOCATION_ID = inv_sub.INVOCATION_ID or inv_sub.INVOCATION_ID = 'ALL') AND Lower(USER_ID) = '{0}' WHERE model_inv.TYPE is not null Order by 2 desc,1 asc", User.ToLower());
            else if (requestData.tableName == "ALL")
                query = string.Format("Select count(*) from sec_analytics_own.invocation_subscriptions where Lower(USER_ID) = '{0}' and INVOCATION_ID = 'ALL'", User.ToLower());
            else
                throw new Exception(string.Format("Unknown tableName: {0}", requestData.tableName));
            return query;

        }

        public override ResponseBO UpdateDB(RequestBO req)
        {
            Log.Debug("Enter");
            ResponseBO retval = new ResponseBO();
            DatabaseHelper dbHelper = this.OracleDbHelper;
            List<long> auditIds = new List<long>();
            try
            {
                //Permission Check
                if (!Compliance.IsActionAllowed(User, req.screenName, Constants.ModelSummaryReportSave, Url, req.runEnviroment))
                    throw new Exception("Permission denied");

                dbHelper.BeginTransaction();
                JavaScriptSerializer json = new JavaScriptSerializer();
                json.MaxJsonLength = Int32.MaxValue;
                ModelSummaryReportBO.SubmitRequestBO submitRequestObj = json.Deserialize<ModelSummaryReportBO.SubmitRequestBO>(req.data.ToString());
                if (submitRequestObj == null)
                    throw new Exception("Failed in Json Deserialization");

                Log.InfoFormat("User: {0}, Updating database", User);
                foreach (var data in submitRequestObj.SubscriptionList)
                {
                    Log.InfoFormat("User: {0}, Processing {1}", User, data);
                    auditIds.Add(LogActionToAudit(new OrderedDictionary() { { "InvocationId", data.InvocationId }, { "IsSubscribe", data.IsSubscribe } }));
                    if (data.IsSubscribe == "N")
                    {
                        if (data.InvocationId == "ALL")
                        {
                            var query = string.Format("delete from sec_analytics_own.invocation_subscriptions WHERE Lower(USER_ID) = '{0}'", User.ToLower());
                            dbHelper.ExecuteNonQuery(query);
                        }
                        else
                        {
                            var query = string.Format("delete from sec_analytics_own.invocation_subscriptions WHERE Lower(USER_ID) = '{0}' AND  INVOCATION_ID = '{1}'", User.ToLower(), data.InvocationId);
                            dbHelper.ExecuteNonQuery(query);
                        }
                    }
                    else
                    {
                        var query = string.Format("UPDATE sec_analytics_own.invocation_subscriptions SET SUBSCRIBE = '{0}' WHERE Lower(USER_ID) = '{1}' AND  INVOCATION_ID = '{2}'", data.IsSubscribe, User.ToLower(), data.InvocationId);
                        long rowAffetected = dbHelper.ExecuteNonQuery(query);
                        if (rowAffetected == 0)
                        {
                            query = "insert into sec_analytics_own.invocation_subscriptions( INVOCATION_ID,USER_ID,SUBSCRIBE) ";
                            query += string.Format("values('{0}','{1}','{2}')", data.InvocationId.Trim(), User.ToLower(), data.IsSubscribe.Trim());
                        }
                        dbHelper.ExecuteNonQuery(query);
                    }
                }
                dbHelper.Commit();

                foreach (long auditId in auditIds)
                    LogActionToAudit(new OrderedDictionary() { { "Status", "Success" } }, auditId);
            }
            catch (Exception ex)
            {
                retval.errorMessage = string.Format("Exception: {0}", ex.Message);
                Log.Error(retval.errorMessage, ex);
                dbHelper.Rollback();

                foreach (long auditId in auditIds)
                    LogActionToAudit(new OrderedDictionary() { { "Status", "Fail" } }, auditId);
            }
            finally
            {
                Log.Debug("Exit");
            }

            return retval;
        }

    }
}
