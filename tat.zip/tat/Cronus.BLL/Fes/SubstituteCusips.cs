﻿using System;
using System.Collections.Generic;
using log4net;
using Cronus.BO;
using Cronus.Bll.Helper;
using System.Web.Script.Serialization;
using Cronus.BO.Fes;
using System.Collections.Specialized;

namespace Cronus.Bll.Fes
{
    class SubstituteCusips : CronusBaseBll
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public override object Clone() { return new SubstituteCusips(); }

        public override string ScreenName()
        {
            return Constants.SubstituteCusips;
        }

        protected override string GetTableQuery(TableDataRequestBO requestData, out DatabaseType dbType)
        {
            dbType = DatabaseType.SYBASE;

            var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
            SubstituteCusipsBO.SeaarchRequestBO data = json.Deserialize<SubstituteCusipsBO.SeaarchRequestBO>(requestData.data.ToString());
            if (data == null)
                throw new Exception("Failed in Json Deserialization");

            string cusips = data.cusips;
            log.Info(string.Format("Select Request for ssm_id = {0}", cusips));
            //Permission Check
            if (string.IsNullOrEmpty(data.cusips))
            {
                if (!Compliance.IsActionAllowed(User, requestData.screenName, Constants.SubstituteCusipsShowAll, Url, requestData.runEnviroment))
                    throw new Exception("Permission denied");
            }
            else
            {
                if (!Compliance.IsActionAllowed(User, requestData.screenName, Constants.SubstituteCusipsSearch, Url, requestData.runEnviroment))
                    throw new Exception("Permission denied");
            }

            var query = "Select convert(date,asof_date, 101) as \'Asof Date\', old_cusip as \'Old Cusip\', new_cusip as \'New Cusip\', notes as Notes, last_chg_user as \'Last Change User\', last_chg_date as \'Last Change Date\' from pm..old_cusip_new_cusip ";
            if (!string.IsNullOrEmpty(cusips))
            {
                string inClausListStr = "";
                foreach (string ssmId in cusips.Split(','))
                {
                    if (string.IsNullOrEmpty(inClausListStr))
                        inClausListStr = string.Format(" '{0}' ", ssmId.TrimStart());
                    else
                        inClausListStr += string.Format(", '{0}' ", ssmId.TrimStart());
                }
                query += string.Format(" Where old_cusip  in ({0}) or new_cusip in ({0})", inClausListStr);
            }
            query += " order by last_chg_date desc ";

            return query;
        }

        public override ResponseBO UpdateDB(RequestBO req)
        {
            log.Debug("Enter");
            SubstituteCusipsBO.saveResponseBO retval = new SubstituteCusipsBO.saveResponseBO() { message = "" };

            try
            {
                //Permission Check
                if (!Compliance.IsActionAllowed(User, req.screenName, Constants.SubstituteCusipsSave, Url, req.runEnviroment))
                    throw new Exception("Permission denied");

                JavaScriptSerializer json = new JavaScriptSerializer();
                json.MaxJsonLength = Int32.MaxValue;
                List<SubstituteCusipsBO.saveRequestBO> data = json.Deserialize<List<SubstituteCusipsBO.saveRequestBO>>(req.data.ToString());
                if (data == null)
                    throw new Exception("Failed in Json Deserialization");

                //Validate data
                foreach (SubstituteCusipsBO.saveRequestBO obj in data)
                {
                    if (string.IsNullOrEmpty(obj.oldCusip))
                        throw new Exception("OldCusip can not be null or empty");
                    if (string.IsNullOrEmpty(obj.newCusip))
                        throw new Exception("NewCusip can not be null or empty");
                }
                SybaseDbHelper.BeginTransaction();
                OracleDbHelper.BeginTransaction();
                List<long> auditIds = new List<long>();
                foreach (SubstituteCusipsBO.saveRequestBO obj in data)
                {
                    string oldCusip = obj.oldCusip;
                    string newCusip = obj.newCusip;
                    string note = obj.note;
                    string mailRecipients = obj.mailRecipients;
                    log.Info(string.Format("Substitute Request by User:{0} Processing {1}", User, obj));

                    auditIds.Add(LogActionToAudit(new OrderedDictionary() { { "OldCusip", oldCusip }, { "NewCusip", newCusip }, { "Note", note }, { "EmailTo", mailRecipients } }));

                    try
                    {
                        string queryDelete = string.Format("delete from pm..old_cusip_new_cusip where asof_date = '{0}' and old_cusip = '{1}'",
                                                            DateTime.Now.ToShortDateString(), oldCusip);

                        string noteTmp = note.Replace("'", "''");
                        string queryInsert = string.Format("insert into pm..old_cusip_new_cusip(asof_date, old_cusip, new_cusip, notes,last_chg_user) values ('{0}' ,'{1}' , '{2}' , '{3}' , '{4}')",
                                                            DateTime.Now.ToShortDateString(), oldCusip, newCusip, noteTmp, User);

                        SybaseDbHelper.ExecuteNonQuery(queryDelete);
                        SybaseDbHelper.ExecuteNonQuery(queryInsert);
                        queryDelete = string.Format("delete from pm_own.old_cusip_new_cusip where asof_date = '{0}' and old_cusip = '{1}'",
                                                                                    DateTime.Now.ToShortDateString(), oldCusip);

                        queryInsert = string.Format("insert into pm_own.old_cusip_new_cusip(asof_date, old_cusip, new_cusip, notes,last_chg_user) values ('{0}' ,'{1}' , '{2}' , '{3}' , '{4}')",
                                                            DateTime.Now.ToShortDateString(), oldCusip, newCusip, noteTmp, User);

                        OracleDbHelper.ExecuteNonQuery(queryDelete);
                        OracleDbHelper.ExecuteNonQuery(queryInsert);

                        retval.message += string.Format("Old Cusip = {0}, New Cusip = {1}, Status = {2} \n", oldCusip, newCusip, "Success");
                    }
                    catch (Exception ex)
                    {
                        log.Error(string.Format("Exception: {0}", ex.Message), ex);
                        SybaseDbHelper.Rollback();
                        OracleDbHelper.Rollback();
                        foreach (long auditId in auditIds)
                            LogActionToAudit(new OrderedDictionary() { { "Status", "Fail" } }, auditId);
                        throw;
                    }
                }
                SybaseDbHelper.Commit();
                OracleDbHelper.Commit();
                foreach (long auditId in auditIds)
                    LogActionToAudit(new OrderedDictionary() { { "Status", "Success" } }, auditId);

                SendMail(retval.message, data[0].note, data[0].mailRecipients);
            }
            catch (Exception ex)
            {
                retval.errorMessage = string.Format("Exception: {0}", ex.Message);
                log.Error(retval.errorMessage, ex);
                throw;
            }
            finally
            {
                log.Debug("Exit");
            }

            return retval;
        }

        private void SendMail(string message, string note, string mailRecipients)
        {
            try
            {
                // Send email confirmation after successful substitution of cusip.             
                string subject = "Substitute Cusip Confirmation";
                string body = string.Format("<b>Substitute Cusip details</b>: <br/><br/>Note: {0}<br/><br/><b>Result:</b><br/>", note);
                body += message.Replace("\n", "<br/>");

                body += "<br/>Thanks,<br/>Cronus<br/><br/>";
                List<string> mailIds = new List<string>();
                string to = GetMailIdOfUser(User);

                mailIds.Add(to);

                if (!string.IsNullOrEmpty(mailRecipients))
                {
                    foreach (var mailId in mailRecipients.Split(','))
                    {
                        if (string.IsNullOrEmpty(mailId)) continue;

                        if (mailId.Contains("@"))
                            mailIds.Add(mailId.Trim());
                        else
                        {
                            string emailName = GetMailIdOfUser(mailId);

                            mailIds.Add(emailName);
                        }
                    }
                }

                mailIds.AddRange(GetMailIdOfScreen(RunOnEnviroment));

                SendEmail(subject, body, string.Join(",", mailIds), ConfigManager.GetSendEmailFrom());
            }
            catch (Exception ex)
            {
               log.Error(string.Format("Exception: {0}", ex.Message), ex);
            }
        }
    }
}
