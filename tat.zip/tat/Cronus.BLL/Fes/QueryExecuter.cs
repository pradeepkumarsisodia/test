﻿using System;
using System.Threading;
using System.Web.Script.Serialization;
using Cronus.Bll.Helper;
using Cronus.BO;
using Cronus.BO.Fes;

namespace Cronus.Bll.Fes
{
    class QueryExecuter : QueryBuilder
    {
        public override object Clone() { return new QueryExecuter(); }

        public override string ScreenName()
        {
            return Constants.QueryExecuter;
        }

        protected override bool IsJiraRequired(string data)
        {
            return false;
        }

        public override ResponseBO CustomFunction(CustomFunctionBO req)
        {
            ResponseBO retval = new ResponseBO();
            var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };

            switch (req.functionName)
            {
                case "Login":
                    {
                        var data = json.Deserialize<QueryBuilderBO.QueryRequestBO>(req.data.ToString());
                        if (data == null)
                            throw new Exception("Failed in Json Deserialization");

                        var dbName = data.DATABASE;
                        var tabId = data.TabId;
                        var uniqId = data.UniqId;
                        var key = GetKey(User, tabId, uniqId, dbName);
                        DatabaseHelper dbHelper = GetDBHelper(key, dbName, data.UserId, data.Pwd);
                        dbHelper.CacheConnection(true);
                        var query = dbName.ToLowerInvariant().StartsWith("ora") ? "select * from dual" : "select 2";
                        dbHelper.ExecuteSelectQuery(query);
                    }
                    break;
                default:
                    throw new Exception(string.Format("Unknown functionName {0}", req.functionName));
            }

            return retval;
        }
    }
}
