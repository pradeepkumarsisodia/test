﻿using System;
using System.Collections.Generic;
using log4net;
using Cronus.BO;
using Cronus.Bll.Helper;
using System.Web.Script.Serialization;
using Cronus.BO.Fes;
using System.Collections.Specialized;

namespace Cronus.Bll.Fes
{
    class AgencyModelMap : CronusBaseBll
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public override object Clone() { return new AgencyModelMap(); }

        public override string ScreenName()
        {
            return Constants.AgencyModelMap;
        }

        protected override string GetTableQuery(TableDataRequestBO requestData, out DatabaseType dbType)
        {
            dbType = DatabaseType.ORACLE;

            if (!Compliance.IsActionAllowed(User, requestData.screenName, Constants.AgencyModelMapSearch, Url,requestData.runEnviroment))
                throw new Exception("Permission denied");

            var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
            var data = json.Deserialize<AgencyModelMapBO.SearchRequestBO>(requestData.data.ToString());
            if (data == null)
                throw new Exception("Failed in Json Deserialization");

            var cusips = data.ssmId;
            string query;
            if (!string.IsNullOrEmpty(cusips))
            {
                var inClausListStr = "";
                foreach (var ssmId in cusips.Split(','))
                {
                    if (string.IsNullOrEmpty(inClausListStr))
                        inClausListStr = string.Format(" '{0}' ", ssmId.TrimStart().Replace("'", "''"));
                    else
                        inClausListStr += string.Format(", '{0}' ", ssmId.TrimStart().Replace("'", "''"));
                }
                Log.Info(string.Format("Select Request for ssm_id = {0}", inClausListStr));

                query = string.Format("Select ssm_id, cusip From PM_OWN.AGENCY_TBA_MAP Where ssm_id in ({0})", inClausListStr);
            }
            else
                throw new Exception("cusip list passed is empty");



            return query;
        }

        public override ResponseBO UpdateDB(RequestBO req)
        {
            Log.Debug("Enter");
            var retval = new AgencyModelMapBO.AddUpdateResponseBO();
            var dbHelper = this.OracleDbHelper;

            try
            {
                if (!Compliance.IsActionAllowed(User, req.screenName, Constants.AgencyModelMapAddUpdate, Url,req.runEnviroment))
                    throw new Exception("Permission denied");

                var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                var data = json.Deserialize<List<AgencyModelMapBO.AddUpdateRequestBO>>(req.data.ToString());
                if (data == null)
                    throw new Exception("Failed in Json Deserialization");

                /*Validate data */
                foreach (var agencyObj in data)
                {
                    if (string.IsNullOrEmpty(agencyObj.ssmId))
                        throw new Exception("SSM_ID can not be null");
                    if (string.IsNullOrEmpty(agencyObj.cusip))
                        throw new Exception("CUSIP can not be null");
                }

                /*Process data */
                dbHelper.BeginTransaction();
                var auditIds = new List<long>();

                foreach (var agencyObj in data)
                {
                    Log.Info(string.Format("Request by User: {0}, Processing {1}", User, agencyObj));
                    var ssmId = agencyObj.ssmId;
                    var cusip = agencyObj.cusip;

                    auditIds.Add(LogActionToAudit(new OrderedDictionary() { { "ssm_id", ssmId }, { "cusip", cusip } }));

                    try
                    {
                        var deleteQuery = string.Format(@"Merge into PM_OWN.AGENCY_TBA_MAP a 
                            using (select '{1}' ssm_id,  '{0}' cusip From dual) b on (a.ssm_id = b.ssm_id) 
                            When matched then 
                                update set a.cusip = b.cusip
                            When not matched then
                                  insert (a.ssm_id, a.cusip) values(b.ssm_id,b.cusip)", cusip.Replace("'", "''"), ssmId.Replace("'", "''"));
                        var rowsAffected = dbHelper.ExecuteNonQuery(deleteQuery);
                        retval.message += string.Format("ssm_id = {0}, cusip = {1}, status = {2} \n", ssmId, cusip, "Success");
                    }
                    catch (Exception ex)
                    {
                        Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                        dbHelper.Rollback();
                        foreach (var auditId in auditIds)
                            LogActionToAudit(new OrderedDictionary() { { "status", "Fail" } }, auditId);
                        throw;
                    }
                }
                dbHelper.Commit();
                foreach (var auditId in auditIds)
                    LogActionToAudit(new OrderedDictionary() { { "status", "Success" } }, auditId);
            }
            catch (Exception ex)
            {
                retval.errorMessage = string.Format("Exception: {0}", ex.Message);
                Log.Error(retval.errorMessage, ex);
            }
            finally
            {
                Log.Debug("Exit");
            }
            return retval;
        }
    }
}
