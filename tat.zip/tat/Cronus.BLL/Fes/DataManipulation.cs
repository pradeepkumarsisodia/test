﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using Cronus.Bll.Helper;
using Cronus.BO;
using System.Web.Script.Serialization;
using Cronus.Bo.Fes;
using System.Text.RegularExpressions;
using System.Collections.Specialized;

namespace Cronus.Bll.Fes
{
    public class DataManipulation : CronusBaseBll
    {
        List<long> auditIds = new List<long>();
        Dictionary<string, object> tableStructureDec = new Dictionary<string, object>();
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public override object Clone() { return new DataManipulation(); }

        public override string ScreenName()
        {
            return Constants.DataManipulation;
        }

        protected string GetKey(string user, string dbName)
        {
            return string.Format("{0}_%_{1}_%_{2}", user, ScreenName(), dbName);
        }

        private DatabaseHelper.Database getDBType(string dbName)
        {
            return dbName.ToLowerInvariant().StartsWith("ora") ? DatabaseHelper.Database.ORACLE : DatabaseHelper.Database.SYBASE;
        }

        protected string GetConfigData(string context, string key)
        {
            string retVal;
            var selectQuery = "";
            switch (context)
            {
                case "CONNECTIONSTRINNG":
                    selectQuery = string.Format("select Value from CRONUS_OWN.CONFIG WHERE Context = '{0}' and Key = '{1}' ", "ConnectionString", key);
                    break;
            }
            var selectedRows = OracleDbHelper.ExecuteSelectQuery(selectQuery);
            if (selectedRows.rows.Count > 0)
                retVal = Convert.ToString(selectedRows.rows[0][0]);
            else
                throw new Exception(string.Format("Config Data missing for {0}", context));

            return retVal;
        }

        DatabaseHelper GetDBHelper(string dbName, string userName, string password)
        {
            var connectionStr = (new ConfigHelper(Url)).GetConnectionStr(GetConfigData("CONNECTIONSTRINNG", dbName), userName, password, false);
            return (getDBType(dbName) == DatabaseHelper.Database.ORACLE) ?
               (DatabaseHelper)new OracleDatabaseHelper(connectionStr, GetKey(User, dbName)) :
               (DatabaseHelper)new SybaseDatabaseHelper(connectionStr, GetKey(User, dbName));
        }

        protected override string GetTableQuery(TableDataRequestBO requestData, out DatabaseType dbType)
        {
            dbType = DatabaseType.ORACLE;

            var tableName = requestData.tableName;
            string query;
            switch (tableName)
            {
                case "GetDataBase":
                    query = string.Format("SELECT distinct key, value,environment FROM CRONUS_OWN.CONFIG WHERE ScreenID = '{0}' and Context = 'Database Config' ORDER BY key desc", "QUERY BUILDER");
                    break;
                default:
                    throw new Exception(string.Format("Unknown TableName {0}", tableName));
            }

            return query;
        }


        protected DataManipulationBO.LoginResponseBO CheckLoginDetail(CustomFunctionBO requestData)
        {
            DataManipulationBO.LoginResponseBO retval = new DataManipulationBO.LoginResponseBO();
            var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
            var data = json.Deserialize<DataManipulationBO.LoginRequestBO>(requestData.data.ToString());
            string dbName = data.dbName;
            string userName = data.userId;
            string password = data.password;

            try
            {
                Log.InfoFormat("Login Request from User {0} for Db {1} as {2} UserName ", User, dbName, userName);
                DatabaseHelper dbHelper = GetDBHelper(dbName, userName, password);
                dbHelper.CacheConnection(false);

                //Do a sample query to verify login
                var query = getDBType(dbName) == DatabaseHelper.Database.ORACLE ? "select 1 from dual" : "select 2";
                dbHelper.ExecuteSelectQuery(query);
                Log.InfoFormat("Login Request successed from User {0} for Db {1} as {2} UserName ", User, dbName, userName);
                retval.status = true;
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Login Request failed from User {0} for Db {1} as {2} UserName ", User, dbName, userName);
                Log.ErrorFormat("Exception {0} ", ex.Message);
                retval.status = false;
            }
            return retval;
        }

        protected DataManipulationBO.SearchResponseBO SearchData(CustomFunctionBO requestData)
        {
            DataManipulationBO.SearchResponseBO retval = new DataManipulationBO.SearchResponseBO();
            var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
            var data = json.Deserialize<DataManipulationBO.SearchRequestBO>(requestData.data.ToString());
            string dbName = data.loginData.dbName;
            string userName = data.loginData.userId;
            string password = data.loginData.password;
            string tableName = data.tableName;
            string whereCondition = data.whereClause;

            try
            {
                if (!Compliance.IsActionAllowed(User, requestData.screenName, Constants.DataManipulationSearch, Url, requestData.runEnviroment))
                    throw new Exception("Permission denied");

                Log.InfoFormat("Search Request from User {0} for Db {1} as {2} UserName for table {3} with whereClause {4}", User, dbName, userName, tableName, whereCondition);
                DatabaseHelper dbHelper = GetDBHelper(dbName, userName, password);
                //dbHelper.CacheConnection(true);

                var uniqColumns = dbHelper.GetUniqueIndexColumns(tableName);
                if (uniqColumns.Count == 0)
                    throw new Exception(string.Format("Table should have atleast one unique index on the table"));

                var query = string.Format("Select * From {0} Where {1}", tableName, string.IsNullOrWhiteSpace(whereCondition) ? " 1 = 1 " : whereCondition);
                retval.data = dbHelper.ExecuteSelectQuery(query,true);
                Log.InfoFormat("{0} rows found for Request from User {1} for Db {2} as {3} UserName for table {4} with whereClause {5}", retval.data.rows.Count, User, dbName, userName, tableName, whereCondition);
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Select query failed from User {0} for Db {1} as {2} UserName for table {3} with whereClause {4}", User, dbName, userName, tableName, whereCondition);
                Log.ErrorFormat("Exception {0} ", ex.Message);
                retval.errorMessage = string.Format("Query Failed on table {0} with error {1}", tableName, ex.Message);
            }
            return retval;
        }
        protected DataManipulationBO.SearchResponseBO TableStructuer(CustomFunctionBO requestData)
        {
            DataManipulationBO.SearchResponseBO retval = new DataManipulationBO.SearchResponseBO();
            var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
            var data = json.Deserialize<DataManipulationBO.SearchRequestBO>(requestData.data.ToString());
            string dbName = data.loginData.dbName;
            string userName = data.loginData.userId;
            string password = data.loginData.password;
            string tableName = data.tableName;
            string whereCondition = data.whereClause;

            try
            {

                Log.InfoFormat("Search Request from User {0} for Db {1} as {2} UserName for table {3}", User, dbName, userName, tableName);
                DatabaseHelper dbHelper = GetDBHelper(dbName, userName, password);
                //dbHelper.CacheConnection(true);



                var query = GetTableStructureQuery(dbName, tableName);
                retval.data = dbHelper.ExecuteSelectQuery(query);
                Log.InfoFormat("{0} rows found for Request from User {1} for Db {2} as {3} UserName for table {4} with whereClause {5}", retval.data.rows.Count, User, dbName, userName, tableName, whereCondition);
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Select query failed from User {0} for Db {1} as {2} UserName for table {3} with whereClause {4}", User, dbName, userName, tableName, whereCondition);
                Log.ErrorFormat("Exception {0} ", ex.Message);
                retval.errorMessage = string.Format("Query Failed on table {0} with error {1}", tableName, ex.Message);
            }
            return retval;
        }

        public override ResponseBO UpdateDB(RequestBO requestData)
        {
            DataManipulationBO.SubmitResponseBO retval = new DataManipulationBO.SubmitResponseBO();
            var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
            var data = json.Deserialize<DataManipulationBO.SubmitRequestBO>(requestData.data.ToString());
            string dbName = data.loginData.dbName;
            string userName = data.loginData.userId;
            string password = data.loginData.password;
            string tableName = data.tableName;
            TableDataResponseBO insertData = data.insertData;
            TableDataResponseBO deleteData = data.deleteData;
            TableDataResponseBO beforeUpdateData = data.beforeUpdateData;
            TableDataResponseBO afterUpdateData = data.afterUpdateData;

            try
            {
                if (!Compliance.IsActionAllowed(User, requestData.screenName, Constants.DataManipulationSave, Url, requestData.runEnviroment))
                    throw new Exception("Permission denied");

                Log.InfoFormat("Submit Request from User {0} for Db {1} as {2} UserName for table {3}", User, dbName, userName, tableName);
                DatabaseHelper dbHelper = GetDBHelper(dbName, userName, password);
                dbHelper.BeginTransaction();
                try
                {
                    if (insertData.rows.Count == 0 && deleteData.rows.Count == 0 && afterUpdateData.rows.Count == 0)
                    {
                        Log.InfoFormat("No change in data");
                    }
                    else
                    {
                        var tableData = dbHelper.ExecuteSelectQuery(GetTableStructureQuery(dbName, tableName));
                        if (tableData.rows.Count > 0)
                        {
                            for (int i = 0; i < tableData.rows.Count; i++)
                            {
                                tableStructureDec.Add(Convert.ToString(tableData.rows[i][0]), tableData.rows[i][1]);
                            }
                        }

                        if (deleteData.rows.Count > 0)
                        {
                            Log.InfoFormat("Deleting data request by User {0} for Db {1} as {2} UserName for table {3}", User, dbName, userName, tableName);
                            DeleteData(dbHelper, tableName, deleteData, dbName, userName);
                            Log.InfoFormat("{0} rows deleted for Request from User {1} for Db {2} as {3} UserName for table {4}", deleteData.rows.Count, User, dbName, userName, tableName);
                        }
                        if (afterUpdateData.rows.Count > 0)
                        {
                            UpdateData(dbHelper, tableName, beforeUpdateData, afterUpdateData, dbName, userName, tableStructureDec);
                            Log.InfoFormat("{0} rows updated for Request from User {1} for Db {2} as {3} UserName for table {4}", afterUpdateData.rows.Count, User, dbName, userName, tableName);
                        }
                        if (insertData.rows.Count > 0)
                        {
                            InsertData(dbHelper, tableName, insertData, dbName, userName, tableStructureDec);
                            Log.InfoFormat("{0} rows inserted for Request from User {1} for Db {2} as {3} UserName for table {4}", insertData.rows.Count, User, dbName, userName, tableName);
                        }

                        foreach (var auditId in auditIds)
                            LogActionToAudit(new OrderedDictionary() { { "status", "Success" } }, auditId);
                        dbHelper.Commit();
                    }
                }
                catch (Exception ex)
                {
                    Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                    dbHelper.Rollback();
                    foreach (var auditId in auditIds)
                        LogActionToAudit(new OrderedDictionary() { { "status", "Fail" } }, auditId);
                    throw;
                }
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("submit request failed from User {0} for Db {1} as {2} UserName for table {3}", User, dbName, userName, tableName);
                Log.ErrorFormat("Exception {0} ", ex.Message);
                retval.errorMessage = string.Format("Submit request failed on table {0} with error {1}", tableName, ex.Message);
            }

            return retval;
        }

        private void InsertData(DatabaseHelper dbHelper, string tableName, TableDataResponseBO data, string dbName, string userName, Dictionary<string, object> tableStructure)
        {
            foreach (var row in data.rows)
            {
                Dictionary<string, object> bindVariableList = new Dictionary<string, object>();
                List<string> nullColList2 = new List<string>();
                List<string> notNullColList2 = new List<string>();
                foreach (var col in data.columns)
                {
                    if (row[data.columns.IndexOf(col)] != null && row[data.columns.IndexOf(col)] != System.DBNull.Value)
                    {
                        object value = ConvertValue(col, Convert.ToString(row[data.columns.IndexOf(col)]), tableStructure, dbName);
                        bindVariableList[col] = value;
                        //bindVariableList[col] = row[data.columns.IndexOf(col)];
                        notNullColList2.Add(col);
                    }
                    else
                        nullColList2.Add(col);
                }
                var bindArgPreFix = dbHelper.GetDBType() == DatabaseHelper.Database.ORACLE ? ":" : "@";
                auditIds.Add(LogActionToAudit(new OrderedDictionary() {
                               { "Database : ", dbName }, { "User : ", userName }, { "TableName : ", tableName }, { "Action : ", "I" }, { "Data", string.Join(" | ", bindVariableList) }, { "Condition",  ""} }));
                if (notNullColList2.Count > 0)
                {
                    var query = string.Format("insert into {0} ({1}) values ({2})"
                        , tableName, string.Join(",", notNullColList2), string.Join(",", notNullColList2.Select(x => bindArgPreFix + x)));
                    dbHelper.ExecuteNonQuery(query, bindVariableList);
                }
                else
                {
                    var query = string.Format("insert into {0} ({1}) values ({2})"
                        , tableName, string.Join(",", data.columns), string.Join(",", data.columns.Select(x => "null")));
                    dbHelper.ExecuteNonQuery(query, bindVariableList);
                    // throw new Exception("As all columns are having null value so not inserting the row");
                }
            }
        }

        private void DeleteData(DatabaseHelper dbHelper, string tableName, TableDataResponseBO data, string dbName, string userName)
        {

            var uniqColumns = dbHelper.GetUniqueIndexColumns(tableName);
            foreach (var row in data.rows)
            {
                Dictionary<string, object> bindVariableList = new Dictionary<string, object>();

                List<string> nullColList2 = new List<string>();
                List<string> notNullColList2 = new List<string>();
                foreach (var col in uniqColumns)
                {
                    if (row[data.columns.IndexOf(col)] != null && row[data.columns.IndexOf(col)] != System.DBNull.Value)
                    {
                        bindVariableList[col] = row[data.columns.IndexOf(col)];
                        notNullColList2.Add(col);
                    }
                    else
                        nullColList2.Add(col);
                }

                var bindArgPreFix = dbHelper.GetDBType() == DatabaseHelper.Database.ORACLE ? ":" : "@";
                List<string> whereList = new List<string>();
                whereList.AddRange(notNullColList2.Select(x => x + " = " + bindArgPreFix + x));
                whereList.AddRange(nullColList2.Select(x => x + " is null "));
                var query = string.Format("delete from {0} where {1}", tableName, string.Join(" and ", whereList));
                auditIds.Add(LogActionToAudit(new OrderedDictionary() {
                               { "Database : ", dbName }, { "User : ", userName }, { "TableName : ", tableName }, { "Action : ", "D" }, { "Data", string.Join(" | ", bindVariableList) }, { "Condition",  string.Join(" | ", whereList) } }));
                dbHelper.ExecuteNonQuery(query, bindVariableList);
            }
        }

        private void UpdateData(DatabaseHelper dbHelper, string tableName, TableDataResponseBO oldData, TableDataResponseBO newData, string dbName, string userName, Dictionary<string, object> tableStructure)
        {
            var uniqColumns = dbHelper.GetUniqueIndexColumns(tableName);

            for (var i = 0; i < oldData.rows.Count; i++)
            {
                Dictionary<string, object> bindVariableList = new Dictionary<string, object>();
                List<string> nullColList = new List<string>();
                List<string> notNullColList = new List<string>();
                foreach (var col in oldData.columns)
                {
                    if ((oldData.rows[i][oldData.columns.IndexOf(col)] == null || oldData.rows[i][oldData.columns.IndexOf(col)] == System.DBNull.Value)
                        && (newData.rows[i][newData.columns.IndexOf(col)] == null || newData.rows[i][newData.columns.IndexOf(col)] == System.DBNull.Value))
                        continue;
                    else if (oldData.rows[i][oldData.columns.IndexOf(col)] == null || oldData.rows[i][oldData.columns.IndexOf(col)] == System.DBNull.Value
                        || newData.rows[i][newData.columns.IndexOf(col)] == null || newData.rows[i][newData.columns.IndexOf(col)] == System.DBNull.Value
                        || oldData.rows[i][oldData.columns.IndexOf(col)].ToString() != newData.rows[i][newData.columns.IndexOf(col)].ToString())
                    {
                        if (newData.rows[i][newData.columns.IndexOf(col)] != null && newData.rows[i][newData.columns.IndexOf(col)] != System.DBNull.Value)
                        {
                            object value = ConvertValue(col, Convert.ToString(newData.rows[i][newData.columns.IndexOf(col)]), tableStructure, dbName);
                            bindVariableList[col] = value;
                            //bindVariableList[col] = newData.rows[i][newData.columns.IndexOf(col)];
                            notNullColList.Add(col);
                        }
                        else
                            nullColList.Add(col);
                    }
                }
                List<string> nullColList2 = new List<string>();
                List<string> notNullColList2 = new List<string>();
                foreach (var col in uniqColumns)
                {
                    if (oldData.rows[i][oldData.columns.IndexOf(col)] != null && oldData.rows[i][oldData.columns.IndexOf(col)] != System.DBNull.Value)
                    {
                        bindVariableList[col + "_1"] = oldData.rows[i][oldData.columns.IndexOf(col)];
                        notNullColList2.Add(col);
                    }
                    else
                        nullColList2.Add(col);
                }

                var bindArgPreFix = dbHelper.GetDBType() == DatabaseHelper.Database.ORACLE ? ":" : "@";
                List<string> setList = new List<string>();
                setList.AddRange(notNullColList.Select(x => x + " = " + bindArgPreFix + x));
                setList.AddRange(nullColList.Select(x => x + " = null "));
                List<string> whereList = new List<string>();
                whereList.AddRange(notNullColList2.Select(x => x + " = " + bindArgPreFix + x + "_1"));
                whereList.AddRange(nullColList2.Select(x => x + " is null "));
                auditIds.Add(LogActionToAudit(new OrderedDictionary() {
                               { "Database : ", dbName }, { "User : ", userName }, { "TableName : ", tableName }, { "Action : ", "U" }, { "Data", string.Join(" | ", bindVariableList) }, { "Condition",  string.Join(" | ", whereList) } }));
                if (setList.Count > 0)
                {
                    var query = string.Format("update {0} set {1} where {2}"
                        , tableName
                        , string.Join(",", setList)
                        , string.Join(" and ", whereList));
                    dbHelper.ExecuteNonQuery(query, bindVariableList);
                }
                else
                {
                    Log.Info("Nothing to update");
                }
            }
        }

        public override ResponseBO CustomFunction(CustomFunctionBO requestData)
        {
            var retval = new ResponseBO();
            switch (requestData.functionName)
            {
                case "Login":
                    {
                        retval = CheckLoginDetail(requestData);
                    }
                    break;
                case "SearchData":
                    {
                        retval = SearchData(requestData);
                    }
                    break;
                case "TableDetail":
                    {
                        retval = TableStructuer(requestData);
                    }
                    break;
                default:
                    retval.errorMessage = string.Format("Unknown function {0} call", requestData.functionName);
                    break;
            }

            return retval;
        }

        private string GetTableStructureQuery(string dbName, string tableNamewithSchema)
        {
            var query = string.Empty;

            var columns = string.Empty;
            var splitTableName = tableNamewithSchema.Split('.').ToList();
            if (splitTableName.Count <= 1)
                throw new Exception(string.Format("Schema name missing from table {0}", tableNamewithSchema));
            var schemaName = splitTableName[0];
            var tableName = splitTableName[splitTableName.Count - 1];

            if (dbName.Contains("ORA"))
            {
                query = string.Format(@"SELECT  column_name, data_type, data_length,nullable,data_default,column_id FROM all_tab_columns where OWNER = '{0}' AND table_name = '{1}' order by column_id ", schemaName.ToUpper(), tableName.ToUpper());

            }
            else
            {
                query = string.Format(@"SELECT  b.name 'column_name', c.name 'data_type',b.length 'data_length',CASE WHEN (b.status&8) != 0 THEN 'Y' ELSE 'N' END nullable, d.text data_default ,b.colid 'column_id'
                FROM {0}..sysobjects  a JOIN {0}..syscolumns b ON a.id = b.id JOIN {0}..systypes c ON  c.usertype = b.usertype left Join {0}..syscomments d on b.cdefault = d.id WHERE a.name LIKE '{1}'  order by b.colid ", schemaName, tableName);
            }
            return query;
        }
        public object ConvertValue(string columnName, string value, Dictionary<string, object> tableStructure, string dbName)
        {
            object returnValue = value;
            var exsits = false;
            var dictval = from x in tableStructure
                          where x.Key.Contains(columnName)
                          select x;
            string colDataType = Convert.ToString(dictval.First().Value);
            exsits = Enum.IsDefined(typeof(enumInt), colDataType.ToUpper());
            if (exsits)
            {
                return Convert.ToDouble(value);
            }
            //dbName.ToLowerInvariant().StartsWith("ora") &&
            else if (colDataType.ToUpper().Contains("DATE") || colDataType.ToUpper().Contains("TIME"))
            {
                returnValue = Convert.ToDateTime(value);
            }
            return returnValue;
        }
    }
    public enum enumInt
    {
        BIGINT,
        INT,
        INTEGER,
        SMALLINT,
        TINYINT,
        DECIMAL,
        NUMERIC,
        DOUBLE,
        FLOAT,
        REAL,
        IDENTITY,
        MONEY,
        NUMBER,
        DEC,

    }

}