﻿using System;
using log4net;
using Cronus.BO;
using Cronus.BO.Fes;
using System.Web.Script.Serialization;
using Cronus.Bll.Helper;
using System.Collections.Specialized;

namespace Cronus.Bll.Fes
{
    class CreditEntityAttributes : CronusBaseBll
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public override object Clone() { return new CreditEntityAttributes(); }

        public override string ScreenName()
        {
            return Constants.CreditEntityAttributes;
        }

        protected override string GetTableQuery(TableDataRequestBO requestData, out DatabaseType dbType)
        {
            //Permission Check
            if (!Compliance.IsActionAllowed(User, requestData.screenName, Constants.CreditEntityAttributesView, Url,requestData.runEnviroment))
                throw new Exception("Permission denied");

            dbType = DatabaseType.ORACLE;
            var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
            var data = json.Deserialize<CreditEntityAttributesBO.SearchRequestBO>(requestData.data.ToString());
            if (data == null)
                throw new Exception("Failed in Json Deserialization");

            string query;
            switch (requestData.tableName)
            {
                case "CreditEntity":
                    query = GetCreditEntityAttributeDataQuery(data);
                    break;
                case "SsmIdDetail":
                    query = GetSsmIdQuery(data);
                    break;
                case "Audit":
                    query = AuditCreditEntityAtttrQuery(data);
                    break;
                default:
                    throw new Exception(string.Format("Unknown RequestType {0}", requestData.tableName));
            }
            return query;

        }

        private static string AuditCreditEntityAtttrQuery(CreditEntityAttributesBO.SearchRequestBO data)
        {
            var query = "select * from CRD_OWN.AUDIT_DTLS_VW";
            query = query + " where CREDIT_ENTITY_ID = '" + data.creditEntityId + "' order by  last_chg_date desc";
            return query;
        }

        private static string GetSsmIdQuery(CreditEntityAttributesBO.SearchRequestBO data)
        {
            var query = "select * from CRD_OWN.SSM_ID_DTLS_VW";
            query = query + " where CREDIT_ENTITY_ID = '" + data.creditEntityId + "' ";
            return query;
        }
        //
        private static string GetCreditEntityAttributeDataQuery(CreditEntityAttributesBO.SearchRequestBO data)
        {
            var query = "select * from CRD_OWN.CE_ATTRIB_VW  where 1 = 1 ";
            if (!string.IsNullOrEmpty(data.reprCdIsDeliverable))
                query = query + " AND LOWER(REPR_CD_IS_DELIVERABLE) = '" + (data.reprCdIsDeliverable) + "' ";

            if (!string.IsNullOrEmpty(data.ssmId.Trim()))
                query = query + " AND ssm_id = '" + data.ssmId.Trim() + "'";

            if (!string.IsNullOrEmpty(data.reprCdsIssuerId.Trim()))
                query = query + " AND LOWER(REPR_CDS_ISSUER_ID) = '" + data.reprCdsIssuerId.Replace("'", "''").ToLower() + "'";

            if (!string.IsNullOrEmpty(data.reprIssuerId.Trim()))
                query = query + " AND LOWER(REPR_ISSUER_ID) = '" + data.reprIssuerId.Replace("'", "''").ToLower() + "'";

            if (!string.IsNullOrEmpty(data.reprTicker.Trim()))
                query = query + " AND LOWER(REPR_TICKER) = '" + data.reprTicker.Replace("'", "''").ToLower() + "'";

            if (!string.IsNullOrEmpty(data.bloomCorpTicker.Trim()))
                query = query + " AND LOWER(BLOOM_CORP_TICKER) = '" + data.bloomCorpTicker.Replace("'", "''").ToLower() + "' ";

            if (!string.IsNullOrEmpty(data.ultParentIssuerId.Trim()))
                query = query + " AND LOWER(ULT_PARENT_ISSUER_ID) = '" + data.ultParentIssuerId.Replace("'", "''").ToLower() + "' ";

            if (!string.IsNullOrEmpty(data.creditEntityId.Trim()))
                query = query + " AND CREDIT_ENTITY_ID = " + data.creditEntityId + " ";

            query = query + " ORDER BY CREDIT_ENTITY_ID";

            return query;
        }

        public override ResponseBO UpdateDB(RequestBO req)
        {
            Log.Debug("Enter");
            var retval = new ResponseBO();
            var dbHelper = OracleDbHelper;

            try
            {
                //Permission Check
                if (!Compliance.IsActionAllowed(User, req.screenName, Constants.CreditEntityAttributesUpdate, Url,req.runEnviroment))
                    throw new Exception("Permission denied");

                dbHelper.BeginTransaction();
                var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                var data = json.Deserialize<CreditEntityAttributesBO.UpdateRequestBO>(req.data.ToString());
                if (data == null)
                    throw new Exception("Failed in Json Deserialization");

                //Validate data
                if (string.IsNullOrEmpty(data.creditEntityId))
                    throw new Exception("CreditEntityID can not be null");

                Log.Info(string.Format("Update Request by User: {0} Processing {1}", User, data));

                var auditId = LogActionToAudit(new OrderedDictionary() { { "CreditEndityId", data.creditEntityId }
                                                                        , { "ReprCdsIssuerId", data.reprCdsIssuerId }
                                                                        , { "ReprCdIsDeliverable", data.reprCdIsDeliverable }
                                                                        , { "ReprBondRecoveryRate", data.reprBondRecoveryRate } 
                                                                        , { "PrimaryCurrency", data.primaryCurrency } 
                                                                        , { "CountryOfExposure", data.countryOfExposure }
                                                                        , { "isActive", data.isActive }});

                try
                {
                    var queryProc = string.Format("Execute CRD_OWN.upd_ce_attrib_pkg.upd_ce_attrib({0}, '{1}','{2}', '{3}', '{4}','{5}','{6}', '{7}')"
                        , data.creditEntityId, data.reprCdsIssuerId, data.reprCdIsDeliverable, data.reprBondRecoveryRate, data.primaryCurrency, data.countryOfExposure, data.isActive, User);
                    dbHelper.ExecuteProcedure(queryProc);
                    LogActionToAudit(new OrderedDictionary() { { "Status", "Success" } }, auditId);
                }
                catch (Exception ex)
                {
                    Log.Error(retval.errorMessage, ex);
                    dbHelper.Rollback();
                    LogActionToAudit(new OrderedDictionary() { { "Status", "Fail" } }, auditId);
                    throw;
                }

            }
            catch (Exception ex)
            {
                retval.errorMessage = string.Format("Exception: {0}", ex.Message);
                Log.Error(retval.errorMessage, ex);
            }
            finally
            {
                Log.Debug("Exit");
            }
            return retval;
        }
    }
}
