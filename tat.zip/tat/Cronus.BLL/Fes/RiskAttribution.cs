﻿using System;
using System.Collections.Generic;
using log4net;
using Cronus.BO;
using Cronus.BO.Fes;
using System.Web.Script.Serialization;
using Cronus.Bll.Helper;
using System.Collections.Specialized;
using Cronus.Bo.Fes;

namespace Cronus.Bll.Fes
{
    class RiskAttribution : CronusBaseBll
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public override object Clone() { return new RiskAttribution(); }

        public override string ScreenName()
        {
            return Constants.RiskAttribution;
        }

        protected override string GetTableQuery(TableDataRequestBO requestData, out DatabaseType dbType)
        {
            //Permission Check
            if (!Compliance.IsActionAllowed(User, requestData.screenName, Constants.RiskAttributionView, Url, requestData.runEnviroment))
                throw new Exception("Permission denied");

            dbType = DatabaseType.ORACLE;
            var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
            var data = json.Deserialize<RiskAttributtionBO.SearchRequestBO>(requestData.data.ToString());
            if (data == null)
                throw new Exception("Failed in Json Deserialization");

            string query;
            switch (requestData.tableName)
            {
                case "RiskMeasures":
                    query = "select distinct KEY  from cronus_own.config";
                    break;
                case "RunIds":
                    query = "select distinct run_id from pm..sec_invocation_matrix where ssm_id ='JPY7186D1'";//data.PriceDate;
                    break;
                default:
                    throw new Exception(string.Format("Unknown RequestType {0}", requestData.tableName));
            }
            return query;
        }

        public override ResponseBO CustomFunction(CustomFunctionBO req)
        {
            Log.Debug("Enter");
            var retval = new RiskAttributtionBO.SearchResponseBO();

            //Permission Check for Screem view Permission
            if (!Compliance.IsActionAllowed(User, req.screenName, Constants.RiskAttributionView, Url, req.runEnviroment))
                throw new Exception("Permission denied");
         
            try
            {
                var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };

                switch (req.functionName)
                {
                    case "Search":                        
                        var requestObj = json.Deserialize<RiskAttributtionBO.SearchRequestBO>(req.data.ToString());
                        if (requestObj == null)
                            throw new Exception("Failed in Json Deserialization");
                        var ssmIds = requestObj.SsmId == null ? null : requestObj.SsmId;
                        var accNo = requestObj.AccountNumber == null ? null : requestObj.AccountNumber;
                        var riskMeasure = requestObj.RiskMeasure == null ? null : requestObj.RiskMeasure;
                        var priceDate = requestObj.PriceDate;
                        var prevPriceDate = requestObj.PreviousPriceDate;
                        var runIds = requestObj.RunId == null ? null : requestObj.RunId;
                        var prevRunIds = requestObj.PreviousRunId == null ? null : requestObj.PreviousRunId;

                        Log.Info(string.Format("Search Request for ssm_ids = {0} , AccountNumber = {1}, RiskMeasures = {2}, PriceDate = {3}, prevPriceDate = {4}, RunId = {5}, PrevRunId = {6} by User = {7}"
                            , ssmIds, accNo, riskMeasure, priceDate, prevPriceDate, runIds, prevRunIds, User));

                        var dbHelper = this.SybaseDbHelper;

                        const string query = "select top 10 acct_no as acct_no,'JPY7186D1' as ssm_id,risk_measure,change_market as today_val, change_position as yesterday_value  from pm..account_attribution_hist where acct_no = 3379";
                        //"select top 10 acct_no as acct_no,'JPY7186D1' as ssm_id,risk_measure,change_market as today_val, change_position as yesterday_value  from pm..account_attribution_hist where acct_no = 3379"
                        retval.data1 = dbHelper.ExecuteSelectQuery(query);                        
                        retval.data2 = dbHelper.ExecuteSelectQuery(query);                        
                        retval.data3 = dbHelper.ExecuteSelectQuery(query);
                        
                        break;
                    default:
                        throw new Exception(string.Format("Unknown functionName {0}", req.functionName));

                }
                return retval;
            }
            catch (Exception ex)
            {
                retval.errorMessage = string.Format("Exception: {0}", ex.Message);
                Log.Error(retval.errorMessage, ex);
            }
            finally
            {
                Log.Debug("Exit");
            }

            return retval;
        }        
        
        public override ResponseBO UpdateDB(RequestBO req)
        {
            Log.Debug("Enter");
            var retval = new ResponseBO();
            var dbHelper = OracleDbHelper;

            try
            {
                //Permission Check
                if (!Compliance.IsActionAllowed(User, req.screenName, Constants.CreditEntityAttributesUpdate, Url, req.runEnviroment))
                    throw new Exception("Permission denied");

                dbHelper.BeginTransaction();
                var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                var data = json.Deserialize<RiskAttributtionBO.UpdateRequestBO>(req.data.ToString());
                if (data == null)
                    throw new Exception("Failed in Json Deserialization");

                //Validate data
                if (string.IsNullOrEmpty(data.creditEntityId))
                    throw new Exception("CreditEntityID can not be null");

                Log.Info(string.Format("Update Request by User: {0} Processing {1}", User, data));

                var auditId = LogActionToAudit(new OrderedDictionary() { { "CreditEndityId", data.creditEntityId }
                                                                        , { "ReprCdsIssuerId", data.reprCdsIssuerId }
                                                                        , { "ReprCdIsDeliverable", data.reprCdIsDeliverable }
                                                                        , { "ReprBondRecoveryRate", data.reprBondRecoveryRate } 
                                                                        , { "PrimaryCurrency", data.primaryCurrency } 
                                                                        , { "CountryOfExposure", data.countryOfExposure }
                                                                        , { "isActive", data.isActive }});

                try
                {
                    var queryProc = string.Format("Execute CRD_OWN.upd_ce_attrib_pkg.upd_ce_attrib({0}, '{1}','{2}', '{3}', '{4}','{5}','{6}', '{7}')"
                        , data.creditEntityId, data.reprCdsIssuerId, data.reprCdIsDeliverable, data.reprBondRecoveryRate, data.primaryCurrency, data.countryOfExposure, data.isActive, User);
                    dbHelper.ExecuteProcedure(queryProc);
                    LogActionToAudit(new OrderedDictionary() { { "Status", "Success" } }, auditId);
                }
                catch (Exception ex)
                {
                    Log.Error(retval.errorMessage, ex);
                    dbHelper.Rollback();
                    LogActionToAudit(new OrderedDictionary() { { "Status", "Fail" } }, auditId);
                    throw;
                }

            }
            catch (Exception ex)
            {
                retval.errorMessage = string.Format("Exception: {0}", ex.Message);
                Log.Error(retval.errorMessage, ex);
            }
            finally
            {
                Log.Debug("Exit");
            }
            return retval;
        }
    }
}
