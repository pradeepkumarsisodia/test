﻿using System.Collections.Generic;

namespace Cronus.Bll.Fes
{
    public class Regression : CronusBaseBll
    {
        private static Dictionary<string, long> _requestIdsCache = new Dictionary<string, long>();

        public override object Clone() { return new Regression(); }

        public override string ScreenName()
        {
            return Constants.Regression;
        }

        //public override ResponseBO SubmitRequest(RequestBO req) 
        //{
        //    log.Debug("Enter");
        //    RiskMeasuresLiveBO.RunResponseBO retval = new RiskMeasuresLiveBO.RunResponseBO();
        //    try
        //    {
        //        //Permission Check
        //        //if (!Compliance.IsActionAllowed(User, req.screenName, Constants.RiskMeasureLive_Run, Url))
        //        //    throw new Exception("Permission denied to view data");

        //        JavaScriptSerializer json = new JavaScriptSerializer();
        //        json.MaxJsonLength = Int32.MaxValue;

        //        var request = json.Deserialize<Dictionary<string, object>>(req.data.ToString());

        //        var parameters = new Dictionary<string, object>
        //        {
        //           {FeServerKeys.CommandParams, new Dictionary<string, object> { {"price-date", request["priceDate"] }} },
        //           {FeServerKeys.CommandFlags, new List<string>()}
        //        };
                
        //        string requestId = Forum.Instance.Publish(User, FeServerTasks.REGRESSION, parameters);

        //        retval.requestId = requestId;
        //    }
        //    catch (Exception ex)
        //    {
        //        retval.errorMessage = string.Format("Exception: {0}", ex.Message);
        //        log.Error(retval.errorMessage,ex);
        //    }
        //    finally
        //    {
        //        log.Debug("Exit");
        //    }

        //    return retval;
        //}

    }
}
