﻿﻿using System;
using System.Collections.Generic;
﻿using log4net;
﻿using System.Web.Script.Serialization;
﻿using Cronus.BO;
﻿using Cronus.Bo.Fes;
using System.Collections.Specialized;
﻿using System.Linq;
﻿using Cronus.Bll.Helper;

namespace Cronus.Bll.Fes
{
    public class StaleRiskMeasures : CronusBaseBll
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private Dictionary<string, string> _configData;
        private Dictionary<string, DatabaseHelper> _dbHelperDict = new Dictionary<string, DatabaseHelper>();

        public override object Clone()
        {
            return new StaleRiskMeasures();
        }

        public override string ScreenName()
        {
            return Constants.StaleRiskMeasures;
        }

        protected override string GetTableQuery(TableDataRequestBO requestData, out DatabaseType dbType)
        {
            var tableName = requestData.tableName;

            dbType = DatabaseType.ORACLE;
            string query;
            switch (tableName)
            {
                case "TableAliases":
                    query = string.Format("select * from  (select distinct KEY  from cronus_own.config  where SCREENID = '{0}' and context = 'STALE_TABLE' and key NOT LIKE '%_ora' order by KEY DESC) s1 " +
                                          " UNION ALL select * from  (select distinct KEY  from cronus_own.config  where SCREENID = '{0}' and context = 'STALE_TABLE' and key  LIKE '%_ora' order by KEY DESC) s2 ", ScreenName());
                    break;
                case "RiskMeasuresAliases":
                    query = string.Format("select distinct KEY  from cronus_own.config  where SCREENID = '{0}' and context = 'STALE_RISK_MEASURE' " +
                                          "order by KEY DESC ", ScreenName());
                    break;
                default:
                    throw new Exception(string.Format("Unknown TableName {0}", tableName));
            }
            return query;
        }

        public override ResponseBO CustomFunction(CustomFunctionBO req)
        {
            Log.Debug("Enter");
            var retval = new ResponseBO();

            //Permission Check for Screem view Permission
            if (!Compliance.IsActionAllowed(User, req.screenName, Constants.StaleRiskMeasuresView, Url, req.runEnviroment))
                throw new Exception("Permission denied");

            try
            {
                var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };

                switch (req.functionName)
                {
                    case "SearchData":
                        {
                            var requestBO = json.Deserialize<StaleRiskMeasuresBO.SearchRequestBO>(req.data.ToString());
                            if (requestBO == null)
                                throw new Exception("Failed in Json Deserialization");

                            retval = SearchData(requestBO);
                            break;
                        }

                    case "SubmitData":
                        {
                            var requestBO = json.Deserialize<StaleRiskMeasuresBO.SubmitRequestBO>(req.data.ToString());
                            if (requestBO == null)
                                throw new Exception("Failed in Json Deserialization");

                            retval = SubmitData(requestBO, req.runEnviroment);
                            break;
                        }

                    default:
                        throw new Exception(string.Format("Unknown functionName {0}", req.functionName));

                }
            }
            catch (Exception ex)
            {
                retval.errorMessage = string.Format("Exception: {0}", ex.Message);
                Log.Error(retval.errorMessage, ex);
            }
            finally
            {
                Log.Debug("Exit");
            }

            return retval;
        }

        private StaleRiskMeasuresBO.SearchResponseBO SearchData(StaleRiskMeasuresBO.SearchRequestBO requestObj)
        {
            var retval = new StaleRiskMeasuresBO.SearchResponseBO()
            {
                CusipList = requestObj.CusipList,
                StaleDate = requestObj.StaleDate,
                TablesDataList = new List<StaleRiskMeasuresBO.TableDataBO>()
            };

            var cusipList = requestObj.CusipList == null ? null : requestObj.CusipList;
            var cusipTable = requestObj.CusipTable;
            var staleDate = requestObj.StaleDate;
            var selectedTableList = requestObj.SelectedTableList == null ? null : requestObj.SelectedTableList;
            var selectedRiskMeasuresList = requestObj.SelectedRiskMeasuresList == null ? null : requestObj.SelectedRiskMeasuresList;

            Log.Info(string.Format("Search Request for ssm_ids/ssm_id_table = {0} , StaleDate = {1}, Tables = {2} by User = {3}"
                , cusipList == null ? cusipTable : string.Join(",", cusipList), staleDate
                , selectedRiskMeasuresList == null ? string.Join(",", selectedTableList) : string.Join(",", selectedRiskMeasuresList), User));

            //Validate the Input. 
            //The cusips or cusip tables is mandatory
            //tables or risk measures should be staled
            if (cusipList == null && string.IsNullOrWhiteSpace(cusipTable))
                throw new Exception("cusip list and cusip table both can not be null");
            if ((selectedTableList == null || selectedTableList.Count == 0) && (selectedRiskMeasuresList == null || selectedRiskMeasuresList.Count == 0))
                throw new Exception("Selected table list and select risk measures can not be null or empty");

            //If cusip table passed get the cusip list
            if (!string.IsNullOrEmpty(cusipTable))
            {
                cusipList = FetchCusipList(cusipTable);
                if (cusipList.Count == 0)
                {
                    retval.WarningMessage = string.Format("No Cusips found in  {0} \n", cusipTable);
                    return retval;
                }
            }

            //Make sure we have unique cusip list
            cusipList = cusipList.Distinct().ToList();
            List<StaleRiskMeasuresBO.TableDataBO> tableDataList = selectedRiskMeasuresList == null ? GetDataForTables(cusipList, staleDate, selectedTableList) : GetDataForRiskMeasures(cusipList, staleDate, selectedRiskMeasuresList);
            foreach (var tableData in tableDataList)
            {
                var missingCusipList = new List<string>();
                foreach (var cusip in cusipList)
                {
                    if (!tableData.CusipList.Contains(cusip))
                        missingCusipList.Add(cusip);
                }
                if (missingCusipList.Count > 0)
                    retval.WarningMessage += string.Format("No data found for table {0} : Cusips {1}\n", tableData.TableAlias, string.Join(",", missingCusipList));
                if(missingCusipList.Count < cusipList.Count)
                    retval.TablesDataList.Add(tableData);
            }
            

            return retval;

        }

        string GetConfigData(string key, string value)
        {
            string retval = "";
            if (_configData == null)
            {
                _configData = new Dictionary<string, string>();
                var query = string.Format(@"select KEY,  CONTEXT, VALUE from CRONUS_OWN.CONFIG where Screenid = '{0}' and (Upper(Environment) = '{1}' or Environment is null)", ScreenName(), RunOnEnviroment);
                var result = OracleDbHelper.ExecuteSelectQuery(query);
                foreach (var row in result.rows)
                {
                    string dictionaryKey = row[0] + "_|_" + row[1];
                    _configData[dictionaryKey] = row[2].ToString();
                }
                if (value != StaleRiskMeasuresBO.Constants.UpdateRelatedColumns)
                {
                    /*Mandatory config*/
                    List<string> mandatoryValues = new List<string>();
                    mandatoryValues.Add(StaleRiskMeasuresBO.Constants.MainTable);
                    mandatoryValues.Add(StaleRiskMeasuresBO.Constants.HistTable);
                    mandatoryValues.Add(StaleRiskMeasuresBO.Constants.Database);
                    mandatoryValues.Add(StaleRiskMeasuresBO.Constants.PriceDateCol);
                    mandatoryValues.Add(StaleRiskMeasuresBO.Constants.SsmIdCol);
                    foreach (var mantoryval in mandatoryValues)
                    {
                        if (!_configData.ContainsKey(key + "_|_" + mantoryval))
                            throw new Exception(string.Format("Config missing for {0} and {1}", key, mantoryval));
                    }
                }
            }

            string dicKey = key + "_|_" + value;
            if (_configData.ContainsKey(dicKey))
                retval = _configData[dicKey];
            return retval;
        }

        List<string> GetColumns(string tableAlias)
        {
            string query = string.Format("Select * From {0} Where 1 = 2", GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.MainTable));

            DatabaseHelper dbHelper = GetConnection(tableAlias);
            TableDataResponseBO data = dbHelper.ExecuteSelectQuery(query);
            return data.columns;
        }

        Dictionary<string, TableDataResponseBO> GetHistTableData(List<string> cusipList, string staleDate, string tableAlias, List<string> columnList)
        {
            Dictionary<string, TableDataResponseBO> retval = new Dictionary<string, TableDataResponseBO>();

            var query = GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.Database) == StaleRiskMeasuresBO.Constants.Oracle ?
                        string.Format(@"select to_date('{5}', 'MM/DD/YYYY') stale_date, {0} from {1} where {2} in ({3}) and {4} = to_date('{5}', 'MM/DD/YYYY') order by ssm_id "
                                            , string.Join(",", columnList.Distinct().ToList())
                                            , GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.HistTable)
                                            , GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.SsmIdCol)
                                            , string.Join(",", cusipList.Select(x => "'" + x + "'"))
                                            , GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.PriceDateCol)
                                            , staleDate)
                    :
                    string.Format(@"select '{5}' stale_date, {0} from {1} where {2} in ({3}) and {4} = '{5}' order by ssm_id "
                                            , string.Join(",", columnList.Distinct().ToList())
                                            , GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.HistTable)
                                            , GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.SsmIdCol)
                                            , string.Join(",", cusipList.Select(x => "'" + x + "'"))
                                            , GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.PriceDateCol)
                                            , staleDate)
                    ;
            DatabaseHelper dbHelper = GetConnection(tableAlias, true);
            TableDataResponseBO data = dbHelper.ExecuteSelectQuery(query);

            foreach (var row in data.rows)
            {
                var cusipIdColIndex = data.columns.FindIndex(x => x.Equals(GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.SsmIdCol), StringComparison.OrdinalIgnoreCase));
                var cusip = row[cusipIdColIndex].ToString();
                if (!retval.ContainsKey(cusip))
                {
                    retval[cusip] = new TableDataResponseBO();
                    retval[cusip].columns = data.columns;
                    if (retval[cusip].rows == null)
                        retval[cusip].rows = new List<List<object>>();
                }
                retval[cusip].rows.Add(row);
            }

            return retval;
        }

        Dictionary<string, TableDataResponseBO> GetMainTableData(List<string> cusipList, string tableAlias, List<string> columnList)
        {
            Dictionary<string, TableDataResponseBO> retval = new Dictionary<string, TableDataResponseBO>();
            //Set first column value as null (price_date column)
            var query = GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.Database) == StaleRiskMeasuresBO.Constants.Oracle ?
                        string.Format(@"select null stale_date, {0} from {1} where {2} in ({3}) order by ssm_id "
                                            , string.Join(",", columnList.Distinct().ToList())
                                            , GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.MainTable)
                                            , GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.SsmIdCol)
                                            , string.Join(",", cusipList.Select(x => "'" + x + "'")))
                    :
                    string.Format(@"select null stale_date, {0} from {1} where {2} in ({3}) order by ssm_id "
                                            , string.Join(",", columnList.Distinct().ToList())
                                            , GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.MainTable)
                                            , GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.SsmIdCol)
                                            , string.Join(",", cusipList.Select(x => "'" + x + "'")))
                    ;
            DatabaseHelper dbHelper = GetConnection(tableAlias);
            TableDataResponseBO data = dbHelper.ExecuteSelectQuery(query);

            foreach (var row in data.rows)
            {
                var cusipIdColIndex = data.columns.FindIndex(x => x.Equals(GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.SsmIdCol), StringComparison.OrdinalIgnoreCase));
                var cusip = row[cusipIdColIndex].ToString();
                if (!retval.ContainsKey(cusip))
                {
                    retval[cusip] = new TableDataResponseBO {columns = data.columns};
                    if (retval[cusip].rows == null)
                        retval[cusip].rows = new List<List<object>>();
                }
                retval[cusip].rows.Add(row);
            }

            return retval;
        }

        Dictionary<string, TableDataResponseBO> GetData(List<string> cusipList, string staleDate, string tableAlias, List<string> columnsList = null)
        {
            Dictionary<string, TableDataResponseBO> retval = new Dictionary<string, TableDataResponseBO>();

            List<string> mainColumnsList = GetColumns(tableAlias);
            if (columnsList != null)
            {
                List<string> tmpColList = new List<string>();
                foreach (var col in mainColumnsList)
                    if (columnsList.FindIndex(x => x.Equals(col, StringComparison.OrdinalIgnoreCase)) != -1)
                        tmpColList.Add(col);
                mainColumnsList = tmpColList;
            }

            //First get today's and stale date data. Then merge that in one table
            Dictionary<string, TableDataResponseBO> histTableDataDic = GetHistTableData(cusipList, staleDate, tableAlias, mainColumnsList);
            Dictionary<string, TableDataResponseBO> mainTableDataDic = GetMainTableData(cusipList, tableAlias, mainColumnsList);

            //Merge data from hist and main table
            foreach (var cusip in mainTableDataDic.Keys)
            {
                if (histTableDataDic.ContainsKey(cusip))
                {
                    retval[cusip] = mainTableDataDic[cusip];
                    retval[cusip].rows.AddRange(histTableDataDic[cusip].rows);
                }
            }

            return retval;
        }

        List<string> RemoveListIgnoreCase(List<string> list, string value)
        {
            List<string> retval = list;

            if (retval.FindIndex(x => x.Equals(value, StringComparison.OrdinalIgnoreCase)) != -1)
                retval.RemoveAt(
                    retval.FindIndex(
                        x => x.Equals(value, StringComparison.OrdinalIgnoreCase)));

            return retval;
        }

        List<string> GetUpdatableColumns(List<string> columnList, string tableAlias)
        {
            List<string> retval = new List<string>();

            retval.AddRange(columnList);
            //Now remove uniq columns
            var columnsToRemove = GetUniqColumns(tableAlias);
            var noUpdateColumns = GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.NoUpdateCol);

            if (!string.IsNullOrWhiteSpace(noUpdateColumns))
                columnsToRemove.AddRange(noUpdateColumns.Split(',').ToList());

            columnsToRemove.Add(StaleRiskMeasuresBO.Constants.SsmIdCol);
            columnsToRemove.Add(StaleRiskMeasuresBO.Constants.PriceDateCol);
            columnsToRemove.Add(StaleRiskMeasuresBO.Constants.StaleDateCol);
            foreach (var col in columnsToRemove)
            {
                retval = RemoveListIgnoreCase(retval, col);
            }

            return retval;
        }

        List<string> GetUniqColumns(string tableAlias)
        {
            List<string> retval = new List<string>();
            var uniqueCols = GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.UniqueKeyCol);
            if (!string.IsNullOrWhiteSpace(uniqueCols))
                retval.AddRange(uniqueCols.Split(',').ToList());
            retval.Add(GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.SsmIdCol));
            retval.Add(GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.PriceDateCol));

            return retval;
        }

        List<StaleRiskMeasuresBO.TableDataBO> GetDataForTables(List<string> cusipList, string staleDate, List<string> tableAliasList, Dictionary<string, List<string>> tableAliasColumnsDict = null)
        {
            List<StaleRiskMeasuresBO.TableDataBO> retval = new List<StaleRiskMeasuresBO.TableDataBO>();

            //Iterate for all selected tables
            foreach (var tableAlias in tableAliasList)
            {
                Dictionary<string, TableDataResponseBO> cusipData =
                    (tableAliasColumnsDict == null || !tableAliasColumnsDict.ContainsKey(tableAlias)) ?
                    GetData(cusipList, staleDate, tableAlias) : GetData(cusipList, staleDate, tableAlias, tableAliasColumnsDict[tableAlias]);
                StaleRiskMeasuresBO.TableDataBO tableData = new StaleRiskMeasuresBO.TableDataBO() { Data = new TableDataResponseBO(), CusipList = new List<string>(), UpdatableColumnsList = new List<string>(), DisplayColumnsList = new List<string>() };
                foreach (var cusip in cusipData.Keys)
                {
                    tableData.Data.columns = cusipData[cusip].columns;
                    tableData.Data.rows = new List<List<object>>();
                    tableData.Data.rows.AddRange(cusipData[cusip].rows);
                    tableData.UpdatableColumnsList = GetUpdatableColumns(tableData.Data.columns, tableAlias);
                    tableData.CusipList.Add(cusip);
                }
                tableData.TableAlias = tableAlias;
                retval.Add(tableData);
            }

            return retval;
        }

        List<StaleRiskMeasuresBO.TableDataBO> GetDataForRiskMeasures(List<string> cusipList, string staleDate, List<string> riskMeasuresList)
        {
            List<StaleRiskMeasuresBO.TableDataBO> retval = new List<StaleRiskMeasuresBO.TableDataBO>();

            Dictionary<string, List<string>> tableAliasColumnsDict = new Dictionary<string, List<string>>();
            //Iterate for all selected risk measures and get tables and columns data from config
            foreach (var riskMeasure in riskMeasuresList)
            {
                var tableAliasColumnsList = GetConfigData(riskMeasure, StaleRiskMeasuresBO.Constants.UpdateRelatedColumns).Split('|');
                foreach (var tableAliasColumns in tableAliasColumnsList)
                {
                    //each entry has tableAlias:Columns
                    var tableColumns = tableAliasColumns.Split(':');
                    if (tableColumns.Count() != 2)
                        throw new Exception(string.Format("Config not correct for risk measure {0} and {1}", riskMeasure, StaleRiskMeasuresBO.Constants.UpdateRelatedColumns));
                    if (tableAliasColumnsDict.Keys.ToList().FindIndex(x => x.Equals(tableColumns[0], StringComparison.OrdinalIgnoreCase)) == -1)
                        tableAliasColumnsDict[tableColumns[0]] = new List<string>();

                    tableAliasColumnsDict[tableColumns[0]].AddRange(tableColumns[1].Split(',').ToList());
                    tableAliasColumnsDict[tableColumns[0]].AddRange(GetUniqColumns(tableColumns[0]));
                    tableAliasColumnsDict[tableColumns[0]] = RemoveListIgnoreCase(tableAliasColumnsDict[tableColumns[0]], GetConfigData(tableColumns[0], StaleRiskMeasuresBO.Constants.PriceDateCol));
                }
            }

            //Get data for all columns
            var data = GetDataForTables(cusipList, staleDate, tableAliasColumnsDict.Keys.ToList(), tableAliasColumnsDict);

            retval = new List<StaleRiskMeasuresBO.TableDataBO>();
            //change the display columns and updatetable column list
            foreach (var tableData in data)
            {
                tableData.UpdatableColumnsList.Clear();
                tableData.UpdatableColumnsList.AddRange(tableAliasColumnsDict[tableData.TableAlias]);
                tableData.UpdatableColumnsList = RemoveListIgnoreCase(tableData.UpdatableColumnsList, GetConfigData(tableData.TableAlias, StaleRiskMeasuresBO.Constants.PriceDateCol));
                tableData.UpdatableColumnsList = RemoveListIgnoreCase(tableData.UpdatableColumnsList, GetConfigData(tableData.TableAlias, StaleRiskMeasuresBO.Constants.SsmIdCol));
                retval.Add(tableData);
            }

            return retval;
        }

        private List<string> FetchCusipList(string cusipTable)
        {
            List<string> cusipList = new List<string>();

            //if table one dot means oracle table else sybase table 
            DatabaseHelper dbHelper = cusipTable.Contains("..") ? SybaseDbHelper : OracleDbHelper;

            var cusipData = dbHelper.ExecuteSelectQuery(String.Format("select * from {0}", cusipTable));
            foreach (var row in cusipData.rows)
            {
                cusipList.Add(row[0].ToString());
            }
            return cusipList;
        }


        private void ExecuteStaleDataQuery(List<string> cusipList, string staleDate, string tableAlias, List<string> columnsToUpdate, Dictionary<string, TableDataResponseBO> mainTableDataDic, Dictionary<string, TableDataResponseBO> histTableDataDic)
        {
            if (string.IsNullOrWhiteSpace(GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.HistDbserver)) ||
                        GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.HistDbserver) == GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.Dbserver))
            {
                UpdateStaleByUpdateQuery(cusipList, staleDate, tableAlias, columnsToUpdate, mainTableDataDic, histTableDataDic);
            }
            else
            {
                UpdateStaleByBindQuery(cusipList, staleDate, tableAlias, columnsToUpdate, mainTableDataDic, histTableDataDic);
            }

        }

        void PopulateStateAudit(List<string> cusipList, string staleDate, string tableAlias, List<string> colList, Dictionary<string, TableDataResponseBO> mainTableDataDic, Dictionary<string, TableDataResponseBO> histTableDataDic)
        {
            foreach (var cusip in cusipList)
            {
                var sql = string.Format("insert into CRONUS_OWN.STALE_AUDIT(SSM_ID,MAIN_TABLE,HIST_TABLE,UNIQUE_KEY_COLS,UPDATED_COLUMNS,OLD_DATA,NEW_DATA,STALE_DATE,LAST_CHG_USER) " +
                          " values('{0}', '{1}', '{2}', {3}, '{4}', '{5}' , '{6}', '{7}', '{8}' ) "
                          , cusip
                          , GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.MainTable)
                          , GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.HistTable)
                          , string.IsNullOrWhiteSpace(GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.UniqueKeyCol)) ? "null" : "'" + GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.UniqueKeyCol) + "'"
                          , string.Join(",", colList)
                          , "[" + string.Join(",", mainTableDataDic[cusip].columns) + "]" + ":[" + string.Join("|", mainTableDataDic[cusip].rows.Select(x => string.Join(",", x))) + "]"
                          , "[" + string.Join(",", histTableDataDic[cusip].columns) + "]" + ":[" + string.Join("|", histTableDataDic[cusip].rows.Select(x => string.Join(",", x))) + "]"
                          , staleDate
                          , User);
                OracleDbHelper.ExecuteNonQuery(sql);
            }
        }

        void UpdateStaleByUpdateQuery(List<string> cusipList, string staleDate, string tableAlias, List<string> columnsToUpdate, Dictionary<string, TableDataResponseBO> mainTableDataDic, Dictionary<string, TableDataResponseBO> histTableDataDic)
        {
            string updateQuery = "";

            //If uniq columns defined for table add that in update query condition
            List<string> uniqCols = string.IsNullOrWhiteSpace(GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.UniqueKeyCol)) ? new List<string>() : GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.UniqueKeyCol).Split(',').ToList();
            var uniqueColumnCondition = "";
            foreach (var columnName in uniqCols)
            {
                uniqueColumnCondition += string.Format(" and srm.{0} = srmh.{0} ", columnName);
            }
            switch (GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.Database))
            {
                case StaleRiskMeasuresBO.Constants.Oracle:
                    {
                        updateQuery = string.Format(
                             @"update {0} srm set ({1}) = (select {1} from {2} srmh where srm.{3} = srmh.{3} and srmh.{5} = '{6}' {7}) 
                                                  where {3} in ({4}) and exists(select 1 from {2} srmh where srm.{3} = srmh.{3} and srmh.{5} = to_date('{6}', 'MM/DD/YYYY') {7})"
                             , GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.MainTable)
                             , string.Join(",", columnsToUpdate)
                             , GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.HistTable)
                             , GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.SsmIdCol)
                             , string.Join(",", cusipList.Select(x => "'" + x + "'"))
                             , GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.PriceDateCol)
                             , staleDate
                             , uniqueColumnCondition
                             );
                    }
                    break;
                case StaleRiskMeasuresBO.Constants.Sybase:
                    {
                        updateQuery = string.Format(
                             @"update {0} set {1} From {0} srm join {2} srmh on (srm.{3} = srmh.{3} and srmh.{5} = '{6}' {7}) 
                                                where srm.{3} in ({4})"
                           , GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.MainTable)
                             , string.Join(",", columnsToUpdate.Select(x => x + " = " + "srmh." + x))
                             , GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.HistTable)
                             , GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.SsmIdCol)
                             , string.Join(",", cusipList.Select(x => "'" + x + "'"))
                             , GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.PriceDateCol)
                             , staleDate
                             , uniqueColumnCondition
                           );
                    }
                    break;
                default:
                    new Exception("Unknown Database");
                    break;
            }

            DatabaseHelper dbHelper = GetConnection(tableAlias);
            var rowsUpdated = dbHelper.ExecuteNonQuery(updateQuery);
            if (rowsUpdated == 0)
            {
                new Exception(string.Format("No Row Updated in table {0}", tableAlias));
            }

        }

        void UpdateStaleByBindQuery(List<string> cusipList, string staleDate, string tableAlias, List<string> columnsToUpdate, Dictionary<string, TableDataResponseBO> mainTableDataDic, Dictionary<string, TableDataResponseBO> histTableDataDic)
        {
            foreach (var cusip in cusipList)
            {
                var mainData = mainTableDataDic[cusip];
                var histData = histTableDataDic[cusip];
                List<string> uniqCols = new List<string>();
                if (!string.IsNullOrWhiteSpace(GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.UniqueKeyCol)))
                    uniqCols.AddRange(GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.UniqueKeyCol).Split(','));
                //Iterate though all rows of newData.
                for (var i = 0; i < mainData.rows.Count; i++)
                {
                    if (i > histData.rows.Count) continue;

                    //Set claus will have old Data
                    Dictionary<string, object> bindVariableList = new Dictionary<string, object>();
                    List<string> nullColList = new List<string>();
                    List<string> notNullColList = new List<string>();
                    foreach (var col in columnsToUpdate)
                    {
                        if (histData.rows[i][mainData.columns.IndexOf(col)] == System.DBNull.Value || histData.rows[i][mainData.columns.IndexOf(col)] == null)
                            nullColList.Add(col);
                        else
                        {
                            bindVariableList[col] = histData.rows[i][mainData.columns.IndexOf(col)];
                            notNullColList.Add(col);
                        }
                    }
                    //where clause will have new data
                    bindVariableList[GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.SsmIdCol) + "_1"] = cusip;
                    List<string> nullColList2 = new List<string>();
                    List<string> notNullColList2 = new List<string>();
                    foreach (var col in uniqCols)
                    {
                        if (histData.rows[i][mainData.columns.IndexOf(col)] == System.DBNull.Value || histData.rows[i][mainData.columns.IndexOf(col)] == null)
                            nullColList2.Add(col);
                        else
                        {
                            bindVariableList[col + "_1"] = mainData.rows[i][histData.columns.FindIndex(x => x.Equals(col, StringComparison.OrdinalIgnoreCase))];
                            notNullColList2.Add(col);
                        }
                    }
                    var whereClauseCols = new List<string>();
                    whereClauseCols.Add(GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.SsmIdCol));
                    whereClauseCols.AddRange(notNullColList2);
                    var bindArgPreFix = GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.Database) == "ORACLE" ? ":" : "@";

                    List<string> setList = new List<string>();
                    setList.AddRange(notNullColList.Select(x => x + " = " + bindArgPreFix + x));
                    setList.AddRange(nullColList.Select(x => x + " = null "));
                    List<string> whereList = new List<string>();
                    whereList.AddRange(whereClauseCols.Select(x => x + " = " + bindArgPreFix + x + "_1"));
                    whereList.AddRange(nullColList2.Select(x => x + " is null "));

                    var query = string.Format("update {0} set {1} where {2}"
                        , GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.MainTable)
                        , string.Join(",", setList)
                        , string.Join(" and ", whereList));
                    DatabaseHelper dbHelper = GetConnection(tableAlias);
                    dbHelper.ExecuteNonQuery(query, bindVariableList);
                }
            }
        }

        private StaleRiskMeasuresBO.SubmitResponseBO SubmitData(StaleRiskMeasuresBO.SubmitRequestBO submitRequestObj, string env)
        {
            var retval = new StaleRiskMeasuresBO.SubmitResponseBO();

            var cusipList = submitRequestObj.CusipList;
            var staleDate = submitRequestObj.StaleDate;
            var tablesColumnsDict = submitRequestObj.tablesColumnsDict;

            var auditIds = new List<long>();
            //Iterate through each table
            //Iterate for each table
            try
            {
                Dictionary<string, List<string>> relatedTableColumnsDict = new Dictionary<string, List<string>>();
                foreach (var tableAlias in tablesColumnsDict.Keys)
                {
                    var relatedTables = GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.UpdateRelatedTables);
                    if (!string.IsNullOrWhiteSpace(relatedTables))
                    {
                        var relatedtableColumns = relatedTables.Split(',').ToList();
                        foreach (var relatedtabCol in relatedtableColumns)
                        {
                            var tableColumnMapping = relatedtabCol.Split('|').ToList();
                            if (tableColumnMapping.Count != 2)
                                throw new Exception(string.Format("Config not correct for {0} and {1}", tableAlias, StaleRiskMeasuresBO.Constants.UpdateRelatedTables));

                            var column = tableColumnMapping[0];
                            var depTableCol = tableColumnMapping[1];

                            if (tablesColumnsDict[tableAlias].FindIndex(x => x.Equals(column, StringComparison.OrdinalIgnoreCase)) != -1)
                            {
                                var tabCol = depTableCol.Split(':').ToList();
                                if (tabCol.Count != 2)
                                    throw new Exception(string.Format("Config not correct for {0} and {1}", tableAlias, StaleRiskMeasuresBO.Constants.UpdateRelatedTables));

                                if (!relatedTableColumnsDict.ContainsKey(tabCol[0])) relatedTableColumnsDict[tabCol[0]] = new List<string>();
                                relatedTableColumnsDict[tabCol[0]].Add(tabCol[1]);

                            }
                        }
                    }
                }
                foreach (var key in relatedTableColumnsDict.Keys)
                    tablesColumnsDict.Add(key, relatedTableColumnsDict[key]);

                foreach (var tableAlias in tablesColumnsDict.Keys)
                {
                    List<string> colList = new List<string>();
                    colList.Add(GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.SsmIdCol));
                    colList.AddRange(tablesColumnsDict[tableAlias]);
                    if (!string.IsNullOrWhiteSpace(GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.UniqueKeyCol)))
                        colList.AddRange(GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.UniqueKeyCol).Split(','));
                    //First get today's and stale date data. Then merge that in one table
                    Dictionary<string, TableDataResponseBO> histTableDataDic = GetHistTableData(cusipList, staleDate, tableAlias, colList);
                    Dictionary<string, TableDataResponseBO> mainTableDataDic = GetMainTableData(cusipList, tableAlias, colList);

                    foreach (var cusip in mainTableDataDic.Keys)
                    {
                        //Audit the data 
                        auditIds.Add(LogActionToAudit(new OrderedDictionary { 
                                                                {"TableAlias", tableAlias}
                                                               ,{"MainTable", GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.MainTable)}
                                                               ,{"HistTable", GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.HistTable)}
                                                               ,{"Cusip", cusip}
                                                               ,{"StaleDate", staleDate }
                                                               ,{"columns", string.Join(",",tablesColumnsDict[tableAlias])}
                                                               ,{"OldData", "[" + string.Join(",",mainTableDataDic[cusip].columns) + "]"+ ":[" + string.Join("|", mainTableDataDic[cusip].rows.Select(x => string.Join(",", x))) + "]"}
                                                               ,{"StaleData", "[" + string.Join(",",histTableDataDic[cusip].columns) + "]"+ ":[" + string.Join("|", histTableDataDic[cusip].rows.Select(x => string.Join(",", x))) + "]"}
                                                               }));
                    }

                    ExecuteStaleDataQuery(cusipList, staleDate, tableAlias, tablesColumnsDict[tableAlias], mainTableDataDic, histTableDataDic);
                    PopulateStateAudit(cusipList, staleDate, tableAlias, tablesColumnsDict[tableAlias], mainTableDataDic, histTableDataDic);

                }
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message, ex);
                foreach (var dbHelper in _dbHelperDict.Values)
                    dbHelper.Rollback();
                foreach (var auditId in auditIds)
                    LogActionToAudit(new OrderedDictionary { { "Status", "Fail" } }, auditId);
                throw;
            }
            SendMail(cusipList, staleDate, tablesColumnsDict, env);
            retval.InfoMessage = "Data Updated Successfully";
            return retval;
        }

        private DatabaseHelper GetConnection(string tableAlias, bool hist = false)
        {

            var key = hist ? tableAlias + "_hist" : tableAlias;

            if (!_dbHelperDict.ContainsKey(key))
            {
                var database = GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.Database);
                var dbName = hist ? GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.HistDbserver) : GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.Dbserver);


                string connectionStr = "";
                if (!string.IsNullOrWhiteSpace(dbName))
                {
                    var selectQuery = string.Format("select Value from CRONUS_OWN.CONFIG WHERE Context = '{0}' and upper(Key) = '{1}' ", "ConnectionString", dbName.ToUpper());
                    var data = OracleDbHelper.ExecuteSelectQuery(selectQuery);
                    connectionStr = data.rows[0][0].ToString();
                    selectQuery = string.Format("select Value from CRONUS_OWN.CONFIG WHERE ScreenId = '{0}' and Context = '{1}' and upper(Key) = '{2}' ", ScreenName(), "DBServierUserName", dbName.ToUpper());
                    data = OracleDbHelper.ExecuteSelectQuery(selectQuery);
                    var userName = data.rows[0][0].ToString();
                    selectQuery = string.Format("select Value from CRONUS_OWN.CONFIG WHERE ScreenId = '{0}' and Context = '{1}' and upper(Key) = '{2}' ", ScreenName(), "DBServierUserPwd", dbName.ToUpper());
                    data = OracleDbHelper.ExecuteSelectQuery(selectQuery);
                    var pswd = data.rows[0][0].ToString();
                    connectionStr = (new ConfigHelper(Url)).GetConnectionStr(connectionStr, userName, pswd, true);
                }
                DatabaseHelper dbHelper;
                switch (database)
                {
                    case "SYBASE":
                        dbHelper = string.IsNullOrWhiteSpace(dbName) ? SybaseDbHelper : new SybaseDatabaseHelper(connectionStr, GetKey());
                        break;
                    case "ORACLE":
                        dbHelper = string.IsNullOrWhiteSpace(dbName) ? OracleDbHelper : new OracleDatabaseHelper(connectionStr, GetKey());
                        break;
                    default:
                        throw new Exception("No database found in config");
                }
                _dbHelperDict[key] = dbHelper;
            }
            return _dbHelperDict[key];
        }


        private void SendMail(List<string> cusipList, string staleDate, Dictionary<string, List<string>> tablesColumnsDict, string env)
        {
            try
            {
                var html = string.Empty;
                const string css = "style = 'border: 1px solid black;'";
                html += "<table  " + css + "> <tr> <th " + css + "> Table Alias </th> <th " + css + "> Main Table </th> <th " + css + ">" +
                        " Hist Table </th> <th " + css + "> Cusip" +
                        " </th> <th " + css + "> Stale Date </th> <th " + css + "> Staled Columns </th>" +
                        "  </tr> ";
                foreach (var cusip in cusipList)
                {
                    foreach (var tableAlias in tablesColumnsDict.Keys)
                    {
                        html += string.Format("<tr> <td  " + css + " > {0} </td>   <td  " + css + "> {1} </td>   <td  " + css + ">   {2} </td>   <td " + css + ">  {3} </td>   <td  " + css + ">  {4} </td> <td  " + css + ">  {5} </td>  </tr>"
                            , tableAlias, GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.MainTable)
                            , GetConfigData(tableAlias, StaleRiskMeasuresBO.Constants.HistTable), cusip, staleDate
                            , string.Join(",", tablesColumnsDict[tableAlias]).Length > 50 ? string.Join(",", tablesColumnsDict[tableAlias]).Substring(0, 50) + "..." : string.Join(",", tablesColumnsDict[tableAlias]));// Here I am assuming that more than 20 columns means all columns
                    }
                }
                html += "</table>";
                // Send email confirmation after successful substitution of cusip.             
                string subject = string.Format("[{0}] Stale Risk Measures Confirmation", env);
                string body = "<b>Stale Risk Measures Details </b>: <br/><br/>";
                body += html;

                body += "<br/> Note: If you want to see the old and new data , you can check it in cronus_own.stale_audit table. <br/>";

                body += "<br/>Thanks,<br/>Cronus<br/><br/>";

                List<string> mailIds = new List<string>();
                string to = GetMailIdOfUser(User);

                mailIds.Add(to);

                mailIds.AddRange(GetMailIdOfScreen(RunOnEnviroment));

                SendEmail(subject, body, string.Join(",", mailIds), ConfigManager.GetSendEmailFrom());
            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Exception: {0}", ex.Message), ex);
            }
        }
    }

}
