﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web.Script.Serialization;
using Cronus.Bll.Helper;
using Cronus.BO;
using Cronus.BO.Fes;
using log4net;
using Newtonsoft.Json.Linq;

namespace Cronus.Bll.Fes
{

    public class QueryBuilder : CronusBaseBll
    {
        private enum QueryType { SELECT, DDL, DML, PROC, ANONYMOUSPROC, INVALID }

        public override object Clone() { return new QueryBuilder(); }

        private static readonly ILog Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        //Key will be tab + user and Value list of queries 
        private static Dictionary<string, QueryBuilderBO.PendingTransactionBO> PendingTransactionsDict = new Dictionary<string, QueryBuilderBO.PendingTransactionBO>();
        private const int MailInterval = 5; // mins
        private const int TransactionTimeout = 15; // mins
        private static Thread PendingTransactionThread;

        public override string ScreenName()
        {
            return Constants.QueryBuilder;
        }

        protected string GetKey(string user, string tabId, long uniqId, string dbName)
        {
            return string.Format("{0}_%_{1}_%_{2}_%_{3}_%_{4}", user, ScreenName(), tabId, uniqId, dbName);
        }

        protected string GetConfigData(string context, string key)
        {
            string retVal;
            var selectQuery = "";
            switch (context)
            {
                case "CONNECTIONSTRINNG":
                    selectQuery = string.Format("select Value from CRONUS_OWN.CONFIG WHERE Context = '{0}' and Key = '{1}' ", "ConnectionString", key);
                    break;
                case "USERNAME":
                    selectQuery = string.Format("select Value from CRONUS_OWN.CONFIG WHERE ScreenId = '{0}' and Context = '{1}' and Key = '{2}' ", ScreenName(), "DBServierUserName", key);
                    break;
                case "PASSWORD":
                    selectQuery = string.Format("select Value from CRONUS_OWN.CONFIG WHERE ScreenId = '{0}' and Context = '{1}' and Key = '{2}' ", ScreenName(), "DBServierUserPwd", key);
                    break;
            }
            var selectedRows = OracleDbHelper.ExecuteSelectQuery(selectQuery);
            if (selectedRows.rows.Count > 0)
                retVal = Convert.ToString(selectedRows.rows[0][0]);
            else
                throw new Exception(string.Format("Config Data missing for {0}", context));

            return retVal;
        }

        protected DatabaseHelper GetDBHelper(string key, string dbName, string userName = null, string pswd = null)
        {
            if (string.IsNullOrWhiteSpace(userName)) userName = GetConfigData("USERNAME", dbName);
            var pswdEncripted = string.IsNullOrWhiteSpace(pswd);
            if (string.IsNullOrWhiteSpace(pswd)) pswd = GetConfigData("PASSWORD", dbName);

            var connectionStr = (new ConfigHelper(Url)).GetConnectionStr(GetConfigData("CONNECTIONSTRINNG", dbName), userName, pswd, pswdEncripted);
            DatabaseHelper dbHelper;
            if (dbName.ToLowerInvariant().StartsWith("ora"))
                dbHelper = new OracleDatabaseHelper(connectionStr, key);
            else
                dbHelper = new SybaseDatabaseHelper(connectionStr, key);
            return dbHelper;
        }

        static QueryBuilder()
        {
            PendingTransactionThread = new Thread(SendMailForPendingTransactions);
            PendingTransactionThread.Start();
        }

        protected override string GetDropDownDataQuery(string fieldName, DropDownRequestBO requestData, out DatabaseType dbType)
        {
            dbType = DatabaseType.ORACLE;
            string query;
            switch (fieldName)
            {
                case "User":
                    query = "Select First_name || ' ' || Last_name as name,   login_id From TLC_BI_OWN.LDAP_USERS_VW a , CRONUS_OWN.USERS b Where lower(a.login_id) = lower(b.USER_ID) and  IS_ACTIVE = 'Y' ORDER BY USER_ID";
                    break;
                case "RequestType":
                    query = string.Format("SELECT distinct key FROM CRONUS_OWN.CONFIG WHERE ScreenID = '{0}' and Context = 'RequestType' ORDER BY key ", ScreenName());
                    break;
                case "SkipBetaExecutionModalReason":
                    query = string.Format("SELECT distinct value FROM CRONUS_OWN.CONFIG WHERE ScreenID = '{0}'and Context = 'Skip Beta Execution' and key = 'Skip Beta Execution Reson' ORDER BY key ", ScreenName());
                    break;
                case "SkipApprovalModalReason":
                    query = string.Format("SELECT distinct value FROM CRONUS_OWN.CONFIG WHERE ScreenID = '{0}' and Context = 'Skip Approval' and key = 'Skip Approval Reson' ORDER BY key ", ScreenName());
                    break;
                default:
                    throw new Exception(string.Format("Unknown FieldName {0}", fieldName));
            }

            return query;
        }

        private string GetApprover(string uname)
        {
            string query = string.Format("Select First_name || ' ' || Last_name || '-' ||  login_id From TLC_BI_OWN.LDAP_USERS_VW a , CRONUS_OWN.USERS b Where lower(a.login_id) = lower(b.USER_ID) and  IS_ACTIVE = 'Y' and lower(user_id) = lower('{0}')", uname);
            var rows = OracleDbHelper.ExecuteSelectQuery(query);
            return rows.rows[0][0].ToString();
        }

        private static void SendMailForPendingTransactions()
        {
            try
            {
                //a infinite while loop which will rollack all the timeout transactions
                while (true)
                {
                    //first findout the timeout transction and put this in list
                    var pendingTransKeys = new List<string>();
                    var autoRollbackKeys = new List<string>();
                    lock (PendingTransactionsDict)
                    {
                        foreach (var key in PendingTransactionsDict.Keys)
                        {
                            var pt = PendingTransactionsDict[key];
                            if (pt.QueryStartTime.AddMinutes(TransactionTimeout) <= DateTime.Now)
                            {
                                autoRollbackKeys.Add(key);
                            }
                            else if (pt.NextMailTime.AddMinutes(MailInterval) <= DateTime.Now)
                            {
                                pendingTransKeys.Add(key);
                                pt.NextMailTime = pt.NextMailTime.AddMinutes(MailInterval);
                            }
                        }
                    }
                    foreach (var key in autoRollbackKeys)
                    {
                        QueryBuilderBO.PendingTransactionBO pt;
                        lock (PendingTransactionsDict)
                        {
                            pt = PendingTransactionsDict[key];
                        }
                        SendEmail(key, "Auto Rollback", "<b>Auto rollback details</b>");

                        var temp = CronusBllFactory.GetInstance().GetBll(Constants.QueryBuilder, pt.User, pt.Url, pt.Environment);

                        ((QueryBuilder)temp).RollbackTab(pt.User, pt.TabId, pt.DBName, pt.DBUserId, pt.DBPswd, pt.UniqId, true);
                    }
                    foreach (var key in pendingTransKeys)
                    {
                        QueryBuilderBO.PendingTransactionBO pt;
                        lock (PendingTransactionsDict)
                        {
                            pt = PendingTransactionsDict[key];
                        }

                        SendEmail(key, "Pending transaction yet to commit", "<b>Pending transaction details</b>");
                    }
                    //sleeping for 30 second
                    Thread.Sleep(30 * 1000);
                }
            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                throw;
            }
        }

        protected override string GetTableQuery(TableDataRequestBO requestData, out DatabaseType dbType)
        {
            dbType = DatabaseType.ORACLE;

            var tableName = requestData.tableName;
            string query;
            switch (tableName)
            {
                case "SaveQueries":
                    query = "Select distinct category, query_name, db_type, query_text from cronus_own.saved_queries order by db_type, category asc, query_name asc";
                    break;
                case "Responsibile":
                    query = string.Format("SELECT distinct key, value FROM CRONUS_OWN.CONFIG WHERE ScreenID = '{0}' and Context = 'Responsibile' ORDER BY key, value", ScreenName());
                    break;
                case "AuditHistory":
                    query = ("select   substr(description, instr(description, '<b>Database</b>:', 1)+length('<b>Database</b>:')+2, 9) AS database, substr(description, instr(description, '<b>Query</b>:', 1)+length('<b>Query</b>:')+2, instr(description, '<b>Database</b>:', 1)-length('<b>Database</b>:')-3) AS query from CRONUS_OWN.audit_trail where last_chg_date between systimestamp-30 and systimestamp and screen_id = 'QUERY BUILDER' ");
                    break;
                case "GetDataBase":
                    query = string.Format("SELECT distinct key, value,environment FROM CRONUS_OWN.CONFIG WHERE ScreenID = '{0}' and Context = 'Database Config' ORDER BY key desc", ScreenName());
                    break;
                default:
                    throw new Exception(string.Format("Unknown TableName {0}", tableName));
            }

            return query;
        }

        protected virtual bool IsJiraRequired(string data)
        {
            return true;
        }

        public override ResponseBO FetchDataForQB(TableDataRequestBO requestData)
        {
            Log.Debug("Enter");
            var retval = new QueryBuilderBO.QueryResultResponseBO { SelectDataCollection = new List<TableDataResponseBO>(), MessageType = "Info" };
            try
            {
                //Permission Check
                if (!Compliance.IsActionAllowed(User, requestData.screenName, Constants.QueryExecute, Url, RunOnEnviroment))
                    throw new Exception("Permission denied");

                //Read the input from UI
                var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                var data = json.Deserialize<QueryBuilderBO.QueryRequestBO>(requestData.data.ToString());
                if (data == null)
                    throw new Exception("Failed in Json Deserialization");

                var userQuery = data.Query;
                var dbName = data.DATABASE;
                var dbType = data.DBType;
                var tabId = data.TabId;
                var uniqId = data.UniqId;
                var thresholdRowCount = data.ExpectedRows;
                var thresholdReached = false;
                // var environment = data.Environment;
                var jiraNo = data.JIRANo;
                var skipApproval = data.SkipApproval;
                var isBetaExecution = data.IsBetaExecution;
                //   var status = data.JIRAStatus;
                var isTranscationMode = data.IsTransactionMode;
                var userId = data.UserId;
                var pswd = data.Pwd;

                Log.InfoFormat("User {0}, Query {1}, DbName {2}, tabId {3} UniqId {4} ThresholdRowCount {5}", User, userQuery, dbName, tabId, uniqId, thresholdRowCount);

                const string regex = ";(?=(?:[^']*'[^']*')*[^']*$)(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)";
                var queryList = Regex.Split(userQuery, regex, RegexOptions.Multiline).ToList();
                long currentQuery = 0;
                var concatQuery = "";
                foreach (var queryStr in queryList)
                {
                    var query = queryStr.Trim();
                    while (query.StartsWith("--"))
                    {
                        if (query.StartsWith("--") && query.IndexOf('\n') != -1)
                            query = query.Substring(query.IndexOf('\n') + 1);
                        else if (query.StartsWith("--") && query.IndexOf('\n') == -1)
                            query = "";
                    }

                    if (FindQueryType(query) == QueryType.ANONYMOUSPROC || !string.IsNullOrWhiteSpace(concatQuery))
                    {
                        //for anonymous proc, start concat rows and execute once found a row start with /
                        if (FindQueryType(query) == QueryType.ANONYMOUSPROC && string.IsNullOrWhiteSpace(concatQuery))
                        {
                            concatQuery = query;
                        }
                        else
                        {
                            if (dbType.ToUpper().StartsWith("ORACLE"))
                                concatQuery += ";";
                            concatQuery += "\n";
                            concatQuery += query;
                        }
                        if (!concatQuery.EndsWith("\n/"))
                            continue;
                        else
                        {
                            query = concatQuery;
                            query = query.Remove(query.Length - 1, 1);
                            concatQuery = "";
                        }
                    }

                    //Audit the query
                    if (string.IsNullOrEmpty(query.Replace('\n', ' ').Trim()))
                        continue;

                    currentQuery++;
                    long auditTrailId = 0;
                    if (string.IsNullOrWhiteSpace(jiraNo))
                    {
                        Log.InfoFormat("Executing Query User {0}, Query {1}, DbName {2}, tabId {3} UniqId {4}", User, query, dbName, tabId, uniqId);
                        auditTrailId = LogActionToAudit(new OrderedDictionary { { "Query", query }, { "Database", dbName }, { "TabId", tabId }, { "TransactionMode", isTranscationMode }, { "ThresholdRowCount", thresholdRowCount } });
                    }
                    else
                    {
                        Log.InfoFormat("Executing Query User {0}, Query {1}, DbName {2}, tabId {3} UniqId {4}, JiraNo {5}, SkipApproval {6}", User, query, dbName, tabId, uniqId, jiraNo, skipApproval);
                        auditTrailId = LogActionToAudit(new OrderedDictionary { { "Query", query }, { "Database", dbName }, { "TabId", tabId }, { "JiraNo", jiraNo }, { "SkipApproval", skipApproval }, { "TransactionMode", isTranscationMode }, { "ThresholdRowCount", thresholdRowCount } });
                    }
                    var result = "";
                    var queryStartTime = DateTime.Now;
                    var key = GetKey(User, tabId, uniqId, dbName);
                    DatabaseHelper dbHelper = GetDBHelper(key, dbName, userId, pswd);
                    dbHelper.CacheConnection(true);
                    try
                    {
                        var queryType = FindQueryType(query);

                        if (queryType != QueryType.SELECT)
                        {
                            //Check permission first
                            if (!(Compliance.IsActionAllowed(User, requestData.screenName, Constants.Query_ALL_W, Url, RunOnEnviroment) ||
                                (dbType == "ORACLEFND" && Compliance.IsActionAllowed(User, requestData.screenName, Constants.Query_FND_W_OTHER_R, Url, RunOnEnviroment)
                                )))
                                throw new Exception("Permission denied for non select queries");

                            if (IsJiraRequired(jiraNo) && (string.IsNullOrWhiteSpace(jiraNo)))
                            {
                                //only select allowed without jira in query builder
                                throw new Exception("Only select queries allowed without JIRA item");
                            }

                            //Expected row count is not required in case of beta execution
                            if (isTranscationMode && !isBetaExecution && queryType == QueryType.DML && thresholdRowCount <= 0)
                                throw new Exception("Expected rows should be populated and greater than 0.");
                        }
                        if (queryType == QueryType.DML && isTranscationMode)
                        {
                            dbHelper.BeginTransaction();
                        }

                        switch (queryType)
                        {
                            case QueryType.SELECT:
                                var sData = dbHelper.ExecuteSelectQuery(query, true);
                                retval.SelectDataCollection.Add(sData);
                                if (queryType == QueryType.SELECT)
                                {
                                    if (sData.rows.Count >= Constants.MaxSelectedRows)
                                        result = string.Format("First {0} Rows Selected", sData.rows.Count);
                                    else
                                        result = string.Format("{0} Rows Selected", sData.rows.Count);
                                }
                                else
                                {
                                    result = "Executed Successfully";
                                }
                                break;
                            case QueryType.DML:
                                var allowedUpdateRowCount = Math.Max(1000, thresholdRowCount * 2);
                                long rowsAffected = dbHelper.ExecuteNonQuery(query, null, null, allowedUpdateRowCount);
                                if (isTranscationMode && thresholdRowCount > 0 && (thresholdRowCount * 1.1 < rowsAffected || thresholdRowCount * 0.9 > rowsAffected))
                                    thresholdReached = true;
                                if (rowsAffected >= allowedUpdateRowCount)
                                {
                                    var errorMessage = string.Format("Rows affected are much more than the expected {0}. ", thresholdRowCount);
                                    if (isTranscationMode)
                                    {
                                        dbHelper.Rollback();
                                        errorMessage += "\nRollback called";
                                    }
                                    else
                                    {
                                        errorMessage += string.Format("\nSo affacting first {0} rows only", rowsAffected);
                                    }

                                    throw new Exception(errorMessage);
                                }
                                result = string.Format("{0} Rows Affected ", rowsAffected);

                                break;
                            case QueryType.DDL:
                                dbHelper.ExecuteDDLQuery(query);

                                result = "Executed Successfully";
                                break;
                            case QueryType.PROC:
                            case QueryType.ANONYMOUSPROC:
                                var procData = dbHelper.ExecuteProcedure(query);
                                retval.SelectDataCollection = procData;
                                result = "Executed Successfully";
                                break;
                            default:
                                throw new Exception("Query Not supported");
                        }

                        //cache query, will send this when commited
                        if (queryType != QueryType.INVALID)
                        {
                            lock (PendingTransactionsDict)
                            {
                                if (!dbHelper.IsActiveTransaction())
                                {
                                    //if there is no active transaction for this user clean the dictonaries
                                    if (PendingTransactionsDict.ContainsKey(key))
                                        PendingTransactionsDict.Remove(key);
                                }
                                if (queryType == QueryType.DML && isTranscationMode)
                                {
                                    if (!PendingTransactionsDict.ContainsKey(key))
                                    {
                                        PendingTransactionsDict[key] = new QueryBuilderBO.PendingTransactionBO
                                        {
                                            Url = Url,
                                            TabId = tabId,
                                            DBName = dbName,
                                            User = User,
                                            UniqId = uniqId,
                                            DBUserId = userId,
                                            DBPswd = pswd,
                                            ScreenName = ScreenName(),
                                            Email = GetMailIdOfUser(userId),
                                            Environment = RunOnEnviroment,
                                            QueryStartTime = DateTime.Now,
                                            NextMailTime = DateTime.Now,
                                            ExecutedQueries = new List<string>(),
                                            ExecutedAuditIds = new List<long>()
                                        };
                                    }
                                    PendingTransactionsDict[key].ExecutedQueries.Add(string.Format("<b>Query:</b> {0}, <b>Result:</b> {1}, <b>ExecutionTime:</b> {2} seconds"
                                                                                            , query, result, (DateTime.Now - queryStartTime).TotalSeconds));

                                    PendingTransactionsDict[key].ExecutedAuditIds.Add(auditTrailId);
                                    retval.ActiveTransaction = true;
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        //if nothing pending to commit release the transaction
                        lock (PendingTransactionsDict)
                        {
                            if (!PendingTransactionsDict.ContainsKey(key))
                            {
                                dbHelper.Rollback();
                            }
                        }
                        Log.Error(String.Format("Exception: {0}, Query: {1} ", ex.Message, query), ex);
                        result = string.Format("Query ({0}) Failed: {1} </br></br>", currentQuery, ex.Message);
                        retval.MessageType = "Error";
                        if (currentQuery < queryList.Count())
                            result += "<b>Note: Query(s) after failed query has not executed</b>";
                        if (!string.IsNullOrEmpty(jiraNo))
                        {
                            JiraHelper.AddComment(jiraNo, string.Format("[{0}] Query Builder: [{1}] [{2}] [{3}] [TransactionMode:{4}] \n {5}{6}", Url, User, dbName, tabId, isTranscationMode, retval.Summary, result));
                        }                        
                        throw;
                    }
                    finally
                    {
                        LogActionToAudit(new OrderedDictionary { { "Result", result }, { "ExecutionTime", (string.Format("{0} seconds", (DateTime.Now - queryStartTime).TotalSeconds)) } }, auditTrailId);
                        retval.Summary += result + "</br></br>";
                    }
                    Log.InfoFormat("Done..Executing Query User {0}, Query {1}, DBName {2}, tabId {3} UniqId {4}", User, query, dbName, tabId, uniqId);
                }

                if (string.IsNullOrEmpty(retval.Summary))
                    retval.Summary = "No query to execute";
                else
                {
                    if (thresholdReached)
                    {
                        retval.MessageType = "Warning";
                        retval.Summary = string.Format("Rows affected are not within 10% of expected rows count {0}</br></br>", thresholdRowCount) + retval.Summary;
                    }
                }
                if (!string.IsNullOrEmpty(jiraNo))
                {
                    JiraHelper.AddComment(jiraNo, string.Format("[{0}] Query Builder: [{1}] [{2}] [{3}] [TransactionMode:{4}] \n", Url, User, dbName, tabId, isTranscationMode) + retval.Summary);
                    //The status of jira item will be moved to executed if it is committed from production. 
                    if (!retval.ActiveTransaction)
                    {
                        if (isBetaExecution)
                            JiraHelper.AddLabel(jiraNo, "BetaExecution:Done");
                        else
                            JiraHelper.ChangeStatus(jiraNo, JiraHelper.JiraStatus.Executed);
                    }

                }
            }
            catch (Exception ex)
            {
                Log.Error("Exception : " + ex.Message, ex);

                if (string.IsNullOrEmpty(retval.Summary))
                    retval.errorMessage = ex.Message;
            }

            //if (retval.ActiveTransaction)
            //    retval.Summary += "<b> Note: Rows updated or inserted include number of rows affected by command and Trigger or triggers </b>";
            return retval;
        }

        private QueryType FindQueryType(string query)
        {
            QueryType retval;

            //first remove the spaces from begin and end
            query = query.Replace('\n', ' ').Replace('\t', ' ').Trim();
            if ((query.ToLowerInvariant().StartsWith("select ") || query.ToLowerInvariant().StartsWith("with ")) && !query.ToLowerInvariant().Contains(" into "))
                retval = QueryType.SELECT;
            else if (query.ToLowerInvariant().StartsWith("exec ") || query.ToLowerInvariant().StartsWith("execute "))
                retval = QueryType.PROC;
            else if (query.ToLowerInvariant().StartsWith("begin ") || query.ToLowerInvariant().StartsWith("declare "))
                retval = QueryType.ANONYMOUSPROC;
            else if (query.ToLowerInvariant().StartsWith("insert ") ||
                     query.ToLowerInvariant().StartsWith("update ") ||
                     query.ToLowerInvariant().StartsWith("delete ") ||
                     query.ToLowerInvariant().StartsWith("merge "))
                retval = QueryType.DML;
            else if ((query.ToLowerInvariant().StartsWith("select ") && query.ToLowerInvariant().Contains(" into ")) ||
                     query.ToLowerInvariant().StartsWith("create ") || query.ToLowerInvariant().StartsWith("alter ") ||
                     query.ToLowerInvariant().StartsWith("drop ") || query.ToLowerInvariant().StartsWith("truncate ") ||
                     query.ToLowerInvariant().StartsWith("grant ") || query.ToLowerInvariant().StartsWith("revoke "))
                retval = QueryType.DDL;
            else
                retval = QueryType.INVALID;

            return retval;
        }

        public override ResponseBO Commit(RequestBO req)
        {
            var retVal = new ResponseBO();

            try
            {
                //Permission Check
                if (!Compliance.IsActionAllowed(User, req.screenName, Constants.QueryExecute, Url, RunOnEnviroment))
                    throw new Exception("Permission denied");

                var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                var data = json.Deserialize<QueryBuilderBO.QueryRequestBO>(req.data.ToString());
                if (data == null)
                    throw new Exception("Failed in Json Deserialization");

                var dbName = data.DATABASE;
                var tabId = data.TabId;
                var uniqId = data.UniqId;
                var jiraNo = data.JIRANo;
               // var approver = data.Approver;
                var isBetaExecution = data.IsBetaExecution;
                var userId = data.UserId;
                var pswd = data.Pwd;

                Log.InfoFormat("User {0}, DBName {1}, TabId {2}, UniqId {3}, Commit", User, dbName, tabId, uniqId);

                var key = GetKey(User, tabId, uniqId, dbName);
                var dbHelper = GetDBHelper(key, dbName, userId, pswd);

                var commitStatus = dbHelper.Commit();

                var auditIds = new List<long>();
                lock (PendingTransactionsDict)
                {
                    if (PendingTransactionsDict.ContainsKey(key))
                    {
                        auditIds = PendingTransactionsDict[key].ExecutedAuditIds;
                    }
                }

                foreach (var auditId in auditIds)
                {
                    if (commitStatus)
                        LogActionToAudit(new OrderedDictionary { { "Commit", "Success" } }, auditId);
                    else
                    {
                        LogActionToAudit(new OrderedDictionary { { "Commit", "Fail" } }, auditId);
                        retVal.errorMessage = "Commit Failed";
                    }
                }

                SendEmail(key, "Committed Query", "<b>Commit</b>: [Successful] for below <b>Query(s) </b>");
                lock (PendingTransactionsDict)
                {
                    if (PendingTransactionsDict.ContainsKey(key))
                        PendingTransactionsDict.Remove(key);
                }
                if (!string.IsNullOrEmpty(jiraNo))
                {
                    if (string.IsNullOrEmpty(retVal.errorMessage))
                    {
                        JiraHelper.AddComment(jiraNo,
                            string.Format("[{0}] Query Builder: [{1}] [{2}] [{3}] \n", Url, User, dbName, tabId) +
                            string.Format("Commit status {0}", "Successful"));

                        //The status of jira item will be moved to executed if it is committed from production. 
                        if (isBetaExecution)
                            JiraHelper.AddLabel(jiraNo, "BetaExecution:Done");
                        else
                            JiraHelper.ChangeStatus(jiraNo, JiraHelper.JiraStatus.Executed);
                    }
                    else
                        JiraHelper.AddComment(jiraNo,
                            string.Format("[{0}] Query Builder: [{1}] [{2}] [{3}] \n", Url, User, dbName, tabId) +
                            string.Format("Commit status {0}", "Fail"));
                }
                Log.InfoFormat("Done..User {0}, DBName {1}, TabId {2}, UniqId {3}, Commit Status {4}", User, dbName, tabId, uniqId, commitStatus);
            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Exception : {0}", ex.Message), ex);
                retVal.errorMessage = string.Format("Commit failed with Exception: {0}", ex.Message);
            }

            return retVal;
        }

        public ResponseBO RollbackTab(string user, string tabId, string dbName, string userName, string pswd, long uniqId, bool force)
        {
            var retVal = new ResponseBO();

            Log.InfoFormat("User {0}, DBName {1}, TabId {2}, UniqId {3}, Rollback", user, dbName, tabId, uniqId);

            var key = GetKey(User, tabId, uniqId, dbName);
            var dbHelper = GetDBHelper(key, dbName, userName, pswd);

            var rollbackStatus = dbHelper.Rollback();
            if (force) dbHelper.CloseConnection();

            var auditIds = new List<long>();
            lock (PendingTransactionsDict)
            {
                if (PendingTransactionsDict.ContainsKey(key))
                {
                    auditIds = PendingTransactionsDict[key].ExecutedAuditIds;
                }
            }

            foreach (var auditId in auditIds)
            {
                if (rollbackStatus)
                {
                    LogActionToAudit(
                        force == false
                            ? new OrderedDictionary { { "Rollback", "Success" } }
                            : new OrderedDictionary { { "Rollback", "Force Success" } }, auditId);
                }
                else
                {
                    LogActionToAudit(
                        force == false
                            ? new OrderedDictionary { { "Rollback", "Fail" } }
                            : new OrderedDictionary { { "Rollback", "Force Fail" } }, auditId);
                }
            }

            lock (PendingTransactionsDict)
            {
                if (PendingTransactionsDict.ContainsKey(key))
                    PendingTransactionsDict.Remove(key);
            }

            Log.InfoFormat("Done..User {0}, DBName {1}, TabId {2}, UniqId {3}, Rollback Status {4}", user, dbName, tabId, uniqId, rollbackStatus);
            return retVal;

        }

        public override ResponseBO Rollback(RequestBO req)
        {
            var retVal = new ResponseBO();
            try
            {
                //Permission Check
                if (!Compliance.IsActionAllowed(User, req.screenName, Constants.QueryExecute, Url, RunOnEnviroment))
                    throw new Exception("Permission denied");

                var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                var data = json.Deserialize<QueryBuilderBO.QueryRequestBO>(req.data.ToString());
                if (data == null)
                    throw new Exception("Failed in Json Deserialization");

                var dbName = data.DATABASE;
                var tabId = data.TabId;
                var uniqId = data.UniqId;
                var jiraNo = data.JIRANo;
                var userId = data.UserId;
                var pswd = data.Pwd;

                //if multiple dbType, it means forceful rollback
                var force = dbName.Contains(',');

                //in case of force rollback we will get detail for each tab
                var dbNames = dbName.Split(',').ToList();
                var tabIds = tabId.Split(',').ToList();
                for (var i = 0; i < dbName.Count() && i < tabIds.Count(); i++)
                    retVal = RollbackTab(User, tabIds[i], dbNames[i], userId, pswd, uniqId, force);

                if (!string.IsNullOrEmpty(jiraNo))
                {
                    if (string.IsNullOrEmpty(retVal.errorMessage))
                        JiraHelper.AddComment(jiraNo, string.Format("[{0}] Query Builder: [{1}] [{2}] [{3}] \n", Url, User, dbName, tabId) + string.Format("Rollback status {0}", "Successful"));
                    else
                        JiraHelper.AddComment(jiraNo, string.Format("[{0}] Query Builder: [{1}] [{2}] [{3}] \n", Url, User, dbName, tabId) + string.Format("Rollback status {0}", "Fail"));
                }
            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                retVal.errorMessage = string.Format("Rollback failed with Exception: {0}", ex.Message);
            }
            return retVal;
        }

        public override ResponseBO CancelAjax(RequestBO req)
        {
            var retVal = new ResponseBO();
            try
            {
                var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                var data = json.Deserialize<QueryBuilderBO.QueryRequestBO>(req.data.ToString());
                if (data == null)
                    throw new Exception("Failed in Json Deserialization");

                var dbName = data.DATABASE;
                var tabId = data.TabId;
                var uniqId = data.UniqId;
                var userId = data.UserId;
                var pswd = data.Pwd;

                Log.InfoFormat("User {0}, DBName {1}, TabId {2}, UniqId: {3} Cancel", User, dbName, tabId, uniqId);

                var key = GetKey(User, tabId, uniqId, dbName);
                var dbHelper = GetDBHelper(key, dbName, userId, pswd);

                var cancelStatus = dbHelper.Cancel();
                if (!cancelStatus)
                    retVal.errorMessage = "Cancel Request failed";
                Log.InfoFormat("Done..User {0}, DBName {1}, TabId {2}, UniqId: {3}", User, dbName, tabId, uniqId);
            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                retVal.errorMessage = string.Format("Exception: {0}", ex.Message);
            }
            return retVal;
        }

        public static void SendEmail(string key, string subject, string body)
        {
            try
            {
                var pt = new QueryBuilderBO.PendingTransactionBO();
                var queriesComited = "";
                lock (PendingTransactionsDict)
                {
                    if (PendingTransactionsDict.ContainsKey(key))
                    {
                        pt = PendingTransactionsDict[key];
                        foreach (var dmlQuery in pt.ExecutedQueries)
                        {
                            queriesComited += " <br> " + dmlQuery + "</br> \n";
                        }
                    }
                }

                if (string.IsNullOrEmpty(queriesComited))
                {
                    Log.Info("Not sending mail as no query to send");
                    return;
                }

                subject = string.Format("[{0}] {5}: [{1}] [{2}] [{3}] {4}", pt.Url, pt.User, pt.DBName, pt.TabId, subject, pt.ScreenName);

                body = string.Format("{0}: <br/> <b>Url:</b> {1}, <b>User:</b> {2}, <b>TabId:</b> {3}, <b>Database:</b> {4}, <b>QueryStartDateTime:</b> {5}, <b>CurrentDateTime:</b> {6} <br/><br/>{7}<br/><br/>Thanks,<br/>Cronus<br/><br/>"
                                , body, pt.Url, pt.User, pt.TabId, pt.DBName, pt.QueryStartTime, DateTime.Now, queriesComited);

                var configManager = new ConfigHelper(pt.Url);
                var sendFrom = configManager.GetSendEmailFrom();
                var sendTo = configManager.GetSendEmailTo(string.Format("QueryBuilderSendTo_{0}", pt.Environment));

                var to = pt.Email + ",";
                Log.InfoFormat("Send Email From: {0}, To: {1}, Subject {2}", pt.User, sendTo, subject);
                if (!string.IsNullOrEmpty(sendTo))
                {
                    to = to + sendTo;
                }
                to = to.Trim(',');
                SendEmail(subject, body, to, sendFrom);
            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Exception: {0}", ex.Message), ex);
            }
        }

        public override ResponseBO UpdateDB(RequestBO req)
        {
            Log.Debug("Enter");
            var retval = new ResponseBO();

            try
            {
                var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                var data = json.Deserialize<QueryBuilderBO.SaveQueryRequestBO>(req.data.ToString());
                if (data == null)
                    throw new Exception("Failed in Json Deserialization");

                //Validate data
                if (string.IsNullOrEmpty(data.Query))
                    throw new Exception("Query can not be null or empty");
                if (string.IsNullOrEmpty(data.DBName))
                    throw new Exception("DBName can not be null or empty");
                if (string.IsNullOrEmpty(data.Name))
                    throw new Exception("Query Name can not be null or empty");

                OracleDbHelper.BeginTransaction();

                Log.Info(string.Format("Query saving Request by User: {0} {1}", User, data));

                var auditId = LogActionToAudit(new OrderedDictionary { { "Category", data.Category }, { "Name", data.Name }, { "TabId", data.TabId }, { "DBName", data.DBName }, { "Query", data.Query }, { "User", User } });

                try
                {
                    var queryUpdate = string.Format("update cronus_own.saved_queries set query_text = '{0}', last_chg_user = '{1}', last_chg_date = SYSTIMESTAMP ", data.Query.Replace("'", "''"), User);
                    queryUpdate += string.Format(" Where query_name = '{0}' and db_type = '{1}' and category = '{2}'", data.Name.Replace("'", "''"), data.DBName, data.Category.Replace("'", "''"));

                    var rowsAffected = OracleDbHelper.ExecuteNonQuery(queryUpdate);
                    if (rowsAffected == 0)
                    {
                        var queryInsert = string.Format("insert into cronus_own.saved_queries(category, query_name, db_type, query_text, last_chg_user) values ('{0}', '{1}', '{2}', '{3}','{4}')"
                                                            , data.Category.Replace("'", "''"), data.Name.Replace("'", "''"), data.DBName, data.Query.Replace("'", "''"), User);

                        OracleDbHelper.ExecuteNonQuery(queryInsert);
                    }
                }
                catch (Exception ex)
                {
                    Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                    OracleDbHelper.Rollback();
                    LogActionToAudit(new OrderedDictionary { { "status", "Fail" } }, auditId);
                    throw;
                }

                OracleDbHelper.Commit();
                LogActionToAudit(new OrderedDictionary { { "status", "Success" } }, auditId);
            }
            catch (Exception ex)
            {
                retval.errorMessage = string.Format("Exception: {0}", ex.Message);
                Log.Error(retval.errorMessage, ex);
            }
            finally
            {
                Log.Debug("Exit");
            }
            return retval;
        }

        private bool IsValueChanged(string oldVal, string newVal)
        {
            if (string.IsNullOrEmpty(oldVal) && string.IsNullOrEmpty(newVal))
                return false;
            return (string.IsNullOrEmpty(oldVal) && !string.IsNullOrEmpty(newVal)) || (string.IsNullOrEmpty(newVal) && !string.IsNullOrEmpty(oldVal)) || newVal != oldVal;
        }


        private ResponseBO SaveJiraItem(QueryBuilderBO.QueryRequestBO req)
        {
            var retVal = new QueryBuilderBO.QueryResponseBO();
            long auditTrailId = 0;
            try
            {
                Log.InfoFormat("User {0}, DbName {1}, tabId {2}, UniqId {3}, Summary {4}, Query {5}, RequestType {6}, GroupResponsibility {7}, TeamResponsibility {8}, Approvaer {9}"
                    , User, req.DATABASE, req.TabId, req.UniqId, req.JIRASummary, req.Query, req.RequestType, req.GroupResponsibility, req.TeamResponsibility, req.Approver);
                if (req.Approver.ToLowerInvariant() == User.ToLowerInvariant())
                    throw new Exception("User saving JIRA can not be a approver");

                auditTrailId = LogActionToAudit(new OrderedDictionary { { "SaveJira Summary", req.JIRASummary }, { "Database", req.DATABASE }
                    , { "TabId", req.TabId }, { "Approver", req.Approver }, { "RequestType", req.RequestType }
                    , { "GroupResponsibility", req.GroupResponsibility }, { "TeamResponsibility", req.TeamResponsibility }, { "Query", req.Query }});

                QueryBuilderBO.QueryResponseBO serachJira = SearchJiraItem(new QueryBuilderBO.QueryRequestBO() { JIRANo = req.JIRANo });

                string desc = GetDesc(req.JIRANo, req.Query, req.SkipBetaExecution, req.SkipBetaExecutionReason, req.SkipApproval, req.SkipApprovalReason);
                JiraHelper.SaveJiraItem(req.JIRANo, GetJiraSummary(req.JIRASummary), desc, User, req.RequestType, req.GroupResponsibility, req.TeamResponsibility);
                JiraHelper.UpdateAssignee(req.JIRANo, User);
                var comment = "";
                if (IsValueChanged(serachJira.JIRASummary, req.JIRASummary))
                {
                    comment += string.Format("Old Summary: {0}, New Summary: {1}\n", serachJira.JIRASummary, req.JIRASummary);
                }
                if (IsValueChanged(serachJira.Query, req.Query))
                {
                    comment += string.Format("Old Query: {0}, New Query: {1}\n", serachJira.Query, req.Query);
                }
                if (IsValueChanged(serachJira.Approver, req.Approver))
                {
                    comment += string.Format("Old Approver: {0}, New Approver: {1}\n", serachJira.Approver, req.Approver);
                    JiraHelper.RemoveLabel(req.JIRANo, string.Format("Approver:{0}", serachJira.Approver));
                    //get the approver short name
                    string approver = req.Approver.Split('-').Length > 0 ? req.Approver.Split('-')[1] : req.Approver;
                    JiraHelper.AddLabel(req.JIRANo, string.Format("Approver:{0}", req.Approver));
                }
                if (IsValueChanged(serachJira.DBType, req.DBType))
                {
                    comment += string.Format("Old DBType: {0}, New DBType: {1}\n", serachJira.DBType, req.DBType);
                    JiraHelper.RemoveLabel(req.JIRANo, string.Format("DBType:{0}", serachJira.DBType));
                    JiraHelper.AddLabel(req.JIRANo, string.Format("DBType:{0}", req.DBType));
                }
                if (IsValueChanged(serachJira.RequestType, req.RequestType))
                {
                    comment += string.Format("Old RequestType: {0}, New RequestType: {1}\n", serachJira.RequestType, req.RequestType);
                }
                if (IsValueChanged(serachJira.GroupResponsibility, req.GroupResponsibility))
                {
                    comment += string.Format("Old GroupResponsibility: {0}, New GroupResponsibility: {1}\n", serachJira.GroupResponsibility, req.GroupResponsibility);
                }
                if (IsValueChanged(serachJira.TeamResponsibility, req.TeamResponsibility))
                {
                    comment += string.Format("Old TeamResponsibility: {0}, New TeamResponsibility: {1}\n", serachJira.TeamResponsibility, req.TeamResponsibility);
                }

                if (!string.IsNullOrEmpty(comment))
                    JiraHelper.AddComment(req.JIRANo, string.Format("[{0}] Query Builder: [{1}] [{2}] [{3}] \n", Url, User, req.DATABASE, req.TabId) + comment);

                Log.InfoFormat("Jira Item Saved JiraNo {0}, JiraLink", retVal.JIRANo, retVal.JIRALink);
                LogActionToAudit(new OrderedDictionary { { "status", "Success" } }, auditTrailId);
            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                retVal.errorMessage = string.Format("Failed while saving Jira Item with Exception: {0}", ex.Message);
                LogActionToAudit(new OrderedDictionary { { "status", "Fail" } }, auditTrailId);
            }
            return retVal;
        }

        private QueryBuilderBO.QueryResponseBO CreateJiraItem(QueryBuilderBO.QueryRequestBO req)
        {
            var retVal = new QueryBuilderBO.QueryResponseBO();
            long auditTrailId = 0;

            try
            {
                Log.InfoFormat("User {0}, Environment {1}, DbName {2}, tabId {3}, UniqId {4}, Summary {5}, Query {6}, RequestType {7}, GroupResponsibility {8}, TeamResponsibility {9}, Approvaer {10}"
                    , User, req.Environment, req.DATABASE, req.TabId, req.UniqId, req.JIRASummary, req.Query, req.RequestType, req.GroupResponsibility, req.TeamResponsibility, req.Approver);
                if (req.Approver.ToLowerInvariant() == User.ToLowerInvariant())
                    throw new Exception("User creating JIRA can not be a approver");

                auditTrailId = LogActionToAudit(new OrderedDictionary { { "CreatJiraItem Summary", req.JIRASummary }, { "Environment", req.Environment }, { "Database", req.DATABASE }
                    , { "TabId", req.TabId }, { "Approver", req.Approver }, { "RequestType", req.RequestType }
                    , { "GroupResponsibility", req.GroupResponsibility }, { "TeamResponsibility", req.TeamResponsibility }, { "Query", req.Query }});
                string approver = req.Approver.Split('-').Length > 0 ? req.Approver.Split('-')[1] : req.Approver;
                var labels = new List<string>
                {
                    string.Format("DBType:{0}", req.DBType),
                    string.Format("Env:{0}", req.Environment),
                    string.Format("URL:{0}", Url),
                    string.Format("User:{0}", User),
                    string.Format("Approver:{0}",approver)
                };

                string desc = GetDesc(null, req.Query, null, null, null, null);
                string environment = (new ConfigHelper(Url)).GetEnv();
                //var jiraItemJson = jira.CreateJiraItem("FESUPPORT", req.JIRASummary, req.Query, "Support", User, "FE Support misc", labels, req.RequestType, req.GroupResponsibility, req.TeamResponsibility);
                var jiraItemJson = JiraHelper.CreateJiraItem("OPSDEV", GetJiraSummary(req.JIRASummary), desc, "Support", User, "", labels, req.RequestType, req.GroupResponsibility, req.TeamResponsibility, environment);

                var jiraItem = JObject.Parse(jiraItemJson);
                retVal.JIRALink = string.Format("https://jira/browse/{0}", (string)jiraItem[JiraHelper.JiraKeys.Key]);
                retVal.JIRANo = (string)jiraItem[JiraHelper.JiraKeys.Key];
                //change the status to InProgress
                JiraHelper.UpdateAssignee(retVal.JIRANo, User);
                JiraHelper.ChangeStatus(retVal.JIRANo, JiraHelper.JiraStatus.InProgress);
                retVal.JIRAStatus = JiraHelper.GetStatus(retVal.JIRANo);

                //JiraHelper.AddWatchers(retVal.JIRANo, User);
                //JiraHelper.AddWatchers(retVal.JIRANo, approver);

                Log.InfoFormat("Jira Item Created JiraNo {0}, JiraLink {1}", retVal.JIRANo, retVal.JIRALink);
                LogActionToAudit(new OrderedDictionary { { "status", "Success" } }, auditTrailId);
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("400"))
                {
                    Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                    retVal.errorMessage = "JIRA web service is not responding or Not able to create issue on JIRA. Please contact JIRA administrator for this issue.";
                }
                else
                {
                    Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                    retVal.errorMessage = string.Format("Failed while creating Jira Item with Exception: {0}", ex.Message);
                }
                LogActionToAudit(new OrderedDictionary { { "status", "Fail" } }, auditTrailId);
            }
            return retVal;
        }

        private void SplitJiraDescription(string description, out bool? skipBetaExecution, out string skipBetaExecutionReason, out bool? skipApproval, out string skipApprovalReason, out string query)
        {
            try
            {
                var jiraItem = JObject.Parse(description);
                skipBetaExecution = null;
                if (jiraItem["SkipBetaExecution"] != null)
                    skipBetaExecution = (string)jiraItem["SkipBetaExecution"] == "True";
                skipApproval = null;
                if (jiraItem["SkipApproval"] != null)
                    skipApproval = (string)jiraItem["SkipApproval"] == "True";
                skipBetaExecutionReason = jiraItem["SkipBetaExecutionReason"] != null ? (string)jiraItem["SkipBetaExecutionReason"] : null;
                skipApprovalReason = jiraItem["SkipApprovalReason"] != null ? (string)jiraItem["SkipApprovalReason"] : null;
                query = jiraItem["Query"] != null ? (string)jiraItem["Query"] : null;
            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                throw new Exception("Failed while parsing description");
            }
        }

        private QueryBuilderBO.QueryResponseBO SearchJiraItem(QueryBuilderBO.QueryRequestBO req)
        {
            var retVal = new QueryBuilderBO.QueryResponseBO();
            try
            {
                Log.InfoFormat("User {0}, tabId {1}, UniqId {2}, JiraNo {3}", User, req.TabId, req.UniqId, req.JIRANo);

                var jiraItemJson = JiraHelper.GetJiraItemDetail(req.JIRANo);

                var jiraItem = JObject.Parse(jiraItemJson);

                var description = (string)jiraItem[JiraHelper.JiraKeys.Fields][JiraHelper.JiraKeys.Description];
                if (description != null)
                {
                    bool? skipBetaExecution;
                    string skipBetaExecutionReason;
                    bool? skipApproval;
                    string skipApprovalReason;
                    string query;
                    SplitJiraDescription(description, out skipBetaExecution, out skipBetaExecutionReason, out skipApproval, out skipApprovalReason, out query);
                    retVal.SkipBetaExecution = skipBetaExecution;
                    retVal.SkipApproval = skipApproval;
                    retVal.SkipBetaExecutionReason = skipBetaExecutionReason;
                    retVal.SkipApprovalReason = skipApprovalReason;
                    retVal.Query = query;
                }
                retVal.JIRANo = req.JIRANo;
                retVal.JIRALink = string.Format("https://jira/browse/{0}", (string)jiraItem[JiraHelper.JiraKeys.Key]);
                if (jiraItem[JiraHelper.JiraKeys.Fields][JiraHelper.JiraKeys.Status].HasValues)
                    retVal.JIRAStatus = (string)jiraItem[JiraHelper.JiraKeys.Fields][JiraHelper.JiraKeys.Status][JiraHelper.JiraKeys.Name];
                /* if (jiraItem["fields"]["assignee"].HasValues)
                     retVal.Approver = GetApprover((string)jiraItem["fields"]["assignee"]["name"]);*/
                retVal.JIRASummary = (string)jiraItem[JiraHelper.JiraKeys.Fields][JiraHelper.JiraKeys.Summary];

                //remove env
                retVal.JIRASummary = retVal.JIRASummary.Remove(0, retVal.JIRASummary.IndexOf(']') > 0 ? retVal.JIRASummary.IndexOf(']') + 1 : 0).Trim();

                if (jiraItem[JiraHelper.JiraKeys.Fields][JiraHelper.JiraKeys.RequestType] != null
                    && jiraItem[JiraHelper.JiraKeys.Fields][JiraHelper.JiraKeys.RequestType].HasValues)
                    retVal.RequestType = (string)jiraItem[JiraHelper.JiraKeys.Fields][JiraHelper.JiraKeys.RequestType][JiraHelper.JiraKeys.Value];

                if (jiraItem[JiraHelper.JiraKeys.Fields][JiraHelper.JiraKeys.TeamResponsible] != null
                    && jiraItem[JiraHelper.JiraKeys.Fields][JiraHelper.JiraKeys.TeamResponsible].HasValues)
                {
                    retVal.GroupResponsibility = (string)jiraItem[JiraHelper.JiraKeys.Fields][JiraHelper.JiraKeys.TeamResponsible][JiraHelper.JiraKeys.Value];

                    if (jiraItem[JiraHelper.JiraKeys.Fields][JiraHelper.JiraKeys.TeamResponsible][JiraHelper.JiraKeys.Child] != null
                        && jiraItem[JiraHelper.JiraKeys.Fields][JiraHelper.JiraKeys.TeamResponsible][JiraHelper.JiraKeys.Child].HasValues)
                        retVal.TeamResponsibility = (string)jiraItem[JiraHelper.JiraKeys.Fields][JiraHelper.JiraKeys.TeamResponsible][JiraHelper.JiraKeys.Child][JiraHelper.JiraKeys.Value];
                }
                var labels = (JArray)jiraItem[JiraHelper.JiraKeys.Fields][JiraHelper.JiraKeys.Labels];

                foreach (JToken t in labels.Where(t => ((string)t).StartsWith("Env:")))
                {
                    retVal.Environment = ((string)t).Split(':')[1];
                }
                foreach (JToken t in labels.Where(t => ((string)t).StartsWith("DBType:")))
                {
                    retVal.DBType = ((string)t).Split(':')[1];
                }
                foreach (JToken t in labels.Where(t => ((string)t).StartsWith("Approver:")))
                {
                    retVal.Approver = GetApprover(((string)t).Split(':')[1]);
                }
                retVal.JIRABetaExecutionDone = null;
                foreach (JToken t in labels.Where(t => ((string)t).StartsWith("BetaExecution:Done")))
                {
                    retVal.JIRABetaExecutionDone = (string)t;
                }
                if (string.IsNullOrEmpty(retVal.DBType))
                    throw new Exception("It seems this JIRA was not created through Query Builder");
            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                retVal.errorMessage = string.Format("Failed while searching Jira Item with Exception: {0}", ex.Message);
            }

            return retVal;
        }

        private string GetLabel(string jiraNumber, string label)
        {
            string retVal = null;

            var jiraItemJson = JiraHelper.GetJiraItemDetail(jiraNumber);
            var jiraItem = JObject.Parse(jiraItemJson);
            var labels = (JArray)jiraItem[JiraHelper.JiraKeys.Fields][JiraHelper.JiraKeys.Labels];

            foreach (JToken t in labels.Where(t => ((string)t).StartsWith(label + ":")))
            {
                retVal = (string)t;
            }

            return retVal;
        }

        private void UpdateDesc(string jiraNo, string query, bool? skipBetaExecutionFlag, string skipBetaExecutionReason, bool? skipApprovalFlag, string skipApprovalReason)
        {
            string desc = GetDesc(jiraNo, query, skipBetaExecutionFlag, skipBetaExecutionReason, skipApprovalFlag, skipApprovalReason);

            JiraHelper.UpdateDesc(jiraNo, desc);
        }

        private string GetJiraSummary(string summary)
        {
            return string.Format("[{0}] {1}", Url, summary);
        }

        private string GetDesc(string jiraNo, string query, bool? skipBetaExecutionFlag, string skipBetaExecutionReason, bool? skipApprovalFlag, string skipApprovalReason)
        {
            JObject obj = new JObject();
            if (skipBetaExecutionFlag != null)
            {
                obj["SkipBetaExecution"] = skipBetaExecutionFlag.ToString();
                obj["SkipBetaExecutionReason"] = skipBetaExecutionReason;
            }
            if (skipBetaExecutionFlag != null)
            {
                obj["SkipApproval"] = skipApprovalFlag.ToString();
                obj["SkipApprovalReason"] = skipApprovalReason;
            }
            obj["Query"] = query;

            return obj.ToString();
        }

        public override ResponseBO CustomFunction(CustomFunctionBO req)
        {
            ResponseBO retval = new ResponseBO();
            var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
            QueryBuilderBO.QueryRequestBO data = json.Deserialize<QueryBuilderBO.QueryRequestBO>(req.data.ToString());
            if (data == null)
                throw new Exception("Failed in Json Deserialization");

            switch (req.functionName)
            {
                case "SaveJiraItem":
                    {
                        retval = SaveJiraItem(data);
                    }
                    break;
                case "CreateJiraItem":
                    {
                        retval = CreateJiraItem(data);
                    }
                    break;
                case "SearchJiraItem":
                    {
                        retval = SearchJiraItem(data);
                    }
                    break;
                case "CloseJiraItem":
                    {
                        JiraHelper.ChangeStatus(data.JIRANo, JiraHelper.JiraStatus.Closed);
                    }
                    break;
                case "ReopenJiraItem":
                    {
                        JiraHelper.ChangeStatus(data.JIRANo, JiraHelper.JiraStatus.Reopen);
                        JiraHelper.ChangeStatus(data.JIRANo, JiraHelper.JiraStatus.InProgress);
                        JiraHelper.RemoveLabel(data.JIRANo, "BetaExecution:Done");
                        UpdateDesc(data.JIRANo, data.Query, null, null, null, null);
                    }
                    break;
                case "SendForApproval":
                    {
                        JiraHelper.ChangeStatus(data.JIRANo, JiraHelper.JiraStatus.PendingApproval);
                        string approver = data.Approver.Split('-').Length > 0 ? data.Approver.Split('-')[1] : data.Approver;
                        JiraHelper.UpdateAssignee(data.JIRANo, approver);
                    }
                    break;
                case "SkipBetaExecutionSelected":
                    {
                        UpdateDesc(data.JIRANo, data.Query, data.SkipBetaExecution, data.SkipBetaExecutionReason, null, null);
                    }
                    break;
                case "SkipApprovalSelected":
                    {
                        UpdateDesc(data.JIRANo, data.Query, data.SkipBetaExecution, data.SkipBetaExecutionReason, data.SkipApproval, data.SkipApprovalReason);
                    }
                    break;
                case "GetJiraStatus":
                    {
                        JiraHelper.GetStatus(data.JIRANo);
                    }
                    break;
                case "BetaExecutionDone":
                    {
                        QueryBuilderBO.QueryResponseBO retval1 = new QueryBuilderBO.QueryResponseBO();
                        retval1.JIRABetaExecutionDone = GetLabel(data.JIRANo, "BetaExecution");
                        retval = retval1;
                    }
                    break;

                default:
                    throw new Exception(string.Format("Unknown functionName {0}", req.functionName));
            }

            return retval;
        }
    }
}
