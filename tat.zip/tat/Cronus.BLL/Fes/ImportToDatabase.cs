﻿using System;
using System.Collections.Generic;
using log4net;
using Cronus.BO;
using Cronus.Bll.Helper;
using System.Web.Script.Serialization;
using Cronus.BO.Fes;
using System.Collections.Specialized;

namespace Cronus.Bll.Fes
{
    internal class ImportToDatabase : CronusBaseBll
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public override object Clone() { return new ImportToDatabase(); }

        public override string ScreenName()
        {
            return Constants.ImportToDatabase;
        }

        private DatabaseHelper GetDBHelper(string dbName)
        {
            DatabaseHelper dbHelper;
            if (dbName.ToLowerInvariant().StartsWith("ora"))
                dbHelper = new OracleDatabaseHelper(ConfigManager.GetConnectionStr(dbName), GetKey());
            else
                dbHelper = new SybaseDatabaseHelper(ConfigManager.GetConnectionStr(dbName), GetKey());
            return dbHelper;
        }

        protected override string GetTableQuery(TableDataRequestBO requestData, out DatabaseType dbType)
        {
            dbType = DatabaseType.ORACLE;

            var tableName = requestData.tableName;
            string query;
            if (tableName == "GetDataBase")
                query = string.Format("SELECT distinct key, value,environment FROM CRONUS_OWN.CONFIG WHERE ScreenID = '{0}' and Context = 'Database Config' ORDER BY key desc", ScreenName());
            else
                throw new Exception(string.Format("Unknown TableName {0}", tableName));

            return query;
        }

        public override ResponseBO UpdateDB(RequestBO req)
        {
            Log.Debug("Enter");
            DatabaseHelper dbHelper = null;
            var auditIds = new List<long>();
            var retval = new ImportToDatabaseBO.TableDataResponseBO();
            try
            {
                if (!Compliance.IsActionAllowed(User, req.screenName, Constants.ImportToDatabase_Import, Url, RunOnEnviroment))
                    throw new Exception("Permission denied");

                var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                var a = req.data.ToString();
                var data = json.Deserialize<ImportToDatabaseBO.AddUpdateRequestBO>(req.data.ToString());
                if (data == null)
                    throw new Exception("Failed in Json Deserialization");
                dbHelper = GetDBHelper(data.database);
                dbHelper.BeginTransaction();
                string queryColType;

                if (data.database.ToLowerInvariant().StartsWith("ora"))
                {

                    string[] results = data.table.Split(new[] { "." }, StringSplitOptions.None);
                    if (results.Length != 2)
                    {
                        throw new Exception("both schema name and table names are required");
                    }
                    var schema = results[0].ToUpper();
                    var table = results[1].ToUpper();

                    queryColType = "select  column_name , data_type from all_tab_columns" +
                            " where table_name = '" + table + "' and owner = '" + schema + "'";

                }
                else
                {
                    string[] results = data.table.Split(new[] { ".." }, StringSplitOptions.None);
                    if (results.Length != 2)
                    {
                        throw (new Exception("both schema name and table names are required"));
                    }
                    var schema = results[0];
                    var table = results[1];
                    // Get the all the columns type for sybase table
                    queryColType = string.Format("select c.name [columnName], t.name [columnType] " +
                        "from {0}..sysobjects o inner join {0}..syscolumns c on c.id = o.id " +
                        " inner join {0}..systypes t on t.type = c.type where o.type = 'U' " +
                        "and o.name = '{1}' and t.name not in " +
                        "('sysname', 'nid', 'uid', 'nvarchar', 'tid', 'nchar' ,'longsysname') ", schema, table);
                }
                var selectedRows = dbHelper.ExecuteSelectQuery(queryColType);
                if (selectedRows.rows.Count == 0)
                {
                    throw (new Exception("Table " + data.table + " does not exists in database " + data.database));
                }
                // Create column and columns type dictionary.
                var colType = new Dictionary<string, string>();
                if (selectedRows.rows.Count > 0)
                {

                    {
                        for (var i = 0; i < selectedRows.rows.Count; i++)
                        {
                            colType.Add(
                                !data.database.ToLowerInvariant().StartsWith("ora")
                                    ? selectedRows.rows[i][0].ToString()
                                    : selectedRows.rows[i][0].ToString().ToLower(), selectedRows.rows[i][1].ToString());
                        }
                    }
                }



                // Here first write select query
                //"select  1 from " + data.table + "  where  " + "ticker  = 'XRS_C' and  asof_date = '08-Sep-2016' and currency = 'USD' and  description ='excess return soybeans vs corn'  and  index_data  = 578.9076981446935";
                var selectQueryInit = "select  1 from " + data.table + "  where ";
                var duplicateRows = new List<List<object>>();
                var uniqueRows = new List<List<object>>();
                foreach (var row in data.rows)
                {
                    string selectQuery = selectQueryInit;


                    if (data.database.ToLowerInvariant().StartsWith("ora"))
                    {

                        for (var j = 0; j < data.headers.Count; j++)
                        {
                            // if column type does not match with used passed headers , then throw error.
                            if (!colType.ContainsKey(data.headers[j].Trim().ToLower()))
                            {
                                throw new Exception(data.headers[j].Trim() + " column does not exist in " + data.table);
                            }


                            if (string.IsNullOrEmpty(row[j].ToString()))
                            {
                                selectQuery += data.headers[j].Trim() + " is NULL and ";
                            }
                            else
                            {
                                selectQuery += data.headers[j].Trim() + "='" + row[j] + "' and ";
                            }

                        }
                        if (selectQuery == selectQueryInit) continue;
                        selectQuery += " 1 =1  ";
                    }
                    else
                    {
                        for (var j = 0; j < data.headers.Count; j++)
                        {
                            // if column type does not match with used passed headers , then throw error.
                            if (!colType.ContainsKey(data.headers[j].Trim()))
                            {
                                throw new Exception(data.headers[j].Trim() + " column does not exist in " + data.table);
                            }

                            //index_data=   convert( float , '578.9076981')
                            var headerType = colType[data.headers[j].Trim()];

                            if (string.IsNullOrEmpty(row[j].ToString()))
                            {
                                selectQuery += data.headers[j].Trim() + " is NULL and ";
                            }
                            else
                            {
                                selectQuery += data.headers[j].Trim() + "= convert( " + headerType + " , '" + row[j] + "') and ";
                            }

                            
                        }

                        if (selectQuery == selectQueryInit) continue;
                        selectQuery += " 1 =1  ";
                    }

                    var result = dbHelper.ExecuteSelectQuery(selectQuery);
                    if (result != null && result.rows.Count > 0)
                    {
                        duplicateRows.Add(row);
                    }
                    else
                    {
                        uniqueRows.Add(row);
                    }

                    //select  1 from pm_own.index_data  where ticker='XRS_C' and asof_date='9/8/16' and currency='USD' and description='excess return soybeans vs corn' and index_data='578.9076981' and  1 =1  


                }
                if (duplicateRows.Count > 0 && !data.ProcceedAnyway)
                {
                    // Send warning to user with all duplicate records.
                    retval.dupRows = duplicateRows;
                    retval.uniqRows = uniqueRows;
                    return retval;
                }

                // If there is no duplicate data then insert it into table
                else
                {
                    var insertQueryInit = "insert into " + data.table + "( ";


                    foreach (var header in data.headers)
                    {
                        if (data.database.ToLowerInvariant().StartsWith("ora"))
                        {
                            if (colType.ContainsKey(header.Trim().ToLower()))
                                insertQueryInit += header.Trim().ToLower() + ",";
                        }
                        else
                        {
                            if (colType.ContainsKey(header.Trim()))
                                insertQueryInit += header.Trim() + ",";
                        }
                    }

                    insertQueryInit = insertQueryInit.TrimEnd(',');
                    insertQueryInit += ")  values (";

                    foreach (var row in data.rows)
                    {
                        Log.Info(string.Format("Import to Database Request by User:{0} database :{1} table:" +
                                           " {2} header: {3}  row :{4} ",
                                           User, data.database, data.table, data.headers.ToArray(), string.Join(",", row.ToArray())));

                        auditIds.Add(LogActionToAudit(new OrderedDictionary { { "Database", data.database }, { "Table", data.table },
                                                                             { "Header", string.Join(",", data.headers.ToArray()) }, 
                                                                             { "Row", string.Join(",", row.ToArray()) } }));

                        var insertQuery = insertQueryInit;

                        if (data.database.ToLowerInvariant().StartsWith("ora"))
                        {
                            for (int j = 0; j < data.headers.Count; j++)
                            {
                                if (string.IsNullOrEmpty(row[j].ToString()))
                                {
                                    insertQuery += " NULL ,";
                                }
                                else
                                {
                                    insertQuery += "'" + row[j] + "',";
                                }
                            }
                            if (insertQuery == insertQueryInit) continue;
                            insertQuery = insertQuery.TrimEnd(',');
                            insertQuery += ")";
                        }

                        else
                        {

                            for (int j = 0; j < data.headers.Count; j++)
                            {
                                var headerType = colType[data.headers[j].Trim()];
                                if (string.IsNullOrEmpty(row[j].ToString()))
                                {
                                    insertQuery += " NULL ,";
                                }
                                else
                                {
                                    insertQuery += " convert( " + headerType + " , '" + row[j] + "') ,";
                                }
                            }
                            insertQuery = insertQuery.TrimEnd(',');
                            insertQuery += ")";
                        }

                        dbHelper.ExecuteNonQuery(insertQuery);
                    }
                }
                dbHelper.Commit();

                foreach (var auditId in auditIds)
                    LogActionToAudit(new OrderedDictionary { { "Status", "Success" } }, auditId);
            }
            catch (Exception ex)
            {

                retval.errorMessage = string.Format("Exception: {0}", ex.Message);
                Log.Error(retval.errorMessage, ex);
                dbHelper.Rollback();

                foreach (var auditId in auditIds)
                    LogActionToAudit(new OrderedDictionary { { "Status", "Fail" } }, auditId);
            }
            finally
            {
                Log.Debug("Exit");
            }
            return retval;
        }


    }
}
