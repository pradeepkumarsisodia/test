﻿using System;
using System.Collections.Generic;
using log4net;
using System.Collections.Specialized;

namespace Cronus.Bll.Fes
{
    public class RiskMeasuresLive : CronusBaseBll
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private static Dictionary<string, long> _requestIdsCache = new Dictionary<string, long>();

        public override object Clone() { return new RiskMeasuresLive(); }

        public override string ScreenName()
        {
            return Constants.RiskMeasureLive;
        }
    }
}
