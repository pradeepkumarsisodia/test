﻿using System.Collections.Generic;
using log4net;

namespace Cronus.Bll.Fes
{
    class OttiRun : CronusBaseBll
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private Dictionary<string, string> analytic_id_datatype_cache = new Dictionary<string, string>();
        private Dictionary<string, Dictionary<string, string>> analytic_id_app_field_cache = new Dictionary<string, Dictionary<string, string>>();

        public override object Clone() { return new OttiRun(); }

        public override string ScreenName()
        {
            return Constants.OttiRun;
        }

        //public override ResponseBO UpdateDB(RequestBO req)
        //{
        //    Log.Debug("Enter");
        //    var retval = new OttiRunBO.AddUpdateResponseBO();
        //    try
        //    {
        //        if (!Compliance.IsActionAllowed(User, req.screenName, Constants.OttiRun_Run, Url))
        //            throw new Exception("Permission denied");

        //        var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
        //        var a = req.data.ToString();
        //        var data = json.Deserialize<OttiRunBO.AddUpdateRequestBO>(req.data.ToString());
        //        if (data == null)
        //            throw new Exception("Failed in Json Deserialization");

        //        if (string.IsNullOrWhiteSpace(retval.message))
        //            retval.message = string.Format("price_date = {0} \n\n", data.price_date.ToString("MM/dd/yyyy"));
        //        retval.message += string.Format("file_Path = {0} \n", data.file_Path);
        //        SendMail(retval.message);
        //        retval.message = "Mail Send Successfully";
        //    }
        //    catch (Exception ex)
        //    {
        //        retval.errorMessage = string.Format("Exception: {0}", ex.Message);
        //        Log.Error(retval.errorMessage, ex);

        //    }
        //    finally
        //    {
        //        Log.Debug("Exit");
        //    }
        //    return retval;
        //}

        //private void SendMail(string message)
        //{
        //    // Send email confirmation after successful substitution of cusip.             
        //    string subject = string.Format("[{0}] Otti Run", ConfigManager.GetEnv());
        //    string body = string.Format("<b>Otti Run details</b>: <br/><br/><b>Result:</b><br/>");
        //    body += message.Replace("\n", "<br/>");

        //    body += "<br/>Thanks,<br/>Cronus<br/><br/>";

        //    //string to = User + "@pimco.com," + System.Configuration.ConfigurationManager.AppSettings["OttiRunSendMailIds"]+",";
        //    string to = System.Configuration.ConfigurationManager.AppSettings["OttiRunSendMailIds"] + ",";
        //    if (!string.IsNullOrEmpty(ConfigManager.GetSendEmailTo()))
        //    {
        //        to = to + ConfigManager.GetSendEmailTo();
        //    }

        //    to = to.Trim(',');
        //    SendEmail(subject, body, to, ConfigManager.GetSendEmailFrom());
        //}
    }
}
