﻿using System;
using System.Collections.Generic;
using System.Linq;
using log4net.Repository.Hierarchy;
using System.IO;
using System.Text.RegularExpressions;
using log4net;
using log4net.Appender;

using Cronus.Bll.Helper;
using Cronus.BO;

namespace Cronus.Bll
{    
    public static class StreamReaderExtentions
    {
        public static IEnumerable<string> ReadLines(this StreamReader stream)
        {
            while (!stream.EndOfStream)
                yield return stream.ReadLine();
        }
    }

    public static class CronusBll
    {
        static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public static string DbCommandTimeout = System.Configuration.ConfigurationManager.AppSettings["commandTimeOut"];

        #region Reporting



        internal static string ScrubHtml(string html)
        {
            var step1 = Regex.Replace(html, @"<[^>]+>|&nbsp;", "").Trim();
            var step2 = Regex.Replace(step1, @"\s{2,}", " ");
            return step2;
        }

        /// <summary>
        /// Create excel for Reporting Export functionality
        /// </summary>
        /// <param name="dateFrom"></param>
        /// <param name="dateTo"></param>
        /// <param name="db"></param>
        /// <param name="currentPage"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortType"></param>
        /// <param name="columnIndex"></param>
        /// <param name="isFilterType"></param>
        /// <param name="userId"></param>
        /// <param name="screenId"></param>
        /// <param name="description"></param>
        /// <returns></returns>
        /// 
        //public static List<AUDIT_TRAIL_BO_Export> ExportReportingData(DateTime dateFrom, DateTime dateTo, string db, int currentPage = 0,
        //                                                              int pageSize = 10, string sortType = "asc", int columnIndex = 0,
        //                                                              bool isFilterType = false, string userId = "", string screenId = "",
        //                                                              string description = "")
        //{
        //    screenId = screenId.ToUpper().Equals("REJECTED CUSIPS") ? "RELOAD REJECTED CUSIPS" : screenId;
        //    dateTo = dateTo.Add(new TimeSpan(23, 59, 59));
        //    description = string.Format(@"{0}", description.Trim(new char[] { ' ', '\n' }));

        //    var resultList = new List<AUDIT_TRAIL_BO_Export>();
        //    try
        //    {
        //        using (var entity = new Cronus.Model.Oracle.EntitiesModel(db))
        //        {
        //            var startIndex = (pageSize * (currentPage - 1));
        //            var result = dateFrom.ToShortDateString() == dateTo.ToShortDateString() ?
        //                entity.AUDIT_TRAILs.Where(t => t.LAST_CHG_DATE.Value >= dateFrom
        //                    && t.LAST_CHG_DATE.Value <= dateTo
        //                    && (t.USER_ID.Contains(userId)
        //                    && t.SCREEN_ID.Contains(screenId)
        //                    && t.DESCRIPTION.Contains(description))).OrderByDescending(a => a.LAST_CHG_DATE).ToList() :
        //                        entity.AUDIT_TRAILs.Where(t => t.LAST_CHG_DATE.Value >= dateFrom
        //                    && t.LAST_CHG_DATE.Value <= dateTo
        //                    && (t.USER_ID.Contains(userId) && t.SCREEN_ID.Contains(screenId)
        //                    && t.DESCRIPTION.Contains(description))).OrderByDescending(a => a.LAST_CHG_DATE).ToList();
        //            foreach (var item in result)
        //            {
        //                resultList.Add(new AUDIT_TRAIL_BO_Export
        //                {
        //                    USER_ID = item.USER_ID,
        //                    SCREEN_ID = item.SCREEN_ID.ToUpper().Equals("RELOAD REJECTED CUSIPS") ? "REJECTED CUSIPS" : item.SCREEN_ID,
        //                    DESCRIPTION = ScrubHtml(item.DESCRIPTION),
        //                    LAST_CHG_DATE = item.LAST_CHG_DATE.HasValue ? item.LAST_CHG_DATE.Value.ToLongDateString() +
        //                    " " + item.LAST_CHG_DATE.Value.ToLongTimeString() : string.Empty,
        //                });
        //            }
        //            if (resultList.Any())
        //            {
        //                if (isFilterType)
        //                {
        //                    if (sortType == "desc")
        //                    {
        //                        switch (columnIndex)
        //                        {
        //                            case 0:
        //                                resultList = resultList.OrderByDescending(a => a.USER_ID).ToList();
        //                                break;
        //                            case 1:
        //                                resultList = resultList.OrderByDescending(a => a.SCREEN_ID).ToList();
        //                                break;
        //                            case 2:
        //                                resultList = resultList.OrderByDescending(a => a.DESCRIPTION).ToList();
        //                                break;
        //                            case 3:
        //                                resultList = resultList.OrderByDescending(a => Convert.ToDateTime(a.LAST_CHG_DATE)).ToList();
        //                                break;
        //                        }
        //                    }
        //                    else
        //                    {
        //                        switch (columnIndex)
        //                        {
        //                            case 0:
        //                                resultList = resultList.OrderBy(a => a.USER_ID).ToList();
        //                                break;
        //                            case 1:
        //                                resultList = resultList.OrderBy(a => a.SCREEN_ID).ToList();
        //                                break;
        //                            case 2:
        //                                resultList = resultList.OrderBy(a => a.DESCRIPTION).ToList();
        //                                break;
        //                            case 3:
        //                                resultList = resultList.OrderBy(a => Convert.ToDateTime(a.LAST_CHG_DATE)).ToList();
        //                                break;
        //                        }
        //                    }
        //                }
        //                else
        //                {
        //                    resultList = resultList.OrderByDescending(a => Convert.ToDateTime(a.LAST_CHG_DATE)).ToList();
        //                }
        //            }
        //            return resultList;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Log.Error("Exception : " + ex.Message, ex);
        //        return resultList;
        //    }
        //}

        #endregion


        #region Rejected Cusips
        public static List<RELOAD_REJECTED_CUSIP_BO_Export> ExportRejectedCusipData(string user, string reloadFlag, string url, string context, string cusipList, string priceDate,string runOnEnvironment)
        {
            Log.Debug("Enter");
            var resultList = new List<RELOAD_REJECTED_CUSIP_BO_Export>();
            string cusipWithQuotes = string.Join(",", cusipList.Split(',').Select(s => "'" + s.Trim() + "'"));
            try
            {
                Log.Info(string.Format("Export to Excel Request by User: {0} Parameters: Context {1} Price date {2}", user, context, priceDate));

                string query = "select convert(date,price_date) as 'Price Date', cusip as 'Cusip',context as 'Context', ";
                query = query + "region_code as 'Region Code',rejection_rule as 'Rejection Rule' from pm..rejected_cusips";
                query = query + " where price_date = '" + priceDate + "'";

                if (context != "")
                {
                    query = query + " and context = '" + context + "' ";
                }
                if (cusipList != "")
                {
                    query = query + " and cusip in (" + cusipWithQuotes + " ) ";
                }

                query = query + " and reload_flag = '" + reloadFlag + "'";
                ConfigHelper configManager = new ConfigHelper(url);
                DatabaseHelper sybaseDBHelper = new SybaseDatabaseHelper(configManager.GetSybaseConnectionStr(runOnEnvironment), user);
                var result = sybaseDBHelper.ExecuteSelectQuery(query);

                if (result.rows.Count > 0)
                {
                    foreach (var item in result.rows)
                    {
                        if (item.Count == 5)
                        {
                            var obj = new RELOAD_REJECTED_CUSIP_BO_Export();
                            obj.PRICE_DATE = Convert.ToString(item[0]);
                            obj.CUSIP = Convert.ToString(item[1]);
                            obj.CONTEXT = Convert.ToString(item[2]);
                            obj.REGION_CODE = Convert.ToString(item[3]);
                            obj.REJECTION_RULE = Convert.ToString(item[4]);
                            resultList.Add(obj);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error("Exception : " + ex.Message, ex);
            }
            finally
            {
                Log.Debug("Exit");
            }
            return resultList;
        }

        #endregion


        #region Reporting :: Current Log
        /// <summary>
        /// Method to get current log file name
        /// </summary>
        /// <returns></returns>
        private static string GetLogFileName()
        {
            try
            {
                Log.Debug("Enter Method -  " + System.Reflection.MethodBase.GetCurrentMethod().Name);
                var appender = ((Hierarchy)LogManager.GetRepository()).Root.Appenders.OfType<RollingFileAppender>().FirstOrDefault();
                return appender != null ? appender.File : string.Empty;
            }
            catch (Exception ex)
            {
                Log.Error("Exception : " + ex.Message, ex);
                return null;
            }
            finally
            {
                Log.Debug("Exit Method -  " + System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
        }

        /// <summary>
        /// Method to load current running log file
        /// </summary>
        /// <returns></returns>

        public static string LoadCurrentLogFile()
        {
            try
            {
                Log.Debug("Enter Method -  " + System.Reflection.MethodBase.GetCurrentMethod().Name);
                var file = GetLogFileName();
                int noOfRows = 1000;
                if (string.IsNullOrEmpty(file))
                    return string.Empty;

                string fileContent = string.Empty;

                if (File.Exists(file))
                {
                    using (Stream stream = File.Open(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    {
                        using (StreamReader streamReader = new StreamReader(stream))
                        {
                            fileContent = string.Format("LogFile : {0}. Displaying last {1} lines", file, noOfRows);
                            List<string> lines = streamReader.ReadLines().ToList();
                           // lines.Reverse();
                            if (lines.Count > noOfRows)
                                lines.RemoveRange(0, lines.Count - noOfRows);
                            //lines.Add(string.Format("LogFile : {0}. Displaying last {1} lines", file, noOfRows));
                            fileContent += lines.Aggregate("", (x, y) => x + "\n" + y);
                        }
                    }
                }

                return fileContent;
            }
            catch (Exception ex)
            {
                Log.Error("Exception : " + ex.Message, ex);
                return "Exception : " + ex.Message;
            }
            finally
            {
                Log.Debug("Exit Method -  " + System.Reflection.MethodBase.GetCurrentMethod().Name);
            }
        }
        #endregion
    }
}
