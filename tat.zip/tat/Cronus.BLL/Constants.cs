﻿namespace Cronus.Bll
{
    public static class Constants
    {
        #region ScreenNames
        public const string AgencyModelMap = "AGENCY MODEL MAP";
        public const string CreditEntityAttributes = "CREDIT ENTITY ATTRIBUTES";
        public const string Dashboard = "DASHBOARD";
        public const string DataManipulation = "DATA MANIPULATION";
        public const string ImportToDatabase = "IMPORT TO DATABASE";
        public const string ManageMasterTables = "MANAGE MASTER TABLES";
        public const string QueryBuilder = "QUERY BUILDER";
        public const string RejectedCusips = "RELOAD REJECTED CUSIPS";
        public const string RiskAttribution = "RISK ATTRIBUTION";
        public const string RiskMeasureLive = "RISK MEASURES LIVE";
        public const string RiskMeasureOverride = "RISK MEASURE OVERRIDE";
        public const string Reporting = "REPORTING";
        public const string SubstituteCusips = "SUBSTITUTE CUSIPS";
        public const string Settings = "SETTINGS";
        public const string TSDefinition = "SETUP NEW DEFINITION";
        public const string StaleRiskMeasures = "STALE RISK MEASURES";
        public const string UserManagement = "USER MANAGEMENT";
        public const string ModelSummaryReport = "MODEL SUMMARY REPORT";
        public const string Regression = "REGRESSION";
        public const string BackFilling = "BackFilling";
        public const string SecAnalyticsOverride = "SEC ANALYTICS OVERRIDE";
        public const string OttiRun = "OTTI RUN";
        public const string SecurityStaleNotes = "SECURITY STALE NOTES";
        public const string AnalyticIdConfiguration = "Analytic Id Configuration";
        public const string QueryExecuter = "QUERY EXECUTER";
        #endregion

        #region Actions
        public const string AgencyModelMapView = "VIEW";
        public const string AgencyModelMapSearch = "SEARCH";
        public const string AgencyModelMapAddUpdate = "AddUpdate";
        public const string BackFillingView = "VIEW";
        public const string BackFillingSave = "SAVE";

        public const string CreditEntityAttributesView = "VIEW";
        public const string CreditEntityAttributesUpdate = "UPDATE";
        public const string DashboardView = "VIEW";
        public const string DashboardSubmit = "SUBMIT";
        public const string DataManipulationView = "VIEW";
        public const string DataManipulationSearch = "SEARCH";
        public const string DataManipulationSave = "SAVE";
        public const string ImportToDatabase_View = "VIEW";
        public const string ImportToDatabase_Import = "IMPORT";
        public const string ManageMasterTablesView = "VIEW";
        public const string ModelSummaryReportView = "VIEW";
        public const string ModelSummaryReportRun = "RUN";
        public const string ModelSummaryReportSave = "SAVE";
        public const string Query_FND_W_OTHER_R = "FND_W_OTHER_R";
        public const string Query_View_FND_ONLY = "View_FND_ONLY";
        public const string Query_ALL_W = "ALL_W";
        public const string QueryExecute = "EXECUTE";
        public const string RegressionView = "VIEW";
        public const string RegressionRun = "RUN";
        public const string RejectedCusipsView = "VIEW";
        public const string RejectedCusipsNotifyForRejection = "Notify for Rejection";
        public const string RejectedCusipsNotifyForReload = "Notify for Reload";
        public const string RejectedCusipsShowDetails = "Show Details";
        public const string RejectedCusipsSearchCurrentNotification = "Search Current Notification";
        public const string RejectedCusipsSearchRejectedCusips = "Search Rejected Cusips";
        public const string RiskAttributionView = "VIEW";
        public const string RiskAttributionSearch = "SEARCH";
        public const string RiskMeasureLiveView = "VIEW";
        public const string RiskMeasureLiveRun = "RUN";
        public const string RiskMeasureLiveLoad = "LOAD";
        public const string RiskMeasureOverrideView = "VIEW";
        public const string RiskMeasureOverrideViewAnalytics = "VIEW ANALYTICS";
        public const string RiskMeasureOverrideViewTraders = "VIEW Traders";
        public const string RiskMeasureOverrideSubmitBase = "SUBMIT BASE";
        public const string RiskMeasureOverrideSubmitScenarios = "SUBMIT SCENARIO";
        public const string RiskMeasureOverrideSubmitTraders = "SUBMIT TRADERS";
        public const string SubstituteCusipsSearch = "SEARCH";
        public const string SubstituteCusipsShowAll = "SHOW ALL";
        public const string SubstituteCusipsSave = "SAVE";
        public const string TSDefinitionView = "VIEW";
        public const string TSDefinitionSubmit = "Submit";
        public const string SecAnalyticsOverride_View = "VIEW";
        public const string SecAnalyticsOverride_Submit = "Submit";
        public const string SecAnalyticsOverride_Search = "SEARCH";
        public const string StaleRiskMeasuresView = "VIEW";
        public const string StaleRiskMeasuresSubmit = "Submit";

        public const string OttiRun_View = "VIEW";
        public const string OttiRun_Run = "RUN";
        public const string SecurityStaleNotes_View = "VIEW";

        
        #endregion

        #region OTHER CONSTANTS
        public const int MaxSelectedRows = 10000;

        public const string DropdownSeperator = "-";
        public const string TSGroupClass = "TS_GROUP_CLASS";
        public const string TSGroupSubclass = "TS_GROUP_SUBCLASS";
        public const string TSFrequency = "TS_FREQUENCY";
        public const string TSGroups = "TS_GROUPS";
        public const string TSDefinitions = "TS_DEFINITIONS";

        #endregion
    }

    public static class FeServerKeys
    {
        public const string ActionTopic = "feserver.action";//"feserver";
        public const string StatusTopic = "feserver.action.status";//"replyfeserver";
        public const string CommandScript = "command-script"; // will remove
        public const string CommandParams = "command-params";
        public const string CommandFlags = "command-flags";
        public const string CommandId = "command-id";
        public const string Subscriber = "MYSUBSNAME";
        public const string Task = "task";
        public const string Action = "action";// will remove
        public const string RequestTime = "request_time";
        public const string Username = "username";
        public const string Client = "client";
        public const string Params = "params";
        public const string Id = "id";
        public const string RefId = "ref-id";// will remove
        public const string Query = "query";// will remove
        public const string Status = "status";
        public const string Message = "message";
        public const string Results = "results";
    }

    public static class FeServerTasks
    {
        public const string Grm = "GRM";
        public const string Regression = "REGRESSION";
        public const string Report = "REPORT";
        public const string Result = "RESULT";
        public const string Status = "STATUS";
        public const string List = "LIST";
    }

    public static class GrmKeys
    {
        public const string GrmScript = "generate_risk_measures.pl";// will remove
        public const string PostProcess = "post-process";
        public const string SecClassify = "skip-classify";
        public const string DBUpdate = "db-update";
        public const string Cusip = "cusip";
        public const string Price = "price";
        public const string PriceDate = "price-date";

        public const string KeyRatesStage = "key-rates-stage";
        public const string PostStats = "post-stats";
        public const string PostSwaps = "post-swaps";
    }

    public static class MsrKeys
    {
        public const string Msr = "MSR";
        public const string InvocationId = "invocation-id";
        public const string PriceDate = "price-date";
        public const string EMail = "mail-id";
    }

    public static class ResultValues
    {
        public const string Ok = "OK";
        public const string Failed = "FAILED";
    }
}
