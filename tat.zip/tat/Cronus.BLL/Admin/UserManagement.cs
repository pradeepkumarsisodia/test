﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Reflection;
using System.Web.Script.Serialization;
using Cronus.Bll.Helper;
using Cronus.BO;
using Cronus.BO.Admin;
//using Cronus.Model.Oracle;
using log4net;

namespace Cronus.Bll.Admin
{
    public class UserManagement : CronusBaseBll
    {
        private static readonly ILog Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        public override object Clone() { return new UserManagement(); }

        public override string ScreenName() { return Constants.UserManagement; }

        protected override string GetTableQuery(TableDataRequestBO requestData, out DatabaseType dbType)
        {
            dbType = DatabaseType.ORACLE;
            var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
            UserManagementBO.SearchBO data = json.Deserialize<UserManagementBO.SearchBO>(requestData.data.ToString());
            if (data == null)
                throw new Exception("Failed in Json Deserialization");

            string query = "";
            string groupId = data.groupId;
            string tab = data.tab;
            switch (tab)
            {
                case "S":
                    query = string.Format("SELECT a.SCREEN_ID, a.ACTION_ID, UPPER(a.ACTION_NAME), a.DESCRIPTION, gap.IS_ACTIVE FROM CRONUS_OWN.ACTION a LEFT JOIN CRONUS_OWN.GROUP_ACTION_PERMISSION gap ON (a.ACTION_ID = gap.ACTION_ID AND gap.GROUP_ID = '{0}' and gap.IS_ACTIVE = 'Y') ORDER BY 1,2 desc", groupId);
                    break;
                case "G":
                    query = string.Format("SELECT u.USER_ID, ug.GROUP_ID FROM CRONUS_OWN.USERS u LEFT JOIN CRONUS_OWN.USER_GROUP ug ON (u.USER_ID = ug.USER_ID AND ug.GROUP_ID = '{0}' and ug.IS_ACTIVE = 'Y') WHERE u.IS_ACTIVE = 'Y' ORDER BY 1", groupId);
                    break;
                case "U":
                    var data2 = json.Deserialize<UserManagementBO.SearchRequestBO>(requestData.data.ToString());
                    if (data2 == null)
                        throw new Exception("Failed in Json Deserialization");

                    var userIds = data2.UserId.ToLowerInvariant();

                    if (!string.IsNullOrEmpty(userIds))
                    {
                        var inClausListStr = "";
                        foreach (var userId in userIds.Split(','))
                        {
                            if (string.IsNullOrEmpty(inClausListStr))
                                inClausListStr = string.Format(" '{0}' ", userId.TrimStart());
                            else
                                inClausListStr += string.Format(", '{0}' ", userId.TrimStart());
                        }
                        Log.Info(string.Format("Select Request for ssm_id = {0}", inClausListStr));

                        query = string.Format("Select login_id ,First_name, Last_name ,email_id From TLC_BI_OWN.LDAP_USERS_VW Where login_id in ({0})", inClausListStr);
                    }
                    break;
            }
            return query;
        }
        protected override string GetDropDownDataQuery(string fieldName, DropDownRequestBO requestData, out DatabaseType dbType)
        {
            dbType = DatabaseType.ORACLE;
            string query = "";
            switch (fieldName)
            {
                case "SCREEN":
                    query = "SELECT CASE WHEN SCREEN_ID = 'RELOAD REJECTED CUSIPS' THEN 'REJECTED CUSIPS' ELSE SCREEN_ID END AS SCREEN_ID FROM CRONUS_OWN.SCREEN";
                    break;
                case "USER":
                    query = "SELECT USER_ID, DESCRIPTION FROM CRONUS_OWN.USERS WHERE IS_ACTIVE = 'Y' ORDER BY USER_ID";
                    break;
                case "GROUP":
                    query = "SELECT GROUP_ID, DESCRIPTION FROM CRONUS_OWN.GROUPS WHERE IS_ACTIVE = 'Y' ORDER BY GROUP_ID";
                    break;
            }

            return query;

        }
        public override ResponseBO UpdateDB(RequestBO requestData)
        {
            //  var retval = new ResponseBO();
            var retval = new UserManagementBO.AddUpdateResponseBO();
            DatabaseHelper dbHelper = OracleDbHelper;
            try
            {
                JavaScriptSerializer json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
                UserManagementBO.UpdateBO data = json.Deserialize<UserManagementBO.UpdateBO>(requestData.data.ToString());
                if (data == null)
                    throw new Exception("Failed in Json Deserialization");

                dbHelper.BeginTransaction();
                switch (data.tab)
                {
                    case "U":
                        {
                            UserManagementBO.UserUpdateBO userData = json.Deserialize<UserManagementBO.UserUpdateBO>(requestData.data.ToString());
                            if (userData == null)
                                throw new Exception("Failed in Json Deserialization");

                            string query = "select 1 from dual";
                            switch (userData.action)
                            {
                                case "U":
                                    query = string.Format("UPDATE CRONUS_OWN.USERS SET DESCRIPTION = '{0},{1}' WHERE Upper(USER_ID) = '{2}'", userData.UserName, userData.Email, userData.UserId.ToUpper());
                                    break;
                                case "I":
                                    query = string.Format("UPDATE CRONUS_OWN.USERS SET IS_ACTIVE = 'Y', DESCRIPTION = '{0},{1}' WHERE Upper(USER_ID) = '{2}' ", userData.UserName, userData.Email, userData.UserId.ToUpper());
                                    long rowAffetected = dbHelper.ExecuteNonQuery(query);
                                    if (rowAffetected == 0)
                                        query = string.Format("INSERT INTO CRONUS_OWN.USERS(USER_ID, DESCRIPTION, IS_ACTIVE) VALUES('{0}', '{1},{2}', 'Y')", userData.UserId.ToUpper(), userData.UserName, userData.Email);
                                    break;
                                case "D":
                                    var query2 = string.Format("UPDATE CRONUS_OWN.USER_GROUP SET IS_ACTIVE = 'N' WHERE UPPER(USER_ID) = '{0}'", userData.UserId.ToUpper());
                                    dbHelper.ExecuteNonQuery(query2);
                                    query = string.Format("UPDATE CRONUS_OWN.USERS SET IS_ACTIVE = 'N' WHERE USER_ID = '{0}'", userData.UserId.ToUpper());
                                    break;
                                case "M":
                                    /*Validate data */
                                    foreach (var userData2 in userData.UserDetailList)
                                    {
                                        if (string.IsNullOrEmpty(userData2.UserId))
                                            throw new Exception("UserId can not be null");
                                        if (string.IsNullOrEmpty(userData2.UserName))
                                            throw new Exception("UserName can not be null");
                                    }

                                    /*Process data */
                                    dbHelper.BeginTransaction();
                                    var auditIds = new List<long>();

                                    foreach (var userdata in userData.UserDetailList)
                                    {
                                        Log.Info(string.Format("Request by User: {0}, Processing {1}", User, userdata));
                                        var userId = userdata.UserId;
                                        var userName = userdata.UserName;
                                        var userEmail = userdata.Email;

                                        auditIds.Add(LogActionToAudit(new OrderedDictionary() { { "userId", userId }, { "userName", userName }, { "userEmail", userEmail } }));

                                        try
                                        {
                                            query = string.Format("merge into CRONUS_OWN.USERS a " +
                                                                              "using (select '{0}' user_id, '{1},{2}' DESCRIPTION from dual)b " +
                                                                              "on (a.user_id=b.user_id) " +
                                                                              "when matched then update set a.DESCRIPTION=b.DESCRIPTION ,IS_ACTIVE = 'Y' " +
                                                                              "when not matched then  insert(user_id,DESCRIPTION, IS_ACTIVE) values(b.user_id,b.DESCRIPTION, 'Y')"
                                                                              , userId.ToUpper(), userName, userEmail);
                                            dbHelper.ExecuteNonQuery(query);
                                            retval.message += string.Format("UserId = {0}, UserName = {1}, userEmail = {2}, status = {3} \n", userId, userName, userEmail, "Success");
                                        }
                                        catch (Exception ex)
                                        {
                                            Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                                            dbHelper.Rollback();
                                            foreach (var auditId in auditIds)
                                                LogActionToAudit(new OrderedDictionary() { { "status", "Fail" } }, auditId);
                                            throw;
                                        }
                                    }
                                    dbHelper.Commit();
                                    foreach (var auditId in auditIds)
                                        LogActionToAudit(new OrderedDictionary() { { "status", "Success" } }, auditId);

                                    break;
                                default:
                                    throw new Exception(string.Format("Unknown action {0}", userData.action));
                            }

                            dbHelper.ExecuteNonQuery(query);
                        }
                        break;
                    case "G":
                        {
                            UserManagementBO.GroupUpdateBO groupData = json.Deserialize<UserManagementBO.GroupUpdateBO>(requestData.data.ToString());
                            if (groupData == null)
                                throw new Exception("Failed in Json Deserialization");
                            if (groupData.action == "M")
                            {
                                UserManagementBO.UsersGroupUpdateBO usersGrp = json.Deserialize<UserManagementBO.UsersGroupUpdateBO>(requestData.data.ToString());
                                if (usersGrp == null)
                                    throw new Exception("Failed in Json Deserialization");
                                ManageUsersInGroup(usersGrp.groupId, usersGrp.userIds, requestData.runEnviroment, usersGrp.deletedUserIds);
                            }
                            else
                            {
                                string query;
                                switch (groupData.action)
                                {
                                    case "U":
                                        query = string.Format("UPDATE CRONUS_OWN.GROUPS SET DESCRIPTION = '{0}' WHERE UPPER(GROUP_ID) = '{1}'", groupData.description, groupData.groupId.ToUpper());
                                        break;
                                    case "I":
                                        query = string.Format("UPDATE CRONUS_OWN.GROUPS SET IS_ACTIVE = 'Y', DESCRIPTION = '{0}' WHERE Upper(GROUP_ID) = '{1}' ", groupData.description, groupData.groupId.ToUpper());
                                        long rowAffetected = dbHelper.ExecuteNonQuery(query);
                                        if (rowAffetected == 0)
                                            query = string.Format("INSERT INTO CRONUS_OWN.GROUPS(GROUP_ID, DESCRIPTION, IS_ACTIVE) VALUES('{0}', '{1}', 'Y')", groupData.groupId.ToUpper(), groupData.description);
                                        break;
                                    case "D":
                                        query = string.Format("UPDATE CRONUS_OWN.GROUPS SET IS_ACTIVE = 'N' WHERE UPPER(GROUP_ID) = '{0}'", groupData.groupId.ToUpper());
                                        break;
                                    default:
                                        throw new Exception("Unknown action");
                                }

                                dbHelper.ExecuteNonQuery(query);
                            }
                        }
                        break;
                    case "S":
                        UserManagementBO.PermissionUpdateBO perm = json.Deserialize<UserManagementBO.PermissionUpdateBO>(requestData.data.ToString());
                        if (perm == null)
                            throw new Exception("Failed in Json Deserialization");
                        ManageActionPermissionsForGroup(perm.groupId, perm.actionIds, requestData.runEnviroment, perm.deleteActionlist, perm.insertActionlist);
                        break;
                    default:
                        throw new Exception(string.Format("Unknown Tab {0}", data.tab));
                }

                dbHelper.Commit();
            }
            catch (Exception ex)
            {
                retval.errorMessage = string.Format("Exception: {0}", ex.Message);
                Log.Error(retval.errorMessage, ex);
                dbHelper.Rollback();
            }

            return retval;
        }

        private void ManageUsersInGroup(string groupId, List<string> users, string runOnEnviroment, List<string> deletedUserlist)
        {

            Log.Debug("Enter");
            var OracleDbHelper = new OracleDatabaseHelper(ConfigManager.GetOracleConnectionStr(runOnEnviroment), string.Format("{0}_%_{1}_%_{2}", users, ScreenName(), Guid.NewGuid()));
            try
            {
                OracleDbHelper.BeginTransaction();
                var rowEffected = 0;
                if (deletedUserlist.Count > 0)
                {

                    string userId = string.Join(",", deletedUserlist.ToList<string>().Select(s => "'" + s.Trim() + "'"));
                    var updateQuery = string.Format(@"update CRONUS_OWN.USER_GROUP set IS_ACTIVE = 'N' where Group_ID = '{0}' and IS_ACTIVE = 'Y'  and user_id in ({1})  ", groupId, userId);
                    rowEffected = OracleDbHelper.ExecuteNonQuery(updateQuery);
                }

                foreach (string user in users)
                {
                    var insertQuery = string.Format(@"insert into CRONUS_OWN.USER_GROUP(GROUP_ID,IS_ACTIVE,USER_ID) values('{0}','Y','{1}')", groupId, user);
                    rowEffected = OracleDbHelper.ExecuteNonQuery(insertQuery);
                }
                OracleDbHelper.Commit();
            }
            catch (Exception ex)
            {
                OracleDbHelper.Rollback();
                Log.Error("Exception : " + ex.Message, ex);

                throw;
            }
            finally
            {
                Log.Debug("Exit");
            }
        }

        private void ManageActionPermissionsForGroup(string groupId, List<long> actionIds, string runOnEnviroment, List<string> deleteActionlist, List<string> insertActionlist)
        {
            Log.Debug("Enter");
            var OracleDbHelper = new OracleDatabaseHelper(ConfigManager.GetOracleConnectionStr(runOnEnviroment), string.Format("{0}_%_{1}_%_{2}", "", ScreenName(), Guid.NewGuid()));
            try
            {
                OracleDbHelper.BeginTransaction();
                var rowEffected = 0;
                if (deleteActionlist.Count > 0)
                {

                    string updateActionIds = string.Join(",", deleteActionlist.ToList<string>().Select(s => "'" + s.Trim() + "'"));
                    var updateQuery = string.Format(@"update CRONUS_OWN.GROUP_ACTION_PERMISSION set IS_ACTIVE = 'N' where Group_ID = '{0}' and IS_ACTIVE = 'Y'  and Action_ID in ({1})  ", groupId, updateActionIds);
                    rowEffected = OracleDbHelper.ExecuteNonQuery(updateQuery);
                }

                foreach (string actionId in insertActionlist)
                {
                    var insertQuery = string.Format(@"insert into CRONUS_OWN.GROUP_ACTION_PERMISSION(GROUP_ID,ACTION_ID,IS_ACTIVE) values('{0}','{1}','Y')", groupId, actionId);
                    rowEffected = OracleDbHelper.ExecuteNonQuery(insertQuery);
                }

                OracleDbHelper.Commit();

            }
            catch (Exception ex)
            {
                OracleDbHelper.Rollback();
                Log.Error("Exception : " + ex.Message, ex);

                throw;
            }
            finally
            {
                Log.Debug("Exit");
            }
        }
    }
}
