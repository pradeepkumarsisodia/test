﻿using System;
using Cronus.BO;
using System.Web.Script.Serialization;
using Cronus.BO.Admin;

namespace Cronus.Bll.Admin
{
    public class Reporting : CronusBaseBll
    {
        //private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public override object Clone() { return new Reporting(); }

        public override string ScreenName()
        {
            return Constants.Reporting;
        }

        protected override string GetTableQuery(TableDataRequestBO requestData, out DatabaseType dbType)
        {
            dbType = DatabaseType.ORACLE;

            var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
            var data = json.Deserialize<ReportingBO.ReportRequestBO>(requestData.data.ToString());
            if (data == null)
                throw new Exception("Failed in Json Deserialization");

            var dateFrom = data.dateFrom;
            var dateTo = data.dateTo;
            var description = data.description;
            var userId = data.userId;
            var groupId = data.groupId;
            var screenId = data.screenId;
            description = string.Format(@"{0}", description.Replace("\\n", string.Empty).Trim());

            string query;
            switch (requestData.tableName)
            {
                case "Reporting":
                    query = "select distinct tr.user_id, CASE WHEN SCREEN_ID = \'RELOAD REJECTED CUSIPS\' THEN \'REJECTED CUSIPS\' ELSE SCREEN_ID END AS screen_id,  description, tr.last_chg_date from  CRONUS_OWN.AUDIT_TRAIL tr ";
                    if (!string.IsNullOrEmpty(groupId))
                        query += " join  CRONUS_OWN.USER_GROUP ug on(ug.user_id = tr.user_id) ";
                    query += " where 1 = 1 ";

                    if (!string.IsNullOrEmpty(description))
                        query += " and Upper(tr.DESCRIPTION) like '%" + description.ToUpper() + "%' ";

                    if (!string.IsNullOrEmpty(userId))
                        query += " and  Upper(tr.USER_ID) = '" + userId.ToUpper() + "' ";

                    if (!string.IsNullOrEmpty(groupId))
                        query += " and  Upper(ug.GROUP_ID) = '" + groupId.ToUpper() + "' ";

                    if (!string.IsNullOrEmpty(screenId))
                    {
                        if (screenId == "REJECTED CUSIPS")
                            screenId = "RELOAD REJECTED CUSIPS";
                        query += " and  Upper(tr.SCREEN_ID) = '" + screenId.ToUpper() + "' ";
                    }

                    query += " and tr.LAST_CHG_DATE >= " + string.Format("to_date('{0}','mm/dd/yyyy HH:MI:SS am')", dateFrom.Date);
                    query += " and tr.LAST_CHG_DATE <= " + string.Format("to_date('{0}','mm/dd/yyyy HH:MI:SS am')", dateTo);
                    query += " order by last_chg_date desc ";

                    break;
                case "Analytics":
                    query = "select screen_id , count(*) as count from cronus_own.audit_trail tr ";
                    if (!string.IsNullOrEmpty(groupId))
                        query += " join  CRONUS_OWN.USER_GROUP ug on(ug.user_id = tr.user_id) ";
                    query += " where 1 = 1 ";


                    if (!string.IsNullOrEmpty(description))
                        query += " and Upper(tr.DESCRIPTION) like '%" + description.ToUpper() + "%' ";

                    if (!string.IsNullOrEmpty(userId))
                        query += " and  Upper(tr.USER_ID) = '" + userId.ToUpper() + "' ";

                    if (!string.IsNullOrEmpty(groupId))
                        query += " and  Upper(ug.GROUP_ID) = '" + groupId.ToUpper() + "' ";

                    if (!string.IsNullOrEmpty(screenId))
                    {
                        if (screenId == "REJECTED CUSIPS")
                            screenId = "RELOAD REJECTED CUSIPS";
                        query += " and  Upper(tr.SCREEN_ID) = '" + screenId.ToUpper() + "' ";
                    }

                    query += " and tr.LAST_CHG_DATE >= " + string.Format("to_date('{0}','mm/dd/yyyy HH:MI:SS am')", dateFrom.Date);
                    query += " and tr.LAST_CHG_DATE <= " + string.Format("to_date('{0}','mm/dd/yyyy HH:MI:SS am')", dateTo);
                    query += " group by screen_id order by  screen_id , count(*) asc";
                    break;
                case "AnalyticsUser":
                    query = "select tr.user_id , count(*) as count from cronus_own.audit_trail tr ";
                    if (!string.IsNullOrEmpty(groupId))
                        query += " join  CRONUS_OWN.USER_GROUP ug on(ug.user_id = tr.user_id) ";
                    query += " where 1 = 1 ";


                    if (!string.IsNullOrEmpty(description))
                        query += " and Upper(tr.DESCRIPTION) like '%" + description.ToUpper() + "%' ";

                    if (!string.IsNullOrEmpty(userId))
                        query += " and  Upper(tr.USER_ID) = '" + userId.ToUpper() + "' ";

                    if (!string.IsNullOrEmpty(groupId))
                        query += " and  Upper(ug.GROUP_ID) = '" + groupId.ToUpper() + "' ";

                    if (!string.IsNullOrEmpty(screenId))
                    {
                        if (screenId == "REJECTED CUSIPS")
                            screenId = "RELOAD REJECTED CUSIPS";
                        query += " and  Upper(tr.SCREEN_ID) = '" + screenId.ToUpper() + "' ";
                    }

                    query += " and tr.LAST_CHG_DATE >= " + string.Format("to_date('{0}','mm/dd/yyyy HH:MI:SS am')", dateFrom.Date);
                    query += " and tr.LAST_CHG_DATE <= " + string.Format("to_date('{0}','mm/dd/yyyy HH:MI:SS am')", dateTo);
                    query += " group by tr.user_id order by  tr.user_id , count(*) asc";
                    break;
                default:
                    throw new Exception(string.Format("Unknown RequestType {0}", requestData.tableName));
            }
            return query;
        }

        protected override string GetDropDownDataQuery(string fieldName, DropDownRequestBO requestData, out DatabaseType dbType)
        {
            dbType = DatabaseType.ORACLE;
            var query = "";
            switch (fieldName)
            {
                case "SCREEN":
                    query = "SELECT CASE WHEN SCREEN_ID = 'RELOAD REJECTED CUSIPS' THEN 'REJECTED CUSIPS' ELSE SCREEN_ID END AS SCREEN_ID FROM CRONUS_OWN.SCREEN";
                    break;
                case "USER":
                    query = "SELECT USER_ID FROM CRONUS_OWN.USERS WHERE IS_ACTIVE = 'Y' ORDER BY USER_ID";
                    break;
                case "GROUP":
                    query = "SELECT GROUP_ID FROM CRONUS_OWN.GROUPS WHERE IS_ACTIVE = 'Y' ORDER BY GROUP_ID";
                    break;
            }
            return query;

        }
    }
}
