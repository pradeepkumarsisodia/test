﻿using System;
using log4net;
using Cronus.BO;
using Cronus.Bll.Helper;
using System.Web.Script.Serialization;
using Cronus.BO.Admin;

namespace Cronus.Bll.Admin
{
    public class Settings : CronusBaseBll
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public override object Clone() { return new Settings(); }

        public override string ScreenName() { return Constants.Settings; }

        protected override string GetTableQuery(TableDataRequestBO requestData, out DatabaseType dbType)
        {
            dbType = DatabaseType.ORACLE;
            string query = string.Format("SELECT USER_ID,DESCRIPTION, PREFERENCE_FILE_PATH FROM CRONUS_OWN.USERS   WHERE  USER_ID  = '{0}' AND IS_ACTIVE = 'Y' ", User);
            return query;
        }

        public override ResponseBO UpdateDB(RequestBO requestData)
        {
            ResponseBO retval = new ResponseBO();

            DatabaseHelper dbHelper = this.OracleDbHelper;
            try
            {
                JavaScriptSerializer json = new JavaScriptSerializer();
                json.MaxJsonLength = Int32.MaxValue;
                SettingsBO.ProfileUpdateBO data = json.Deserialize<SettingsBO.ProfileUpdateBO>(requestData.data.ToString());
                if (data == null)
                    throw new Exception("Failed in Json Deserialization");

                dbHelper.BeginTransaction();

                SettingsBO.ProfileUpdateBO userData = json.Deserialize<SettingsBO.ProfileUpdateBO>(requestData.data.ToString());
                if (userData == null)
                    throw new Exception("Failed in Json Deserialization");

                var query = string.Format("UPDATE CRONUS_OWN.USERS SET PREFERENCE_FILE_PATH = '{0}' WHERE Upper(USER_ID) = '{1}' ", userData.ImagePath, User);
                dbHelper.ExecuteNonQuery(query);

                dbHelper.Commit();
            }
            catch (Exception ex)
            {
                retval.errorMessage = string.Format("Exception: {0}", ex.Message);
                log.Error(retval.errorMessage, ex);
                dbHelper.Rollback();
            }

            return retval;
        }
    }
}
