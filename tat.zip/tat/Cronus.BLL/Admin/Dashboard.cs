﻿using System;
using Cronus.BO;
using System.Web.Script.Serialization;
using Cronus.BO.Admin;

namespace Cronus.Bll.Admin
{
    public class Dashboard : CronusBaseBll
    {
        //private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public override object Clone() { return new Dashboard(); }

        public override string ScreenName()
        {
            return Constants.Dashboard;
        }

        protected override string GetTableQuery(TableDataRequestBO requestData, out DatabaseType dbType)
        {
            dbType = DatabaseType.ORACLE;

            var json = new JavaScriptSerializer { MaxJsonLength = int.MaxValue };
            var data = json.Deserialize<DashboardBO.ReportRequestBO>(requestData.data.ToString());
            if (data == null)
                throw new Exception("Failed in Json Deserialization");

            var dateFrom = data.DateFrom;
            var dateTo = data.DateTo;
            var groupId = data.GroupId;
            var screenId = data.ScreenId;

            // Set Default Group to Techops if nothing is passed
            //if (string.IsNullOrEmpty(GroupId))
            //{
            //    GroupId = "Techops";
            //}
            string query;
            switch (requestData.tableName)
            {
                case "AnalyticsScreen":
                    query = "select screen_id , count(*) as count from cronus_own.audit_trail tr ";
                    if (!string.IsNullOrEmpty(groupId))
                        query += " join  CRONUS_OWN.USER_GROUP ug on(ug.user_id = tr.user_id) ";
                    query += " where 1 = 1 ";

                    if (!string.IsNullOrEmpty(groupId))
                        query += " and  Upper(ug.GROUP_ID) = '" + groupId.ToUpper() + "' ";

                    query += " and tr.LAST_CHG_DATE >= " + string.Format("to_date('{0}','mm/dd/yyyy HH:MI:SS am')", dateFrom.Date);
                    query += " and tr.LAST_CHG_DATE <= " + string.Format("to_date('{0}','mm/dd/yyyy HH:MI:SS am')", dateTo);
                    query += " group by screen_id order by  screen_id , count(*) asc";
                    break;
                case "AnalyticsUser":
                    query = "select tr.user_id , count(*) as count from cronus_own.audit_trail tr ";
                    if (!string.IsNullOrEmpty(groupId))
                        query += " join  CRONUS_OWN.USER_GROUP ug on(ug.user_id = tr.user_id) ";
                    query += " where 1 = 1 ";

                    if (!string.IsNullOrEmpty(groupId))
                        query += " and  Upper(ug.GROUP_ID) = '" + groupId.ToUpper() + "' ";

                    if (!string.IsNullOrEmpty(screenId))
                    {
                        if (screenId == "REJECTED CUSIPS")
                            screenId = "RELOAD REJECTED CUSIPS";
                        query += " and  Upper(tr.SCREEN_ID) = '" + screenId.ToUpper() + "' ";
                    }

                    query += " and tr.LAST_CHG_DATE >= " + string.Format("to_date('{0}','mm/dd/yyyy HH:MI:SS am')", dateFrom.Date);
                    query += " and tr.LAST_CHG_DATE <= " + string.Format("to_date('{0}','mm/dd/yyyy HH:MI:SS am')", dateTo);
                    query += " group by tr.user_id order by  tr.user_id , count(*) asc";
                    break;

                case "SkipApproval":
                    query =
                        string.Format(
                            @"select trim(regexp_replace(description,'.*(<b>SkipApproval</b>: \[\w+\]).*','\1',1,1,'n')) as skip_approval, count(*) " +
                            " as SkipApproval from cronus_own.audit_trail tr where rownum < 1000 and SCREEN_ID = 'QUERY BUILDER' and " +
                            " (description like '%<b>SkipApproval</b>: [True]%'  OR description like '%<b>SkipApproval</b>: [False]%') ");

                    query += " and tr.LAST_CHG_DATE >= " + string.Format("to_date('{0}','mm/dd/yyyy HH:MI:SS am')", dateFrom.Date);
                    query += " and tr.LAST_CHG_DATE <= " + string.Format("to_date('{0}','mm/dd/yyyy HH:MI:SS am')", dateTo);
                    query += @" group by  trim(regexp_replace(description,'.*(<b>SkipApproval</b>: \[\w+\]).*','\1',1,1,'n')) ";
                    break;

                case "TopQueries":
                    query = @"select 
                                upper(regexp_substr(query, '\w+')) as db_operation ,  count(*) as cnt
                                from (
                                select regexp_replace(ltrim(description,'<b>Query</b>: '),'\].*','')||']' query
                                from cronus_own.audit_trail where user_id in ( select distinct user_id from cronus_own.user_group ";

                    if (!string.IsNullOrEmpty(groupId))
                        query += "where  Upper(GROUP_ID)  = '" + groupId.ToUpper() + "'";

                    query += @")
                                and screen_id ='QUERY BUILDER'
                                and description like ('%Success%')
                                and description not like ('%SaveJira%')
                                and description not like ('%Creat%JiraItem%')";

                    query += " and LAST_CHG_DATE >= " + string.Format("to_date('{0}','mm/dd/yyyy HH:MI:SS am')", dateFrom.Date);
                    query += " and LAST_CHG_DATE <= " + string.Format("to_date('{0}','mm/dd/yyyy HH:MI:SS am')", dateTo);

                    query += @" )  t
                                group by upper(regexp_substr(query, '\w+'))
                                order by 2 desc ";

                    break;

                case "TopTables":
                    query = @"select 
                        regexp_substr(query,'pm\.(\w\w\w)?\.\w+|\w+_own\.\w+',1,1,'im') as table_name , count(*) as cnt 
                        from (
                        select regexp_replace(ltrim(description,'<b>Query</b>: '),'\].*','')||']' query
                                from cronus_own.audit_trail where user_id in ( select distinct user_id from cronus_own.user_group ";

                    if (!string.IsNullOrEmpty(groupId))
                        query += "where  Upper(GROUP_ID)  = '" + groupId.ToUpper() + "'";

                    query += @")
                                and screen_id ='QUERY BUILDER'
                                and description like ('%Success%')
                                and description not like ('%SaveJira%')
                                and description not like ('%Creat%JiraItem%')";

                    query += " and LAST_CHG_DATE >= " + string.Format("to_date('{0}','mm/dd/yyyy HH:MI:SS am')", dateFrom.Date);
                    query += " and LAST_CHG_DATE <= " + string.Format("to_date('{0}','mm/dd/yyyy HH:MI:SS am')", dateTo);

                    query += @" )  t

                        group by regexp_substr(query,'pm\.(\w\w\w)?\.\w+|\w+_own\.\w+',1,1,'im')
                        order by 2 desc";
                    break;

                default:
                    throw new Exception(string.Format("Unknown RequestType {0}", requestData.tableName));
            }
            return query;
        }

        protected override string GetDropDownDataQuery(string fieldName, DropDownRequestBO requestData, out DatabaseType dbType)
        {
            dbType = DatabaseType.ORACLE;
            var query = "";
            switch (fieldName)
            {
                case "SCREEN":
                    query = "SELECT CASE WHEN SCREEN_ID = 'RELOAD REJECTED CUSIPS' THEN 'REJECTED CUSIPS' ELSE SCREEN_ID END AS SCREEN_ID FROM CRONUS_OWN.SCREEN";
                    break;
                case "GROUP":
                    query = "SELECT GROUP_ID FROM CRONUS_OWN.GROUPS WHERE IS_ACTIVE = 'Y' ORDER BY GROUP_ID";
                    break;
            }
            return query;

        }
    }
}
