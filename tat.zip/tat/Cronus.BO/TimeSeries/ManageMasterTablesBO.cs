﻿using System.Collections.Specialized;
namespace Cronus.BO.TimeSeries
{
    public class ManageMasterTablesBO
    {
        public class SearchRequestBO
        {
            public string TableName;
            public OrderedDictionary ToOrderedDictionary()
            {
                return new OrderedDictionary() { { "TableName", TableName } };
            }

            public override string ToString()
            {
                string str = "";
                OrderedDictionary od = ToOrderedDictionary();
                foreach (var key in od.Keys)
                    str += string.Format("{{0}: {1}} ", key, od[key]);

                return str;
            }
        }
        public class UpdateRequestBO
        {
            public string TableName;
            public string Action;
            public FrequencyData FreqData;
            public GROUPSData GrpData;
            public GROUP_CLASSData ClassData;
            public GROUP_SUBCLASSData SubClassData;
            public DEFINITIONSData DefinitionsData;
            public OrderedDictionary ToOrderedDictionary()
            {
                var od = new OrderedDictionary() { { "TableName", TableName }, { "Action", Action } };
                if (FreqData != null)
                {
                    foreach (var key in FreqData.ToOrderedDictionary().Keys)
                        od.Add(key, FreqData.ToOrderedDictionary()[key]);
                }
                else if (GrpData != null)
                {
                    foreach (var key in GrpData.ToOrderedDictionary().Keys)
                        od.Add(key, GrpData.ToOrderedDictionary()[key]);
                }
                else if (ClassData != null)
                {
                    foreach (var key in ClassData.ToOrderedDictionary().Keys)
                        od.Add(key, ClassData.ToOrderedDictionary()[key]);
                }
                else if (SubClassData != null)
                {
                    foreach (var key in SubClassData.ToOrderedDictionary().Keys)
                        od.Add(key, SubClassData.ToOrderedDictionary()[key]);
                }

                else if (DefinitionsData != null)
                {
                    foreach (var key in DefinitionsData.ToOrderedDictionary().Keys)
                        od.Add(key, DefinitionsData.ToOrderedDictionary()[key]);
                }
                return od;
            }

            public override string ToString()
            {
                string str = "";
                OrderedDictionary od = ToOrderedDictionary();
                foreach (var key in od.Keys)
                    str += string.Format("{{0}: {1}} ", key, od[key]);

                return str;
            }
        }

        public class FrequencyData
        {
            public long ID { get; set; }
            public string DESCRIPTION { get; set; }
            public long LAST_DATE_ADJ { get; set; }
            public string DAY_TO_RUN { get; set; }
            public string COMMENTS { get; set; }
            public OrderedDictionary ToOrderedDictionary()
            {
                return new OrderedDictionary() { { "ID", ID }, { "Description", DESCRIPTION }, { "LastDateAdj", LAST_DATE_ADJ }, { "DayToRun", DAY_TO_RUN }, { "Comment", COMMENTS } };
            }
            public override string ToString()
            {
                string str = "";
                OrderedDictionary od = ToOrderedDictionary();
                foreach (var key in od.Keys)
                    str += string.Format("{{0}: {1}} ", key, od[key]);

                return str;
            }

        }

        public class GROUPSData
        {
            public long ID { get; set; }
            public long CLASS_ID { get; set; }
            public long SUBCLASS_ID { get; set; }
            public string QC { get; set; }
            public string QC_SWITCH { get; set; }
            public string STALE_SWITCH { get; set; }
            public string QC_HIST { get; set; }
            public OrderedDictionary ToOrderedDictionary()
            {
                return new OrderedDictionary() { { "ID", ID }, { "ClassID", CLASS_ID }, { "SubClassID", SUBCLASS_ID }, { "QC", QC.Replace("<","&lt").Replace(">", "&gt") }
                                               , { "QCSwitch", QC_SWITCH }, { "StaleSwitch", STALE_SWITCH }, { "QCHist", QC_HIST.Replace("<","&lt").Replace(">", "&gt") } };
            }
            public override string ToString()
            {
                string str = "";
                OrderedDictionary od = ToOrderedDictionary();
                foreach (var key in od.Keys)
                    str += string.Format("{{0}: {1}} ", key, od[key]);

                return str;
            }

        }

        public class GROUP_CLASSData
        {
            public long ID { get; set; }
            public string CLASS { get; set; }
            public OrderedDictionary ToOrderedDictionary()
            {
                return new OrderedDictionary() { { "ID", ID }, { "Class", CLASS } };
            }
            public override string ToString()
            {
                string str = "";
                OrderedDictionary od = ToOrderedDictionary();
                foreach (var key in od.Keys)
                    str += string.Format("{{0}: {1}} ", key, od[key]);

                return str;
            }

        }

        public class GROUP_SUBCLASSData
        {
            public long ID { get; set; }
            public string SUBCLASS { get; set; }
            public long PRIORITY { get; set; }
            public OrderedDictionary ToOrderedDictionary()
            {
                return new OrderedDictionary() { { "ID", ID }, { "SubClass", SUBCLASS }, { "Priority", PRIORITY } };
            }
            public override string ToString()
            {
                string str = "";
                OrderedDictionary od = ToOrderedDictionary();
                foreach (var key in od.Keys)
                    str += string.Format("{{0}: {1}} ", key, od[key]);

                return str;
            }
        }

        public class DEFINITIONSData
        {
            public long ID { get; set; }
            public long GROUP_ID { get; set; }
            public long SID { get; set; }
            public string DESCRIPTION { get; set; }
            public long FREQUENCY_ID { get; set; }
            public string PARENT_ID { get; set; }
            public string STRKEY1 { get; set; }
            public string STRKEY2 { get; set; }
            public string STRKEY3 { get; set; }
            public string STRKEY4 { get; set; }
            public string STRKEY5 { get; set; }
            public string NUMKEY1 { get; set; }
            public string NUMKEY2 { get; set; }
            public string NUMKEY3 { get; set; }
            public string NUMKEY4 { get; set; }
            public string NUMKEY5 { get; set; }
            public bool P_NUMKEY1 { get; set; }
            public bool P_NUMKEY2 { get; set; }
            public bool P_NUMKEY3 { get; set; }
            public bool P_NUMKEY4 { get; set; }
            public bool P_NUMKEY5 { get; set; }

            public OrderedDictionary ToOrderedDictionary()
            {
                return new OrderedDictionary() { { "ID", ID }, { "GROUP_ID", GROUP_ID }, { "SID", SID }, { "DESCRIPTION", DESCRIPTION }, { "FREQUENCY_ID", FREQUENCY_ID }, { "PARENT_ID", PARENT_ID }, 
                    { "STRKEY1", STRKEY1 }, { "STRKEY2", STRKEY2 }, { "STRKEY3", STRKEY3 }, { "STRKEY4", STRKEY4 }, { "STRKEY5", STRKEY5 },
                    { "NUMKEY1", NUMKEY1 }, { "NUMKEY2", NUMKEY2 }, { "NUMKEY3", NUMKEY3 }, { "NUMKEY4", NUMKEY4 }, { "NUMKEY5", NUMKEY5 },
                    { "P_NUMKEY1", P_NUMKEY1 }, { "P_NUMKEY2", P_NUMKEY2 }, { "P_NUMKEY3", P_NUMKEY3 }, { "P_NUMKEY4", P_NUMKEY4 }, { "P_NUMKEY5", P_NUMKEY5 } };
            }
            public override string ToString()
            {
                var str = "";
                var od = ToOrderedDictionary();
                foreach (var key in od.Keys)
                    str += string.Format("{{0}: {1}} ", key, od[key]);

                return str;
            }
        }
    }
}
