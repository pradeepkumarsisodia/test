﻿using System.Collections.Generic;
using System.Collections.Specialized;
namespace Cronus.BO.TimeSeries
{
    public class BackFillingBO
    {
        public class FileDataBO
        {
            public string Tab { get; set; }
            public List<string> Columns;
            public List<List<string>> DefinitionDataList;
            public string FileName;
            public string GroupIds;
            public string DefIds;
            public string FromDate;
            public string ToDate;


            public OrderedDictionary ToOrderedDictionary()
            {
                return new OrderedDictionary() { { "fileName", FileName } };
            }
            public override string ToString()
            {
                string str = "";
                OrderedDictionary od = ToOrderedDictionary();
                foreach (var key in od.Keys)
                    str += string.Format("{0}: {1} ", key, od[key]);

                return str;
            }

        }

    }
}
