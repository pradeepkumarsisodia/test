﻿using System.Collections.Generic;

namespace Cronus.BO.TimeSeries
{
    public class TSDefinitionsBO
    {
        public class DefinitionDataBO
        {
            public string DESCRIPTION { get; set; }
            public string FREQUENCY_ID { get; set; }
            public string GROUP_ID { get; set; }
            public string NUMKEY1 { get; set; }
            public string NUMKEY2 { get; set; }
            public string NUMKEY3 { get; set; }
            public string NUMKEY4 { get; set; }
            public string NUMKEY5 { get; set; }
            public string PARENT_ID { get; set; }
            public string PREFIX { get; set; }
            public string SID { get; set; }
            public string STRKEY1 { get; set; }
            public string STRKEY2 { get; set; }
            public string STRKEY3 { get; set; }
            public string STRKEY4 { get; set; }
            public string STRKEY5 { get; set; }
            public string SUFFIX { get; set; }
            public override string ToString()
            {
                return string.Format("GROUP_ID: {0}, FREQUENCY_ID: {1}, SID: {2}, PREFIX: {3}, PARENT_ID: {4}, DESCRIPTION: {5}, STRKEY1: {6}, STRKEY2: {7}, STRKEY3: {8}, STRKEY4: {9}, STRKEY5: {10}, NUMKEY1: {10}, NUMKEY2: {11}, NUMKEY3: {12}, NUMKEY4: {13}, NUMKEY5: {14}, SUFFIX: {15}"
                    , GROUP_ID, FREQUENCY_ID, SID, PARENT_ID, DESCRIPTION
                    , STRKEY1, STRKEY2, STRKEY3, STRKEY4, STRKEY5
                    , NUMKEY1, NUMKEY2, NUMKEY3, NUMKEY4, NUMKEY5, SUFFIX);
            }
        }

        public class SubmitRequestBO
        {
            public List<DefinitionDataBO> definitionDataList;
            public Dictionary<string, bool> numKeyChecked;
        }
    }


}
