﻿using System.Collections.Generic;
using System.Web.Script.Serialization;

namespace Cronus.BO
{

    #region Custom BO Classes
    public class ACTION_BO
    {
        public string SCREEN_ID { get; set; }
        public string ACTION_NAME { get; set; }
        public long ACTION_ID { get; set; }
        public string DESCRIPTION { get; set; }
        public bool IS_PERMITTED { get; set; }
    }

    public class ActionPermittedResponseBO : ResponseBO
    {
        public List<ACTION_BO> actionPermittedList;
    }

    public class UserInformation
    {
        public string CronusUserName { get; set; }
        public string CronusUserEmail { get; set; }
    }

    public class AUDIT_TRAIL_BO_Export
    {
        public string USER_ID { get; set; }
        public string SCREEN_ID { get; set; }
        public string DESCRIPTION { get; set; }
        public string LAST_CHG_DATE { get; set; }
    }

    public class RELOAD_REJECTED_CUSIP_BO_Export
    {
        public string PRICE_DATE { get; set; }
        public string CUSIP { get; set; }
        public string CONTEXT { get; set; }
        public string REGION_CODE { get; set; }
        public string REJECTION_RULE { get; set; }
    }


    #endregion


    public class RequestBOSerializer
    {
        public RequestBOSerializer()
        {

        }
        public string Serialize(RequestBO request)
        {
            var d = new Dictionary<string, object>
            {
                {"screenName", request.screenName},
                {"data", request.data.ToString()}
            };

            var s = new JavaScriptSerializer().Serialize(d);

            return s;
        }
        public RequestBO Deserialize<T>(string s) where T : new()
        {
            var json = new JavaScriptSerializer();
            var d = json.Deserialize<Dictionary<string, object>>(s);
            if (d["data"] != null)
            {
                d["data"] = json.Deserialize<T>(d["data"].ToString());
            }
            return new RequestBO()
            {
                screenName = d["screenName"].ToString(),
                data = d["data"]
            };
        }
    }

    public class RequestBO
    {
        public string screenName { get; set; }
        public object data { get; set; }
        public string runEnviroment { get; set; }

        public override string ToString()
        {
            return string.Format("ScreenName: {0}, Data: {{2}}", screenName, data);
        }
    }

    public class SubscriptionRequest
    {
        public string ScreenName { get; set; }
        public Dictionary<string, object> Params { get; set; }
    }

    public class CustomFunctionBO : RequestBO
    {
        public string functionName { get; set; }

        public override string ToString()
        {
            return string.Format("ScreenName: {0}, FunctionName [{2}], Data: {{2}}", screenName, functionName, data);
        }
    }

    public class FeServerRequest
    {
        public string ClientId { get; set; }
        public string ScreenName { get; set; }
        public string Task { get; set; }
        public Dictionary<string, object> Params { get; set; }

        public override string ToString()
        {
            return string.Format("ScreenName: {0}, Data: {1}, Params: {2}", ScreenName, Task, Params);
        }
    }

    public class NotificationRequest
    {
        public string RequestId { get; set; }
        public string ScreenName { get; set; }
        public string RedirectionUrl { get; set; }
        public bool Register { get; set; }
    }

    public class NotificationRegistrationRequest
    {
        public string ScreenName { get; set; }
        public List<string> RequestIds { get; set; }
    }


    public class ActionResponse 
    {
        //WebServer Error if any. null or empty implies no error.
        public string Error { get; set; }

        //Id assigned to the submitted action
        public string Id { get; set; }
    }
    public class QueryResponse
    {
        //WebServer Error if any. null or empty implies no error.
        public string Error { get; set; }

        //FeServer response of the query, which might contain error.
        public Dictionary<string, object> Response { get; set; }
    }

    public class ResultMessageBO : RequestBO
    {
        public string requestId { get; set; }
    }

    public class ResultResponseBO : ResponseBO
    {
        public string result { get; set; }
    }

    public class ResponseBO
    {
        public string errorMessage { get; set; }
    }

    public class RequestIdResponseBO : ResponseBO
    {
        public string requestId;
    }

    public class DataValueBo
    {
        public string data { get; set; }
        public string value { get; set; }
    }

    public class DropDownRequestBO : RequestBO
    {
        public string fieldName { get; set; }
    }

    public class DropDownResponseBo : ResponseBO
    {
        public List<DataValueBo> dropDownData { get; set; }
    }

    public class TableDataResponseBO : ResponseBO
    {
        public string tableName { get; set; }
        public List<string> columns { get; set; }
        public List<List<object>> rows { get; set; }
    }

    public class TableDataRequestBO : RequestBO
    {
        public string tableName { get; set; }
    }

    public class CycleDateAndPreviousDateBo : ResponseBO
    {
        public string CycleDate { get; set; }
        public string PreviousDate { get; set; }
    }

}
