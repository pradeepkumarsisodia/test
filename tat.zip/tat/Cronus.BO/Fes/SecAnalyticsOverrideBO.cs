﻿using System;


namespace Cronus.BO.Fes
{
    public class SecAnalyticsOverrideBO
    {
        public class AddUpdateRequestBO
        {
            public string action;
            public string ssm_id;
            public string analytic_id;
            public string value;
            public string old_value;
            public string backUp_Metric;
            public string note;
            public DateTime price_date;
            public override string ToString()
            {
                return string.Format("ssmid: {0}, analyticid: {1}", ssm_id, analytic_id);
            }
           
        }
        public class AddUpdateResponseBO : ResponseBO
        {
            public string message { get; set; }
        }
     
    }
}
