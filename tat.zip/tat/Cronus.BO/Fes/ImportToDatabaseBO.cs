﻿using System.Collections.Generic;

namespace Cronus.BO.Fes
{
    public class ImportToDatabaseBO
    {
        public class AddUpdateRequestBO
        {
            public List<List<object>> rows;
            public List<string> headers;            
            public string table;
            public string database;
            public bool ProcceedAnyway { get; set; }
            //public override string tostring()
            //{
            //    return string.format("table: {0}, database: {1}", table, database);
            //}

        }
        public class AddUpdateResponseBO : ResponseBO
        {
            public string message { get; set; }
        }

        public class TableDataResponseBO : ResponseBO
        {
            public string tableName { get; set; }
            public List<string> columns { get; set; }
            public List<List<object>> dupRows { get; set; }
            public List<List<object>> uniqRows { get; set; }
        }
     
    }
}
