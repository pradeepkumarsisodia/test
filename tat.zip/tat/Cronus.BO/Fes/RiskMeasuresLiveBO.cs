﻿using System;

namespace Cronus.Bo.Fes
{
    public class RiskMeasuresLiveBO
    {
        public class RunRequestBO
        {
            public string cusip;
            public string price;
            public DateTime priceDate;

            public bool isPostProcess;
            public bool isLoad;

            public override string ToString()
            {
                return string.Format("Cusip: {0}, Price: {1}, PriceDate: {2}, PostProcessFlag: {3}, LoadFlag: {4}", cusip, price, priceDate, isPostProcess, isLoad);
            }
        }

    }
}
