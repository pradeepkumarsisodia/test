﻿using System;

namespace Cronus.BO.Fes
{
    public class OttiRunBO
    {
        public class AddUpdateRequestBO
        {
            public string file_Path;
            public DateTime price_date;
           
            public override string ToString()
            {
                return string.Format("priceDate: {0}, filePath: {1}", price_date, file_Path);
            }

        }
        public class AddUpdateResponseBO : ResponseBO
        {
            public string message { get; set; }
        }
     
    }
}
