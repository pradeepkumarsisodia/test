﻿namespace Cronus.BO.Fes
{
    public class SubstituteCusipsBO
    {
        public class SeaarchRequestBO
        {
            public string cusips { get; set; }
        }

        public class saveRequestBO
        {
            public string oldCusip { get; set; }
            public string newCusip { get; set; }
            public string note { get; set; }
            public string mailRecipients { get; set; }
            public override string ToString()
            {
                return string.Format("OldCusip: {0}, NewCusip: {1}, Note: {2}, MailRecipients: {3}",oldCusip, newCusip, note, mailRecipients);
            }
        }
        public class saveResponseBO : ResponseBO
        {
            public string message;
        }
    }

}
