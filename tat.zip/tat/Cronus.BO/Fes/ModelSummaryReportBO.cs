﻿using System;
using System.Collections.Generic;

namespace Cronus.Bo.Fes
{
    public class ModelSummaryReportBO
    {
        public class InvocationSubscribeBO
        {
            public string InvocationId { get; set; }
            public string IsSubscribe { get; set; }
            public override string ToString()
            {
                return string.Format("invocationId: {0}, IsSubscribe: {1}", InvocationId, IsSubscribe);
            }
        }

        public class SubmitRequestBO
        {
            public List<InvocationSubscribeBO> SubscriptionList;           
        }



        public class RunRequestBO
        {
            public string InvocationId;
            public DateTime PriceDate;
            public bool IsSubscribe;
            public string ClientId;

            public override string ToString()
            {
                return string.Format("InvocationId: {0}, Price: {1}, IsSubscribe: {2}", InvocationId, PriceDate,IsSubscribe);
            }
        }

    }
}
