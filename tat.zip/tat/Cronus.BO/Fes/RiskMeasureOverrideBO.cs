﻿using System.Collections.Generic;

namespace Cronus.BO.Fes
{
    public class RiskMeasureOverrideBO
    {
        public class SearchRequestBO
        {
            public string tab { get; set; }
            public string ssmId;
        }
        public class SubmitRequestBO
        {
            public string tab { get; set; }
            //ACTION: D = Delete, U = Update or Insert
            public string action { get; set; }
            //ScenarioRiskMeasureBO, BaseRiskMeasureBO, TradersRiskMeasureBO based on tab
            public List<BaseRiskMeasureBO> baseRiskMeasureObj;
            public List<ScenarioRiskMeasureBO> scenarioRiskMeasureObj;
            public List<TradersRiskMeasureBO> tradersRiskMeasureObj;
        }
        public class ScenarioRiskMeasureBO
        {
            public string PRICE_DATE { get; set; }
            public string CUSIP { get; set; }
            public string NOTES { get; set; }
            public string PRICE { get; set; }
            public string CONVEXITY { get; set; }
            public string DURATION { get; set; }
            public string DELTA { get; set; }
            public string OAS { get; set; }
            public string YTM { get; set; }
            public string YTW { get; set; }
            public string CURVE_TYPE { get; set; }
            public string PROVIDER_ID { get; set; }
            public string BACKUP_MATRIC { get; set; }
            public string OAS_IS_INPUT { get; set; }
        }

        public class BaseRiskMeasureBO
        {
            public string SSM_ID { get; set; }
            public string DURATION { get; set; }
            public string DELTA { get; set; }
            public string BACKUP_MATRIC { get; set; }
            public string NOTES { get; set; }
        }

        public class TradersRiskMeasureBO
        {
            public string SSM_ID { get; set; }
            public string ISIN { get; set; }
            public string DURATION { get; set; }
            public string OAS { get; set; }
            public string SPREAD_DURATION { get; set; }
            public string PRICE { get; set; }
            public string IS_MORTGAGE_SECURITY { get; set; }
            public string HARD_DURATION { get; set; }
        }
    }
}
