﻿using System.Collections.Generic;

namespace Cronus.BO.Fes
{
    public class RejectedCusipsBO
    {
        public class SearchRequestBO
        {
            public string tab;
            public string cusip;
            public string context;
            public string priceDate;
            public bool reloadFlag;
            public override string ToString()
            {
                return string.Format("Cusip: {0}, Context: {1}, PriceDate: {2}, ReploadFlag: {3}", cusip, context, priceDate, reloadFlag);
            }
        }

        public class CusipContextBO
        {
            public string cusip;
            public string context;
            public string[] analyticIds;
            public bool reloadFlag;
        }
        public class NotifyRequestBO
        {
            public List<CusipContextBO> cusipContextData;
            public string priceDate;
            public bool reloadFlag;
        }
        public class NotifyResponseBO : ResponseBO
        {
            public string message;
        }
    }
}
