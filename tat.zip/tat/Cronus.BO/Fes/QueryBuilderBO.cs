﻿using System;
using System.Collections.Generic;

namespace Cronus.BO.Fes
{
    public class QueryBuilderBO
    {
        public class QueryResultResponseBO : ResponseBO
        {
            public bool ActiveTransaction;
            public string Summary;
            public List<TableDataResponseBO> SelectDataCollection;
            public string MessageType;
        }

        public class QueryRequestBO
        {
            public string Environment { get; set; }
            public string JIRANo { get; set; }
            public string JIRALink { get; set; }
            public string JIRAStatus { get; set; }
            public string JIRABetaExecutionDone { get; set; }
            public string JIRASummary { get; set; }
            public string RequestType { get; set; }
            public string GroupResponsibility { get; set; }
            public string TeamResponsibility { get; set; }
            public string Approver { get; set; }
            public bool IsBetaExecution { get; set; }
            public bool SkipBetaExecutionY { get; set; }
            public bool SkipBetaExecutionN { get; set; }
            public string SkipBetaExecutionReason { get; set; }
            public bool SkipApprovalY { get; set; }
            public bool SkipApprovalN { get; set; }
            public string SkipApprovalReason { get; set; }
            public string DATABASE { get; set; }
            public string Category { get; set; }
            public string QueryName { get; set; }
            public string Query { get; set; }
            public long ExpectedRows { get; set; }
            public bool? SkipBetaExecution { get; set; }
            public bool? SkipApproval { get; set; }
            public string DBType { get; set; }
            public string TabId { get; set; }
            public long UniqId { get; set; }
            public bool IsTransactionMode { get; set; }
            public string UserId { get; set; }
            public string Pwd { get; set; }
            /* public override string ToString()
             {
                 return string.Format("DBName: {0}, TabId: {1}, UniqId: {2} Query: {3} Approver: {4}", DBName, TabId, UniqId, Query, Approver);
             }*/
        }

        public class SaveQueryRequestBO
        {
            public string Name;
            public string TabId;
            public string DBName;
            public string Query;
            public string User;
            public string Category { get; set; }
            public override string ToString()
            {
                return string.Format("DBName: {0}, TabId: {1}, Name: {2} Query: {3},User: {4}", DBName, TabId, Name, Query, User);
            }
        }

        public class PendingTransactionBO
        {
            public string Url;
            public string TabId;
            public string DBName;
            public string User;
            public string DBUserId;
            public string DBPswd;
            public string ScreenName;
            public string Environment;
            public string Email;
            public long UniqId;
            public DateTime QueryStartTime;
            public DateTime NextMailTime;
            public List<string> ExecutedQueries;
            public List<long> ExecutedAuditIds;
        }

        public class QueryResponseBO : ResponseBO
        {
            public string Environment { get; set; }
            public string JIRANo { get; set; }
            public string JIRALink { get; set; }
            public string JIRAStatus { get; set; }
            public string JIRABetaExecutionDone { get; set; }
            public string JIRASummary { get; set; }
            public string RequestType { get; set; }
            public string GroupResponsibility { get; set; }
            public string TeamResponsibility { get; set; }
            public string Approver { get; set; }
            public bool IsBetaExecution { get; set; }
            public bool SkipBetaExecutionY { get; set; }
            public bool SkipBetaExecutionN { get; set; }
            public string SkipBetaExecutionReason { get; set; }
            public bool SkipApprovalY { get; set; }
            public bool SkipApprovalN { get; set; }
            public string SkipApprovalReason { get; set; }
            public string DATABASE { get; set; }
            public string Category { get; set; }
            public string QueryName { get; set; }
            public string Query { get; set; }
            public long ExpectedRows { get; set; }
            public bool? SkipBetaExecution { get; set; }
            public bool? SkipApproval { get; set; }
            public string DBType { get; set; }
            public string TabId { get; set; }
            public long UniqId { get; set; }
        }
    }
}
