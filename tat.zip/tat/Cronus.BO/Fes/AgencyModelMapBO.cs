﻿namespace Cronus.BO.Fes
{
    public class AgencyModelMapBO
    {
        public class SearchRequestBO
        {
            public string ssmId { get; set; }
            public override string ToString()
            {
                return string.Format("SSM_ID: {0}", ssmId);
            }
        }
        public class AddUpdateRequestBO
        {
            public string ssmId { get; set; }
            public string cusip { get; set; }
            public override string ToString()
            {
                return string.Format("SSM_ID: {0}, Cusip: {1}", ssmId, cusip);
            }
        }
        public class AddUpdateResponseBO : ResponseBO
        {
            public string message { get; set; }
        }
    }
}
