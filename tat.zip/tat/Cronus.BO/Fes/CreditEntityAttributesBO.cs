﻿namespace Cronus.BO.Fes
{
    public class CreditEntityAttributesBO
    {
        public class SearchRequestBO
        {
            public string creditEntityId;
            public string reprCdsIssuerId;
            public string reprCdIsDeliverable;
            public string reprBondRecoveryRate;
            public string bloomCorpTicker;
            public string reprTicker;
            public string reprIssuerId;
            public string ssmId;
            public string ultParentIssuerId;
            public string requestType;

            public override string ToString()
            {
                return string.Format("CreditEndityId: {0}, ReprCdsIssuerId: {1}, ReprCdIsDeliverable: {2}, ReprBondRecoveryRate: {3}, BloomCorpTicker: {4}, ReprTicker: {5}, reprIssuerId: {6}, SsmId: {7}, UltParentIssuerId: {8}, requestType: {9}"
                    , creditEntityId, reprCdsIssuerId, reprCdIsDeliverable, reprBondRecoveryRate, bloomCorpTicker, reprTicker, reprIssuerId, ssmId, ultParentIssuerId, requestType);
            }
        }
        public class SearchResponseBO : ResponseBO
        {
        }

        public class UpdateRequestBO
        {
            public string creditEntityId;
            public string reprCdsIssuerId;
            public string reprCdIsDeliverable;
            public string reprBondRecoveryRate;
            public string primaryCurrency;
            public string countryOfExposure;
            public string isActive;
            public override string ToString()
            {
                return string.Format("CreditEndityId: {0}, ReprCdsIssuerId: {1}, ReprCdIsDeliverable: {2}, ReprBondRecoveryRate: {3}, PrimaryCurrency: {4}, CountryOfExposure: {5}"
                    , creditEntityId, reprCdsIssuerId, reprCdIsDeliverable, reprBondRecoveryRate, primaryCurrency, countryOfExposure);
            }
        }
        public class UpdateResponseBO : ResponseBO
        {
        }
    }
}
