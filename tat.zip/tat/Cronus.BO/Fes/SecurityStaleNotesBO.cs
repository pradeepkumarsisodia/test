﻿using System;
using System.Collections.Specialized;
namespace Cronus.BO.Fes
{
    public class SecurityStaleNotesBO
    {
        public class SearchRequestBO
        {
            public string TableName;
            public OrderedDictionary ToOrderedDictionary()
            {
                return new OrderedDictionary() { { "TableName", TableName } };
            }

            public override string ToString()
            {
                string str = "";
                OrderedDictionary od = ToOrderedDictionary();
                foreach (var key in od.Keys)
                    str += string.Format("{{0}: {1}} ", key, od[key]);

                return str;
            }
        }

        public class UpdateRequestBO
        {
            public string TableName;
            public string Action;
            public SEC_NOTESData SecNotesData;
            public OrderedDictionary ToOrderedDictionary()
            {
                var od = new OrderedDictionary() { { "TableName", TableName }, { "Action", Action } };

                if (SecNotesData != null)
                {
                    foreach (var key in SecNotesData.ToOrderedDictionary().Keys)
                        od.Add(key, SecNotesData.ToOrderedDictionary()[key]);
                }

                return od;
            }

            public override string ToString()
            {
                string str = "";
                OrderedDictionary od = ToOrderedDictionary();
                foreach (var key in od.Keys)
                    str += string.Format("{{0}: {1}} ", key, od[key]);

                return str;
            }
        }

        public class SEC_NOTESData
        {
            public string SSMId { get; set; }
            public int AppUserId { get; set; }
            public string Code1 { get; set; }
            public string Code2 { get; set; }
            public string Code3 { get; set; }
            public string Risk1 { get; set; }
            public string Risk2 { get; set; }
            public string RefTag { get; set; }
            public string IntexProblems { get; set; }
            public string BBProblems { get; set; }
            public string AltSw { get; set; }
            public string Notes { get; set; }
            public string ExpirationDate { get; set; }
            public OrderedDictionary ToOrderedDictionary()
            {
                return new OrderedDictionary() { { "SSMId", SSMId }, { "AppUserId", AppUserId }, { "Code1", Code1 }, { "Code2", Code2 }, 
                { "Code3", Code3 } , {"Risk1", Risk1} , {"Risk2", Risk2} , {"RegTag", RefTag}, {"IntexProblems",IntexProblems} , {"BBProblems", BBProblems},
                {"AltSw",AltSw} , {"Notes",Notes} , {"ExpirationDate", ExpirationDate}};
            }
            public override string ToString()
            {
                string str = "";
                OrderedDictionary od = ToOrderedDictionary();
                foreach (var key in od.Keys)
                    str += string.Format("{{0}: {1}} ", key, od[key]);

                return str;
            }

        }

    }
}
