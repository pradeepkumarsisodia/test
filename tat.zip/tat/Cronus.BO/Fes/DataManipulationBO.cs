﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Cronus.BO;

namespace Cronus.Bo.Fes
{
    public class DataManipulationBO
    {
        public class LoginRequestBO
        {
            public string dbName { get; set; }
            public string userId { get; set; }
            public string password { get; set; }
        }

        public class LoginResponseBO: ResponseBO
        {
            public bool status { get; set; }
        }

        public class SearchRequestBO
        {
            public LoginRequestBO loginData { get; set; }
            public string tableName { get; set; }
            public string whereClause { get; set; }
        }

        public class SearchResponseBO : ResponseBO
        {
            public TableDataResponseBO data { get; set; }
        }

        public class SubmitRequestBO
        {
            public LoginRequestBO loginData { get; set; }
            public string tableName { get; set; }
            public TableDataResponseBO beforeUpdateData { get; set; }
            public TableDataResponseBO afterUpdateData { get; set; }
            public TableDataResponseBO insertData { get; set; }
            public TableDataResponseBO deleteData { get; set; }
        }

        public class SubmitResponseBO : ResponseBO
        {
            public string message { get; set; }
        }
    }
}