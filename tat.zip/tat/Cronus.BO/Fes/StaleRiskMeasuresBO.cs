﻿using System.Collections.Generic;
using Cronus.BO;

namespace Cronus.Bo.Fes
{
    public class StaleRiskMeasuresBO
    {
        public class Constants
        {

            public const string UpdateRelatedColumns = "UPDATE_RELATED_COLUMNS";
            public const string MainTable = "MAIN_TABLE";
            public const string HistTable = "HIST_TABLE";
            public const string SsmIdCol = "SSM_ID_COL";
            public const string StaleDateCol = "stale_date";
            public const string PriceDateCol = "PRICE_DATE_COL";
            public const string UniqueKeyCol = "UNIQUE_KEY_COL";
            public const string NoUpdateCol = "NO_UPDATE_COL";
            public const string StaleDate = "StaleDate";
            public const string Database = "DATABASE";
            public const string Dbserver = "DBSERVER";
            public const string HistDbserver = "HIST_DBSERVERERVER";
            public const string UpdateRelatedTables = "UPDATE_RELATED_TABLES";
            public const string Oracle = "ORACLE";
            public const string Sybase = "SYBASE";
        }

        //This will have all the infor of table like tableName(alias),
        //current data, historical data, columns That needs to update, Column that need not to be update 
        public class TableDataBO
        {
            public string TableAlias;
            public TableDataResponseBO Data;
            public List<string> CusipList;
            public List<string> UpdatableColumnsList;
            public List<string> DisplayColumnsList;
        }

        //BO for search action
        public class SearchRequestBO
        {
            public List<string> CusipList;
            public string CusipTable;
            public string StaleDate;
            public List<string> SelectedTableList;
            public List<string> SelectedRiskMeasuresList;
        }

        //BO for Response of search action
        public class SearchResponseBO : ResponseBO
        {
            public string InfoMessage;
            public string WarningMessage;
            public List<string> CusipList;
            public string StaleDate;
            public List<TableDataBO> TablesDataList;
        }

        //BO for Submit action
        public class SubmitRequestBO
        {
            public List<string> CusipList;
            public string StaleDate;
            public Dictionary<string, List<string>> tablesColumnsDict;

        }

        //BO for Response of submit action
        public class SubmitResponseBO : ResponseBO
        {
            public string InfoMessage;
            public string WarningMessage;
        }
    }
}

