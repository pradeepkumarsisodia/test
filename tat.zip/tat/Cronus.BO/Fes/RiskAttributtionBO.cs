﻿namespace Cronus.BO.Fes
{
    public class RiskAttributtionBO
    {
        public class SearchRequestBO
        {
            public string SsmId;
            public string AccountNumber;
            public string PriceDate;
            public string PreviousPriceDate;
            public string RunId;
            public string PreviousRunId;
            public string RiskMeasure;
            public string Days;           

            public override string ToString()
            {
                return string.Format("SsmId: {0}, AccountNumber: {1}, PriceDate: {2}, PreviousPriceDate: {3}, RunId: {4}, PreviousRunId: {5}, RiskMeasure: {6}, Days: {7}"
                    , SsmId, AccountNumber, PriceDate, PreviousPriceDate, RunId, PreviousRunId, RiskMeasure, Days);
            }
        }
        public class SearchResponseBO : ResponseBO
        {
            public TableDataResponseBO data1;
            public TableDataResponseBO data2;
            public TableDataResponseBO data3;
        }

        public class UpdateRequestBO
        {
            public string creditEntityId;
            public string reprCdsIssuerId;
            public string reprCdIsDeliverable;
            public string reprBondRecoveryRate;
            public string primaryCurrency;
            public string countryOfExposure;
            public string isActive;
            public override string ToString()
            {
                return string.Format("CreditEndityId: {0}, ReprCdsIssuerId: {1}, ReprCdIsDeliverable: {2}, ReprBondRecoveryRate: {3}, PrimaryCurrency: {4}, CountryOfExposure: {5}"
                    , creditEntityId, reprCdsIssuerId, reprCdIsDeliverable, reprBondRecoveryRate, primaryCurrency, countryOfExposure);
            }
        }
        public class UpdateResponseBO : ResponseBO
        {
        }
    }
}
