﻿using System;

namespace Cronus.BO.Admin
{
    public class ReportingBO
    {
        public class ReportRequestBO
        {
            public DateTime dateFrom;
            public DateTime dateTo;
            public string description;
            public string userId;
            public string groupId;
            public string screenId;
        }
    }
}
