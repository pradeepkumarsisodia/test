﻿using System;

namespace Cronus.BO.Admin
{
    public class DashboardBO
    {
        public class ReportRequestBO
        {
            public DateTime DateFrom;
            public DateTime DateTo;                        
            public string GroupId;
            public string ScreenId;
        }
    }
}
