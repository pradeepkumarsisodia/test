﻿namespace Cronus.BO.Admin
{
    public class SettingsBO
    {

        public class UserID
        {
            public string userId;
        }

        public class ProfileUpdateBO
        {
            public string ImagePath;
        }
    }
}
