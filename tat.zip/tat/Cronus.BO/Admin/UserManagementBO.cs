﻿using System.Collections.Generic;

namespace Cronus.BO.Admin
{
    public class UserManagementBO
    {
        public class SearchRequestBO
        {
            public string UserId { get; set; }
            public override string ToString()
            {
                return string.Format("User ID: {0}", UserId);
            }
        }

        public class SearchBO
        {
            public string tab;
            public string groupId;
        }

        public class UpdateBO
        {
            public string tab;
            public string action;
        }
        public class UserUpdateBO : UpdateBO
        {
            public string UserId;
            public string UserName;
            public string Email;
            public List<UserDetails> UserDetailList;
        }
        public class UserDetails
        {
            public string UserId;
            public string UserName;
            public string Email;
        }
        public class GroupUpdateBO : UpdateBO
        {
            public string groupId;
            public string description;
        }
        public class UsersGroupUpdateBO : UpdateBO
        {
            public string groupId;
            public List<string> userIds;
            public List<string> deletedUserIds;
        }
        public class PermissionUpdateBO : UpdateBO
        {
            public string groupId;
            public List<long> actionIds;
           public List<string> deleteActionlist;
           public List<string> insertActionlist;
        }
        public class AddUpdateResponseBO : ResponseBO
        {
            public string message { get; set; }
        }

    }
}
