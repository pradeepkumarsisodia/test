﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cronus.Bo.Admin
{
   public class EntitlementBO
    {
        public User user { get; set; }
        public List<Role> roles { get; set; }
        public string appName { get; set; }
    }
   public class User
   {
       public int id { get; set; }
       public string loginId { get; set; }
       public List<Role> roles { get; set; }
   }
   public class Role
   {
       public int id { get; set; }
       public string name { get; set; }
       public List<Permission> permissions { get; set; }
   }
   public class Permission
   {
       public int permissionId { get; set; }
       public string permissionName { get; set; }
       public int permissionTypeId { get; set; }
       public string permissionType { get; set; }
       public string permissionInd { get; set; }
   }
}
