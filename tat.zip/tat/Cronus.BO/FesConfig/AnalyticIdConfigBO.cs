﻿using System.Collections.Generic;
using Cronus.BO;

namespace Cronus.Bo.FesConfig
{
    public class AnalyticIdConfigBO
    {
        public class SearchRequestBO
        {
            public string value { get; set; }
            public override string ToString()
            {
                return string.Format("InputValue: {0}", value);
            }
        }

        public class ConfigInputData
        {
            public string analyticId { get; set; }
            public string previousAnayticId { get; set; }
            public string modelFieldName { get; set; }
            public string dataType { get; set; }
            public List<string> lableList { get; set; }
            public string providerId { get; set; }
            public string curveType { get; set; }
            public string curveId { get; set; }
            public string product { get; set; }
            public string modelOutputType { get; set; }
            public string scenarioConfigFile { get; set; }
            public string sensitivityConfigFile { get; set; }
            public string description { get; set; }
            public string callType { get; set; }

            public List<RiskMeasuresToApp> riskMeasuresToAppList { get; set; }
            public List<RiskMeasuresToInvocation> riskMeasuresToInvocationList { get; set; }
            public override string ToString()
            {
                return string.Format("Analytic Id: {0}", analyticId);
            }
        }

        public class RiskMeasuresToApp
        {
            public string analyticIdToStage { get; set; }
            public string mainTable { get; set; }
            public string appField { get; set; }
            public string dataType { get; set; }
            public string liveTable { get; set; }
            public double modelSrmDiffThreshold { get; set; }
            public bool isApplicable { get; set; }
            public string description { get; set; }
            //  public string columnName { get; set; } 

            public override string ToString()
            {
                return string.Format("Main Table: {0}", mainTable);
            }
        }

        public class RiskMeasuresToInvocation
        {
            public string analyticIdToStage { get; set; }
            public List<string> invocationList { get; set; }
            public override string ToString()
            {
                return string.Format("Main Table: {0}", analyticIdToStage);
            }
        }

        public class SearchResponseBO : ResponseBO
        {
            public ConfigInputData data { get; set; }
        }
        
        public class CacheDataResponse : ResponseBO
        {
            public List<KeyValuePair<string,string>> data { get; set; }
        }

        public class ConfigUpdateResponse : ResponseBO
        {
            public string message { get; set; }
        }
    }
}
