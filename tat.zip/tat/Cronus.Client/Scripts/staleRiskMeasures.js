﻿"use strict";
var screenName = Cronus.Screens.StaleRiskMeasures;
var tableAlias = [];
var dtDict = {};
var cusipListForDt = [];
var staleDateForDt;
var OracleSybaseMap = {};

$(document).on("ready", function () {
    //Permission Check
    if (!Cronus.selectedPage(screenName, Cronus.Actions.StaleRiskMeasures_View)) {
        return;
    }
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.StaleRiskMeasures_Submit, screenName) == false) {
        $("#btnSubmit").attr('disabled', true);
        $("#btnSubmit").addClass('disabledbtn');
    }

    //Fetch the initial data
    InitiateScreen();

    //Callback functions.
    $("#txtSsmId").keypress(function (e) {
        if (e.which === 13) {
            $('#btnSearch').click();
            return false;
        }
    });

    $('#btnSearch').click(function () {
        searchData();
    });

    $('#btnSubmit').click(function () {
        staleRiskMeasures();
    });

});

function InitiateScreen() {
    hideResults();
    fetchTableAliases();
    fetchRiskMeasuresAliases();
    $("#txtStaleDate").datepicker({ maxDate: new Date() });
    Cronus.populatePreviousDate($("#txtStaleDate"));
}

function showFromCalender() {
    $("#txtStaleDate").focus();
    return false;
}

function resetResult() {
    $("#divResult").html("");
    $("#container").html("");
    tableAlias = [];
    dtDict = {};
    staleDateForDt = "";
    cusipListForDt = [];
}
function hideResults() {
    $("#btnSubmit").hide();
    $("#divSubmitRecords").hide();
    resetResult();

}

function searchData() {
    var cusipField = $("#txtSsmId").val();
    if (!Cronus.isNotEmptyNullOrUndefined(cusipField)) {
        swal("Error", "Please pass list of cusips saperated by comma [,]", "error");
        $("#txtSsmId").focus();
        return;
    }

    var cusipList, cusipTable;
    if (cusipField.indexOf('.') > 0 || cusipField.indexOf('..') > 0) {
        cusipTable = cusipField;
    } else {
        if (!Cronus.validateCusipList(cusipField, 9)) {
            swal("Error", "Please pass list of valid ssm_ids", "error");
            return;
        } else {
            cusipList = cusipField.split(",");
        }
    }

    var staleDate = $("#txtStaleDate").val();
    if (!Cronus.isNotEmptyNullOrUndefined(staleDate)) {
        swal("Error", "Please pass stale date", "error");
        return;
    }

    var selectedTables = $("#ddlTables").val();
    var selectedRiskMeasures = $("#ddlRiskMeasures").val();
    if (Cronus.isNotEmptyNullOrUndefined(selectedTables) && Cronus.isNotEmptyNullOrUndefined(selectedRiskMeasures)) {
        swal("Error", "Please select either only tables or only risk measure to stale.", "error");
        return;
    }

    if (!Cronus.isNotEmptyNullOrUndefined(selectedTables) && !Cronus.isNotEmptyNullOrUndefined(selectedRiskMeasures)) {
        swal("Error", "Please select either tables or risk measure to stale.", "error");
        return;
    }

    var inputObj;
    inputObj = { screenName: screenName, functionName: "SearchData", data: { CusipList: cusipList, CusipTable: cusipTable, SelectedTableList: selectedTables, SelectedRiskMeasuresList: selectedRiskMeasures, StaleDate: staleDate} };

    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var results = retval.AjaxObj.responseJSON;
        if (results.errorMessage == null || results.errorMessage == "") {
            if (results.TablesDataList.length > 0) {
                resetResult();
                $("#btnSubmit").show();
                $("#divSubmitRecords").show();
                staleDateForDt = results.StaleDate;
                cusipListForDt = results.CusipList;
                for (var i = 0; i < results.TablesDataList.length; i++) {
                    if (results.TablesDataList[i].Data.columns == null) {
                        continue;
                    }
                    tableAlias.push(results.TablesDataList[i].TableAlias);

                    var html = "";
                    html += '<div id = "divStale' + i + '" class="divstalecount"">';
                    html += '<div class="col-lg-4 col-sm-4 col-md-4" style="padding-left: 0px">';
                    html += '<select class="form-control" multiple="multiple" id="ddlTableColumns' + i + '">';
                    html += '</select>';
                    html += '</div>';

                    html += '</br></br></br>';
                    html += '<table style="width: 100%; margin-top: 20px;" id="dtStale' + i + '"> </table></div>';
                    html += '</div>';
                    $("#container").append(html);
                    $("#divResult").append('<button type="button" id="btnResult_' + i + '" tabid="' + i + '" class="btn btn-primary tabsbutton" ' +
                        'onclick="result(this)">' + results.TablesDataList[i].TableAlias + '</button>');

                    populateResultTab(i, results.TablesDataList[i]);
                    $("#divStale" + i).hide();
                    var tableCols = [];
                    for (var j = 0; j < results.TablesDataList[i].UpdatableColumnsList.length; j++)
                        tableCols.push(results.TablesDataList[i].UpdatableColumnsList[j]);
                    Cronus.populateMultiSelectDropDown("#ddlTableColumns" + i, tableCols);
                }
                $("#divResult").append('<br/>');
                $("#divResult").append('<br/>');
                $("#btnResult_0").click();
            }
            if (results.InfoMessage) {
                swal("Info", results.InfoMessage.replace("\\n", "<br\>"), "success");
            }
            if (results.WarningMessage) {
                swal("Warning", results.WarningMessage.replace("\\n", "<br\>"), "warning");
            }
        }
        else {
            swal("error", results.errorMessage.replace("\\n", "<br\>"), "error");
        }
    });
}

function populateResultTab(tabId, tablesDataList) {
    $("#dtStale" + tabId).css('display', 'none');
    // This will clear all the content of datatable before executing new query    
    dtDict[tabId] = Cronus.destroyDataTable(dtDict[tabId], "#dtStale" + tabId);

    $("#dtStale" + tabId).css('display', 'table');
    dtDict[tabId] = Cronus.refreshDataTable(dtDict[tabId], $("#dtStale" + tabId), tablesDataList.Data.columns, tablesDataList.Data.rows);
}

function result(el) {
    var tabId = $(el).attr('tabId');

    $("#container .divstalecount").each(function () {
        $(this).hide();
    });
    $('#divStale' + tabId).show();
    $("#divResult .tabsbutton").each(function () {
        $(this).addClass("disabledbtn");
    });

    $(el).removeClass("disabledbtn");

}
//
function staleRiskMeasures() {
    //only update the selected columns
    var tablesToBeStaled = "";
    var tablesColumnsDict = {};
    var tablesOra = [];
    var tablesSyb = [];
    for (var i = 0; i < tableAlias.length; i++) {
        var selectedColumns = $("#ddlTableColumns" + i).val();
        if (!Cronus.isNotEmptyNullOrUndefined(selectedColumns)) {
            swal("Error", "Please select at least 1 column of " + tableAlias[i] + " to be staled", "error");
            return;
        }
        var columns = selectedColumns;
        var columnsStr = " " + columns;
        if (columnsStr.length > 30) columnsStr = columnsStr.substr(0, 30) + '...';
        tablesToBeStaled += "<b> " + tableAlias[i] + "</b> :" + columnsStr + "<br\> ";
        
        if (tableAlias[i].indexOf("_ora") >= 0) {
            tablesOra.push(tableAlias[i]);
        } else {
            tablesSyb.push(tableAlias[i]);
        }
        tablesColumnsDict[tableAlias[i]] = columns;
    }

    var tablesMising = "";    
    $.each(tablesOra, function (index, elm) {
        if ($.inArray(OracleSybaseMap[elm], tablesSyb) === -1) {
            tablesMising += OracleSybaseMap[elm] + ", ";
        }
    });    
    if (Cronus.isNotEmptyNullOrUndefined(tablesMising)) {
        var retVal = confirm("Sybase table(s) " + tablesMising + " missing  corresponding to Oralce. Do you wish to continue?");
        if (retVal === true) {

        } else {
            return false;
        }
    }

    swal({ html: true,
        title: "Data will be staled for table:columns", text: tablesToBeStaled + " </br> <b> Do you wish to continue? </b>", type: "info", showCancelButton: true, confirmButtonColor: "#2e6da4",
        confirmButtonText: "No", cancelButtonText: "Yes", cancelButtonColor: "#2e6da4", closeOnConfirm: true, closeOnCancel: false
    },
     function (isConfirm) {
         if (!isConfirm) {
             swal.close();
             var inputObj = { screenName: screenName, functionName: "SubmitData", data: { cusipList: cusipListForDt, staleDate: staleDateForDt, tablesColumnsDict: tablesColumnsDict} };

             var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, ".blockOverlay", true);
             $.when(retval.AjaxObj).done(function () {
                 var results1 = retval.AjaxObj.responseJSON;
                 if (results1.errorMessage == null || results1.errorMessage == "") {
                     hideResults();
                     swal("Info", "Data Staled successfully ", "success");

                 }
             });
         }
         else { return true; }
     });
}

function fetchTableAliases() {
    var inputObj = { screenName: screenName, tableName: "TableAliases" };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage === null || result.errorMessage === "") {
            var tables = [];
            for (var i = 0; i < result.rows.length; i++) {
                tables.push(result.rows[i][0]);                
                if (result.rows[i][0].indexOf("_ora") >= 0 && !(result.rows[i][0].indexOf("srm_eq3_ora") >= 0)) {

                    OracleSybaseMap[result.rows[i][0]] = result.rows[i][0].substring(0, result.rows[i][0].length - 4);
                }
            }
            Cronus.populateMultiSelectDropDown("#ddlTables", tables);
        }
    });
}

function fetchRiskMeasuresAliases() {
    var inputObj = { screenName: screenName, tableName: "RiskMeasuresAliases" };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage === null || result.errorMessage === "") {
            var riskMeasuresList = [];
            for (var i = 0; i < result.rows.length; i++)
                riskMeasuresList.push(result.rows[i][0]);
            Cronus.populateMultiSelectDropDown("#ddlRiskMeasures", riskMeasuresList);
        }
    });
}