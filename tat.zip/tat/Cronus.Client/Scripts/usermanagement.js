﻿"use strict";
var screenName = Cronus.Screens.UserManagement;
var dtInvocations;
var handsonExcel;

$(document).ready(function () {
    if (!Cronus.selectedPage(screenName, Cronus.Actions.UserManagement_View)) {
        return;
    }

    fetchGroupList();
    fetchAllUsersList();
    resizeUserGroup();

    $("#btnSaveGroup").click(function () {
        createGroup();
    });
    $("#btnUpdateGroup").click(function () {
        updateGroup();
    });

    $("#dtActionPermissions").on("change", ".subsCheckbox", function (event) {
        if (this.checked) {
            $(this).attr("checked", "checked");
        } else {
            $(this).removeAttr("checked");
        }

    });

    // Used for adding/updaing multiple users in a go.
    $("#dvHandsonTable").html("");

    var container = document.getElementById('dvHandsonTable');
    var setting = {
        data: [["", "", ""]],
        startRows: 2,
        startCols: 3,
        minSpareCols: 0,
        minSpareRows: 5,
        height: 200,
        colHeaders: ["User Id*", "Name", "Email Id"],
        stretchH: "all",
        currentRowClassName: "currentRow",
        currentColClassName: "currentCol",
        contextMenu: ['row_above', 'row_below', 'remove_row', 'undo', 'redo'],
        maxCols: 3
    };
    var handsonTable = new Handsontable(container, setting);
    handsonExcel = handsonTable;

    $("#btnUserSearch").click(function () {
        searchUser(handsonTable);
        return false;
    });

    $("#txtSearchUsers").keypress(function (e) {
        if (e.which === 13) {
            $("#btnUserSearch").click();
            return false;
        }
    });

    $("#btnUpdateUsers").click(function () {
        UpdateUsers(handsonTable);
        return false;
    });






    //    /// On selection of master table from dropdown, old data table content is destroyed and new dataTable is populated for new master table.
    //    var selectedmasterTable = $("#ddlGroupsScreen").find(":selected").val();
    //    $("#ddlGroupsScreen").on("change", function () {
    //        selectedmasterTable = $(this).val();

    //        if (selectedmasterTable === "Select Group") {
    //            $("#spnDescriptionWrapperScreen").addClass("hidden");
    //            destroyDataTable(dtInvocations, "#dtMasterTable");
    //            return false;
    //        }
    //        else {
    //            $("#addTable").removeClass("hidden");
    //        }

    //    });

});


function searchUser(handsonTable) {
    handsonTable.loadData([["", "", ""]]);
    var userId = $("#txtSearchUsers").val().trim();
    if (userId == "" || userId == null) {
        swal("Error", "Please pass userId", "error");
        $("#txtSearchUsers").focus();
        return;
    }
    else {
        var inputObj = { screenName: screenName, data: { UserId: userId, tab: 'U' } };

        var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", true);
        $.when(retval.AjaxObj).done(function () {
            var result = retval.AjaxObj.responseJSON;
            if (result.errorMessage == null || result.errorMessage == "") {
                // Add result data in list
                if (result.rows.length > 0) {
                    var rowsData = [];
                    for (var i = 0; i < result.rows.length; i++)
                        rowsData.push([result.rows[i][0], result.rows[i][1] + " " + result.rows[i][2], result.rows[i][3]]);
                    handsonTable.loadData(rowsData);
                }
                else
                    swal("Info", "No data found", "success");
            }
        });
    }
}

function UpdateUsers() {
    var userData = [];
    var rowscount = 0;
    var errorfound = false;
    var data = handsonExcel.getData();

    for (var j = 0; j < data.length; j++) {
        var userId = data[j][0];
        var userName = data[j][1];
        var email = data[j][2];
        // If both are null thjen continue in the loop
        if (errorfound || (!Cronus.isNotEmptyNullOrUndefined(userId) && (!Cronus.isNotEmptyNullOrUndefined(userName))))
            continue;
        errorfound = false;

        rowscount++;
        if (!Cronus.isNotEmptyNullOrUndefined(userId)) {
            swal("Error", "Please pass userId at row " + rowscount, "error");
            errorfound = true;
        }

        if (!Cronus.isNotEmptyNullOrUndefined(userName)) {
            swal("Error", "Please pass user Name at row " + rowscount, "error");
            errorfound = true;
        }

        if (!Cronus.isNotEmptyNullOrUndefined(email)) {
            swal("Error", "Please pass email at row " + rowscount, "error");
            errorfound = true;
        }

        else {
            userData.push({ USERID: userId, USERNAME: userName, EMAIL: email });
        }
    }

    if (rowscount === 0 && !errorfound && userData.length === 0) {
        swal("Error", "Please pass ssm_id at row 1", "error");
        errorfound = true;
    }

    if (errorfound) {
        $("#dvHandsonTable").focus();
        return;
    }
    var inputObj = { screenName: screenName, data: { tab: 'U', action: 'M', UserDetailList: userData } };

    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            swal("Info", result.message, "success");
            fetchAllUsersList();
        }
    });
}

function resizeUserGroup() {
    var bodyheight = $(window).height();
    var bodywidth = $(window).width();
    $(".dvLeftSwapper,.dvRightSwapper").height(bodyheight - 245);
    $(".dvSwapperWrapper").height(bodyheight - 273);
    $(".dvSecond").height(bodyheight - 273);
}

$(window).resize(function () {
    resizeUserGroup();
});
var groupUsersIds = [];
var deletedGroupUsersIds = [];
function swapDiv(elem) {
    if ($("#emptyRowNonGroupUser").attr('id') != undefined) {
        $("#emptyRowNonGroupUser").remove();
    }
    if ($("#emptyRowGroupUser").attr('id') != undefined) {
        $("#emptyRowGroupUser").remove();
    }
    var userId = $(elem).attr('id');
    if ($(elem).parent().attr("id") == "nongroupUsers") {
        $(elem).detach().prependTo('#groupUsers');
        if ($.inArray(userId, groupUsersIds) === -1) {
            groupUsersIds.push(userId);
        }
        deletedGroupUsersIds = jQuery.grep(deletedGroupUsersIds, function (value) {
            return value != userId;
        });
    }
    else {
        if ($.inArray(userId, deletedGroupUsersIds) === -1) {
            deletedGroupUsersIds.push(userId);
        }
        groupUsersIds = jQuery.grep(groupUsersIds, function (value) {
            return value != userId;
        });

        $(elem).detach().prependTo('#nongroupUsers');
    }
    if ($("#nongroupUsers > div").length == 0) {
        $("#nongroupUsers").html('<div id="emptyRowNonGroupUser" class="dvNonExistingUsers"><img src="../Images/Users/user.png" class="imgSwapperContent"><span>No user found !</span></div>');

    } else if ($("#groupUsers > div").length == 0) {
        $("#groupUsers").html('<div id="emptyRowGroupUser" class="dvExistingUsers"><img src="../Images/Users/user.png" class="imgSwapperContent"><span>No user found !</span></div>');
    }
}
function toggleTab(el) {
    $('.tabs').addClass('disabledbtn');
    $(el).removeClass('disabledbtn');
    var id = $(el).attr('id');
    if (id == "btnUsersGroup") {
        fetchGroupList();
        $("#ddlGroups").val('');
        $("#ddlGroups").change();
        $("#tblUsersGroup").css('display', 'table');
        $("#tblScreenPrm").css('display', 'none');
        $("#tblUsers").css('display', 'none');
    } else if (id == "btnScreenPrm") {
        fetchGroupList();
        $("#ddlGroupsScreen").val('');
        $("#ddlGroupsScreen").change();
        $("#tblScreenPrm").css('display', 'table');
        $("#tblUsersGroup").css('display', 'none');
        $("#tblUsers").css('display', 'none');
    } else if (id == "btnUsers") {
        fetchAllUsersList();
        $("#ddlUsers").val('');
        $("#ddlUsers").change();
        $("#tblUsers").css('display', 'table');
        $("#tblUsersGroup").css('display', 'none');
        $("#tblScreenPrm").css('display', 'none');
    }
}
function fetchGroupList() {
    var inputObj = { screenName: screenName, fieldName: "GROUP" };

    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDropDownData, ".blockOverlay", false);
    if (retval.Error == false) {
        var result = retval.Result;
        $("#ddlGroups,#ddlGroupsScreen").html('<option value="">Select Group</option>');
        var ddOption = "";
        for (var i = 0; i < result.dropDownData.length; i++) {
            //place to fix
            var desc = result.dropDownData[i].value.trim().split('-').length > 1 ? result.dropDownData[i].value.trim().split('-')[1] : "";
            ddOption += '<option description="' + desc + '" value="' + result.dropDownData[i].data.trim() + '">' + result.dropDownData[i].data.trim() + '</option>';
        }
        $("#ddlGroups,#ddlGroupsScreen").append(ddOption);
    }
}
function fetchUsersList(el) {
    var groupId = $(el).val().trim();
    $("#spnDescription").html('');
    $("#nongroupUsers").html('<div id="emptyRowNonGroupUser" class="dvNonExistingUsers"><img src="../Images/Users/user.png" class="imgSwapperContent"><span>No user found !</span></div>');
    $("#groupUsers").html('<div id="emptyRowGroupUser" class="dvExistingUsers"><img src="../Images/Users/user.png" class="imgSwapperContent"><span>No user found !</span></div>');
    if (groupId == "") {
        $("#aEditGroup").hide();
        $("#aDeleteGroup").hide();
        $("#spnDescriptionWrapper").css('visibility', 'hidden');
        return;
    }
    $("#aEditGroup").show();
    $("#aDeleteGroup").show();
    $("#spnDescriptionWrapper").css('visibility', 'visible');
    var groupDesc = $("#ddlGroups option:selected").attr('description');
    $("#spnDescription").html(groupDesc);

    var inputObj = { screenName: screenName, data: { tab: 'G', groupId: groupId } };

    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", false);
    if (retval.Error == false) {
        var result = retval.Result;
        groupUsersIds = [];
        $("#nongroupUsers").html('');
        $("#groupUsers").html('');
        for (var i = 0; i < result.rows.length; i++) {
            var userId = result.rows[i][0];
            var groupId = result.rows[i][1];
            if (groupId == undefined || groupId == null || groupId == "") {
                var nongroupusers = '<div id="' + userId + '" onclick="swapDiv(this)" class="dvNonExistingUsers"><img src="' + $("#hdnImagePath").val() + '" class="imgSwapperContent"  /><span>' + userId + '</span></div>';
                $("#nongroupUsers").append(nongroupusers);
            }
            else {
                var groupusers = '<div id="' + userId + '" onclick="swapDiv(this)" class="dvExistingUsers"><img src="' + $("#hdnImagePath").val() + '" class="imgSwapperContent"  /><span>' + userId + '</span></div>';
                $("#groupUsers").append(groupusers);
                // groupUsersIds.push(userId);
            }
        }
    }
}
function showGroupModel() {
    $("#txtGroupName").attr('disabled', false);
    $("#txtGroupName").css('background-color', 'white');
    $("#spnGrpHeader").text("Create Group");
    $("#txtGroupName").attr("disabled", false);
    $("#txtGroupName").val('');
    $("#mtxtGroupDesc").val('');
    $("#btnUpdateGroup").hide();
    $("#btnSaveGroup").show();
    $('.bs-grp-modal-lg').modal('show');
}
function updateGroupModel() {
    $("#txtGroupName").css('background-color', '#E0E0E0');
    $("#spnGrpHeader").text("Update Group");
    $("#txtGroupName").attr("disabled", true);
    $("#txtGroupName").val($("#ddlGroups").val());
    var groupDesc = $("#ddlGroups option:selected").attr('description');
    $("#mtxtGroupDesc").val(groupDesc);
    $("#btnUpdateGroup").show();
    $("#btnSaveGroup").hide();
    $('.bs-grp-modal-lg').modal('show');
}

function removerUser(el) {
    $(el).parent().parent().remove();
    return false;
}

function createGroup() {
    var groupid = $("#txtGroupName");
    var groupdesc = $("#mtxtGroupDesc");
    if (groupid.val().trim() == "") {
        groupid.focus();
        return;
    }

    var inputObj = { screenName: screenName, data: { tab: 'G', action: 'I', groupId: groupid.val().trim(), description: groupdesc.val().trim() } };

    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, ".blockOverlay", false);
    if (retval.Error == false) {
        $(".close").click();
        var ddOption = '<option description="' + groupdesc.val().trim() + '" value="' + groupid.val().trim() + '">' + groupid.val().trim() + '</option>';
        $("#ddlGroups").append(ddOption);
        $("#ddlGroups").val(groupid.val().trim());
        $("#spnDescription").html(groupdesc.val().trim());
        $("#spnDescriptionWrapper").css('visibility', 'visible');
        $("#aEditGroup").show();
        $("#aDeleteGroup").show();
        $('#ddlGroups').change();
        swal("Info", "Group added successfully", "success");
    }
    else
        $("#spnDescriptionWrapper").css('visibility', 'hidden');
}
function updateGroup() {
    var groupid = $("#txtGroupName");
    var groupDesc = $("#mtxtGroupDesc");
    if (groupid.val().trim() == "") {
        groupid.focus();
        return;
    }
    var inputObj = { screenName: screenName, data: { tab: 'G', action: 'U', groupId: groupid.val().trim(), description: groupDesc.val().trim() } };

    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, ".blockOverlay", false);
    if (retval.Error == false) {
        $(".close").click();
        swal("Info", "Group updated successfull!", "success");
        $("#ddlGroups option:selected").attr('description', groupDesc.val().trim());
        $("#spnDescription").html(groupDesc.val().trim());
    }
    else
        $("#spnDescriptionWrapper").css('visibility', 'hidden');

    return false;
}
function deleteGroup() {
    var groupId = $("#ddlGroups").val().trim();
    if (groupId == "") {
        return;
    }

    var a = confirm('Are you sure to delete this group ?');
    if (a) {
        var inputObj = { screenName: screenName, data: { tab: 'G', action: 'D', groupId: groupId } };

        var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, ".blockOverlay", false);
        if (retval.Error == false) {
            $("#ddlGroups option:selected").remove();
            $("#aEditGroup").hide();
            $("#aDeleteGroup").hide();
            $("#spnDescriptionWrapper").css('visibility', 'hidden');
            $('#ddlGroups').change();
            swal("Info", "Group deleted successfully", "success");

        }
        else
            $("#spnDescriptionWrapper").css('visibility', 'hidden');
    }
}

function updateGroupUsers() {
    var groupid = $("#ddlGroups").val().trim();
    if (groupid == "") {
        return;
    }
    var a = confirm('Are you sure to update group users ?');
    if (a) {
        var inputObj = { screenName: screenName, data: { tab: 'G', action: 'M', groupId: groupid, userIds: groupUsersIds, deletedUserIds: deletedGroupUsersIds } };

        var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, ".blockOverlay", false);
        if (retval.Error == false) {

            $("#groupUsers .dvNonExistingUsers").addClass('dvExistingUsers');
            $("#groupUsers .dvNonExistingUsers").removeClass('dvNonExistingUsers');
            $("#nongroupUsers .dvExistingUsers").addClass('dvNonExistingUsers');
            $("#nongroupUsers .dvExistingUsers").removeClass('dvExistingUsers');
            groupUsersIds = [];
            deletedGroupUsersIds = [];
            swal("Info", "User group updated successfully", "success");
        }
    }
    return false;
}

var screenActionIds = [];
var deleteScreenActionIds = [];
var insertScreenActionIds = [];
function fetchScreenList(el) {
    var groupId = $(el).val().trim();

    $("#spnDescriptionScreen").html('');
    if (groupId === "") {
        $("#spnDescriptionWrapperScreen").css('visibility', 'hidden');
        Cronus.destroyDataTable(dtInvocations, "#dtMasterTable");
        return;
    }

    $("#spnDescriptionWrapperScreen").css('visibility', 'visible');
    var groupDesc = $("#ddlGroupsScreen option:selected").attr('description');
    $("#spnDescriptionScreen").html(groupDesc);

    var inputObj = { screenName: screenName, data: { tab: 'S', groupId: groupId } };

    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage === "") {
            var dataTableArray = [];
            var columns = ["Screen", "Action", "Description", "Is Permitted"];
            var datarow;
            for (var i = 0; i < result.rows.length; i++) {
                datarow = [];
                datarow.push(result.rows[i][0]);
                datarow.push(result.rows[i][2]);
                datarow.push(result.rows[i][3]);

                if (result.rows[i][4]) {
                    datarow.push("<input type='checkbox' class='subsCheckbox' checked='checked' onchange='selectedRow(this)' id= " + result.rows[i][1] + " />");
                }
                else {
                    datarow.push("<input type='checkbox' class='subsCheckbox' onchange='selectedRow(this)' id= " + result.rows[i][1] + " />");
                }
                dataTableArray.push(datarow);
            }
            dtInvocations = Cronus.refreshDataTable(dtInvocations, $("#dtActionPermissions"), columns, dataTableArray);
        }
    });
};

function selectedRow(el) {
    var id = $(el).attr("id");
    var checked = $(el).is(':checked');
    if (checked == false) {
        if ($.inArray(id, deleteScreenActionIds) === -1) {
            deleteScreenActionIds.push(id);
        }
        insertScreenActionIds = jQuery.grep(insertScreenActionIds, function (value) {
            return value != id;
        });
    } else {
        if ($.inArray(id, insertScreenActionIds) === -1) {
            insertScreenActionIds.push(id);
        }
        deleteScreenActionIds = jQuery.grep(deleteScreenActionIds, function (value) {
            return value != id;
        });
    }


    var rows = dtInvocations.fnGetData();
    screenActionIds = [];
    for (var i = 0; i < rows.length; i++) {
        var checkBoxRow = rows[i][3];
        var screenActionId = $(checkBoxRow).attr('id');
        if (screenActionId == id) {
            if (checked) {
                rows[i][3] = "<input type='checkbox' class='subsCheckbox' checked='checked' onchange='selectedRow(this)' id= " + id + " />";
            }
            else {
                rows[i][3] = "<input type='checkbox' class='subsCheckbox' onchange='selectedRow(this)' id= " + id + " />";
            }
        }
    }
}

function fetchScreenList2(el) {
    var groupId = $(el).val().trim();
    $("#spnDescriptionScreen").html('');
    $("#tblScreens").find("tr:gt(0)").remove();
    if (groupId == "") {
        $("#spnDescriptionWrapperScreen").css('visibility', 'hidden');
        $("#tblScreens").append('<tr><td colspan="4">No record found</td></tr>');
        return;
    }

    $("#spnDescriptionWrapperScreen").css('visibility', 'visible');
    var groupDesc = $("#ddlGroupsScreen option:selected").attr('description');
    $("#spnDescriptionScreen").html(groupDesc);

    var inputObj = { screenName: screenName, data: { tab: 'S', groupId: groupId } };

    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", false);
    if (retval.Error == false) {
        var result = retval.Result;
        screenActionIds = [];
        for (var i = 0; i < result.rows.length; i++) {
            //screen_id - action_id - action_name - description - is_permitted
            var row = '<tr><td>' + result.rows[i][0] + '</td><td>' + result.rows[i][2] + '</td><td>' + result.rows[i][3] + '</td>';
            if (result.rows[i][4]) {
                screenActionIds.push(result.rows[i][1]);
                row += '<td><input onclick="selectScreenAction(this);" checked="checked" id=' + result.rows[i][1] + ' type="checkbox" /></td></tr>';
            } else {
                row += '<td><input onclick="selectScreenAction(this);" id=' + result.rows[i][1] + ' type="checkbox" /></td></tr>';
            }
            $("#tblScreens").append(row);
        }
    }
}


function selectScreenAction(el) {
    var screenActionId = $(el).attr('id');
    if ($(el).is(":checked")) {
        if ($.inArray(screenActionId, screenActionIds) === -1) {
            screenActionIds.push(screenActionId);
        }
    } else {
        screenActionIds = jQuery.grep(screenActionIds, function (value) {
            return value != screenActionId;
        });
    }
}

function updateGroupScreenPermissons() {
    var groupid = $("#ddlGroupsScreen").val().trim();
    if (groupid == "") {
        return;
    }

    var rows = dtInvocations.fnGetData();
    screenActionIds = [];
    for (var i = 0; i < rows.length; i++) {
        var checkBoxRow = rows[i][3];
        var screenActionId = $(checkBoxRow).attr('id');
        var isLoad = $(checkBoxRow).is(":checked");
        if (isLoad) {
            screenActionIds.push(screenActionId);
        }
    }

    var a = confirm('Are you sure to update group screen permissions ?');
    if (a) {
        var inputObj = { screenName: screenName, data: { tab: 'S', action: 'U', groupId: groupid, actionIds: screenActionIds, deleteActionlist: deleteScreenActionIds, insertActionlist: insertScreenActionIds } };

        var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, ".blockOverlay", false);
        if (retval.Error == false) {
            deleteScreenActionIds = [];
            insertScreenActionIds = [];
            swal("Info", "Screen permission updated successfully", "success");
        }
    }
}

//------------------------------------
function fetchAllUsersList() {
    var inputObj = { screenName: screenName, fieldName: "USER" };

    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDropDownData, ".blockOverlay", false);
    if (retval.Error == false) {
        var result = retval.Result;
        $("#ddlUsers").html('<option value="">Select User</option>');
        var ddOption = "";
        for (var i = 0; i < result.dropDownData.length; i++) {
            var name = "";
            var email = "";
            if (result.dropDownData[i].value != null) {
                var desc = result.dropDownData[i].value.trim().split(',');
                if (desc.length > 0) {
                    name = desc[0].trim().split('-').length > 1 ? desc[0].trim().split('-')[1] : "";
                }
                if (desc.length > 1) {
                    email = desc[1];
                }
            }
            ddOption += '<option email="' + email + '" username="' + name + '" value="' + result.dropDownData[i].data.trim() + '">' + result.dropDownData[i].data.trim() + '</option>';
        }
        $("#ddlUsers").append(ddOption);
    }
}

function fetchUsersDetail(el) {
    var userid = $(el).val();
    if (userid == "") {
        $("#aDeleteUser").hide();
        $("#btnAddUsers").show();
        $("#btnUpdateUser").hide();
        $("#txtUserId").attr('disabled', false);
        $("#txtUserId").css('background-color', 'white');
        $("#txtUserId").val('');
        $("#txtEmail").val('');
        $("#txtName").val('');
        return;
    }
    $("#aDeleteUser").show();
    $("#btnUpdateUser").show();
    $("#btnAddUsers").hide();
    $("#txtUserId").attr('disabled', true);
    $("#txtUserId").css('background-color', '#E0E0E0');
    $("#txtUserId").val($(el).val());
    $("#txtEmail").val($("#ddlUsers option:selected").attr('email'));
    $("#txtName").val($("#ddlUsers option:selected").attr('username'));
}

function resetAddUser() {
    $("#ddlUsers").val("");
    $("#ddlUsers").change();
    $("#txtUserId").focus();
    return false;
}

function updateUser() {
    var userId = $("#txtUserId");
    var name = $("#txtName");
    var email = $("#txtEmail");
    if (userId.val() == "") {
        userId.focus();
        return;
    }
    else {
        var inputObj = { screenName: screenName, data: { tab: 'U', action: 'U', userId: userId.val().trim(), userName: name.val().trim(), email: email.val().trim() } };

        var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, ".blockOverlay", false);
        if (retval.Error == false) {
            $("#ddlUsers").val(userId.val().trim());
            $("#ddlUsers option:selected").attr('email', email.val().trim());
            $("#ddlUsers option:selected").attr('username', name.val().trim());
            swal("Info", "User updated successfully", "success");
        }
    }
    fetchAllUsersList();
}
function addNewUser() {
    var userId = $("#txtUserId");
    var name = $("#txtName");
    var email = $("#txtEmail");
    if (userId.val() == "") {
        userId.focus();
        return;
    }
    else {
        var inputObj = { screenName: screenName, data: { tab: 'U', action: 'I', userId: userId.val().trim(), userName: name.val().trim(), email: email.val().trim() } };

        var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, ".blockOverlay", false);
        if (retval.Error == false) {
            fetchAllUsersList();
            $("#ddlUsers").val(userId.val().trim().toUpperCase());
            $("#aDeleteUser").show();
            $("#btnAddUsers").hide();
            $("#btnUpdateUser").show();
            $("#txtUserId").val(userId.val().trim().toUpperCase());
            $("#txtUserId").attr('disabled', true);
            $("#txtUserId").css('background-color', '#E0E0E0');
            swal("Info", "User added successfully", "success");
        }
    }

}
function deleteUser() {
    var userId = $("#txtUserId");
    if (userId.val() == "") {
        userId.focus();
        return;
    } else {
        var a = confirm('Are you sure to delete user ?');
        if (a) {
            var inputObj = { screenName: screenName, data: { tab: 'U', action: 'D', userId: userId.val().trim() } };

            var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, ".blockOverlay", false);
            if (retval.Error == false) {
                $("#ddlUsers option:selected").remove();
                $("#ddlUsers").change();
                $("#txtUserId").val('');
                $("#txtEmail").val('');
                $("#txtName").val('');
                swal("Info", "User deleted successfully", "success");
            }
        }
    }
    fetchAllUsersList();
}