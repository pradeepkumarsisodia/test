﻿"use strict";
var screenName = Cronus.Screens.AgencyModelMap;
var handsonExcel;

$(document).ready(function () {
    if (!Cronus.selectedPage(screenName, Cronus.Actions.AgencyModelMap_View)) {
        return;
    }

    //Permission Check
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.AgencyModelMap_Search, screenName) == false) {
        $("#btnSsm_idSearchModelMap").attr('disabled', true);
        $("#btnSsm_idSearchModelMap").addClass('disabledbtn');
    }
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.AgencyModelMap_AddUpdate, screenName) == false) {
        $("#btnUpdateModelMap").attr('disabled', true);
        $("#btnUpdateModelMap").addClass('disabledbtn');
    }

    $("#dvHandsonTable").html("");

    var container = document.getElementById('dvHandsonTable');
    var setting = {
        data: [["", ""]],
        startRows: 2,
        startCols: 2,
        minSpareCols: 0,
        minSpareRows: 5,
        height: 200,
        colHeaders: ["SSM_ID*", "CUSIP*"],
        stretchH: "all",
        currentRowClassName: "currentRow",
        currentColClassName: "currentCol",
        contextMenu: ['row_above', 'row_below', 'remove_row', 'undo', 'redo'],
        maxCols: 2
    };
    var handsonTable = new Handsontable(container, setting);
    handsonExcel = handsonTable;

    $("#btnSsm_idSearchModelMap").click(function () {
        if (Cronus.Compliance.isActionPermitted(Cronus.Actions.AgencyModelMap_Search, screenName))
            searchCusip(handsonTable);
        return false;
    });

    $("#txtSsm_id").keypress(function (e) {
        if (e.which == 13) {
            $("#btnSsm_idSearchModelMap").click();
            return false;
        }
    });

    $("#btnUpdateModelMap").click(function () {
        UpdateAgencyTbaMap(handsonTable);
        return false;
    });
});

function validateEnrty(value) {
    var retval = true;
    if (value.length > 128) {
        swal("Error", value + " is more than 128 char", "error");
        retval = false;
    }
    //else if (value.match(/^[a-zA-Z0-9 ]+$/) == null) {
    //    swal("Error", value + " has spacial char", "error");
    //    retval = false;
    //}
    return retval;
}

function searchCusip(handsonTable) {
    handsonTable.loadData([["", ""]]);
    var ssmId = $("#txtSsm_id").val().trim();
    if (ssmId == "" || ssmId == null) {
        swal("Error", "Please pass ssm_id", "error");
        $("#txtSsm_id").focus();
        return;
    }
    //else if (ValidateCusipList(ssmId, 128) == false) {
    //    $("#txtSsm_id").focus();
    //    return;
    //}
    else {
        var inputObj = { screenName: screenName, data: { ssmId: ssmId} };

        var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, null, true, '#btnSsm_idSearchModelMap');
        $.when(retval.AjaxObj).done(function () {
            var result = retval.AjaxObj.responseJSON;
            if (result.errorMessage == null || result.errorMessage == "") {
                // Add result data in list
                if (result.rows.length > 0) {
                    var rowsData = [];
                    for (var i = 0; i < result.rows.length; i++)
                        rowsData.push([result.rows[i][0], result.rows[i][1]]);
                    handsonTable.loadData(rowsData);
                }
                else
                    swal("Info", "No data found", "success");
            }
        });
    }
}

function UpdateAgencyTbaMap(handsonTable) {
    var agencyTbaMapData = [];
    var rowscount = 0;
    var errorfound = false;
    var data = handsonExcel.getData();

    for (var j = 0; j < data.length; j++) {
        var ssmId = data[j][0];
        var cusip = data[j][1];
        // If both are null thjen continue in the loop
        if (errorfound || (!Cronus.isNotEmptyNullOrUndefined(ssmId) && (!Cronus.isNotEmptyNullOrUndefined(cusip))))
            continue;
        errorfound = false;

        rowscount++;
        if (!Cronus.isNotEmptyNullOrUndefined(ssmId)) {
            swal("Error", "Please pass ssm_id at row " + rowscount, "error");
            errorfound = true;
        }
        else if (!validateEnrty(ssmId)) {
            errorfound = true;
        }
        if (!Cronus.isNotEmptyNullOrUndefined(cusip)) {
            swal("Error", "Please pass cusip at row " + rowscount, "error");
            errorfound = true;
        }
        else if (!validateEnrty(cusip)) {
            errorfound = true;
        }
        else {
            agencyTbaMapData.push({ SSMID: ssmId, CUSIP: cusip });
        }
    }

    if (rowscount === 0 && !errorfound && agencyTbaMapData.length === 0) {
        swal("Error", "Please pass ssm_id at row 1", "error");
        errorfound = true;
    }

    if (errorfound) {
        $("#dvHandsonTable").focus();
        return;
    }
    var inputObj = { screenName: screenName, data: agencyTbaMapData };

    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, null, true, "#btnUpdateModelMap");
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            swal("Info", result.message, "success");
        }
    });
}