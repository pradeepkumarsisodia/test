﻿"use strict";
var screenName = Cronus.Screens.ManageMasterTables;
var dt;
var selectedmasterTable;
var _mode, _selectedId;

$(document).ready(function () {
    if (!Cronus.selectedPage(screenName, Cronus.Actions.ManageMasterTables_View)) {
        return;
    }
        
    $("#addTable").click(function () {
        AddTable();
    });

    $("#btnSaveFreq").click(function () {
        SaveFreq();
    });

    $("#btnSaveGroups").click(function () {
        SaveGroups();
    });

    $("#btnSaveClass").click(function () {
        SaveClass();
    });

    $("#btnSaveSubClass").click(function () {
        SaveSubClass();
    });

    $("#btnSaveDefinitions").click(function () {
        SaveDefinitions();
    });

    /// On selection of master table from dropdown, old data table content is destroyed and new dataTable is populated for new master table.
    selectedmasterTable = $("#masterTable").find(":selected").val();
    $("#masterTable").on("change", function () {
        selectedmasterTable = $(this).val();

        if (selectedmasterTable === "TS_SELECT") {
            $("#addTable").addClass("hidden");
            Cronus.destroyDataTable(dt, "#dtMasterTable");
            return false;
        }
        else {
            $("#addTable").removeClass("hidden");
        }

        listTableData(selectedmasterTable);
    });

    $("#masterTable").val("TS_SELECT").trigger("change");
});

function AddTable() {
    if (selectedmasterTable === "TS_GROUP_CLASS") {
        showClassTablePopup(0);
    }
    else if (selectedmasterTable === "TS_GROUP_SUBCLASS") {
        showSubClassTablePopup(0);
    }
    else if (selectedmasterTable === "TS_FREQUENCY") {
        showFrequencyTablePopup(0);
    }
    else if (selectedmasterTable === "TS_GROUPS") {
        showGroupsTablePopup(0);
    }
    else if (selectedmasterTable === "TS_DEFINITIONS") {
        showDefinitionsTablePopup(0);
    }
}

function SaveFreq() {
    var id = $("#txtId").val().trim();
    if (id === "" || id === null) {
        id = -1;
    }
    var description = $("#txtDescription").val().trim();
    var lastDateAdj = $("#txtLast_Date_Adj").val().trim();
    var dayToRun = $("#txtDay_To_Run").val().trim();
    var comments = $("#txtComments").val().trim();
    if (description === "") {
        swal("Please enter description!", "", "error");
        $("#txtDescription").focus();
        return;
    }

    else if (lastDateAdj === "") {
        swal("Please enter last_Date_Adj!", "", "error");
        $("#txtLast_Date_Adj").focus();
        return;
    }
    else if (dayToRun === "") {
        swal("Please enter day_To_Run!", "", "error");
        $("#txtDay_To_Run").focus();
        return;
    }

    var action = "I";
    if (_mode === 1) {
        action = "U";
    }
    var inputObj = { screenName: screenName,
        data: { freqData: { ID: id, DESCRIPTION: description, LAST_DATE_ADJ: lastDateAdj, DAY_TO_RUN: dayToRun, COMMENTS: comments }, action: action, tableName: selectedmasterTable }
    };
    successUpdateMasterTable(inputObj, action);
}

function SaveGroups() {
    var id = $("#txtGroupId").val().trim();
    if (id === "" || id === null) {
        id = -1;
    }
    var classId = $("#txtclass_id").val().trim();
    var subclassId = $("#txtsubclass_id").val().trim();
    var qc = $("#txtqc").val().trim();
    var qcSwitch = $("#txtqc_switch").val().trim();
    var staleSwitch = $("#txtstale_switch").val().trim();
    var qcHist = $("#txtqc_hist").val().trim();

    if (classId === "") {
        swal("Please enter class id!", "", "error");
        $("#txtclass_id").focus();
        return;
    }
    else if (subclassId === "") {
        swal("Please enter subclass id!", "", "error");
        $("#txtsubclass_id").focus();
        return;
    }
    else if (qc === "") {
        swal("Please enter QC!", "", "error");
        $("#txtqc").focus();
        return;
    }
    else if (qcSwitch === "") {
        swal("Please enter qc switch!", "", "error");
        $("#qc_switch").focus();
        return;
    }
    else if (staleSwitch === "") {
        swal("Please enter stale switch!", "", "error");
        $("#stale_switch").focus();
        return;
    }

    var action = "I";
    if (_mode === 1) {
        action = "U";
    }

    var inputObj = { screenName: screenName,
        data: { grpData: { ID: id, CLASS_ID: classId, SUBCLASS_ID: subclassId, QC: qc, QC_SWITCH: qcSwitch, STALE_SWITCH: staleSwitch, QC_HIST: qcHist }, action: action, tableName: selectedmasterTable }
    };

    successUpdateMasterTable(inputObj, action);

}

function SaveClass() {
    var id = $("#txtClassId").val().trim();
    if (id === "" || id === null) {
        id = -1;
    }
    var classId = $("#txtclass").val().trim();

    if (classId === "") {
        swal("Please enter class id!", "", "error");
        $("#txtclass_id").focus();
        return;
    }

    var action = "I";
    if (_mode === 1) {
        action = "U";
    }
    var inputObj = { screenName: screenName,
        data: { CLASSData: { ID: id, class: classId }, action: action, tableName: selectedmasterTable }
    };

    successUpdateMasterTable(inputObj, action);
}



function SaveSubClass() {
    var id = $("#txtSubClassId").val().trim();
    if (id === "" || id === null) {
        id = -1;
    }
    var subclassId = $("#txtsubclass").val().trim();
    var priority = $("#txtpriority").val().trim();

    if (subclassId === "") {
        swal("Please enter Sub class id!", "", "error");
        $("#txtsubclass").focus();
        return;
    }
    else if (priority === "") {
        swal("Please enter priority!", "", "error");
        $("#txtpriority").focus();
        return;
    }

    var action = "I";
    if (_mode === 1) {
        action = "U";
    }

    var inputObj = { screenName: screenName,
        data: { subClassData: { ID: id, SUBCLASS: subclassId, PRIORITY: priority }, action: action, tableName: selectedmasterTable }
    };

    successUpdateMasterTable(inputObj, action);
}

function SaveDefinitions() {
    var id = $("#txtDefinitionId").val().trim();
    if (id === "" || id === null) {
        id = -1;
    }

    var groupId = $("#txtDefGROUP_ID").val().trim();
    var sid = $("#txtDefSID").val().trim();
    var frequencyId = $("#txtDefFREQUENCY_ID").val().trim();

    if (groupId === "") {
        swal("Please enter Group Id!", "", "error");
        $("#txtDefGROUP_ID").focus();
        return;
    }

    else if (sid === "") {
        swal("Please enter SID!", "", "error");
        $("#txtDefSID").focus();
        return;
    }
    else if (frequencyId === "") {
        swal("Please enter Frequency Id!", "", "error");
        $("#txtDefFREQUENCY_ID").focus();
        return;
    }
    var action = "I";
    if (_mode === 1) {
        action = "U";
    }

    var inputObj = { screenName: screenName,
        data: { DEFINITIONSData: {
            ID: id, GROUP_ID: groupId, SID: sid, DESCRIPTION: $("#txtDefDESCRIPTION").val().trim(), FREQUENCY_ID: $("#txtDefFREQUENCY_ID").val().trim(),
            PARENT_ID: $("#txtDefPARENT_ID").val().trim(), STRKEY1: $("#txtDefSTRKEY1").val().trim(), STRKEY2: $("#txtDefSTRKEY2").val().trim(),
            STRKEY3: $("#txtDefSTRKEY3").val().trim(), STRKEY4: $("#txtDefSTRKEY4").val().trim(), STRKEY5: $("#txtDefSTRKEY5").val().trim(),
            NUMKEY1: $("#txtDefNUMKEY1").val().trim(), NUMKEY2: $("#txtDefNUMKEY2").val().trim(), NUMKEY3: $("#txtDefNUMKEY3").val().trim(),
            NUMKEY4: $("#txtDefNUMKEY4").val().trim(), NUMKEY5: $("#txtDefNUMKEY5").val().trim(), P_NUMKEY1: $("#chkParentKey1").is(":checked"),
            P_NUMKEY2: $("#chkParentKey2").is(":checked"),P_NUMKEY3: $("#chkParentKey3").is(":checked"),P_NUMKEY4: $("#chkParentKey4").is(":checked"),
            P_NUMKEY5: $("#chkParentKey5").is(":checked")
        },
            action: action, tableName: selectedmasterTable
        }
    };

    successUpdateMasterTable(inputObj, action);
};

function successUpdateMasterTable(inputObj, action) {
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage === null || result.errorMessage === "") {
            if (action === "I") {
                action = "Insert";
            }
            else {
                action = "Update";
            }

            swal("Data " + action + " was successfull", "", "success");
            listTableData(selectedmasterTable);
        }
    });
}

function showFrequencyTablePopup(mode) {
    _mode = mode;
    if (mode === 0) {
        $("#modalTitle").html("Add new Frequency");
        $("#txtId").parent().parent().hide();
        $("#txtclass_id").val("");
        $("#txtLast_Date_Adj").val("");
        $("#txtDay_To_Run").val("");
        $("#txtComments").val("");
        $("#txtDescription").val("");
    } else {
        $("#txtId").parent().parent().show();
        $("#modalTitle").html("Update Frequency");
    }
    $(".bs-frequency-modal-lg").modal("show");
}

function showGroupsTablePopup(mode) {
    _mode = mode;
    if (mode === 0) {
        $("#modalTitle").html("Add new Group");
        $("#txtGroupId").parent().parent().hide();
        $("#txtclass_id").val("");
        $("#txtsubclass_id").val("");
        $("#txtqc").val("");
        $("#txtqc_switch").val("");
        $("#txtstale_switch").val("");
        $("#txtqc_hist").val("");
    } else {
        $("#txtGroupId").parent().parent().show();
        $("#modalTitle").html("Update a Group");
    }
    $(".bs-groups-modal-lg").modal("show");
}


function showClassTablePopup(mode) {
    _mode = mode;
    if (mode === 0) {
        $("#modalTitle").html("Add new Group Class");
        $("#txtClassId").parent().parent().hide();
        $("#txtclass").val("");
    } else {
        $("#txtClassId").parent().parent().show();
        $("#modalTitle").html("Update a Group Class");
    }
    $(".bs-class-modal-lg").modal("show");
}

function showSubClassTablePopup(mode) {
    _mode = mode;
    if (mode === 0) {
        $("#modalTitle").html("Add new Group Sub Class");
        $("#txtSubClassId").parent().parent().hide();
        $("#txtsubclass").val("");
        $("#txtpriority").val("");
    } else {
        $("#txtSubClassId").parent().parent().show();
        $("#modalTitle").html("Update a Group Sub Class");
    }
    $(".bs-subclass-modal-lg").modal("show");
}

function showDefinitionsTablePopup(mode) {
    _mode = mode;
    if (mode === 0) {
        $("#modalTitle").html("Add new Definitions");
        $("#txtDefinitionId").parent().parent().hide();
        $("#txtDefGROUP_ID").val("");
        $("#txtDefSID").val("");
        $("#txtDefDESCRIPTION").val("");
        $("#txtDefFREQUENCY_ID").val("");
        $("#txtDefPARENT_ID").val("");

        for (var j = 1; j < 6; j++) {
            $("#txtDefSTRKEY" + j).val("");
            $("#txtDefNUMKEY" + j).val("");
            $("#chkParentKey" + j).prop("checked", false);           
        }

//        $("#txtDefSTRKEY1").val("");
//        $("#txtDefSTRKEY2").val("");
//        $("#txtDefSTRKEY3").val("");
//        $("#txtDefSTRKEY4").val("");
//        $("#txtDefSTRKEY5").val("");
//        $("#txtDefNUMKEY1").val("");
//        $("#txtDefNUMKEY2").val("");
//        $("#txtDefNUMKEY3").val("");
//        $("#txtDefNUMKEY4").val("");
//        $("#txtDefNUMKEY5").val("");
//        $("#chkParentKey1").prop("checked", false);
//        $("#chkParentKey2").prop("checked", false);
//        $("#chkParentKey3").prop("checked", false);
//        $("#chkParentKey4").prop("checked", false);
//        $("#chkParentKey5").prop("checked", false);
    } else {
        $("#txtDefinitionId").parent().parent().show();
        $("#modalTitle").html("Update Definitions");
    }
    $(".bs-definitions-modal-lg").modal("show");
}

function listTableData(tableName) {
    // $(".close").trigger("click");
    var inputObj = { screenName: screenName, tableName: tableName };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage === null || result.errorMessage === "") {
            successlistTableData(result.columns, result.rows);
        }
    });
}

function successlistTableData(cols, rows) {
    var columns = cols;
    columns.push("Edit");
    var dataTableArray = [];
    for (var i = 0; i < rows.length; i++) {
        var datarow = [];
        for (var j = 0; j < columns.length - 1; j++) {
            datarow.push(rows[i][j]);
        }

        datarow.push("<input type='button' class='btn btn-success dataTable' value='Edit' onclick=fetchMasterTableInfo(" + i + "); />");

        dataTableArray.push(datarow);
    }
    dt = Cronus.refreshDataTable(dt, $("#dtMasterTable"), columns, dataTableArray, 1, [{ orderable: false, targets: -1}]);
}

function fetchMasterTableInfo(row) {
    var data = dt.fnGetData();

    successMasterTableInfo(data[row]);
}


function successMasterTableInfo(data) {
    if (selectedmasterTable === "TS_GROUP_CLASS") {
        _selectedId = data[0];
        $("#txtClassId").val(data[0]);
        $("#txtclass").val(data[1]);
        showClassTablePopup(1);
    }
    else if (selectedmasterTable === "TS_GROUP_SUBCLASS") {
        _selectedId = data[0];
        $("#txtSubClassId").val(data[0]);
        $("#txtsubclass").val(data[1]);
        $("#txtpriority").val(data[2]);
        showSubClassTablePopup(1);
    }
    else if (selectedmasterTable === "TS_FREQUENCY") {
        _selectedId = data[0];
        $("#txtId").val(data[0]);
        $("#txtDescription").val(data[1]);
        $("#txtLast_Date_Adj").val(data[2]);
        $("#txtDay_To_Run").val(data[3]);
        if (data[4] === "(null)") {
            $("#txtComments").val("");
        }
        else
            $("#txtComments").val(data[4]);

        showFrequencyTablePopup(1);
    }
    else if (selectedmasterTable === "TS_GROUPS") {
        _selectedId = data[0];
        $("#txtGroupId").val(data[0]);
        $("#txtclass_id").val(data[1]);
        $("#txtsubclass_id").val(data[2]);
        $("#txtqc").val(data[3]);
        $("#txtqc_switch").val(data[4]);
        $("#txtstale_switch").val(data[5]);

        if (data[6] === "(null)") {
            $("#txtqc_hist").val("");
        }
        else
            $("#txtqc_hist").val(data[6]);

        showGroupsTablePopup(1);
    }
    else if (selectedmasterTable === "TS_DEFINITIONS") {
        _selectedId = data[0];
        $("#txtDefinitionId").val(data[0]);
        $("#txtDefGROUP_ID").val(data[1]);
        $("#txtDefSID").val(data[2]);
        $("#txtDefDESCRIPTION").val(data[3]);
        $("#txtDefFREQUENCY_ID").val(data[4]);
        $("#txtDefPARENT_ID").val(data[5]);
        for (var j = 1; j < 6; j++) {
            $("#txtDefSTRKEY" + j).val(data[j + 5]);
            $("#txtDefNUMKEY" + j).val(data[j + 10]);
            if (data[j + 15] === 1)
                $("#chkParentKey" + j).prop("checked", true);
            else
                $("#chkParentKey" + j).prop("checked", false);
        }       
        showDefinitionsTablePopup(1);
    }
}