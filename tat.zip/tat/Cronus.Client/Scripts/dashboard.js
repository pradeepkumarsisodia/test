﻿"use strict";
var screenName = Cronus.Screens.Dashboard;
var ajaxRequest = "";
var dtReport;

$(document).ready(function () {
    if (!Cronus.selectedPage(screenName, Cronus.Actions.Dashboard_View)) {
        return;
    }
    //Permission Check
    // if (Cronus.Compliance.isActionPermitted(Cronus.Actions.Dashboard_UnlimitedAccess, screenName) == false) {        
    // }

    Cronus.fetchAutoCompleteData(screenName, "SCREEN", Cronus.RestApi.FetchDropDownData, $('#txtScreenId'), $("#hdnScreenId"));
    Cronus.fetchAutoCompleteData(screenName, "GROUP", Cronus.RestApi.FetchDropDownData, $('#txtGroupId'), $("#hdnGroupId"));

    $(document).keyup(function (e) {
        if (e.keyCode == 27) {
            stopAjax();
        }
    });

    // calling by default to get data
    GetAnalyticsData(7);
});

// generate barChart
var myChart = null;
function generateBar(data, type) {
    var sortedData = data.sort(function (a, b) { return b[1] - a[1] });
    var labels = sortedData.map(function (a) { return a[0]; });
    var dataPoints = sortedData.map(function (a) { return a[1] });
    var barData = {
        labels: labels,
        datasets: [
            {
                label: "Front",
                fillColor: "rgba(247, 80, 90, 0.0)",
                strokeColor: "#2bab51",
                pointColor: "#F7505A",
                pointStrokeColor: "rgba(0,0,0,0.2)",
                pointHighlightStroke: "rgba(225,225,225,0.75)",
                data: dataPoints
            }
  ]
    };

    if (myChart != null) {
        myChart.destroy();
    }
    var ctx = document.getElementById(type + "Bar").getContext("2d");

    myChart = new Chart(ctx).Bar(barData, {
        pointDotRadius: 6,
        pointDotStrokeWidth: 2,
        datasetStrokeWidth: 3,
        scaleShowVerticalLines: false,
        scaleGridLineWidth: 2,
        scaleShowGridLines: true,
        scaleGridLineColor: "rgba(225, 255, 255, 0.015)",
        // scaleOverride: true,
        //scaleSteps: 9,
        //scaleStepWidth: 100,
        //scaleStartValue: 0,

        responsive: true

    });
    window.myLineChart = myChart;
}

// generate chartjs function 

function createTopUsage(data, type) {
    // console.log(data);
    // Chartjs generation unit    
    var decendingSorted = data.sort(function (a, b) { return b[1] - a[1] });
    //console.log(decendingSorted);
    var sumOfHits = data.reduce(function (acc, val) { return acc + val[1] }, 0);
    var percentages = [];

    for (var j = 0; j < 4; j++) {
        var k = j + 1;
        $("#top" + k + type).html("");
        $("#" + type + "Name" + k).html("");
        $("#" + type + "Stat" + k).html("");
    }
    //    if (!decendingSorted.length) {
    //        $("#top1" + type).closest('div').hide();
    //    }
    for (var i = 0; i < decendingSorted.length && i < 4; i++) {
        var counter = i + 1;
        $("#top" + counter + type).html("");
        $("#" + type + "Name" + counter).text(decendingSorted[i][0]);
        $("#" + type + "Stat" + counter).html("&nbsp;&nbsp;&nbsp;" + decendingSorted[i][1]);

        percentages.push(parseFloat((decendingSorted[i][1] / sumOfHits).toFixed(2)));

        var circleChart = new ProgressBar.Circle('#top' + counter + type, {
            color: '#F7505A',
            strokeWidth: 5,
            trailWidth: 3,
            duration: 1000,
            text: {
                value: '0%'
            },
            step: function (state, bar) {
                bar.setText((bar.value() * 100).toFixed(0) + "%");
            }
        });
        circleChart.animate(percentages[i]);
    }
}


$("#btnGetAnaltyticsData").click(function () {
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.Dashboard_Submit, screenName))
        GetAnalyticsData(7);
    return false;
});

$("#txtScreenId").keypress(function (e) {
    if (e.which == 13) {
        $("#btnGetAnaltyticsData").click();
        return false;
    }
});
$("#txtGroupId").keypress(function (e) {
    if (e.which == 13) {
        $("#btnGetAnaltyticsData").click();
        return false;
    }
});


function GetAnalyticsData(days) {    
    var today = new Date();
    var previousDate = new Date();
    previousDate.setDate(previousDate.getDate() - days);
    var dateTo = (today.getMonth() + 1) + "/" + today.getDate() + "/" + today.getFullYear();
    var dateFrom = (previousDate.getMonth() + 1) + "/" + previousDate.getDate() + "/" + previousDate.getFullYear();

    var inputObj = { screenName: screenName, tableName: "AnalyticsUser",
        data: { groupId: $("#txtGroupId").val(), ScreenId: $("#txtScreenId").val(), DateFrom: dateFrom + " 00:00:00", DateTo: dateTo + " 23:59:59" }
    };

    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            createTopUsage(result.rows, "User");
            generateBar(result.rows, "user");
        }
        ajaxRequest = retval.AjaxObj;
    });
    inputObj.tableName = "AnalyticsScreen";
    var retvalUser = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", true);
    $.when(retvalUser.AjaxObj).done(function () {
        var result = retvalUser.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {

            createTopUsage(result.rows, "Screen");
            generateBar(result.rows, "screen");
        }
        ajaxRequest = retvalUser.AjaxObj;
    });

    inputObj.tableName = "SkipApproval";
    var retvalSkipApproval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", true);
    $.when(retvalSkipApproval.AjaxObj).done(function () {
        var result = retvalSkipApproval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {

            createTopUsage(result.rows, "Skip");
        }
        ajaxRequest = retvalSkipApproval.AjaxObj;
    });

    inputObj.tableName = "TopQueries";
    var retvalTopQueries = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", true);
    $.when(retvalTopQueries.AjaxObj).done(function () {
        var result = retvalTopQueries.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            createTopUsage(result.rows, "Query");
            generateBar(result.rows, "query");
        }
        ajaxRequest = retvalTopQueries.AjaxObj;
    });
//        inputObj.tableName = "TopTables";
//        var retvalTopTables = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", true);
//        $.when(retvalTopTables.AjaxObj).done(function () {
//            var result = retvalTopTables.AjaxObj.responseJSON;
//            if (result.errorMessage == null || result.errorMessage == "") {
//                createTopUsage(result.rows, "Table");
//                generateBar(result.rows, "table");
//            }
//            ajaxRequest = retvalTopTables.AjaxObj;
//        });

    $(".controls").click(function () {
        $(".controls").removeClass("activeControl");
        $(this).addClass("activeControl");
    });
}

function stopAjax() {
    ajaxRequest.abort();
    ajaxRequest = "";
}

function clearGroupIdTextbox() {
    $("#hdnGroupId").val('');
}

function clearScreenIdTextbox(id) {
    $("#hdnScreenId").val(id);
}

