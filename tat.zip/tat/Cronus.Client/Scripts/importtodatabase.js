﻿"use strict";
var screenName = Cronus.Screens.ImportToDatabase;
var dtImportData, dtDupFileData, dtUniqueFileData;
var headers = [];
var dataTableArray = [];
var uniqArray = [];
var databases = {};

$(document).ready(function () {
    if (!Cronus.selectedPage(screenName, Cronus.Actions.ImportToDatabase_View)) {
        return;
    }

    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.ImportToDatabase_Import, screenName) == false) {
        $("#btnImportToDatabase").attr('disabled', true);
        $("#btnImportToDatabase").addClass('disabledbtn');
    }

    getDataBase();
    populateDatabaseDropDown();
    $('#btnImportToDatabase').click(function () {
        importToDatabase(false, dataTableArray, "#btnImportToDatabase");
    });
    $('#btnImportAll').click(function () {
        importToDatabase(true, dataTableArray, "#btnImportAll");
    });
    $('#btnImportUnique').click(function () {
        importToDatabase(true, uniqArray, '#btnImportUnique');
    });
});

function getDataBase() {
    var inputObj = { screenName: screenName, tableName: "GetDataBase" };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlayQuery", false);
    if (retval.Error == false) {
        var result = retval.Result;
        $.each(result.rows, function (index, value) {
            if (!(value[2] in databases)) {
                databases[value[2]] = {};
            }
            databases[value[2]][value[0]] = value[1];
        });
    }
}

function clearFileBrower() {

    Cronus.destroyDataTable(dtImportData, '#dtFileData');
    Cronus.destroyDataTable(dtDupFileData, '#dtDupFileData');
    Cronus.destroyDataTable(dtUniqueFileData, '#dtUniqueFileData');

    headers = [];
    dataTableArray = [];
    uniqArray = [];

    $("#txtFileName").text("");
    var input = $("#importDataFile");
    input.replaceWith(input.val('').clone(true));
    $(".blockOverlay").css('display', 'none');
}

function importToDatabase(proceedAnyway, rows, btnElm) {
    var table = $("#txtTable").val();

    if ($('#txtTable').val() == undefined || $('#txtTable').val() == "" || $('#txtTable').val() == null) {
        //clearFileBrower();
        $('#txtTable').focus();
        swal("Error", "Table name is madatory", "error");
        return;
    }

    if (table.indexOf('.') === -1) {
        swal("Error", "Schema name is mandatory with table", "error");
        return;
    }

    var database = $("#ddlDatabase").val();

    if (database.indexOf('SYB') !== -1 && table.indexOf('..') === -1) {
        swal("Error", "wrong table format for sybase. This should be schema..table", "error");
        return;
    }

    if (database.indexOf('ORA') !== -1 && table.indexOf('..') > 0) {
        swal("Error", "wrong table format for Oracle. This should be schema.table", "error");
        return;
    }

    if (rows.length === 0) {
        swal("There is no data to submit !!", "", "error");
        return;
    }

    var inputObj = { screenName: screenName,
        data: { ProcceedAnyway: proceedAnyway, headers: headers, rows: rows, table: table, database: database }
    };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, null, true, btnElm);

    $.when(retval.AjaxObj).done(function () {

        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            if (result.dupRows) {
                $('#myModal').modal('show');
                $("#duplicateDataMesage").text("Following entries are duplicate");
                dtDupFileData = Cronus.refreshDataTable(dtDupFileData, $("#dtDupFileData"), headers, result.dupRows);
                if (result.uniqRows.length) {
                    $("#rowsPresent").show();
                    $("#rowsAbsent").hide();
                    dtUniqueFileData = Cronus.refreshDataTable(dtUniqueFileData, $("#dtUniqueFileData"), headers, result.uniqRows);
                    uniqArray = result.uniqRows;
                }
                else {
                    $("#rowsPresent").hide();
                    $("#rowsAbsent").show();
                }
            } else {
                swal("Info", "Data Inserted successfully in " + table, "success");
                clearFileBrower();
            }
            //   clearFileBrower();
            //resetScreen();

        }
    });

}
function readDataFile(input) {

    $("#txtFileName").text(input.files[0].name);

    $("#txtFileName").css('color', '');

    if (input.files && input.files[0]) {
        var reader = new window.FileReader();
        $(".blockOverlay").css('display', 'block');
        reader.onload = function (e) {
            try {
                loadFile(e.target.result, ",");

            } catch (err) {

                $(".blockOverlay").css('display', 'none');
                // Clear file browser
                clearFileBrower();
                swal("Error", err, "error");
            }
        };
        reader.readAsText(input.files[0]);
    }
    input = $("#importDataFile");
    input.replaceWith(input.val('').clone(true));
}


function loadFile(text, seperator) {

    var lines = text.split(/[\r\n]+/g).filter(function (x) { return x && x.trim(); }); // tolerate both Windows and Unix linebreaks    
    if (lines.length <= 0) {
        throw ("No data in file");
    }
    headers = lines[0].split(',');
    dataTableArray = [];
    var dataDict = {};
    for (var i = 1; i < lines.length; i++) {
        var line = lines[i];
        if (line === "" || line == undefined || line == null)
            continue;
        if (line.match(/^#/))
            continue;

        if (dataDict[line] == 1) {
            throw ("this row  " + line + "  is dulplicate. Please remove duplicate entries and try again");
            return -1;
        }
        dataDict[line] = 1;

        var data = line.split(',');
        if (data.length == headers.length) {

            //create data row
            var datarow = [];
            for (var index = 0; index < headers.length; index++) {
                datarow.push(data[index]);
            }
            dataTableArray.push(datarow);
        }

    }
    //console.log(dataDict);
    dtImportData = Cronus.refreshDataTable(dtImportData, $("#dtFileData"), headers, dataTableArray);
    $(".blockOverlay").css('display', 'none');
}



function openfileuploader() {
    $("#importDataFile").click();
}

/*This function populate the database dropdown */
function populateDatabaseDropDown() {
    var environment = $("#ddlCommanEnviroment").val();
    if (databases[environment] == undefined) {
        swal("Error", "Database Detail not found", "error");
        return false;
    }
    $("#ddlDatabase").html("");

    for (var key in databases[environment]) {
        $("#ddlDatabase").append('<option value="' + databases[environment][key] + '">' + databases[environment][key] + '</option>');
    }
    return true;
}
