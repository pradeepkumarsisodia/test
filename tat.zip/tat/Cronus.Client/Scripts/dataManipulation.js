﻿"use strict";
var screenName = Cronus.Screens.DataManipulation;
var dt;
var tableData;
var databases = {};
var tableName;
var whereClause;
var tableStructuer;

$(document).on("ready", function () {

    if (!Cronus.selectedPage(screenName, Cronus.Actions.DataManipulation_View)) {
        return;
    }
    //Permission Check
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.DataManipulation_Search, screenName) == false) {
        $("#btnSearch").attr('disabled', true);
        $("#btnSearch").addClass('disabledbtn');
    }
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.DataManipulation_Save, screenName) == false) {
        $("#btnSave").attr('disabled', true);
        $("#btnSave").addClass('disabledbtn');
    }
    //get all the database which can be updated by this screen
    getDataBase();
    populateDatabaseDropDown();
    $('.dis').attr('disabled', true);
    $('#ddlTableColumns').multiselect({
        includeSelectAllOption: true,
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        buttonWidth: false,
        onDropdownHidden: function (event) {
        }
    });

    //show login screen
    $('#divLogin').modal('show');

    //On click of login button of modal
    $('#btnLogin').click(function () {
        login();
    });
    //press enter key on password box.
    $('#txtLoginPassword').bind("keypress", function (e) {
        if (e.keyCode == 13) {
            $('#btnLogin').click();
        }
    });
    //on click of login button on main screen
    $('#btnShowlogin').click(function () {
        showLoginClick();
    });

    //On click of search button
    $('#btnSearch').click(function () {
        searchData();
    });

    $("#btnEditInline").click(function () {
        makeDataTableEditable();
    });

    $("#btnAdd").click(function () {
        addRow();
    });

    $("#btnEdit").click(function () {
        cloneRow("Edit", "Update");
    });

    $("#btnDelete").click(function () {
        markForDelete();
    });

    $("#btnRevert").click(function () {
        revertChanges();
    });

    $("#btnClone").click(function () {
        cloneRow("Clone", "Add");
    });

    $("#btnSave").click(function () {
        saveChanges();
    });

    $("#btnAddNewRow").click(function () {
        var $tableBody = $('#tableCommon').find("tbody"),
        $trLast = $tableBody.find("tr:last"),
        $trNew = addRowInModal();
        $trLast.after($trNew);

    });
    $("#btnsubmitdata").click(function () {
        SavePopUpData();
    });
    $('#txttableName').bind("keypress", function (e) {
        if (e.keyCode == 13) {
            $('#btnSearch').click();
        }
    });
});
function SavePopUpData() {
    $("#divCommonModel > #tableCommon > tbody > tr").each(function () {
        // $this = $(this);
        var rowData = new Array();
        var rowId = $(this).attr('id');
        $(this).find("td :input").each(function () {
            var value = $(this).val() == "" ? null : $(this).val();
            rowData.push(value);
        });
        updateRowFromModal(rowData, rowId);
    });

    $('.singleselect').prop('checked', false);
    $('#example-select-all').prop('checked', false);
    $("#modalCommanDML").modal("hide");
}

function checkRowChecked() {
    if ($("input:checked").length == 0) {
        swal('error', "Please select atleast one row", "error");
        return false;
    }
}

function getDataBase() {
    var inputObj = { screenName: screenName, tableName: "GetDataBase" };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlayQuery", false);
    if (retval.Error == false) {
        var result = retval.Result;
        $.each(result.rows, function (index, value) {
            if (!(value[2] in databases)) {
                databases[value[2]] = {};
            }
            databases[value[2]][value[0]] = value[1];
        });
    }
}

function populateDatabaseDropDown() {
    var environment = $("#ddlCommanEnviroment").val();
    if (databases[environment] == undefined) {
        swal("Error", "Database Detail not found", "error");
        return false;
    }
    $("#ddlLoginDatabase").html("");

    for (var key in databases[environment]) {
        $("#ddlLoginDatabase").append('<option value="' + databases[environment][key] + '">' + databases[environment][key] + '</option>');
    }
    return true;
}

function bindColumns() {
    $('#ddlTableColumns').multiselect("destroy");
    $('#ddlTableColumns').empty();

    for (var i = 0; i < tableData.columns.length; i++) {
        $('<option>').val(i + 1).text(tableData.columns[i]).appendTo('#ddlTableColumns');
    }

    $('#ddlTableColumns').multiselect({
        includeSelectAllOption: true,
        enableFiltering: true,
        enableCaseInsensitiveFiltering: true,
        buttonWidth: false,
        onDropdownHidden: function (event) {
            var ddlSelectedValues = new Array();
            ddlSelectedValues = $('#ddlTableColumns').val();
            var columns = $("#dtdata").dataTable().dataTableSettings[0].aoColumns;
            $.each(columns, function (i, v) {
                if (jQuery.inArray(String(i), ddlSelectedValues) !== -1) {
                    if (v.bVisible == false) {
                        dt.fnSetColumnVis(i, true, false);
                    }
                }
                else {
                    dt.fnSetColumnVis(i, false, false);
                }

            });
            dt.fnSetColumnVis(0, true, false);
            dt.fnDraw();
        }
    });
    $("#ddlTableColumns").multiselect("selectAll", false);
}

function showLoginClick() {
    if ($('#btnShowlogin').val() == "Login") {
        $('#txtLoginUserId').val('');
        $('#txtLoginPassword').val('');
        $('#divLogin').modal("show");
    }
    else {
        swal({
            title: "Warning: ", text: "Do you want to logout? \n Window will reload.", type: "warning", showCancelButton: true, confirmButtonColor: "#2e6da4",
            confirmButtonText: "Cancel", cancelButtonText: "Ok", cancelButtonColor: "#2e6da4", closeOnConfirm: true, closeOnCancel: false
        },
        function (isConfirm) {
            if (!isConfirm) {
                $('#btnShowlogin').val('Login');
                location.reload();
            }
        });
    }
}

function login() {
    if ($('#txtLoginUserId').val() != '' && $('#txtLoginPassword').val() != '') {
        var loginObj = {
            userId: $('#txtLoginUserId').val(),
            password: $('#txtLoginPassword').val(),
            dbName: $('#ddlLoginDatabase').val()
        };
        var inputObj = { screenName: screenName, data: loginObj, functionName: "Login" };
        var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, ".blockOverlayQuery", false);
        $.when(retval.AjaxObj).done(function () {
            var result = retval.AjaxObj.responseJSON;
            if (result.status) {
                $('#lblSelectedDatabase').html("Database : " + $('#ddlLoginDatabase').val());
                $('#lblCurrentlogedInUser').html("Logged In As : " + $('#txtLoginUserId').val());
                $('#lblCurrentlogedInUser').css("color", "green");
                $('#btnShowlogin').val('Logout');
                $('.ale').attr('disabled', false);
                $('.multiselect').attr('disabled', false);
                $('#divLogin').modal('hide');
            }
            else {
                swal("Error", "Login Failed", "error");
            }

        });
    }
    else {
        swal("Error", "Please enter UserId and Password.", "error");
    }
}

function searchData() {
    if ($("#txttableName").val() == null || $("#txttableName").val() == "") {
        swal("error", "Please enter table name", "error");
        return;
    }
    var loginObj = {
        userId: $('#txtLoginUserId').val(),
        password: $('#txtLoginPassword').val(),
        dbName: $('#ddlLoginDatabase').val()
    };
    var dataobj = {
        loginData: loginObj,
        tableName: $("#txttableName").val(),
        whereClause: $("#txtConditon").val()
    };
    var inputObj = {
        screenName: screenName,
        functionName: "SearchData",
        data: dataobj
    };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, null, true, '#btnSearch');
    $.when(retval.AjaxObj).done(function () {
        var results = retval.AjaxObj.responseJSON;
        if (results.errorMessage == null || results.errorMessage == "") {
            tableName = $("#txttableName").val();
            whereClause: $("#txtConditon").val()
            tableData = jQuery.extend(true, {}, results.data);
            getTableStructuer();
            bindColumns();
            populateData(results.data);
            $("#btnAdd, #btnEdit, #btnDelete, #btnRevert, #btnSave, #btnClone").attr('disabled', false);
        }
        else { $("#btnEdit, #btnDelete").attr('disabled', true); }
    });
}

function getTableStructuer() {
    var loginObj = {
        userId: $('#txtLoginUserId').val(),
        password: $('#txtLoginPassword').val(),
        dbName: $('#ddlLoginDatabase').val()
    };
    var dataobj = {
        loginData: loginObj,
        tableName: $("#txttableName").val(),
        whereClause: $("#txtConditon").val()
    };
    var inputObj = {
        screenName: screenName,
        functionName: "TableDetail",
        data: dataobj
    };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, null, true, '#btnSearch');
    $.when(retval.AjaxObj).done(function () {
        var results = retval.AjaxObj.responseJSON;
        if (results.errorMessage == null || results.errorMessage == "") {
            tableStructuer = jQuery.extend(true, {}, results.data);
        }

    });
}
function populateData(data, editable) {
    var columns = data.columns;
    var rows = data.rows;
    var dataTableArray = [];
    //Add First column as check box
    columns.splice(0, 0, '<input type="checkbox" name="select_all" value="1" id="example-select-all">');
    //Add status as last column
    columns.push('Status');
    for (var i = 0; i < rows.length; i++) {
        var datarow = [];
        //Add first row as check box
        datarow.push('<input type="checkbox" name="id_' + i + '" class="singleselect" value=' + i + '\>');
        // columns.length - 2 becasue we add two more columns checkbox and status columns
        for (var j = 0; j < columns.length - 2; j++) {
            datarow.push(rows[i][j]);
        }
        datarow.push(0);
        dataTableArray.push(datarow);
    }

    dt = Cronus.refreshDataTable(dt, $("#dtdata"), columns, dataTableArray, null, [{ orderable: false, targets: 0 }]);
    dt.fnSetColumnVis(columns.length - 1, false);
    $('#example-select-all').on('click', function () {
        // Check/uncheck checkboxes for all rows in the table
        $('.singleselect').prop('checked', this.checked);
    });

    $('#dtdata tbody').on('change', '.singleselect', function () {
        // If checkbox is not checked
        if (!this.checked) {
            var el = $('#example-select-all').get(0);
            // If "Select all" control is checked and has 'indeterminate' property
            if (el && el.checked && ('indeterminate' in el)) {
                // Set visual state of "Select all" control 
                // as 'indeterminate'
                el.indeterminate = true;
            }
        }
    });
    $('#dtdata tbody').on('dblclick', 'td', function (el) {
        var positions = dt.fnGetPosition(this);
        //if row marked for delete, the row cannot be edited
        var node = dt.fnGetNodes(positions[0]);
        if (getStatusValue(node) == 1)
            return;
        //check if cell is html
        if (String(dt.fnGetData(positions[0])[positions[2]]).indexOf('<input type') == -1) {
            var id = positions[0] + '_' + positions[2];
            var value = dt.fnGetData(positions[0])[positions[1]];
            value = value == null ? "" : value;
            var inputHtml = CreateTextBoxControlDataTable(value, (parseInt(positions[2]) - 1), positions[0], id);
            dt.fnUpdate(inputHtml, positions[0], positions[2], false);
            $("#txtval" + id).val(value);
            ShowBorder("txtval" + id);
            $(".date-field").mask("9999-99-99");
            $(".datetime-field").mask("9999-99-99 99:99:99");
        }
    });
}

function saveChanges() {
    var beforeUpdateData = jQuery.extend(true, {}, tableData);
    var afterUpdateData = jQuery.extend(true, {}, tableData);
    var insertData = jQuery.extend(true, {}, tableData);
    var deleteData = jQuery.extend(true, {}, tableData);
    beforeUpdateData.rows = [];
    afterUpdateData.rows = [];
    insertData.rows = [];
    deleteData.rows = [];
    var rowEffected = 0;
    var allData = dt.fnGetData();
    $(allData).each(function (rowIndex, rowData) {
        var cellData = rowData[rowData.length - 1];
        var updatedRowData = jQuery.extend(true, [], rowData);
        updatedRowData.splice(0, 1);
        if (cellData == 1) {
            deleteData.rows.push(updatedRowData);
            rowEffected++;
        }
        else if (cellData == 2) {
            insertData.rows.push(updatedRowData);
            rowEffected++;
        }
        else if (cellData == 3) {
            afterUpdateData.rows.push(updatedRowData);
            beforeUpdateData.rows.push(tableData.rows[rowIndex]);
            rowEffected++;
        }
    });

    if (rowEffected == 0) {
        swal("error", "There is not data for Insert,Update or Delete.", "error");
        return;
    }

    var loginobj = {
        userId: $('#txtLoginUserId').val(),
        password: $('#txtLoginPassword').val(),
        dbName: $('#ddlLoginDatabase').val()
    };
    var dataobj = {
        loginData: loginobj,
        tableName: $("#txttableName").val(),
        beforeUpdateData: beforeUpdateData,
        afterUpdateData: afterUpdateData,
        insertData: insertData,
        deleteData: deleteData
    };
    var inputObj = {
        screenName: screenName,
        data: dataobj
    };
    // data["UniqueColumns"] = uniquecolumsvaluedata;
   

    swal({
        html: true,
        title: "Are you sure?", text: rowEffected + " row/s will be affected </br> <b> Do you wish to continue? </b>", type: "info", showCancelButton: true, confirmButtonColor: "#2e6da4",
        confirmButtonText: "No", cancelButtonText: "Yes", cancelButtonColor: "#2e6da4", closeOnConfirm: true, closeOnCancel: false
    },
 function (isConfirm) {
     if (!isConfirm) {
         swal.close();
         var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, null, true, null);
         $.when(retval.AjaxObj).done(function () {
             var result = retval.AjaxObj.responseJSON;
             if (result.errorMessage == null || result.errorMessage == "") {
                 //   $("#modalCommanDML").modal("hide")
                 swal("Info", "Changes done successfully", "success");
                 $('#txttableName').val(tableName);
                 $('#txtConditon').val(whereClause);
                 searchData();

             }
         });
     }
     else { return true; }
 });
}

function getStatusValue(node) {
    return dt.fnGetData(node)[tableData.columns.length + 1];
}

function updateRow(el) {
    var id = $(el).attr("id");
    var colid = $(el).attr("col_id");
    var rowid = $(el).attr("row_id");
    var myInput = document.getElementById(id).style;
    myInput.border = "none";
    myInput.background = "transparent";
    var node = dt.fnGetNodes(rowid);
    if (parseInt(rowid) <= (tableData.rows.length - 1)) {
        if ((tableData.rows[rowid][parseInt(colid) - 1] == null && $("#" + id).val() != "")
            || (tableData.rows[rowid][parseInt(colid) - 1] != null && $("#" + id).val() == "")
            || ((tableData.rows[rowid][parseInt(colid) - 1] != null && $("#" + id).val() != "") && tableData.rows[rowid][parseInt(colid) - 1] != $("#" + id).val())) {
            if (getStatusValue(node) == 0) {
                dt.fnUpdate(3, node, dt.fnGetData(node).length - 1, false);
                $(node).css('background-color', 'yellow');
            }
            if (getStatusValue(node) == 0 || getStatusValue(node) == 3)
                $(node.childNodes[parseInt(colid)]).css('color', 'red');
        }
        else {
            $(node.childNodes[parseInt(colid)]).css('color', 'black');
        }
    }
    if ($("#" + id).val() == "")
        dt.fnUpdate(null, node, parseInt(colid), false);
    else
        dt.fnUpdate($("#" + id).val(), node, parseInt(colid), false);
}

function ShowBorder(id) {
    // var id = $(el).attr("id");
    var myInput = document.getElementById(id).style;
    myInput.borderStyle = "solid";
    myInput.background = "";
    document.getElementById(id).focus();
}

function markForDelete() {
    $(".singleselect:checked").each(function () {
        var node = dt.fnGetNodes(this.value);
        $(node).css('background', 'red');
        dt.fnUpdate(1, node, dt.fnGetData(node).length - 1, false);
    });
    $('.singleselect').prop('checked', false);
}

function addRow() {
    populateModal(undefined, 'Add', 'Insert', true);
}

function addRowInModal(rowData) {
    rowId++;
    var html = "";
    if (rowData == undefined) {
        html += '<tr>';
        for (var l = 0; l < tableData.columns.length; l++) {
            //html += '<td style="line-height:30px">' + '<input type="text" style="width:100px" class="form-control" id="txt' + l + '" />' + '</td>';
            html += '<td style="line-height:30px">' + CreateTextBoxControl("", l) + '</td>';
        }
        html += '</tr>';
    }
    else {
        html += '<tr id="' + $(rowData[0]).val() + '">';
        for (var l = 0; l < tableData.columns.length; l++) {
            // html += '<td style="line-height:30px">' + '<input type="text" style="width:100px" class="form-control" id="txt' + l + '" value = "' + (rowData[l + 1] == null ? '' : rowData[l + 1]) + '" />' + '</td>';
            var value = rowData[l + 1] == null ? '' : rowData[l + 1];
            html += '<td style="line-height:30px">' + CreateTextBoxControl(value, l) + '</td>';
        }
    }

    html += '</tr>';

    return html;
}
function CreateTextBoxControlDataTable(value, colIndex, rowId, controlId) {

    var textboxHtml = "";
    var id = tableStructuer.rows[colIndex][0];
    var length = tableStructuer.rows[colIndex][2];
    var datatype = tableStructuer.rows[colIndex][1];

    if (datatype.toLowerCase().match(/^.*int.*$/)) {
        textboxHtml = '<input type="text" row_id = "' + rowId + '" col_id = "' + (parseInt(colIndex) + 1) + '"  id="txtval' + controlId + '" maxlength="' + length + '"  datatype = "' + datatype + '" columnname ="' + id + '" oldvalue="' + value + '" style="border:none; background:transparent"  placeholder="' + id + '" onkeypress="Cronus.validAbsIntiger(event)" onblur="updateRow(this)" />'
    }
    else if (datatype.toLowerCase() == "float" || datatype.toLowerCase() == "decimal" || datatype.toLowerCase() == "numeric" || datatype.toLowerCase() == "identity" || datatype.toLowerCase() == "real" || datatype.toLowerCase() == "number" || datatype.toLowerCase() == "money" || datatype.toLowerCase() == "smallmoney") {
        textboxHtml = '<input type="text" row_id = "' + rowId + '" col_id = "' + (parseInt(colIndex) + 1) + '" class="form-control" id="txtval' + controlId + '" maxlength="' + length + '" datatype = "' + datatype + '" columnname ="' + id + '" oldvalue="' + value + '" style="border:none; background:transparent"  placeholder="' + id + '" onkeypress="Cronus.validReal(event)" onblur="updateRow(this)" />'
    }
    else if (datatype.toLowerCase() == "date") {
        textboxHtml = '<input type="text" row_id = "' + rowId + '" col_id = "' + (parseInt(colIndex) + 1) + '" class="form-control date-field" id="txtval' + controlId + '"  datatype = "' + datatype + '" columnname ="' + id + '" oldvalue="' + value + '"  style="border:none; background:transparent" title ="yyyy-mm-dd"  placeholder="yyyy-mm-dd" onblur="datetimeFormat(this),updateRow(this)"  />'
    }
    else if (datatype.toLowerCase() == "datetime" || datatype.toLowerCase().indexOf("timestamp") >= 0) {
        textboxHtml = '<input type="text" row_id = "' + rowId + '" col_id = "' + (parseInt(colIndex) + 1) + '" class="form-control datetime-field" id="txtval' + controlId + '"   datatype = "' + datatype + '" columnname ="' + id + '" oldvalue="' + value + '"  style="border:none; background:transparent" title ="yyyy-mm-dd HH:MM:SS"  placeholder="yyyy-mm-dd HH:MM:SS" onblur="datetimeFormat(this),updateRow(this)"  />'
    }
    else {
        textboxHtml = '<input type="text" row_id = "' + rowId + '" col_id = "' + (parseInt(colIndex) + 1) + '" class="form-control" id="txtval' + controlId + '" maxlength="' + length + '"  datatype = "' + datatype + '" columnname ="' + id + '" oldvalue="' + value + '" style="border:none; background:transparent"  placeholder="' + id + '" onblur="updateRow(this)"  />'
    }
    return textboxHtml;
}

function CreateTextBoxControl(value, colIndex) {

    var textboxHtml = "";
    var id = tableStructuer.rows[colIndex][0];
    var length = tableStructuer.rows[colIndex][2];
    var datatype = tableStructuer.rows[colIndex][1];
    //  var datedata = "";


    if (datatype.toLowerCase().match(/^.*int.*$/)) {
        textboxHtml = '<input type="text"  class="form-control" id="txt' + id + '" maxlength="' + length + '" value = "' + value + '" datatype = "' + datatype + '" columnname ="' + id + '" oldvalue="' + value + '" style="width:100px" placeholder="' + id + '" onkeypress="Cronus.validAbsIntiger(event)"/>'
    }
    else if (datatype.toLowerCase() == "float" || datatype.toLowerCase() == "decimal" || datatype.toLowerCase() == "numeric" || datatype.toLowerCase() == "identity" || datatype.toLowerCase() == "real" || datatype.toLowerCase() == "number" || datatype.toLowerCase() == "money" || datatype.toLowerCase() == "smallmoney") {
        textboxHtml = '<input type="text" class="form-control" id="txt' + id + '" maxlength="' + length + '" value = "' + value + '" datatype = "' + datatype + '" columnname ="' + id + '" oldvalue="' + value + '" style="width:100px" placeholder="' + id + '" onkeypress="Cronus.validReal(event)"/>'
    }
    else if (datatype.toLowerCase() == "date") {
        textboxHtml = '<input type="text" class="form-control date-field" id="txt' + id + rowId + '" title ="yyyy-mm-dd"  value = "' + value + '" datatype = "' + datatype + '" columnname ="' + id + '" oldvalue="' + value + '"  style="width:100px" placeholder="yyyy-mm-dd"  />'
    }
    else if (datatype.toLowerCase() == "datetime" || datatype.toLowerCase().indexOf("timestamp") >= 0) {
        textboxHtml = '<input type="text" class="form-control datetime-field" id="txt' + id + rowId + '" title ="yyyy-mm-dd HH:MM:SS"  value = "' + value + '" datatype = "' + datatype + '" columnname ="' + id + '" oldvalue="' + value + '"  style="width:100px" placeholder="yyyy-mm-dd HH:MM:SS"  />'
    }
    else {
        textboxHtml = '<input type="text" class="form-control" id="txt' + id + '" maxlength="' + length + '" value = "' + value + '" datatype = "' + datatype + '" columnname ="' + id + '" oldvalue="' + value + '" style="width:100px" placeholder="' + id + '" />'
    }
    return textboxHtml;
}

function datetimeFormat(el) {
    var data = $(el).val();
    if (data == undefined || data == null || data == "") {
        return "";
    }
    var datetimearray = new Array();
    datetimearray = data.split(" ");
    var date = datetimearray[0];
    var datearray = date.split("-");
   
    if (datetimearray[0].indexOf("_") >= 0) {
        $(el).val("");
        return;
    }
    var time = "";
    if (datetimearray[1] != undefined) {
        time = datetimearray[1].replace(new RegExp("_", "ig"), "0");
    }
    else {
        time = "00:00:00";
    }
    $(el).val(datetimearray[0]+ " " + time);

}

var rowId;
function populateModal(rowsData, popUpHeader, buttonText, addMoreRows) {
    $("#divCommonModel").empty();
    $("#spnPopUpHeader").text(popUpHeader);
    rowId = 0;
    //header html
    var html = "<table id ='tableCommon' class='table table-striped table-bordered table-hover'>";
    html += "<thead>";
    for (var l = 0; l < tableData.columns.length; l++) {
        html += '<th style="line-height:30px">' + tableData.columns[l] + '</th>';
    }
    html += "</thead>";

    //data html
    html += "<tbody>";
    if (rowsData == undefined) {

        html += addRowInModal();
    }
    else {
        for (var i = 0; i < rowsData.length; i++) {

            html += addRowInModal(rowsData[i]);
        }
    }
    html += "</tbody>";
    html += "</table>";
    $("#divCommonModel").append(html);
    $(".date-field").mask("9999-99-99");
    $(".datetime-field").mask("9999-99-99 99:99:99");
    if (addMoreRows == undefined)
        $("#btnAddNewRow").css("visibility", "hidden");
    else
        $("#btnAddNewRow").css("visibility", "visible");
    $("#btnsubmitdata").text(buttonText);
    $("#modalCommanDML").modal("show");
}

function cloneRow(popUpHeader, buttonText) {

    var rowsData = [];
    $(".singleselect:checked").each(function () {
        if (this.value != "multiselect-all") {
            var node = dt.fnGetNodes(parseInt(this.value));
            if (getStatusValue(node) != 1) {
                var rowData = jQuery.extend(true, [], dt.fnGetData(parseInt(this.value)));
                rowsData.push(rowData);
            }
        }
    });
    if (rowsData.length > 0)
        populateModal(rowsData, popUpHeader, buttonText, undefined);

    $('.singleselect').prop('checked', false);
}
function updateRowFromModal(rowData, rownumber) {
    if ($("#btnsubmitdata").text() == "Update") {
        //var rowDataInDt = dt.fnGetData(rownumber);
        var rowDataInDt = jQuery.extend(true, [], dt.fnGetData(rownumber));
        rowDataInDt
        .splice(tableData.columns.length + 1, 1);
        rowDataInDt.splice(0, 1);
        var valueChanged = false;
        var node = dt.fnGetNodes(rownumber);
        for (var i = 0; i < tableData.columns.length; i++) {
            var currentData = rowData[i] == "" ? null : rowData[i];
            var oldData = rowDataInDt[i];
            if (oldData != currentData) {
                valueChanged = true;
                if (rowData[i] == "")
                    dt.fnUpdate(null, rownumber, i + 1, false);
                else
                    dt.fnUpdate(rowData[i], rownumber, i + 1, false);
                $(node.childNodes[i + 1]).css('color', 'red');
            }
            else
                $(node.childNodes[i + 1]).css('color', 'black');
        }

        if (valueChanged) {
            if (getStatusValue(node) == 0) {
                dt.fnUpdate(3, node, dt.fnGetData(node).length - 1, false);
                $(node).css('background-color', 'yellow');
            }
        }
    }
    else if ($("#btnsubmitdata").text() == "Insert" || $("#btnsubmitdata").text() == "Add") {
        var tmpRowdata = [];
        var val = dt.fnGetData().length;
        tmpRowdata.push('<input type="checkbox" name="id_' + val + '" class="singleselect" value=' + val + '\>');
        for (var i = 0; i < rowData.length; i++) {
            if (rowData[i] == "")
                tmpRowdata.push(null);
            else
                tmpRowdata.push(rowData[i]);
        }
        tmpRowdata.push(2);
        var row_id = dt.fnAddData(tmpRowdata);
        dt.fnSort([tableData.columns.length + 1, 'desc']);
        dt.fnFilter('');
        var node = dt.fnGetNodes(row_id);
        $(node).css('background', 'green');
    }
}

function makeDataTableEditable() {
    var rows = dt.fnGetNodes();
    $('.singleselect').prop('checked', false);
}

function revertChanges() {
    var rownumbers = [];
    $(".singleselect:checked").each(function () {
        if (this.value != "multiselect-all") {
            rownumbers.push(parseInt(this.value));
        }
    });
    rownumbers.sort(function (a, b) {
        return a - b;
    }).reverse();
    $(rownumbers).each(function (index, rowNumber) {
        if (rowNumber >= tableData.rows.length) {
            dt.fnDeleteRow(rowNumber);

            for (var i = rowNumber; i < dt.fnGetData().length; i++) {
                dt.fnUpdate('<input type="checkbox" name="id_' + i + '" class="singleselect" value=' + i + '\>', i, 0, false);
            }
        }
        else {
            var node = dt.fnGetNodes(rowNumber);
            $(node).css('background', 'transparent');
            var rowData = dt.fnGetData(node);
            for (var i = 0; i < tableData.columns.length - 1; i++) {
                rowData[i + 1] = tableData.rows[rowNumber][i];
                $(node.childNodes[i + 1]).css('color', 'black');
            }
            rowData[rowData.length - 1] = 0;
            dt.fnUpdate(rowData, node);
        }
    });
    $('.singleselect').prop('checked', false);
}
