﻿
//class constructor to create instance of CronusServerProxy
function CronusServerProxy(screenName) {

    //private members
    var _screenName = screenName;

    //instance method
    this.getScreenName = function () {
        return _screenName;
    };
}

CronusServerProxy.prototype = {

    constructor: CronusServerProxy,

    fetchCycleAndPreviosDate: function (onComplete) {

        var inputObj = { screenName: this.getScreenName() };

        var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchCycleAndPreviosDate, ".blockOverlay", true);
        $.when(retval.AjaxObj).done(function () {
            var result = retval.AjaxObj.responseJSON;
            if (result.errorMessage == null || result.errorMessage === "") {
                if (result.CycleDate != null && onComplete)
                    onComplete(result.CycleDate);
            }
        });
    },

    register: function (requestId, register, onSubmitted) {

        var request = {
            RequestId: requestId,
            ScreenName: this.getScreenName(),
            Register: register,
            RedirectionUrl: window.location.href + "?id=" + requestId
        };

        var retval = Cronus.ajaxCall(request, Cronus.RestApi.Register, ".blockOverlay", true);
        $.when(retval.AjaxObj).done(function () {
            var response = retval.AjaxObj.responseJSON;
            console.log("registration : ", response);
        });
    },

    fetchDataForTable: function (tableName, data, onSuccess, onError) {

        //request.tableName
        // request.data
    },

    fetchRegistrations: function (requestIds, onSuccess) {

        var request = {
            ScreenName: this.getScreenName(),
            RequestIds: requestIds
        };

        var retval = Cronus.ajaxCall(request, Cronus.RestApi.FetchRegistrations, ".blockOverlay", true);
        $.when(retval.AjaxObj).done(function () {
            var response = retval.AjaxObj.responseJSON;
            console.log("GetRegistrations : ", response);
            if (onSuccess)
                onSuccess(response);
        });
    }
};