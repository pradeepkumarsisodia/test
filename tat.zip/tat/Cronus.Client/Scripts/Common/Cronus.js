﻿var Cronus = function (module) {
    // common.js functions 


    function isNotEmptyNullOrUndefined(data) {
        return (data !== undefined) && (data !== null) && (data !== "");
    }

    var selectedPage = function (screenName, viewPermission) {
        $("title").html("Cronus: " + screenName);
        $(".selectedTab").removeClass("selectedTab");
        //var anchorId = screenNamePageDict[screenName];
        var anchorId = Cronus.Compliance.ScreenNamePageDict[screenName];
        var treeMenu = $("#" + anchorId).parent().parent();
        if (treeMenu != undefined && treeMenu[0].classList.contains("treeview-menu")) {
            treeMenu.addClass('menu-open');
            var treeView = treeMenu.parent();
            if (treeView != undefined && treeView[0].classList.contains("treeview")) {
                treeView.addClass('active');
            }
        }

        $("#" + anchorId).parent().addClass("selectedTab");
        $("#" + anchorId).css("color", "#FFFFFF");

        //Permission Check
        if (viewPermission != undefined && Cronus.Compliance.isActionPermitted(viewPermission, screenName) == false) {
            // swal("Error", "View permission missing", "error");
            window.location = $("#hdnHomePageUrl").val();
            return false;
        }
        return true;
    }

    // // // Comment for identification 


    function validateCusipList(cusipList, maxLength) {
        if (cusipList != "" || cusipList != null) {
            if (validateForSpecialChars(cusipList) == false) {
                return false;
            }
            if (cusipList.length == 0) {
                return true;
            }

            var splittedCusips = cusipList.split(',');
            for (var i = 0; i < splittedCusips.length; i++) {
                var cusip = splittedCusips[i].trim();
                if (cusip.length == 0) {
                    swal("Error", "length of cusip " + cusip + " is 0. Remove extra comma(s)", "error");
                    return false;
                }
                else if (cusip.length > maxLength) {
                    swal("Error", "length of cusip " + cusip + " is greater than " + maxLength, "error");
                    return false;
                }
            }
            return true;
        }
    }

    function validateForSpecialChars(val) {
        if (val != "" || val != null) {
            if (/^[a-zA-Z0-9\s,]*$/.test(val) == false) {
                swal("Error", val + " Contains special Character(s)", "error");
                return false;
            }
            return true;
        }
    }

    function checkUserExistenceCookie() {
        var username = $.cookie('cronusUserName');
        var useremail = $.cookie('cronusUserEmail');
        if (username == null || username == "null" || username == '' || useremail == null || useremail == "null" || useremail == '') {
            var inputObj = {};

            var retval = ajaxCall(inputObj, Cronus.RestApi.FetchUserInformation, ".blockOverlay", false);
            if (retval.Error == false) {
                var result = retval.Result;
                $(".blockOverlay").css('display', 'none');
                var username = result.CronusUserName;
                var useremail = result.CronusUserEmail;
                $('#spnusername').html(username);
                $('#spnuseremail').html(useremail);
                $.cookie('cronusUserName', username, { path: '/' });
                $.cookie('cronusUserEmail', useremail, { path: '/' });
            }
        } else {
            $('#spnusername').html(username);
            $('#spnuseremail').html(useremail);
        }
    }

    function changeLang(el) {
        if ($(el).html() == 'French') {
            $("#spnLang").html('un outil primordial de risqué ');
            $(el).html('English');
        } else {
            $("#spnLang").html('A risk overriding tool ');
            $(el).html('French');
        }
        return false;
    }

    //Validate Inputs
    function validAbsIntiger(evt) {
        var e = evt || window.event;
        var key = e.keyCode || e.which;

        if (!e.shiftKey && !e.altKey && !e.ctrlKey &&
        // numbers   
		key >= 48 && key <= 57 ||
        // Backspace and Tab and Enter
		key == 8 || key == 9 || key == 13) {
            // input is VALID
        }
        else {
            // input is INVALID
            e.returnValue = false;
            if (e.preventDefault) e.preventDefault();
        }
    }

    //+ and - Interger
    function validInteger(evt) {
        var e = evt || window.event;
        var key = e.keyCode || e.which;

        if (!e.shiftKey && !e.altKey && !e.ctrlKey &&
        // numbers   
		key >= 48 && key <= 57 ||
        // Backspace and Tab and Enter
		key == 8 || key == 9 || key == 13 ||
        //+, -
		key == 43 || key == 45) {
            // input is VALID
        }
        else {
            // input is INVALID
            e.returnValue = false;
            if (e.preventDefault) e.preventDefault();
        }
    }

    //+ and - Real
    function validReal(evt) {
        var e = evt || window.event;
        var key = e.keyCode || e.which;

        if (!e.shiftKey && !e.altKey && !e.ctrlKey &&
        // numbers   
		key >= 48 && key <= 57 ||
        // Backspace and Tab and Enter
		key == 8 || key == 9 || key == 13 ||
        //+, -
		key == 43 || key == 45 ||
        //e, E, .
		key == 101 || key == 69 || key == 46) {
            // input is VALID
        }
        else {
            // input is INVALID
            e.returnValue = false;
            if (e.preventDefault) e.preventDefault();
        }
    }

    function validString(evt) {
        var e = evt || window.event;
        var key = e.keyCode || e.which;

        if (!e.shiftKey && !e.altKey && !e.ctrlKey &&
        // numbers   
		key >= 48 && key <= 57 ||
        // Backspace and Tab and Enter
		key == 8 || key == 9 || key == 13 ||
        // A-Z   
		key >= 65 && key <= 90 ||
        // a-z   
		key >= 97 && key <= 122 ||
        //space
		key == 32) {
            // input is VALID
        }
        else {
            // input is INVALID
            e.returnValue = false;
            if (e.preventDefault) e.preventDefault();
        }
    }

    function validCommaSeperatedString(evt) {
        var e = evt || window.event;
        var key = e.keyCode || e.which;

        if (!e.shiftKey && !e.altKey && !e.ctrlKey &&
        // numbers   
		key >= 48 && key <= 57 ||
        // Backspace and Tab and Enter
		key == 8 || key == 9 || key == 13 ||
        // A-Z   
		key >= 65 && key <= 90 ||
        // a-z   
		key >= 97 && key <= 122 ||
        //space comma
		key == 32 || key == 44) {
            // input is VALID
        }
        else {
            // input is INVALID
            e.returnValue = false;
            if (e.preventDefault) e.preventDefault();
        }
    }


    // // Comment for identification 

    var showProfile = function () {
        var profilediv = $("#dvprofile");
        if (profilediv.hasClass('show')) {
            profilediv.removeClass('show'); ;
            profilediv.addClass('hide');
        } else {
            profilediv.removeClass('hide'); ;
            profilediv.addClass('show');
        }
        return false;
    }
    var closeProfile = function () {
        var profilediv = $("#dvprofile");
        profilediv.removeClass('show'); ;
        profilediv.addClass('hide');
        return false;
    }

    // ajaxCall.js copy
    var ajaxCall = function (inputObj, restApiName, blockOverlay, async, btn) {
        if (isNotEmptyNullOrUndefined(blockOverlay))
            $(blockOverlay).css('display', 'block');

        if (isNotEmptyNullOrUndefined(btn))
            $(btn).button('loading');
        var error = false;
        inputObj.runEnviroment = $("#ddlCommanEnviroment").val();
        var retval;
        var ajaxObj = $.ajax({
            cache: false,
            async: async,
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: serviceUrl + "api/restapi/" + restApiName,
            data: JSON.stringify(inputObj),
            dataType: "json",
            success: function (result) {
                if (isNotEmptyNullOrUndefined(blockOverlay))
                    $(blockOverlay).css('display', 'none');
                if (result != null && result.errorMessage != null && result.errorMessage != "") {
                    swal("Error", result.errorMessage, "error");
                    error = true;
                }
                retval = result;

                if (isNotEmptyNullOrUndefined(btn))
                    $(btn).button('reset');
            },
            error: function () {
                if (isNotEmptyNullOrUndefined(blockOverlay))
                    $(blockOverlay).css('display', 'none');
                swal("Error", "Unknown Exception in " + restApiName + " function call", "error");
                if (isNotEmptyNullOrUndefined(btn))
                    $(btn).button('reset');
            }
        });
        return { AjaxObj: ajaxObj, Error: error, Result: retval };
    }


    // autoComplete.js Copy
    var fetchAutoCompleteData = function (screenName, fieldName, restAPI, textElement, hiddenELement) {
        var inputObj = new Object();
        inputObj.screenName = screenName;
        inputObj.fieldName = fieldName;
        inputObj.runEnviroment = $("#ddlCommanEnviroment").val();
        $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            url: serviceUrl + "api/restapi/" + restAPI,
            data: JSON.stringify(inputObj),
            async: false,
            timeout: 1000,
            dataType: "json",
            success: function (result) {
                $(textElement).autocomplete({
                    lookup: result.dropDownData,
                    minChars: 0,
                    onSelect: function (suggestion) {
                        if (suggestion.data != -1) {
                            $(hiddenELement).val(suggestion.data);
                        }
                    }
                });
            }
        });
    }

    // next two functions aren't used anywhere!
    var clearTextbox = function (hidenElement) {
        $(hidenElement).val('');
    }

    var checkValue = function (el, type) {
        if (type == 'user' && $("#hdnUserId").val() == "") {
            $(el).val('');
        } else if (type == 'screen' && $("#hdnScreenId").val() == "") {
            $(el).val('');
        }
        else if (type == 'group' && $("#hdnGroupId").val() == "") {
            $(el).val('');
        }
    }

    var populateMultiSelectDropDown = function (multiSelectDropDownLabel, data) {
        $(multiSelectDropDownLabel).multiselect("destroy");
        $(multiSelectDropDownLabel).empty();
        for (var i = 0; i < data.length; i++) {
            $('<option>').val(data[i]).text(data[i]).appendTo(multiSelectDropDownLabel);
        }
        $(multiSelectDropDownLabel).multiselect({
            includeSelectAllOption: true,
            enableFiltering: true,
            enableCaseInsensitiveFiltering: true,
            buttonWidth: false,
            onDropdownHidden: function (event) {
            }
        });
    }

    // dataTables.js Copy 

    var destroyDataTable = function (dt, tableElement) {
        if (dt != undefined) {
            dt.fnClearTable();
            dt.fnDestroy();
            if (tableElement != undefined)
                $(tableElement).html('');
        }
        return dt;
    }

    var refreshDataTable = function (dt, tableElement, columns, dataTableArray, fixedLastCols, columndefs, tripledotflag) {
        //  Clear contents of dataTables
        dt = destroyDataTable(dt, tableElement);
        var columnsName = [];

        for (var index = 0; index < columns.length; index++) {
            columnsName.push({ title: columns[index], defaultContent: "(null)" });
        }
        var applytripledot = 0;
        if (tripledotflag != undefined) {
            applytripledot = tripledotflag;
        }

        $.extend(true, $.fn.dataTable.defaults, {
            dom: 'Blfrtip',
            buttons: [
            'copy', 'print', {
                extend: 'csv',
                text: 'Export To Excel'
            }
            ]
        });
        $.fn.dataTable.render.ellipsis = function () {            
            if (tripledotflag != undefined && tripledotflag != null) {
                return function (data, type, row) {
                    return type === 'display' && data != null && data.length > 200 ? (data.substr(0, 200).lastIndexOf("<b>") > data.substr(0, 200).lastIndexOf("</b>") ? data.substr(0, 200).substr(0, data.substr(0, 200).lastIndexOf("<b>") - 1) : data.substr(0, 200)) + '<a onclick= "openCommanDiloagBoxForDT(this)"  href="javascript:void(0);" fulltext =\'' + data.replace(new RegExp("'", "g"), "|").replace(new RegExp("\n", "g"), "") + '\'   ><strong><u>…</u></strong></a>' : data;
                }
            }
        };
        var settings = {
            data: dataTableArray,
            scrollX: true,
            //scrollY: 250,
            destroy: true,
            columns: columnsName,
            scrollCollapse: true,
            deferRender: true,
            order: [],
            columnDefs: [{
                targets: applytripledot,
                render: $.fn.dataTable.render.ellipsis()
            }]
        };

        if (isNotEmptyNullOrUndefined(fixedLastCols)) {
            settings["fixedColumns"] = {
                rightColumns: [fixedLastCols]
            };
        }
        if (isNotEmptyNullOrUndefined(columndefs)) {
            settings["columnDefs"] = columndefs;
        }
        $(tableElement).DataTable(settings);

        dt = $(tableElement).dataTable();
        return dt;
    }



    // populateCycle.js Copy
    // linked seperately in cshtml files 

    var populateCycleDate = function (dateElement) {
        var inputObj = { screenName: screenName };

        var retval = ajaxCall(inputObj, Cronus.RestApi.FetchCycleAndPreviosDate, ".blockOverlay", true);
        $.when(retval.AjaxObj).done(function () {
            var result = retval.AjaxObj.responseJSON;
            if (result.errorMessage == null || result.errorMessage === "") {
                if (result.CycleDate != null) {
                    var cycleDate = result.CycleDate.split(' ')[0];
                    if (cycleDate !== "") {
                        $(dateElement).datepicker({ maxDate: cycleDate });
                        $(dateElement).datepicker('setDate', cycleDate);
                    }
                }
            }
        });
    }

    var populatePreviousDate = function (dateElement) {
        var inputObj = { screenName: screenName };

        var retval = ajaxCall(inputObj, Cronus.RestApi.FetchCycleAndPreviosDate, ".blockOverlay", true);
        $.when(retval.AjaxObj).done(function () {
            var result = retval.AjaxObj.responseJSON;
            if (result.errorMessage == null || result.errorMessage === "") {
                if (result.CycleDate != null) {
                    var previousDate = result.PreviousDate.split(' ')[0];
                    if (previousDate !== "") {
                        $(dateElement).datepicker({ maxDate: previousDate });
                        $(dateElement).datepicker('setDate', previousDate);
                    }
                }
            }
        });
    }

    var populateEnvironmentDropDownCommon = function () {

        if (Cronus.commonEnvironments[url] == undefined) {
            swal("Error", "Environment Detail not found", "error");
            return false;
        }
        $("#ddlCommanEnviroment").html("");
        var Selectvalue = "";
        for (var key in Cronus.commonEnvironments[url]) {
            Selectvalue += '<option value="' + Cronus.commonEnvironments[url][key] + '">' + Cronus.commonEnvironments[url][key] + '</option>';
        }
        $("#ddlCommanEnviroment").append(Selectvalue);

        return true;
    }
    var getParameterByName = function (name, url) {
        if (!url) {
            url = window.location.href;
        }
        name = name.replace(/[\[\]]/g, "\\$&");
        var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, " "));
    }

    var getBaseUrl = function () {
        var hostaddress = window.location.protocol + '//' + window.location.hostname + (window.location.port ? ':' + window.location.port : '');
        var subhostaddress = "";
        if (window.location.hostname.toLowerCase() == "cronusdelta") {
            subhostaddress = "/cronus-client-delta";
        }
        else if (window.location.hostname.toLowerCase() == "localhost") {
            subhostaddress = "";
        }
        else {
            subhostaddress = "/cronus-client";
        }
        return hostaddress + subhostaddress;
    }

    module.selectedPage = selectedPage;
    module.ajaxCall = ajaxCall;
    module.fetchAutoCompleteData = fetchAutoCompleteData;
    module.clearTextbox = clearTextbox;
    module.checkValue = checkValue;
    module.destroyDataTable = destroyDataTable;
    module.refreshDataTable = refreshDataTable;
    // changed to camelCase from Constructor type
    module.populateCycleDate = populateCycleDate;
    module.populateMultiSelectDropDown = populateMultiSelectDropDown;
    module.populatePreviousDate = populatePreviousDate;
    // change ends here!
    module.showProfile = showProfile;
    module.closeProfile = closeProfile;

    // added later -- to be fulfilled in all the pages 
    module.isNotEmptyNullOrUndefined = isNotEmptyNullOrUndefined;
    module.validateCusipList = validateCusipList;
    module.validateForSpecialChars = validateForSpecialChars;
    module.checkUserExistenceCookie = checkUserExistenceCookie;
    module.changeLang = changeLang;
    module.validAbsIntiger = validAbsIntiger;
    module.validInteger = validInteger;
    module.validReal = validReal;
    module.validString = validString;
    module.validCommaSeperatedString = validCommaSeperatedString;
    module.populateEnvironmentDropDownCommon = populateEnvironmentDropDownCommon;
    module.getParameterByName = getParameterByName;
    module.GetBaseUrl = getBaseUrl;
    return module;


} (Cronus || {});

