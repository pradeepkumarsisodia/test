﻿var Cronus = function (module) {
    var _screens = {
        AgencyModelMap: "AGENCY MODEL MAP",
        AnalyticIdConfiguration: "Analytic Id Configuration",
        BackFilling: "BackFilling",
        CreditEntityAttributes: "CREDIT ENTITY ATTRIBUTES",
        Dashboard: "DASHBOARD",
        DataManipulation: "Data Manipulation",
        ImportToDatabase: "IMPORT TO DATABASE",
        ManageMasterTables: "MANAGE MASTER TABLES",
        ModelSummaryReport: "MODEL SUMMARY REPORT",
        OttiRun: "Otti Run",
        SecurityStaleNotes: "SECURITY STALE NOTES",
        QueryBuilder: "QUERY BUILDER",
        QueryExecuter: "QUERY EXECUTER",
        RiskAttribution: "RISK ATTRIBUTION",
        RiskMeasureLive: "RISK MEASURES LIVE",
        RiskMeasureOverride: "RISK MEASURE OVERRIDE",
        Regression: "REGRESSION",
        RejectedCusips: "RELOAD REJECTED CUSIPS",
        Reporting: "REPORTING",
        SecAnalyticsOverride: "Sec Analytics Override",
        Settings: "SETTINGS",
        StaleRiskMeasures: "STALE RISK MEASURES",
        SubstituteCusips: "SUBSTITUTE CUSIPS",
        TSDefinition: "SETUP NEW DEFINITION",
        UserManagement: "USER MANAGEMENT"
    };

    var _actions = {
        AgencyModelMap_AddUpdate: "AddUpdate",
        AgencyModelMap_Search: "SEARCH",
        AgencyModelMap_View: "VIEW",
        AnalyticIdConfiguration_Submit: "Submit",
        AnalyticIdConfiguration_View: "VIEW",
        BackFilling_Save: "SAVE",
        BackFilling_View: "VIEW",
        CreditEntityAttributes_Update: "UPDATE",
        CreditEntityAttributes_View: "VIEW",
        Dashboard_View: "VIEW",
        Dashboard_Submit: "SUBMIT",
        DataManipulation_View: "VIEW",
        DataManipulation_Search: "SEARCH",
        DataManipulation_Save: "SAVE",
        ImportToDatabase_View: "VIEW",
        ImportToDatabase_Import: "IMPORT",
        ManageMasterTables_View: "VIEW",
        SecurityStaleNotes_View: "VIEW",
        ModelSummaryReport_Run: "RUN",
        ModelSummaryReport_Save: "SAVE",
        ModelSummaryReport_View: "VIEW",
        OttiRun_Run: "RUN",
        OttiRun_View: "VIEW",
        QueryBuilder_ALL_W: "ALL_W",
        QueryBuilder_Execute: "EXECUTE",
        QueryBuilder_FND_W_OTHER_R: "FND_W_OTHER_R",
        QueryBuilder_View: "VIEW",
        QueryBuilder_View_FND_ONLY: "View_FND_ONLY",
        QueryExecuter_ALL_W: "ALL_W",
        QueryExecuter_Execute: "EXECUTE",
        QueryExecuter_FND_W_OTHER_R: "FND_W_OTHER_R",
        QueryExecuter_View: "VIEW",
        QueryExecuter_View_FND_ONLY: "View_FND_ONLY",
        RiskAttribution_Search: "SEARCH",
        RiskAttribution_View: "VIEW",
        Regression_Run: "RUN",
        Regression_View: "VIEW",
        RejectedCusips_ExportToExcel: "EXPORT TO EXCEL",
        RejectedCusips_NotifyForRejection: "Notify for Rejection",
        RejectedCusips_NotifyForReload: "Notify for Reload",
        RejectedCusips_SearchCurrentNotification: "Search Current Notification",
        RejectedCusips_SearchRejectedCusips: "Search Rejected Cusips",
        RejectedCusips_ShowDetails: "Show Details",
        RejectedCusips_View: "VIEW",
        Reporting_Go: "GO",
        Reporting_UnlimitedAccess: "UNLIMITED ACCESS",
        Reporting_View: "VIEW",
        RiskMeasureLive_Load: "LOAD",
        RiskMeasureLive_Run: "RUN",
        RiskMeasureLive_View: "VIEW",
        RiskMeasureOverride_SubmitBase: "SUBMIT BASE",
        RiskMeasureOverride_SubmitScenarios: "SUBMIT SCENARIO",
        RiskMeasureOverride_SubmitTraders: "SUBMIT TRADERS",
        RiskMeasureOverride_View: "VIEW",
        RiskMeasureOverride_ViewAnalytics: "VIEW ANALYTICS",
        RiskMeasureOverride_ViewTraders: "VIEW Traders",
        SecAnalyticsOverride_Search: "SEARCH",
        SecAnalyticsOverride_Submit: "Submit",
        SecAnalyticsOverride_View: "VIEW",
        Settings_View: "VIEW",
        SubstituteCusips_Save: "SAVE",
        SubstituteCusips_Search: "SEARCH",
        SubstituteCusips_ShowAll: "SHOW ALL",
        SubstituteCusips_View: "VIEW",
        StaleRiskMeasures_Submit: "SUBMIT",
        StaleRiskMeasures_View: "VIEW",
        TSDefinition_Submit: "Submit",
        TSDefinition_View: "VIEW",
        UserManagement_View: "VIEW"
    };

    var _restApi = {
        CancelAjax: "CancelAjax",
        Commit: "Commit",
        CustomFunction: "CustomFunction",
        FetchActionsForUser: "FetchActionsForUser",
        FetchCycleAndPreviosDate: "FetchCycleAndPreviosDate",
        FetchDataForQB: "FetchDataForQB",
        FetchDataForTable: "FetchDataForTable",
        FetchDropDownData: "FetchDropDownData",
        FetchResults: "FetchResults",
        FetchRegistrations: "FetchRegistrations",
        FetchUserInformation: "FetchUserInformation",
        LoadCurrentLogFile: "LoadCurrentLogFile",
        Register: "Register",
        Rollback: "Rollback",
        UpdateDB: "UpdateDB"
    };

    var commonEnvironments = {
        "cronus-dr": { "PRODDR": "PRODDR" },
        "cronus": { "PROD": "PROD", "BETA": "BETA", "DELTA": "DELTA", "DELTA2": "DELTA2", "BETA": "BETA", "DEV": "DEV" }
              , "cronusbeta": { "BETA": "BETA", "DEV": "DEV" }
              , "cronusdev": { "DEV": "DEV", "BETA": "BETA" }
              , "cronusdelta": { "DELTA": "DELTA", "DELTA2": "DELTA2", "BETA": "BETA" }
              , "localhost:8180": { "DEV": "DEV", "BETA": "BETA", "DELTA": "DELTA", "DELTA2": "DELTA2","PROD": "PROD", "PRODDR": "PRODDR" }
    };

    var commonEnvColor = { "PRODDR": "red", "PROD": "red", "DEV": "green", "BETA": "green", "DELTA": "gray", "DELTA2": "blue" };



    module.Screens = _screens;
    module.Actions = _actions;
    module.RestApi = _restApi;
    module.commonEnvironments = commonEnvironments;
    module.commonEnvColor = commonEnvColor;

    return module;


} (Cronus || {});

