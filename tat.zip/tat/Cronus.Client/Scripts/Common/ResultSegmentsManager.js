﻿

function ResultSegmentsManager(serverProxy, requestId, maxRowsFetch) {

     /*
    * the items of the ranges list are json objects, each has 3 fields { data:[], begin:int, end: int}
    */

   var ranges = [];

   
   /*
    * Note that all [begin,end) pairs are defined with respect to the complete range at server, not to the sub-range which 
    * is returned as response. subRange() function defined below, adjusts the pair of [begin, end) before extracting the 
    * sub-range from a given (returned) range.
    */

    var outerBegin = null;
    var outerEnd = null;
    var totalEntries = -1;
    var self = this; //so that it can be accessed  (non-member) function, such as callbacks;
    
   
   var logRanges = function (r) {
        for(var i = 0; i < r.length; ++i )
            console.log(r[i].begin, r[i].end);
   };

   this.maxRowsFetch = function() {
        if ( maxRowsFetch == null || maxRowsFetch == undefined )
            return 100; //rows
        return maxRowsFetch;
   };

   this.totalRowCount = function (){
        return totalEntries;
   };

   var insert = function (range) {
   
        if ( outerBegin == null || outerBegin > range.begin )  outerBegin = range.begin;
        if ( outerEnd == null || outerEnd < range.end )  outerEnd = range.end;

        if ( ranges.length == 0 ) {
            ranges.push(range);
        }
        else {
            for(var i = 0; i < ranges.length; ++i ) {
                if ( range.begin < ranges[i].begin ) {
                    if ( range.end > ranges[i].begin ) {
                        console.error("logical bug in insert", range.begin, range.end, ranges[i].begin, ranges[i].end);
                        logRanges(ranges);
                    }
                    ranges.splice(i, 0, range);
                    return;
                }
            }
            ranges.push(range);
        }
   };
   
    var contains = function (index, rangeIndex) {
        return ranges[rangeIndex].begin <= index && index < ranges[rangeIndex].end;
    };

    var subRange = function (rangeIndex, begin, end) {
        console.log("subrange:", begin, end, " from ", ranges[rangeIndex].begin, ranges[rangeIndex].end);
        if (begin == null) begin = ranges[rangeIndex].begin;
        if (end == null) end = ranges[rangeIndex].end;
        var x = { data: ranges[rangeIndex].data.slice(begin - ranges[rangeIndex].begin, end - ranges[rangeIndex].begin), begin: begin, end: end };
        console.log("subrange of size ", x.data.length, " returning for [", begin, ",", end, ")");
        return x;
    };

    var make_path = function(begin, end){
        return "/" + uistate.type + "/" + uistate.model + "/" + uistate.risk + "/values[" + begin + ":" + end + "]";    
    };

    var getResults = function (segments, callback) {
        var paths = [];
        for (var i = 0; i < segments.length; ++i) {
            paths.push(make_path(segments[i][0], segments[i][1]));
        }
        feserverProxy.submitQuery(FeServer.Tasks.JPATH, { "id": requestId, "paths": paths }, function (response) {
            callback(response.results, paths);
        }, null);

        /*
        var ps = {};
        for (var i = 0; i < paths.length; ++i) {
        ps[paths[i]] = {
        begin: parseInt(paths[i].split('[')[1].split(':')[0]),
        end: 6871,
        data: []
        };
        }
        var results = {
        "paths": ps
        };
        console.log(results);
        callback(results); */
    };

    var findGaps = function (begin, end) {

        if (begin >= end) {
            console.error("invalid range definition: begin = ", begin, " end = ", end);
            return [];
        }

        if (ranges.length == 0) {
            return [[begin, end]];
        }
        else if (end <= ranges[0].begin || begin >= ranges[ranges.length - 1].end) {
            return [[begin, end]];
        }

        var gaps = [];
        var i = 0;
        if (begin < ranges[0].begin) {
            gaps.push([begin, ranges[0].begin]);
        }
        else if (contains(begin, i)) {
            if (contains(end - 1, i)) {
                return []; //no gap, as entire range [begin, end) is found within one segment.
            }
        }
        else {
            for (++i; i < ranges.length; ++i) {
                if (ranges[i - 1].end != ranges[i].begin) {   //gap found
                    if (ranges[i - 1].end <= begin && begin < ranges[i].begin) {
                        if (end <= ranges[i].begin) {
                            return [[begin, end]];
                        }
                        gaps.push([ranges[i - 1].end, end]);
                        break;
                    }
                }
                else if (contains(begin, i)) {
                    if (contains(end - 1, i)) {
                        return []; //no gap, as entire range [begin, end) is found within one segment.
                    }
                    break;
                }
            }
        }

        //begin has been processed so far, either by finding a gap, or segment.
        if (i != ranges.length) {
            console.log("i = ", i, " gaps so far = ", gaps);
            for (++i; i < ranges.length; ++i) {
                if (ranges[i - 1].end != ranges[i].begin) {   //gap found
                    if (ranges[i - 1].end < end && end <= ranges[i].begin) {
                        gaps.push([ranges[i - 1].end, end]);
                        return gaps;
                    }
                    if (end > ranges[i].begin)
                        gaps.push([ranges[i - 1].end, ranges[i].begin]);
                    else {
                        console.error("logic error: end = ", end, " should have been found by now, i = ", i);
                        logRanges(ranges);
                    }
                }
                else if (contains(end - 1, i)) {
                    return gaps;
                }
            }
            if (end > ranges[i - 1].end)
                gaps.push([ranges[i - 1].end, end]);
            return gaps;
        }
        console.info("gaps not found for begin = ", begin, " end = ", end);
        return [];
    };

    var getRangeImpl = function (begin, end) {
        for (var i = 0; i < ranges.length; ++i) {
            if (contains(begin, i)) {
                if (contains(end - 1, i)) {
                    return subRange(i, begin, end).data;
                }
                var rows = subRange(i, begin, null).data;
                while (++i < ranges.length) {
                    if (ranges[i - 1].end != ranges[i].begin) {
                        console.error("gap found between ranges ", i - 1, " and ", i);
                        logRanges(ranges);
                        return [];
                    }
                    if (contains(end - 1, i)) {
                        console.log("adding items from range [", ranges[i].begin, ", ", ranges[i].end, "] upto end = ", end);
                        rows = rows.concat(subRange(i, null, end).data);
                        break;
                    }
                    else {
                        console.log("adding all items from range [", ranges[i].begin, ", ", ranges[i].end, "]");
                        rows = rows.concat(subRange(i, null, null).data);
                    }
                }
                console.info("data of size = ", rows.length, " returned for [", begin, ", ", end, ")");
                return rows;
            }
        }
        console.error("range not found: begin = ", begin, " end = ", end);
    };

    this._getRange = function (begin, end, callback) {

        var gaps = findGaps(begin, end);
        console.info("get range: ", begin, end, " gaps:", gaps);

        if (gaps.length == 0) {
            console.log("loading from cache");
            callback(getRangeImpl(begin, end));
            console.log("-------------");
        }
        else {
            getResults(gaps, function (results, paths) {
                console.log(results);
                for (var i = 0; i < paths.length; ++i) {
                    var path = paths[i];
                    var range = {
                        begin: null,
                        end: results["payloads"][path]["begin"],
                        data: results["payloads"][path]["data"]
                    };
                    range.begin = range.end - range.data.length;
                    insert(range);
                    logRanges(ranges);
                    console.log("caching...", range.begin, range.end);
                    totalEntries = results["payloads"][path]["end"];
                }
                callback(getRangeImpl(begin, end));
                console.log("-------------");
            });
        }
    };
}

ResultSegmentsManager.prototype.getRows = function (begin, end, callback) {
    this._getRange(begin, end, callback);
}
