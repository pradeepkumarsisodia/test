﻿var Cronus = function (module) {
    var _actionScreenDict = {};
    var _screenNamePageDict = {};

    var screens = Cronus.Screens;
    _screenNamePageDict[screens.AgencyModelMap] = "anclAgencyModelMap";
    _screenNamePageDict[screens.AnalyticIdConfiguration] = "anclAnalyticIdConfiguration";
    _screenNamePageDict[screens.BackFilling] = "anclBackFilling";
    _screenNamePageDict[screens.CreditEntityAttributes] = "anclCreditEnityAttributes";
    _screenNamePageDict[screens.Dashboard] = "ancDashboard";
    _screenNamePageDict[screens.DataManipulation] = "anclDataManipulation";
    _screenNamePageDict[screens.ImportToDatabase] = "anclImportToDatabase";
    _screenNamePageDict[screens.ManageMasterTables] = "anclManageMasterTables";
    _screenNamePageDict[screens.ModelSummaryReport] = "anclModelSummaryReport";
    _screenNamePageDict[screens.OttiRun] = "anclOttiRun";
    _screenNamePageDict[screens.SecurityStaleNotes] = "anclSecurityStaleNotes";
    _screenNamePageDict[screens.QueryBuilder] = "anclQuery";
    _screenNamePageDict[screens.QueryExecuter] = "anclQueryExecuter";
    _screenNamePageDict[screens.RiskAttribution] = "anclRiskAttribution";    
    _screenNamePageDict[screens.Regression] = "anclRegression";
    _screenNamePageDict[screens.RejectedCusips] = "anclReload";
    _screenNamePageDict[screens.Reporting] = "anclReporting";
    _screenNamePageDict[screens.RiskMeasureLive] = "anclRiskMeasuresLive";
    _screenNamePageDict[screens.RiskMeasureOverride] = "anclRiskOverride";
    _screenNamePageDict[screens.SecAnalyticsOverride] = "anclSecAnalyticsOverride";
    _screenNamePageDict[screens.Settings] = "anclSettings";
    _screenNamePageDict[screens.StaleRiskMeasures] = "anclStaleRiskMeasures";
    _screenNamePageDict[screens.SubstituteCusips] = "anclSubstitute";
    _screenNamePageDict[screens.TSDefinition] = "anclTSDefinitions";
    _screenNamePageDict[screens.UserManagement] = "anclUser";

    var getactionScreenDictKey = function (actionName, screenName) {
        return actionName.trim().toUpperCase() + "_%_" + screenName.trim().toUpperCase();
    };

    var _compliance = {

        getUIPermission: function () {
            var retval = Cronus.ajaxCall(new Object(), Cronus.RestApi.FetchActionsForUser, "", false);
            if (retval.Error == false) {
                var result = retval.Result.actionPermittedList;
                var screenPermitted = {};

                for (var i = 0; i < result.length; i++) {
                    _actionScreenDict[getactionScreenDictKey(result[i].ACTION_NAME, result[i].SCREEN_ID)] = true;
                    screenPermitted[result[i].SCREEN_ID] = true;
                }
                $.each(_screenNamePageDict, function (key, value) {
                    $("#" + value).parent().css('display', 'none');
                    if ($("#" + value).parent().parent().parent()[0].className == "treeview")
                        $("#" + value).parent().parent().parent().css('display', 'none');
                });
                $.each(_screenNamePageDict, function (key, value) {
                    if (screenPermitted[key.toUpperCase()] === true) {
                        $("#" + value).parent().css('display', 'inline');
                        if ($("#" + value).parent().parent().parent()[0].className == "treeview")
                            $("#" + value).parent().parent().parent().css('display', 'inline');
                    }
                });
            }
        },

        isActionPermitted: function (actionName, screenName) {

            var actionScreenName = getactionScreenDictKey(actionName, screenName);
            var isPermitted = _actionScreenDict[actionScreenName] === true;
            return isPermitted;
        },
        ScreenNamePageDict: _screenNamePageDict
    }
    module.Compliance = _compliance;
    return module;
} (Cronus || {});
