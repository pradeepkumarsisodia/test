﻿"use strict";
var screenName = Cronus.Screens.QueryBuilder;
var activeTab = "Tab01";
var uniqId = Math.round(new Date().getTime() + (Math.random() * 100));
//dictionary of all datatables for tabs
var dtDict = {};
var resultData = {};
var openTabs = {};
var ajaxRequest = {};
var savedQueriesCache = {};
var responsibility = {};
var betaExecutionTabIds = {};
var isRollback = false;

var screenFieldsValue = {};
var screenFields = {};

var databases = {};

var betaExecutionDB = databases["BETA"];

var ENVIRONMENT = "Environment";
var QUERYTEXT = "QUERYTEXT";
var JIRANO = "JIRANo";
var JIRALINK = "JIRALink";
var JIRASTATUS = "JIRAStatus";
var JIRABETAEXECUTIONDONE = "JIRABetaExecutionDone";
var JIRASUMMARY = "JIRASummary";
var REQUESTTYPE = "RequestType";
var GROUPRESPONSIBILITY = "GroupResponsibility";
var TEAMRESPONSIBILITY = "TeamResponsibility";
var APPROVER = "Approver";
var SKIPBETAEXECUTIONY = "SkipBetaExecutionY";
var SKIPBETAEXECUTIONN = "SkipBetaExecutionN";
var SKIPBETAEXECUTIONREASON = "SkipBetaExecutionReason";
var SKIPAPPROVALY = "SkipApprovalY";
var SKIPAPPROVALN = "SkipApprovalN";
var SKIPAPPROVALREASON = "SkipApprovalReason";
var DATABASE = "Database";
var CATEGORY = "Category";
var QUERYNAME = "QueryName";
var QUERY = "Query";
var EXPECTEDROWS = "ExpectedRows";
var SKIPBETAEXECUTION = "SkipBetaExecution";
var SKIPAPPROVAL = "SkipApproval";
var DBTYPE = "DBType";
var TABID = "TabId";
var UNIQID = "UniqId";
var ISBETAEXECUTION = "IsBetaExecution";
var RESULTTAB = "ResultTab";
var ISTRANSACTIONMODE = "IsTransactionMode";

// Used for selected query execution
var startSelection;
var endSelection;

$(document).ready(function () {
    if (!Cronus.selectedPage(screenName, Cronus.Actions.QueryBuilder_View)) {
        return;
    }

    getDataBase();
    getSavedQueries();
    populateResponsibility();
    addTab();
    addTab();

    $("#btnTab01").click();
    $(window).bind("beforeunload", function () {
        if (isRollback == true) {
            var retval = rollbackAllTabs();
            return retval;
        }
    });

    // This will be used for escape key pressed by user to cancel all Ajax calls
    $(document).keyup(function (e) {
        if (e.keyCode == 27) {
            cancelQuery();
        }
    });

    // This will be used for enerr key pressed by user
    $("#txtSkipApprovalModalReason").keypress(function (e) {
        if (e.which === 13) {
            $("#btnOkApprovalModal").click();
            return false;
        }
    });
    // This will be used for enerr key pressed by user
    $("#txtSkipBetaExecutionModalReason").keypress(function (e) {
        if (e.which === 13) {
            $("#btnOkSkipBetaModal").click();
            return false;
        }
    });

    //When the approval modal closed.
    $('#skipApprovalModal').on('hidden.bs.modal', function () {
        cancelApprovalReason();
    });

    //When the skip beta execution modal closed.
    $('#skipBetaEcecutionModal').on('hidden.bs.modal', function () {
        cancelBetaExecutionReason();
    });


});

function getDataBase() {
    var inputObj = { screenName: screenName, tableName: "GetDataBase" };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlayQuery", false);
    if (retval.Error == false) {
        var result = retval.Result;
        $.each(result.rows, function (index, value) {
            if (!(value[2] in databases)) {
                databases[value[2]] = {};
            }
            databases[value[2]][value[0]] = value[1];
        });
        betaExecutionDB = databases["BETA"];
    }
}

function populateScreenFieldsValue(tabId, flag) {

    screenFields[ENVIRONMENT] = $("#ddlCommanEnviroment");
    screenFields[JIRANO] = $("#" + tabId + " #txtJIRAId");
    screenFields[JIRALINK] = $("#" + tabId + " #lblJIRALink");
    screenFields[JIRASTATUS] = $("#" + tabId + " #txtStatusMessage");
    screenFields[JIRABETAEXECUTIONDONE] = $("#" + tabId + " #txtBetaExecutionDone");
    screenFields[JIRASUMMARY] = $("#" + tabId + " #txtSummary");
    screenFields[REQUESTTYPE] = $("#" + tabId + " #txtRequestType");
    screenFields[GROUPRESPONSIBILITY] = $("#" + tabId + " #txtGroupResponsibile");
    screenFields[TEAMRESPONSIBILITY] = $("#" + tabId + " #txtTeamResponsibile");
    screenFields[APPROVER] = $("#" + tabId + " #txtApprover");
    screenFields[SKIPBETAEXECUTIONY] = $("#" + tabId + " #rdSkipBetaExecutionY");
    screenFields[SKIPBETAEXECUTIONN] = $("#" + tabId + " #rdSkipBetaExecutionN");
    screenFields[SKIPBETAEXECUTIONREASON] = $("#" + tabId + " #txtSkipBetaExecutionReason");
    screenFields[SKIPAPPROVALY] = $("#" + tabId + " #rdSkipApprovalY");
    screenFields[SKIPAPPROVALN] = $("#" + tabId + " #rdSkipApprovalN");
    screenFields[SKIPAPPROVALREASON] = $("#" + tabId + " #txtSkipApprovalReason");
    screenFields[DATABASE] = $("#" + tabId + " #ddlDatabase");
    screenFields[CATEGORY] = $("#" + tabId + " #txtCategory");
    screenFields[QUERYNAME] = $("#" + tabId + " #txtQName");
    screenFields[ISTRANSACTIONMODE] = $("#" + tabId + " #ddlTransactionMode");


    if (Cronus.isNotEmptyNullOrUndefined(flag)) {
        screenFields[QUERY] = $("#" + tabId + " #txtquerynew");
    }
    else {
        screenFields[QUERY] = $("#" + tabId + " #txtquery");
    }

    screenFields[EXPECTEDROWS] = $("#" + tabId + " #txtRowsAffeted");

    for (var key in screenFields) {
        screenFieldsValue[key] = screenFields[key].val() != undefined ? screenFields[key].val().trim() : undefined;
    }
    screenFieldsValue[SKIPBETAEXECUTION] = screenFields[SKIPBETAEXECUTIONY].is(':checked') ? true : (screenFields[SKIPBETAEXECUTIONN].is(':checked') ? false : undefined);
    screenFieldsValue[SKIPAPPROVAL] = screenFields[SKIPAPPROVALY].is(':checked') ? true : (screenFields[SKIPAPPROVALN].is(':checked') ? false : undefined);
    screenFieldsValue[SKIPBETAEXECUTIONY] = screenFields[SKIPBETAEXECUTIONY].is(':checked');
    screenFieldsValue[SKIPAPPROVALY] = screenFields[SKIPAPPROVALY].is(':checked');
    screenFieldsValue[SKIPBETAEXECUTIONN] = screenFields[SKIPBETAEXECUTIONN].is(':checked');
    screenFieldsValue[SKIPAPPROVALN] = screenFields[SKIPAPPROVALN].is(':checked');

    screenFieldsValue[EXPECTEDROWS] = Cronus.isNotEmptyNullOrUndefined(screenFieldsValue[EXPECTEDROWS]) ? screenFieldsValue[EXPECTEDROWS] : 0;

    for (var key in databases[screenFieldsValue[ENVIRONMENT]]) {
        if (databases[screenFieldsValue[ENVIRONMENT]][key] == screenFieldsValue[DATABASE]) {
            screenFieldsValue[DBTYPE] = key;
        }
    }
    screenFieldsValue[TABID] = tabId;
    screenFieldsValue[UNIQID] = uniqId;
}

/*This function validate if mandatory fields has value*/
function checkMandatoryFields(tabId, fields, screenFieldsValue) {
    var retval = true;
    $.each(fields, function (index, field) {
        if (!Cronus.isNotEmptyNullOrUndefined(screenFieldsValue[field]) || !Cronus.isNotEmptyNullOrUndefined(screenFieldsValue[field].trim())) {
            swal("Error", "Please enter " + field, "error");
            // $("#" + tabId + screenFields[field]).focus();
            retval = false;
        }
    });
    return retval;
}

/* This function is called to populate any dropdonw*/
function populateDropDown(tabId, dataDict, field, childField, onSelectCallback) {
    if (childField != undefined) {
        $(childField).val('');
        $(childField).autocomplete({ source: [] });
    }

    $(field).val('');
    $(field).autocomplete({ source: [] });
    var autoCompleteArray = [{}];
    if (dataDict != undefined) {
        autoCompleteArray = dataDict;
        $(field).autocomplete({
            lookup: autoCompleteArray,
            minChars: 0,
            onSelect: function (suggestion) {
                if (suggestion.data != -1) {
                    if (onSelectCallback != undefined)
                        onSelectCallback(tabId);
                }
            }
        });
    }
}

/*This function populate the database dropdown */
function populateDatabaseDropDown(tabId) {
    var environment = $("#ddlCommanEnviroment").val();
    if (databases[environment] == undefined) {
        swal("Error", "Database Detail not found", "error");
        return false;
    }
    $("#" + tabId + " #ddlDatabase").html("");

    for (var key in databases[environment]) {
        if (key != "ORACLEFND") {
            if (Cronus.Compliance.isActionPermitted(Cronus.Actions.QueryBuilder_View_FND_ONLY, screenName) == false) {
                if (Cronus.Compliance.isActionPermitted(Cronus.Actions.QueryBuilder_ALL_W, screenName) || (key == "ORACLEFND" && Cronus.Compliance.isActionPermitted(QueryBuilder_FND_W_OTHER_R, QueryBuilder)))
                    $("#" + tabId + " #ddlDatabase").append('<option value="' + databases[environment][key] + '">' + databases[environment][key] + '</option>');
                else
                    $("#" + tabId + " #ddlDatabase").append('<option value="' + databases[environment][key] + '">' + databases[environment][key] + ' - R ' + '</option>');
            }
        }
        else {
            if (Cronus.Compliance.isActionPermitted(Cronus.Actions.QueryBuilder_ALL_W, screenName) || (key == "ORACLEFND" && Cronus.Compliance.isActionPermitted(QueryBuilder_FND_W_OTHER_R, QueryBuilder)))
                $("#" + tabId + " #ddlDatabase").append('<option value="' + databases[environment][key] + '">' + databases[environment][key] + '</option>');
            else
                $("#" + tabId + " #ddlDatabase").append('<option value="' + databases[environment][key] + '">' + databases[environment][key] + ' - R ' + '</option>');
        }
    }


    $("#" + tabId + " #spndatabse").html($("#" + tabId + " #ddlDatabase").val());

    return true;
}

/*This function check the jira status and display error in case of invalid status */
function jiraStatusValid(jiraNo, jiraStatus, skipApprovalFlag, skipBetaExecution, betaExecutionDone) {
    //if betaExecution is skipped, the status should be approved if skipApprovalFlag is false
    if (!skipBetaExecution && !betaExecutionDone && jiraStatus !== "In Progress") {
        swal("Error!!! Invalid Status", "For beta execution status should be In Progress of Jira item " + jiraNo, "error");
        return false;
    }
    else if (!skipBetaExecution && betaExecutionDone && !skipApprovalFlag && jiraStatus !== "Approved") {
        swal("Error!!! Invalid Status", "For prod execution status should be Approved of Jira item " + jiraNo, "error");
        return false;
    }
    else if (skipBetaExecution && !skipApprovalFlag && jiraStatus != "Approved") {
        swal("Error!!! Invalid Status", "For prod execution status should be Approved of Jira item " + jiraNo, "error");
        return false;
    }
    else if (skipBetaExecution && skipApprovalFlag && jiraStatus != "In Progress") {
        swal("Error!!! Invalid Status", "If you are skipping Approval, then for prod execution Status should be In Progress of Jira item " + jiraNo, "error");
        return false;
    }
    return true;
}

/*This function will return true if beta execution else return false*/
function isBetaExecution(tabId, screenFieldsValue) {
    if (!Cronus.isNotEmptyNullOrUndefined(screenFieldsValue[JIRANO])) return false;
    else {
        if (screenFieldsValue[SKIPBETAEXECUTION] == undefined || screenFieldsValue[SKIPBETAEXECUTION]) return false;
        else {
            var inputObj = { screenName: screenName, data: screenFieldsValue, functionName: "BetaExecutionDone" };
            var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, ".blockOverlayQuery", false);
            if (retval.Result.JIRABetaExecutionDone == undefined || retval.Result.JIRABetaExecutionDone == null) return true;
            else return false;
        }
    }
    return false;
}

/*This function will return DBServer on which query/commit/rollback will be executed.*/
function getExecutionDBServer(tabId, screenFieldsValue, isBetaExec) {
    if (isBetaExec) {
        for (var key in databases[screenFieldsValue[ENVIRONMENT]]) {
            if (databases[screenFieldsValue[ENVIRONMENT]][key] == screenFieldsValue[DATABASE]) {
                return betaExecutionDB[key];
            }
        }
    }
    return screenFieldsValue[DATABASE];
}

function destroyResultTab(tabId) {
    // This will clear all the content of datatable before executing new query
    dtDict[tabId] = Cronus.destroyDataTable(dtDict[tabId], "#dtQBResults" + tabId);
    //    $("#" + tabId + " #divResult").remove();
}

function populateResultTab(tabId, resultTabId) {
    // This will clear all the content of datatable before executing new query
    $("#" + tabId + " #dtQBSummary").css('display', 'none');
    $("#dtQBResults" + tabId).css('display', 'none');
    destroyResultTab(tabId);
    if (resultTabId == RESULTTAB + "00") {
        $("#" + tabId + " #dtQBSummary").css('display', 'block');
        $("#" + tabId + " #dtQBSummary").html(resultData[tabId][resultTabId]); //.replace(new RegExp("</br>", "ig"), "\n"));
    }
    else if (resultData != undefined) {
        $("#dtQBResults" + tabId).css('display', 'table');
        dtDict[tabId] = Cronus.refreshDataTable(dtDict[tabId], $("#dtQBResults" + tabId), resultData[tabId][resultTabId].columns, resultData[tabId][resultTabId].rows);
    }
}

/*This function is called if execute button is clicked*/
function executeQuery(el, selectedQuery) {
    var returntype = false;
    var tabId = $(el).attr('tabId');
    if ($('#' + tabId + " #ddlTransactionMode").val() == "True" && parseInt($("#" + tabId + " #txtRowsAffeted").val()) > 50000) {
        swal({
            title: "Info" + ": " + tabId, text: "Make sure that the query should be batched properly. Do you wish to continue?", type: "info", showCancelButton: true, confirmButtonColor: "#2e6da4",
            confirmButtonText: "No", cancelButtonText: "Yes", cancelButtonColor: "#2e6da4", closeOnConfirm: true, closeOnCancel: false
        },
     function (isConfirm) {
         if (!isConfirm) {
             if ($('#' + tabId + " #txtJIRAId").val() == "") swal.close();
             returntype = executeQueryNew(el, selectedQuery);
         }
         else { return true; }
     });
    }
    else {
        returntype = executeQueryNew(el, selectedQuery);
    }
    return returntype;
}

function executeQueryNew(el, selectedQuery) {
    var tabId = $(el).attr('tabId');
    var flag = false;
    if (!Cronus.isNotEmptyNullOrUndefined(selectedQuery)) {
        var selectedText = wrapText('#' + tabId + " #txtquery");
        $('#' + tabId + " #txtquerynew").val(selectedText);
        flag = true;
    }

    ///populate the data dictionary
    populateScreenFieldsValue(tabId, flag);


    //Check the mandatory field
    if (!checkMandatoryFields(tabId, [QUERY], screenFieldsValue)) { return false; }

    // This will clear all the content of datatable before executing new query
    destroyResultTab(tabId);
    $("#" + tabId + " #dtQBSummary").css('display', 'none');
    if (resultData != undefined && resultData[tabId] != undefined) {
        $.each(resultData[tabId], function (key, value) { $("#" + tabId + " #" + key + "btnResult").remove(); });
    }
    resultData[tabId] = undefined;
    var infotext = "";
    //if jira number is populated
    if (Cronus.isNotEmptyNullOrUndefined(screenFieldsValue[JIRANO])) {
        //Check for skip beta execution
        if (screenFieldsValue[SKIPBETAEXECUTION] == undefined) {
            swal("Error", "Select skip beta execution radio button", "error");
            return false;
        }
        screenFieldsValue[JIRABETAEXECUTIONDONE] = !isBetaExecution(tabId, screenFieldsValue);
        screenFieldsValue[ISBETAEXECUTION] = !screenFieldsValue[JIRABETAEXECUTIONDONE];
        //Check for skip Approver
        if ((screenFieldsValue[SKIPBETAEXECUTION] || screenFieldsValue[JIRABETAEXECUTIONDONE]) && screenFieldsValue[SKIPAPPROVAL] == undefined) {
            swal("Error", "Select skip approval radio button", "error");
            return false;
        }

        //Check if jira status is valid
        if (!jiraStatusValid(screenFieldsValue[JIRANO], screenFieldsValue[JIRASTATUS], screenFieldsValue[SKIPAPPROVAL], screenFieldsValue[SKIPBETAEXECUTION], screenFieldsValue[JIRABETAEXECUTIONDONE])) { return false; }

        //For beta execution the database should be beta.       
        screenFieldsValue[DATABASE] = getExecutionDBServer(tabId, screenFieldsValue, screenFieldsValue[ISBETAEXECUTION]);
        infotext = screenFieldsValue[ISBETAEXECUTION] ? "BetaExecution(" + screenFieldsValue[DATABASE] + ")\n" : "ProdExecution (" + screenFieldsValue[DATABASE] + ")\n";

    }
    if (screenFieldsValue[ISTRANSACTIONMODE] != "True") {
        infotext += "The query is running in non-transaction mode with auto commit, you won’t be able to rollback \n";
    }
    if (infotext != "") {
        //Confirm message to execute query on beta or prod server.
        swal({
            title: "Info" + ": " + tabId, text: infotext + "Do you wish to continue?", type: "info", showCancelButton: true, confirmButtonColor: "#2e6da4",
            confirmButtonText: "No", cancelButtonText: "Yes", cancelButtonColor: "#2e6da4", closeOnConfirm: true, closeOnCancel: true
        },
        function (isConfirm) {
            if (!isConfirm) { sendForExecution(tabId, screenFieldsValue); }
            else { return true; }
        });
    }
    else {
        sendForExecution(tabId, screenFieldsValue);
    }

    return true;
}

/*This function send the request to execute the query and display result accordingly */
function sendForExecution(tabId, screenFieldsValue) {

    var inputObj = { screenName: screenName, data: screenFieldsValue };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForQB, ".blockOverlayQuery", true);
    ajaxRequest[tabId] = retval.AjaxObj;
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            if ($('#' + tabId + " #ddlTransactionMode").val() == "True" && result.ActiveTransaction)
                updateCommitRollback(tabId, true, screenFieldsValue[ISBETAEXECUTION]);
                
            $("#txtQueryStatus").html(result.Summary);
            if (result.MessageType == "Warning") {
                $("#modalTitle").css("color", "red").html(result.MessageType);
                if ($('#' + tabId + " #ddlTransactionMode").val() == "True") {
                    $("#btnContinue").removeClass("hidden");
                    $("#btnRollbackQuery").removeClass("hidden");
                    $('#btnRollbackQuery').click(function () {
                        rollbackTab(tabId, false);
                        $(".close").click();
                    });
                }
                else {
                    $("#btnContinue").addClass("hidden");
                    $("#btnRollbackQuery").addClass("hidden");
                }
                $('#infoQueryModal').modal('show');
            }
            else if (result.MessageType == "Error") {
                $("#btnContinue").addClass("hidden");
                $("#btnRollbackQuery").addClass("hidden");
                $("#modalTitle").css("color", "red").html(result.MessageType);
                $('#infoQueryModal').modal('show');
            }
            else {
                //if query execution is successful
                $("#btnContinue").addClass("hidden");
                $("#btnRollbackQuery").addClass("hidden");
                $("#modalTitle").css("color", "black").html(result.MessageType);
                if (Cronus.isNotEmptyNullOrUndefined(screenFieldsValue[JIRANO]) && !result.ActiveTransaction) {
                    searchJira(tabId, uniqId, screenFieldsValue);
                    if (screenFieldsValue[JIRABETAEXECUTIONDONE] && betaExecutionTabIds[tabId] == undefined) {
                        closeJira(tabId, screenFieldsValue[JIRANO]);
                    }
                    else {
                        enableSkipApproval(tabId);
                    }
                }
            }
            

            var r_tabId = RESULTTAB + "00";
            resultData[tabId] = {};
            resultData[tabId][r_tabId] = result.Summary;
            $("#" + tabId + " #divResult").append('<button type="button" id="' + r_tabId + 'btnResult" tabid="' + tabId + '" result_tabid="' + r_tabId + '" class="btn btn-primary tabsbutton" onclick="result(this)">ResultSummary</button> ');

            if (typeof result.SelectDataCollection[0] !== 'undefined') {
                for (var resultTabId = 1; resultTabId <= result.SelectDataCollection.length; resultTabId++) {
                    var r_tabId = RESULTTAB + resultTabId;
                    if (resultTabId < 10)
                        r_tabId = RESULTTAB + "0" + resultTabId;
                    resultData[tabId][r_tabId] = result.SelectDataCollection[resultTabId - 1];

                    $("#" + tabId + " #divResult").append('<button type="button" id="' + r_tabId + 'btnResult" tabid="' + tabId + '" result_tabid="' + r_tabId + '" class="btn btn-primary tabsbutton" onclick="result(this)">' + r_tabId + '</button> ');
                }
            }
            $("#" + tabId + " #" + RESULTTAB + "00" + "btnResult").click();
            ajaxRequest[tabId] = "";
            isRollback = true;
        }
    });
}

/*This function is called onClick of Commit button */
function commitQuery(el) {
    var tabId = $(el).attr('tabId');
    $('#' + tabId + " #ddlTransactionMode").removeAttr("disabled");
    //  hideCommitRollback(tabId);
    //  $("#btnResetTimer_" + tabId).css("display", "none");
    //$("#btnStopTimer_" + tabId).click();

    //populate the data dictionary
    populateScreenFieldsValue(tabId);

    //Check if beta execution or prod execution
    screenFieldsValue[DATABASE] = getExecutionDBServer(tabId, screenFieldsValue, betaExecutionTabIds[tabId]);

    var inputObj = { screenName: screenName, data: screenFieldsValue };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.Commit, ".blockOverlayQuery", false);
    if (retval.Error == false) {
        swal("Info", tabId + ": " + "Commit Successfull", "success");
        if (Cronus.isNotEmptyNullOrUndefined(screenFieldsValue[JIRANO])) {
            if (!betaExecutionTabIds[tabId]) closeJira(tabId, screenFieldsValue[JIRANO]);
            else enableSkipApproval(tabId);
            searchJira(tabId, uniqId, screenFieldsValue);
        }
    }
    updateCommitRollback(tabId, false, false);
}

/*This function is called if page is refreshed or closed */
function rollbackAllTabs() {
    //Iterate to each tab do the following
    //If query is executing, cancel the query
    //If rollback button is enable call rollback.
    for (var i in openTabs) {
        cancelQuery(i);
        rollbackTab(i, true);
    }

    //the below swal is added for IE. if removed, this function is not called.
    return "Rollbacking all pending transactions of all open tabs";
}

/*This function is called escape if pressed */
function cancelQuery(tabId) {
    //if tabId is not passed take active tab
    if (tabId == undefined) tabId = activeTab;
    //populate the data dictionary
    populateScreenFieldsValue(tabId);

    //Check if beta execution or prod execution
    screenFieldsValue[DATABASE] = getExecutionDBServer(tabId, screenFieldsValue, betaExecutionTabIds[tabId]);

    if (ajaxRequest[tabId] != undefined) {
        if (ajaxRequest[tabId] == "") return;
        ajaxRequest[tabId].abort();
        var inputObj = { screenName: screenName, data: screenFieldsValue };
        var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.CancelAjax, ".blockOverlayQuery", false);
        if (retval.Error == false) { swal("Info", tabId + ": " + "Query Cancelled", "success"); }
    }
}

/*This function is called onClick of Rollback button */
function rollbackQuery(el) {
    var tabId = $(el).attr('tabId');


    $('#' + tabId + " #ddlTransactionMode").removeAttr("disabled");
    // hideCommitRollback(tabId);    //$("#btnResetTimer_" + tabId).css("display", "none");
    $("#btnStopTimer_" + tabId).click();
    rollbackTab(tabId, false);
}

/*This function send the request to rollback for asked tab */
function rollbackTab(tabId, force) {

    //populate the data dictionary
    populateScreenFieldsValue(tabId);

    //Check if beta execution or prod execution
    screenFieldsValue[DATABASE] = getExecutionDBServer(tabId, screenFieldsValue, betaExecutionTabIds[tabId]);

    var inputObj = { screenName: screenName, data: screenFieldsValue };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.Rollback, ".blockOverlayQuery", false);
    if (retval.Error == false && force == false) { swal("Info", tabId + ": " + "Rollback Successfull", "success"); }
    updateCommitRollback(tabId, false, false);
}

function updateDbSpan(el) {
    $("#spndatabse").html($(el).val());
    return false;
}


/*This function is called to enable or disable commit/rollback buttons*/
function updateCommitRollback(tabId, isEnable, isBetaExec) {
    if (isEnable) {

        if ($('#' + tabId + " #ddlTransactionMode").val() == "True") {
            countDownTimer(tabId);
            $('#' + tabId + " #ddlTransactionMode").attr('disabled', "disabled");
            showCommitRollback(tabId);
        }

    }



    openTabs[tabId] = isEnable;
    $("#" + tabId + " #ddlDatabase").attr('disabled', isEnable);
    $("#" + tabId + " #txtJIRAId").attr('disabled', isEnable);

    if (isEnable) {
        if (isBetaExec != undefined) betaExecutionTabIds[tabId] = isBetaExec;
        $("#" + tabId + " #btnCommit").attr('disabled', !isEnable).removeClass('disabledbtn');
        $("#" + tabId + " #btnRollback").attr('disabled', !isEnable).removeClass('disabledbtn');
        $("#" + tabId + " #btnCreateJIRATicket").attr('disabled', isEnable).addClass('disabledbtn');
        $("#" + tabId + " #btnSearchJIRAItem").attr('disabled', isEnable).addClass('disabledbtn');
        $("#" + tabId + " #btnReset").attr('disabled', isEnable).addClass('disabledbtn');

        // This will enable clicks on other links while commit/rollback are disabled
        $("#dvTabContent a").each(function () {
            $(this).bind('click', false);
        });
    }
    else {
        $("#btnStopTimer_" + tabId).click();
        $('#' + tabId + " #ddlTransactionMode").removeAttr("disabled");

        if (isBetaExec != undefined) betaExecutionTabIds[tabId] = undefined;
        $("#" + tabId + " #btnCommit").attr('disabled', !isEnable).addClass('disabledbtn');
        $("#" + tabId + " #btnRollback").attr('disabled', !isEnable).addClass('disabledbtn');
        $("#" + tabId + " #btnCreateJIRATicket").attr('disabled', isEnable).removeClass('disabledbtn');
        $("#" + tabId + " #btnSearchJIRAItem").attr('disabled', isEnable).removeClass('disabledbtn');
        $("#" + tabId + " #btnReset").attr('disabled', isEnable).removeClass('disabledbtn');

        // This will disable clicks on other links while commit/rollback are enabled
        $("#dvTabContent a").each(function () {
            $(this).unbind('click');
        });
    }
}

/*The below functions are related to JIRA*/

/*This function cache team and group Responsibilities*/
function populateResponsibility() {
    var inputObj = { screenName: screenName, tableName: "Responsibile" };
    responsibility = {};
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlayQuery", false);
    if (retval.Error == false) {
        var result = retval.Result;
        for (var i = 0; i < result.rows.length; i++) {
            var groupResponsibility = result.rows[i][0];
            var teamResponsibility = result.rows[i][1];
            if (responsibility[GROUPRESPONSIBILITY] == undefined)
                responsibility[GROUPRESPONSIBILITY] = [];

            if (responsibility[groupResponsibility] == undefined) {
                responsibility[GROUPRESPONSIBILITY].push({ data: groupResponsibility, value: groupResponsibility });
                responsibility[groupResponsibility] = [];
            }
            responsibility[groupResponsibility].push({ data: teamResponsibility, value: teamResponsibility });
        }
    }
}

/*This function to populate group Responsibilities*/
function populateGroupResponsibility(tabId) {
    populateDropDown(tabId, responsibility[GROUPRESPONSIBILITY], "#" + tabId + " #txtGroupResponsibile", "#" + tabId + " #txtTeamResponsibile", populateTeamResponsibility);
}

/*This function to populate team Responsibilities*/
function populateTeamResponsibility(tabId) {
    var groupResponsibility = $("#" + tabId + " #txtGroupResponsibile").val();
    populateDropDown(tabId, responsibility[groupResponsibility], "#" + tabId + " #txtTeamResponsibile", null, null);
}

function getApproverId(tabId) {
    if (Cronus.isNotEmptyNullOrUndefined($("#" + tabId + " #txtApprover").val()) && $("#" + tabId + " #txtApprover").val().indexOf("-") > 0)
        return ($("#" + tabId + " #txtApprover").val().split("-")[1].trim());
}

/*This function is used to disable and enable Jira Item input from user */
function disableEnableJiraFields(screenFields, disable) {
    screenFields[JIRASUMMARY].attr('disabled', disable);
    screenFields[REQUESTTYPE].attr('disabled', disable);
    screenFields[GROUPRESPONSIBILITY].attr('disabled', disable);
    screenFields[TEAMRESPONSIBILITY].attr('disabled', disable);
    screenFields[APPROVER].attr('disabled', disable);
    screenFields[DATABASE].attr('disabled', disable);
    screenFields[CATEGORY].attr('disabled', disable);
    screenFields[QUERYNAME].attr('disabled', disable);
    screenFields[QUERY].attr('disabled', disable);
}

/*This function is called onClick of CreateJira*/
function createJIRATicket(el) {
    var tabId = $(el).attr('tabId');
    //populate the data dictionary
    populateScreenFieldsValue(tabId);
    var fields = [JIRASUMMARY, REQUESTTYPE, GROUPRESPONSIBILITY, TEAMRESPONSIBILITY, APPROVER, QUERY];
    if (!checkMandatoryFields(tabId, fields, screenFieldsValue)) return false;

    var inputObj = { screenName: screenName, data: screenFieldsValue, functionName: "CreateJiraItem" };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, ".blockOverlayQuery", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage === "") {
            //swal("Info: " + tabId, "JIRA Created", "success");
            screenFields[JIRANO].val(result.JIRANo);
            //screenFields[JIRALINK].attr('disabled', true).val(result.JIRALink);
            screenFields[JIRALINK].prop("href", result.JIRALink);
            screenFields[JIRALINK].prop("target", "_blank");
            screenFields[JIRASTATUS].val(result.JIRAStatus);
            screenFields[SKIPBETAEXECUTIONY].prop("checked", false);
            screenFields[SKIPBETAEXECUTIONN].prop("checked", false);
            screenFields[SKIPAPPROVALY].prop("checked", false);
            screenFields[SKIPAPPROVALN].prop("checked", false);
            screenFields[SKIPAPPROVALREASON].val("");
            screenFields[SKIPBETAEXECUTIONREASON].val("");

            disableEnableJiraFields(screenFields, true);

            $("#" + tabId + " #btnCreateJIRATicket").attr('disabled', false).removeClass('disabledbtn');
            $("#" + tabId + " #btnEdit").attr('disabled', false).removeClass('disabledbtn');
            $("#" + tabId + " #btnSave").attr('disabled', true).addClass('disabledbtn');

            enableBetaExecution(tabId, undefined, screenFieldsValue[ENVIRONMENT]);
            enableSkipApproval(tabId);
        }
    });
}

/*This function is called onClick of Reset button*/
function resetTab(el) {
    var tabId = $(el).attr('tabId');
    //populate the data dictionary
    populateScreenFieldsValue(tabId);

    screenFields[JIRANO].val("");
    screenFields[JIRALINK].removeAttr("href");
    screenFields[JIRALINK].text("JIRA ID Link");
    screenFields[JIRASTATUS].val("");
    screenFields[JIRABETAEXECUTIONDONE].val("");

    disableEnableJiraFields(screenFields, false);
    screenFields[JIRASUMMARY].val("");
    screenFields[REQUESTTYPE].val("");
    screenFields[GROUPRESPONSIBILITY].val("");
    screenFields[TEAMRESPONSIBILITY].val("");
    screenFields[APPROVER].val("");
    screenFields[QUERY].val("");
    screenFields[CATEGORY].val("");
    screenFields[QUERYNAME].val("");
    screenFields[SKIPAPPROVALREASON].val("");
    screenFields[SKIPBETAEXECUTIONREASON].val("");

    screenFields[SKIPBETAEXECUTIONY].prop("checked", false);
    screenFields[SKIPBETAEXECUTIONN].prop("checked", false);
    screenFields[SKIPAPPROVALY].prop("checked", false);
    screenFields[SKIPAPPROVALN].prop("checked", false);

    $("#" + tabId + " #btnEdit").attr('disabled', true).addClass('disabledbtn');
    $("#" + tabId + " #btnSave").attr('disabled', true).addClass('disabledbtn');
    $("#" + tabId + " #btnCreateJIRATicket").attr('disabled', false).removeClass('disabledbtn'); //uncomment this once service user created 

    disableBetaExecution(tabId);
    disableSkipApproval(tabId);
}

/*This function is called onClick of Edit button*/
function editJira(el) {
    var tabId = $(el).attr('tabId');
    //populate the data dictionary
    populateScreenFieldsValue(tabId);

    disableEnableJiraFields(screenFields, false);
    disableBetaExecution(tabId);
    disableSkipApproval(tabId);

    $("#" + tabId + " #btnEdit").attr('disabled', true).addClass('disabledbtn');
    $("#" + tabId + " #btnSave").attr('disabled', false).removeClass('disabledbtn');
    $("#" + tabId + " #btnCreateJIRATicket").attr('disabled', false).removeClass('disabledbtn'); //uncomment this once service user created
    $("#" + tabId + " #btnExecute").attr('disabled', true).addClass('disabledbtn');
}

/*This function is called onClick of Save button*/
function saveJira(el) {
    var tabId = $(el).attr('tabId');
    //populate the data dictionary
    populateScreenFieldsValue(tabId);

    var fields = [JIRASUMMARY, REQUESTTYPE, GROUPRESPONSIBILITY, TEAMRESPONSIBILITY, APPROVER, QUERY];
    if (!checkMandatoryFields(tabId, fields, screenFieldsValue)) return false;

    var inputObj = { screenName: screenName, data: screenFieldsValue, functionName: "SaveJiraItem" };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, ".blockOverlayQuery", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            // swal("Info: " + tabId, "JIRA Saved", "success");
            disableEnableJiraFields(screenFields, true);
            enableBetaExecution(tabId, undefined, screenFieldsValue[ENVIRONMENT]);
            enableSkipApproval(tabId);

            $("#" + tabId + " #btnEdit").attr('disabled', false).removeClass('disabledbtn');
            $("#" + tabId + " #btnSave").attr('disabled', true).addClass('disabledbtn');
            $("#" + tabId + " #btnCreateJIRATicket").attr('disabled', false).removeClass('disabledbtn');
            $("#" + tabId + " #btnExecute").attr('disabled', false).removeClass('disabledbtn');
            searchJira(tabId, uniqId, screenFieldsValue);
        }
    });
    return true;
}

function searchJIRAItem(el) {
    var tabId = $(el).attr('tabId');
    //populate the data dictionary
    populateScreenFieldsValue(tabId);

    var fields = [JIRANO];
    if (!checkMandatoryFields(tabId, fields, screenFieldsValue)) return false;

    searchJira(tabId, uniqId, screenFieldsValue);
    return true;
}

function searchJira(tabId, uniqId, screenFieldsValue) {
    var inputObj = { screenName: screenName, data: screenFieldsValue, functionName: "SearchJiraItem" };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, ".blockOverlayQuery", true);

    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            if (result.Environment != screenFields[ENVIRONMENT].val()) {
                swal("Error: ", "Please select " + result.Environment + " environment as jira is of " + result.Environment + " environment", "error");
                return;
            }
            //screenFields[JIRALINK].attr('disabled', true).val(result.JIRALink);
            screenFields[JIRANO].val(result.JIRANo);
            screenFields[JIRALINK].prop("href", result.JIRALink);
            screenFields[JIRALINK].prop("target", "_blank");
            screenFields[JIRASTATUS].val(result.JIRAStatus);

            if (result.SkipApprovalReason != undefined) screenFields[SKIPAPPROVALREASON].val(result.SkipApprovalReason);
            else screenFields[SKIPAPPROVALREASON].val("");
            if (result.SkipBetaExecutionReason != undefined) screenFields[SKIPBETAEXECUTIONREASON].val(result.SkipBetaExecutionReason);
            else screenFields[SKIPBETAEXECUTIONREASON].val("");
            enableBetaExecution(tabId, result.SkipBetaExecution, screenFieldsValue[ENVIRONMENT]);
            if (result.SkipBetaExecution != undefined) {
                screenFields[SKIPBETAEXECUTIONY].prop("checked", result.SkipBetaExecution);
                screenFields[SKIPBETAEXECUTIONN].prop("checked", !result.SkipBetaExecution);
            }

            if (result.SkipApproval != undefined) {

                screenFields[SKIPAPPROVALY].prop("checked", result.SkipApproval);
                screenFields[SKIPAPPROVALN].prop("checked", !result.SkipApproval);

            }
            else {
                screenFields[SKIPAPPROVALY].prop("checked", false);
                screenFields[SKIPAPPROVALN].prop("checked", false);
            }

            disableEnableJiraFields(screenFields, true);
            screenFields[JIRASUMMARY].val(result.JIRASummary);
            screenFields[REQUESTTYPE].val(result.RequestType);
            screenFields[GROUPRESPONSIBILITY].val(result.GroupResponsibility);
            screenFields[TEAMRESPONSIBILITY].val(result.TeamResponsibility);
            screenFields[APPROVER].val(result.Approver);
            screenFields[QUERY].val(result.Query);

            screenFields[DATABASE].val(databases[result.Environment][result.DBType]).attr('selected', true).change();


            $("#" + tabId + " #btnCreateJIRATicket").attr('disabled', false).removeClass('disabledbtn');
            $("#" + tabId + " #btnEdit").attr('disabled', false).removeClass('disabledbtn');
            $("#" + tabId + " #btnSave").attr('disabled', true).addClass('disabledbtn');


            enableSkipApproval(tabId);
            if (result.JIRABetaExecutionDone != undefined || (screenFields[SKIPBETAEXECUTIONY].is(':checked'))) {
                if (result.JIRABetaExecutionDone != undefined) {
                    screenFields[JIRABETAEXECUTIONDONE].val("Beta Execution:Done");
                    disableBetaExecution(tabId);
                }
                else {
                    screenFields[JIRABETAEXECUTIONDONE].val("Beta Execution:NA");
                    if ((screenFields[SKIPAPPROVALY].is(':checked')) || (screenFields[SKIPAPPROVALN].is(':checked'))) disableBetaExecution(tabId);
                }
            }
            else {
                screenFields[JIRABETAEXECUTIONDONE].val("Beta Execution:Pending");
                disableSkipApproval(tabId);
            }
            if (result.JIRAStatus == "In Progress") {
                screenFields[SKIPAPPROVALY].prop("checked", false);
                screenFields[SKIPAPPROVALN].prop("checked", false);
            }
        }
    });
}

/*This function send request to close/reopen the JIRA*/
function closeJira(tabId, jiraNo) {
    if (tabId != activeTab) return;
    //populate the data dictionary
    populateScreenFieldsValue(tabId);

    swal({
        title: "Info" + ": " + tabId, text: "Do you wish to re-use the same JIRA ID for executing another Query?", type: "info", showCancelButton: true, confirmButtonColor: "#2e6da4",
        confirmButtonText: "No", cancelButtonText: "Yes", cancelButtonColor: "#2e6da4", closeOnConfirm: true, closeOnCancel: true
    },
    function (isConfirm) {
        if (isConfirm) {
            var inputObj = { screenName: screenName, data: screenFieldsValue, functionName: "CloseJiraItem" };
            Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, ".blockOverlayQuery", false);
            searchJira(tabId, uniqId, screenFieldsValue);
            disableBetaExecution(tabId);
            $("#" + tabId + " #rdSkipBetaExecutionN").prop("checked", false);
            $("#" + tabId + " #rdSkipBetaExecutionY").prop("checked", false);
            enableBetaExecution(tabId, undefined, screenFieldsValue[ENVIRONMENT]);
            disableSkipApproval(tabId);
        }
        else {
            var inputObj = { screenName: screenName, data: screenFieldsValue, functionName: "ReopenJiraItem" };
            Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, ".blockOverlayQuery", false);
            $("#" + tabId + " #rdSkipBetaExecutionN").prop("checked", false);
            $("#" + tabId + " #rdSkipBetaExecutionY").prop("checked", false);
            searchJira(tabId, uniqId, screenFieldsValue);
        }
    });
}
/*
Skip Approval Functions Disable and Enable
*/
function disableSkipApproval(l_tabId) {
    $("#" + l_tabId + " #rdSkipApprovalY").attr('disabled', true).addClass('disabledbtn');
    $("#" + l_tabId + " #rdSkipApprovalN").attr('disabled', true).addClass('disabledbtn');
}

function enableSkipApproval(l_tabId) {
    $("#" + l_tabId + " #rdSkipApprovalY").attr('disabled', false).removeClass('disabledbtn');
    $("#" + l_tabId + " #rdSkipApprovalN").attr('disabled', false).removeClass('disabledbtn');
}

/*This function is called onClick of skip Approval*/
function skipApprovalOnClick(el, skip) {
    var weekday = new Date().getDay();
    var dt = new Date();
    var tabId = $(el).attr('tabId');
    //skip approval not allowed between Sunday 8 PM PST to Fiday 6 PM
    if (((weekday == 0 && dt.getHours() > 19) || (weekday == 1 || weekday == 2 || weekday == 3 || weekday == 4) || (weekday == 5 && dt.getHours() <= 17)) && skip == true) {
        swal("error", "Sorry! your cann't skip approval from Sunday 8 PM PST to Fiday 6 PM.", "error");
        $("#" + tabId + " #rdSkipApprovalY").prop('checked', false);
    }
    else {

        //populate the data dictionary
        populateScreenFieldsValue(tabId);
        if (screenFieldsValue[JIRASTATUS] == "Pending Approval" && skip) {
            swal("Error!!! Invalid Status", "Jira item " + screenFieldsValue[JIRANO] + " approval can not be skipped as status is Pending Approval", "error");
            searchJira(tabId, uniqId, screenFieldsValue);
            return false;
        }

        screenFields[SKIPAPPROVALREASON].val("");
        screenFieldsValue[SKIPAPPROVALREASON] = "";
        if (skip) {
            $("#txtSkipApprovalModalReason").val("");
            $('#skipApprovalModal').modal({ show: true, backdrop: 'static', keyboard: false });
        }
        else {
            screenFieldsValue[SKIPAPPROVAL] = false;
            //Ajax call to Update the description
            var inputObj = { screenName: screenName, data: screenFieldsValue, functionName: "SkipApprovalSelected" };
            Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, ".blockOverlayQuery", false);

            //Ajax call to change the status 
            inputObj = { screenName: screenName, data: screenFieldsValue, functionName: "SendForApproval" };
            Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, ".blockOverlayQuery", false);
        }

        //Refresh the screen
        searchJira(tabId, uniqId, screenFieldsValue);
    }
}

/*This function is called onClick of OK button of skipApprovalReason Modal*/
function copySkipApprovalReason() {
    var tabId = activeTab;
    //populate the data dictionary
    populateScreenFieldsValue(tabId);
    screenFields[SKIPAPPROVALREASON].val($("#txtSkipApprovalModalReason").val());
    screenFieldsValue[SKIPAPPROVALREASON] = $("#txtSkipApprovalModalReason").val();
    if (!checkMandatoryFields(tabId, [SKIPAPPROVALREASON], screenFieldsValue)) return false;
    $("#skipApprovalModal").modal('hide');

    //Update Description
    screenFieldsValue[SKIPAPPROVAL] = true;
    var inputObj = { screenName: screenName, data: screenFieldsValue, functionName: "SkipApprovalSelected" };
    Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, ".blockOverlayQuery", false);

    //Refresh the screen
    searchJira(tabId, uniqId, screenFieldsValue);
    return true;
}

/*This function is called onClick of CANCEL button of skipApprovalReason Modal*/
function cancelApprovalReason() {
    if ($("#" + activeTab + " #txtSkipApprovalReason").val() == undefined || $("#" + activeTab + " #txtSkipApprovalReason").val() == null || $("#" + activeTab + " #txtSkipApprovalReason").val() == "")
        $("#" + activeTab + " #rdSkipApprovalY").prop('checked', false);
    $("#skipApprovalModal").modal('hide');
}

/*
Skip Beta Execution Functions disable and enable
*/
function disableBetaExecution(l_tabId) {
    $("#" + l_tabId + " #rdSkipBetaExecutionY").attr('disabled', true).addClass('disabledbtn');
    $("#" + l_tabId + " #rdSkipBetaExecutionN").attr('disabled', true).addClass('disabledbtn');
}

function enableBetaExecution(l_tabId, skipBetaExecution, environment) {
    //By default SkipBetaExecution should be N for prod and Y for others
    if (skipBetaExecution == undefined) {
        if (document.location.host == 'cronus' && environment == "PROD")
            $("#" + l_tabId + " #rdSkipBetaExecutionN").prop("checked", true);
        else {
            $("#" + l_tabId + " #rdSkipBetaExecutionY").prop("checked", true);
            $("#" + l_tabId + " #txtSkipBetaExecutionReason").val(environment + " Env");
        }
    }
    $("#" + l_tabId + " #rdSkipBetaExecutionY").attr('disabled', false).removeClass('disabledbtn');
    $("#" + l_tabId + " #rdSkipBetaExecutionN").attr('disabled', false).removeClass('disabledbtn');
}

/*This function is called onClick of skipBetaExecution radio button*/
function skipBetaExecutionOnClick(el, skip) {
    var tabId = $(el).attr('tabId');
    //populate the data dictionary
    populateScreenFieldsValue(tabId);

    screenFields[SKIPBETAEXECUTIONREASON].val("");
    screenFieldsValue[SKIPBETAEXECUTIONREASON] = "";
    if (skip) {
        $("#txtSkipBetaExecutionModalReason").val("");
        $('#skipBetaEcecutionModal').modal({ show: true, backdrop: 'static', keyboard: false });
    }
    else {
        screenFieldsValue[SKIPBETAEXECUTION] = false;
        //Update description
        var inputObj = { screenName: screenName, data: screenFieldsValue, functionName: "SkipBetaExecutionSelected" };
        Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, ".blockOverlayQuery", false);
    }

    //Update Screen
    searchJira(tabId, uniqId, screenFieldsValue);
}

/*This function is called onClick of OK button of skipBetaExecutionReason Modal*/
function copyBetaExecutionReason() {
    var tabId = activeTab;
    //populate the data dictionary

    populateScreenFieldsValue(tabId);

    screenFields[SKIPBETAEXECUTIONREASON].val($("#txtSkipBetaExecutionModalReason").val());
    screenFieldsValue[SKIPBETAEXECUTIONREASON] = $("#txtSkipBetaExecutionModalReason").val();
    if (!checkMandatoryFields(tabId, [SKIPBETAEXECUTIONREASON], screenFieldsValue)) {
        return false;
    }
    $("#skipBetaEcecutionModal").modal('hide');
    enableSkipApproval(tabId);


    //Update description
    screenFieldsValue[SKIPBETAEXECUTION] = true;
    var inputObj = { screenName: screenName, data: screenFieldsValue, functionName: "SkipBetaExecutionSelected" };
    Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, ".blockOverlayQuery", false);

    //Update Screen
    searchJira(tabId, uniqId, screenFieldsValue);



}

/*This function is called onClick of CANCEL button of skipBetaExecutionReason Modal*/
function cancelBetaExecutionReason() {
    if ($("#" + activeTab + " #txtSkipBetaExecutionReason").val() == undefined || $("#" + activeTab + " #txtSkipBetaExecutionReason").val() == null || $("#" + activeTab + " #txtSkipBetaExecutionReason").val() == "")
        $("#" + activeTab + " #rdSkipBetaExecutionY").prop('checked', false);
    $("#skipBetaEcecutionModal").modal('hide');
}


/*
Save Query functionality
*/
function openModal(tabId) {
    $('#hdnCurrTabId').val(tabId);
    populateScreenFieldsValue(tabId);

    $('#txtDatabaseName').val(screenFieldsValue[DATABASE]);
    $('#txtQuerySaved').val(screenFieldsValue[QUERY]);
    $('#txtCategoryName').val(Cronus.isNotEmptyNullOrUndefined(screenFieldsValue[CATEGORY]) ? screenFieldsValue[CATEGORY] : "");
    $('#txtQueryName').val(Cronus.isNotEmptyNullOrUndefined(screenFieldsValue[QUERYNAME]) ? screenFieldsValue[QUERYNAME] : "");
    $('#saveQueryModal').modal('show');
}

/*This function is used to populate category dropdown */
function populateCategoryDropDown(tabId) {
    var connection = $("#" + tabId + " #ddlDatabase").val();

    if (savedQueriesCache[connection] != undefined && savedQueriesCache[connection][CATEGORY] != undefined)
        populateDropDown(tabId, savedQueriesCache[connection][CATEGORY], "#" + tabId + " #txtCategory", "#" + tabId + " #txtQName", populateQueryName);
    else
        populateDropDown(tabId, null, "#" + tabId + " #txtCategory", "#" + tabId + " #txtQName", populateQueryName);
}

/*This function is used to populate queryName dropdown */
function populateQueryName(tabId) {
    var connection = $("#" + tabId + " #ddlDatabase").val();
    var category = $("#" + tabId + " #txtCategory").val();
    if (savedQueriesCache[connection] != undefined && savedQueriesCache[connection][category] != undefined)
        populateDropDown(tabId, savedQueriesCache[connection][category][QUERYNAME], "#" + tabId + " #txtQName", null, populateQuery);
    else
        populateDropDown(tabId, null, "#" + tabId + " #txtQName", null, populateQuery);
}

/*This function is used to cache saved queries dropdown */
function getSavedQueries() {
    var inputObj = { screenName: screenName, tableName: "SaveQueries" };
    savedQueriesCache = {};
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlayQuery", false);
    if (retval.Error == false) {
        var result = retval.Result;
        for (var i = 0; i < result.rows.length; i++) {
            var category = result.rows[i][0];
            var name = result.rows[i][1];
            var dbName = result.rows[i][2];
            var text = result.rows[i][3];
            if (savedQueriesCache[dbName] == undefined)
                savedQueriesCache[dbName] = {};

            if (savedQueriesCache[dbName][CATEGORY] == undefined)
                savedQueriesCache[dbName][CATEGORY] = [];

            if (savedQueriesCache[dbName][category] == undefined)
                savedQueriesCache[dbName][CATEGORY].push({ data: category, value: category });

            if (savedQueriesCache[dbName][category] == undefined)
                savedQueriesCache[dbName][category] = {};

            if (savedQueriesCache[dbName][category][QUERYNAME] == undefined)
                savedQueriesCache[dbName][category][QUERYNAME] = [];

            if (savedQueriesCache[dbName][category][name] == undefined)
                savedQueriesCache[dbName][category][QUERYNAME].push({ data: name, value: name });
            savedQueriesCache[dbName][category][name] = text;
        }
    }
}

/*This function is used to populate query if selected saved query */
function populateQuery(tabId, key) {
    populateScreenFieldsValue(tabId);

    screenFields[QUERY].html('');
    screenFields[QUERY].val('');
    var connection = screenFieldsValue[DATABASE];
    var category = screenFieldsValue[CATEGORY];
    var queryName = screenFieldsValue[QUERYNAME];
    if (savedQueriesCache[connection][category] != undefined && savedQueriesCache[connection][category][queryName]) {
        screenFields[QUERY].html(savedQueriesCache[connection][category][queryName]);
        screenFields[QUERY].val((savedQueriesCache[connection][category][queryName]));
    }
}

/*This function is called if user change the database */
function databaseChange(el) {
    var tabId = $(el).attr('tabId');
    populateCategoryDropDown(tabId);
}

/*This function is called onClick of OK button of save query modal*/
function saveQuery() {
    var tabId = activeTab;
    var connection = $("#txtDatabaseName").val();
    var query = $("#txtQuerySaved").val().trim();
    var queryName = $("#txtQueryName").val().trim();
    var categoryName = $("#txtCategoryName").val().trim();
    if (!Cronus.isNotEmptyNullOrUndefined(connection)) {
        swal("Oops", "DBName can not be null or empty", "error");
        return false;
    }
    else if (!Cronus.isNotEmptyNullOrUndefined(categoryName)) {
        swal("Oops", "Category can not be null or empty", "error");
        $("#txtCategoryName").focus();
        return false;
    }
    else if (!Cronus.isNotEmptyNullOrUndefined(query)) {
        swal("Oops", "Query can not be null or empty", "error");
        $("#txtQuerySaved").focus();
        return false;
    }

    else if (!Cronus.isNotEmptyNullOrUndefined(queryName)) {
        swal("Oops", "Query Name can not be null or empty", "error");
        $("#txtQueryName").focus();
        return false;
    }

    var inputObj = { screenName: screenName, data: { dbName: connection, tabId: tabId, query: query, name: queryName, category: categoryName } };

    if (savedQueriesCache[connection] != undefined && savedQueriesCache[connection][categoryName] != undefined && savedQueriesCache[connection][categoryName][queryName]) {
        swal({
            title: "Warning: " + tabId, text: "Do you want to override the query?", type: "warning", showCancelButton: true, confirmButtonColor: "#2e6da4",
            confirmButtonText: "Cancel", cancelButtonText: "Ok", cancelButtonColor: "#2e6da4", closeOnConfirm: true, closeOnCancel: false
        },
            function (isConfirm) {
                if (!isConfirm) {
                    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, ".blockOverlayQuery", false);
                    if (retval.Error == false) {
                        swal("Info: " + tabId, "Query Saved", "success");
                        getSavedQueries();
                        populateCategoryDropDown(activeTab);
                    }
                }
            });
    }
    else {
        var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, ".blockOverlayQuery", false);
        if (retval.Error == false) {
            swal("Info: " + tabId, "Query Saved", "success");
            getSavedQueries();
            populateCategoryDropDown(activeTab);
        }
    }
    return true;
}

/*This function is called onClick of any tabid */
function showTab(el) {
    $("#dvTab .tabsbutton").each(function () {
        $(this).addClass("disabledbtn");
    });
    $(el).removeClass('disabledbtn');
    var tabId = $(el).attr('tabId');
    $("#dvTabContent .divTabBody").each(function () {
        $(this).hide();
    });
    $("#" + tabId).show();

    $("#" + tabId + " #txtquery").focus();
    activeTab = tabId;
}
function result(el) {
    var tabId = $(el).attr('tabId');
    var r_tabId = $(el).attr('result_tabId');
    //gkg
    $("#divResult .tabsbutton").each(function () {
        $(this).addClass("disabledbtn");
    });

    $(el).removeClass("disabledbtn");
    populateResultTab(tabId, r_tabId);
}

/*This function is called to add tab */
function addTab() {
    var tabIdNo = parseInt($("#dvTab").children().length);

    $("#dvTab .tabsbutton").each(function () {
        $(this).addClass("disabledbtn");
    });
    var tabId = "Tab" + tabIdNo;
    if (tabIdNo < 10)
        tabId = "Tab0" + tabIdNo;

    $('#dvTab input:last').before("<input type='button' class='btn btn-primary tabsbutton' id='btn" + tabId + "' " +
            "value='" + tabId + "' tabid='" + tabId + "' onclick='showTab(this);' />");

    $("#dvTabContent .divTabBody").each(function () {
        $(this).hide();
    });

    $("#dvTabContent").append('<div class="row divTabBody " id="' + tabId + '" style="display: block">' +
            '<br />' +
             '<div class="row" >' +
                '<div class="col-lg-2 col-sm-2 col-md-2">' +
                        '<input type="text"  class="margin-right-20 form-control" placeholder="JIRA ID" id="txtJIRAId" tabid="' + tabId + '">' +
                '</div>' +
                '<div class="col-lg-2 col-sm-2 col-md-2">' +
                        '<a target="_blank" id="lblJIRALink" tabid="' + tabId + '"> JIRA ID Link</a> ' +
                '</div>' +
                '<div class="col-lg-2 col-sm-2 col-md-2">' +
                        '<input type="text"  class="margin-right-20 form-control" readonly="readonly" placeholder="JIRA Status" id="txtStatusMessage" tabid="' + tabId + '">' +
                '</div>' +
                '<div class="col-lg-2 col-sm-2 col-md-2">' +
                        '<input type="text"  class="margin-right-20 form-control" readonly="readonly" placeholder="Beta Execution Status" id="txtBetaExecutionDone" tabid="' + tabId + '">' +
                '</div>' +
                '<div class="col-lg-1 col-sm-1 col-md-1">' +
                        '<button type="button" id="btnSearchJIRAItem" tabid="' + tabId + '" class="btn btn-primary" onclick="searchJIRAItem(this)"> Search</button> ' +
                        '</div>' +
                 '<div class="col-lg-1 col-sm-1 col-md-1">' +
                        '<button type="button" id="btnReset" tabid="' + tabId + '" class="btn btn-primary" onclick="resetTab(this)"> Reset</button> ' +
                 '</div>' +
                 '<div class="col-lg-2 col-sm-2 col-md-2">' +
                        '<button type="button" id="btnEdit" tabid="' + tabId + '" class="btn btn-primary" onclick="editJira(this)"> Edit</button> ' +
                        '<button type="button" id="btnSave" tabid="' + tabId + '" class="btn btn-primary" onclick="saveJira(this)"> Save</button> ' +
                '</div>' +
            '</div>' +
            '<br />' +
              '<div class="row">' +
                '<div class="col-lg-2 col-sm-2 col-md-2">' +
                        '<input type="text"  class="margin-right-20 form-control" placeholder="Summary" id="txtSummary" tabid="' + tabId + '">' +
                '</div>' +
                '<div class="col-lg-2 col-sm-2 col-md-2">' +
                        '<input type="text"  class="margin-right-20 form-control" placeholder="Request Type" id="txtRequestType" tabid="' + tabId + '">' +
                '</div>' +
                '<div class="col-lg-2 col-sm-2 col-md-2">' +
                        '<input type="text"  class="margin-right-20 form-control" placeholder="GroupResponsibile" id="txtGroupResponsibile" tabid="' + tabId + '">' +
                '</div>' +
                '<div class="col-lg-2 col-sm-2 col-md-2">' +
                        '<input type="text"  class="margin-right-20 form-control" placeholder="TeamResponsibile" id="txtTeamResponsibile" tabid="' + tabId + '">' +
                '</div>' +
                 '<div class="col-lg-2 col-sm-2 col-md-2">' +
                        '<input type="text"  class="margin-right-20 form-control" placeholder="Approver" id="txtApprover" tabid="' + tabId + '">' +
                '</div>' +
                 '<div class="col-lg-2 col-sm-2 col-md-2">' +
                        '<button type="button" id="btnCreateJIRATicket" tabid="' + tabId + '" class="btn btn-primary" onclick="createJIRATicket(this)"> Create JIRA Ticket</button> ' +
                '</div>' +
            '</div>' +
            '<br />' +
             '<div class="row">' +
                    '<div class="col-lg-4 col-sm-4 col-md-4" >' +
                        '<label">Skip Beta Execution </label>' +

                        '<label class="radio-inline margin-left-20"> <input type="radio" tabid="' + tabId + '"  id="rdSkipBetaExecutionY" value="Skip Beta Execution" onclick="skipBetaExecutionOnClick(this, true)" /> Yes </label>' +
                        '<label class="radio-inline"> <input type="radio" tabid="' + tabId + '" id="rdSkipBetaExecutionN" value="Skip Beta Execution" onclick="skipBetaExecutionOnClick(this, false)" /> No </label>' +
                    '</div>' +
                    '<div class="col-lg-4 col-sm-4 col-md-4">' +
                        '<label">Skip Approval </label>' +
                       '<label class="radio-inline margin-left-20"> <input type="radio" tabid="' + tabId + '" id="rdSkipApprovalY" value="Skip Approval" onclick="skipApprovalOnClick(this, true)" /> Yes </label>' +
                       '<label class="radio-inline"> <input type="radio" tabid="' + tabId + '" id="rdSkipApprovalN" value="Skip Approval" onclick="skipApprovalOnClick(this, false)"/> No </label>' +
                    '</div>' +
            '</div>' +
            '<div class="row">' +
                    '<div class="col-lg-4 col-sm-4 col-md-4" >' +
                        '<input type="text"  class="form-control form-inline" readonly="readonly" placeholder="Reason" id="txtSkipBetaExecutionReason" tabid="' + tabId + '">' +
                    '</div>' +
                 '<div class="col-lg-4 col-sm-4 col-md-4">' +
                       '<input type="text"  class="form-control  form-inline" readonly="readonly" placeholder="Reason" id="txtSkipApprovalReason" tabid="' + tabId + '">' +
                    '</div>' +
            '</div>' +
            '<br />' +

            '<div class="row">' +
                '<div class="col-lg-2 col-sm-2 col-md-2">' +
                    '<select class="form-control" id="ddlDatabase" tabid="' + tabId + '" onchange="databaseChange(this);" onclick="javascript:return updateDbSpan(this);">' +
                    '</select>' +
                '</div>' +
                 '<div class="col-lg-2 col-sm-2 col-md-2">' +
                    '<input class="form-control" type="text" id="txtCategory" tabid="' + tabId + '" placeholder="Category" style="height: 30px !important;"/>' +
                '</div>' +
                '<div class="col-lg-2 col-sm-2 col-md-2">' +
                    '<input class="form-control" type="text" id="txtQName" tabid="' + tabId + '" placeholder="QueryName" style="height: 30px !important;"/>' +
                '</div>' +
                 '<div class="col-lg-1 col-sm-1 col-md-1">' +
                     '<button type="button" id="btnSaveQuery" tabid="' + tabId + '" class="btn btn-primary" onclick="openModal(\'' + tabId + '\')"> Save Query</button> ' +
                '</div>' +
    //                 '<div class="col-lg-2 col-sm-2 col-md-2">' +
    //                        '<input type="text"  class="form-control" placeholder="history" id="txtPastQueries" tabid="' + tabId + '">' +
    //                '</div>' +
            '</div>' +
            '<br />' +
            '<div class="row">' +
                '<div class="col-lg-12 col-sm-12 col-md-12"> ' +
                    '<textarea class="form-control" rows="5" cols="3" id="txtquery" tabid="' + tabId + '" placeholder="Enter your query. Use semicolon (;) as a separator for multiple queries"   ></textarea> ' +
                     '<textarea class="form-control" rows="5" style="display:none" cols="3" id="txtquerynew" tabid="' + tabId + '" placeholder="Enter your query. Use semicolon (;) as a separator for multiple queries"  ></textarea> ' +
                '</div> ' +
            '</div>' +
            '<br />' +
           '<div class="row">' +
                '<div class="col-lg-3 col-sm-3 col-md-3">' +
                        '<input type="text" class="form-control" placeholder="Expected rows affected eg 100" id="txtRowsAffeted" tabid="' + tabId + '" onkeypress="Cronus.validAbsIntiger(event)">' +
                '</div>' +
                '<div class="col-lg-6 col-sm-6 col-md-6">' +
                '<div class="col-lg-3 col-sm-3 col-md-3">' +
                '<select id = "ddlTransactionMode" class="form-control" tabid= "' + tabId + '" ><option value="True">Transaction Mode</option><option value="False">Non-Transaction Mode</option></select>' +
                 '</div>' +
                '<div class="col-lg-9 col-sm-9 col-md-9">' +
                        '<button type="button" id="btnExecute" tabid="' + tabId + '" class="btn btn-primary" onclick="executeQuery(this)"> Execute</button> ' +
                        '<button type="button" id="btnCommit" tabid="' + tabId + '" class="btn btn-primary" onclick="commitQuery(this)"> Commit</button> ' +
                        '<button type="button" id="btnRollback" tabid="' + tabId + '" class="btn btn-primary" onclick="rollbackQuery(this)"> Rollback</button> ' +
                        '</div>' +
                '</div>' +
                   '<div class="col-lg-3 col-sm-3 col-md-3">' +
                        '<div id="timerContainer" tabid="' + tabId + '"></div>' +
                '</div>' +
            '</div>' +

            '<div class="row margin-top-30">' +
            '<div class="col-lg-12 col-sm-12 col-md-12">' +
            '<div id="divResult" tabid="' + tabId + '" style="height: 30px !important;"/>' +
                '</div>' +
                 '</div>' +
                '<br />' +
                '<div class="col-lg-12 col-sm-12 col-md-12">' +
                    '<table id="dtQBResults' + tabId + '" class="display cell-border" width="100%">' +
                    '</table>' +

                    '<span class="form-control" id="dtQBSummary" tabid="' + tabId + '">   </span>' +
                 '</div>' +
            '</div>' +
            '<div class="blockOverlayQuery">' +
                       '<span class="blockUIQuery">' +
                          "<img src='../Images/loader.GIF' alt='Running Query...' /></span>" +
            '</div>' +
         '</div>');

    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.QueryBuilder_Execute, screenName) == false) {
        $("#" + tabId + " #btnExecute").attr('disabled', true);
        $("#" + tabId + " #btnExecute").addClass('disabledbtn');
        $("#" + tabId + " #btnSaveQuery").attr('disabled', true);
        $("#" + tabId + " #btnSaveQuery").addClass('disabledbtn');
    }

    $("#" + tabId + " #txtJIRAId").keypress(function (e) {
        if (e.which === 13) {
            $("#" + tabId + " #btnSearchJIRAItem").click();
            return false;
        }
    });

    $('#' + tabId + " #txtquery").on("keydown", function (event) {
        if (event.which === 120) {

            var selectedText = wrapText('#' + tabId + " #txtquery");
            $('#' + tabId + " #txtquerynew").val(selectedText);
            executeQuery(this, selectedText);
        }
    });
    $('#' + tabId + " #ddlTransactionMode").on("change", function () {

        if ($(this).val() === "True") {
            showCommitRollback(tabId);

        } else {
            hideCommitRollback(tabId);
        }

    });


    $("#" + tabId + " #dtQBSummary").css('display', 'none');


    $("#" + tabId + " #txtquery").focus();
    populateDatabaseDropDown(tabId);
    updateCommitRollback(tabId, false, false);
    populateCategoryDropDown(tabId);

    disableBetaExecution(tabId);
    disableSkipApproval(tabId);
    $("#" + tabId + " #btnSave").attr('disabled', true).addClass('disabledbtn');
    $("#" + tabId + " #btnEdit").attr('disabled', true).addClass('disabledbtn');

    Cronus.fetchAutoCompleteData(screenName, "User", Cronus.RestApi.FetchDropDownData, $("#" + tabId + " #txtApprover"));
    Cronus.fetchAutoCompleteData(screenName, "RequestType", Cronus.RestApi.FetchDropDownData, $("#" + tabId + " #txtRequestType"));
    Cronus.fetchAutoCompleteData(screenName, "SkipBetaExecutionModalReason", Cronus.RestApi.FetchDropDownData, $("#txtSkipBetaExecutionModalReason"));
    Cronus.fetchAutoCompleteData(screenName, "SkipApprovalModalReason", Cronus.RestApi.FetchDropDownData, $("#txtSkipApprovalModalReason"));
    populateGroupResponsibility(tabId);
}
function showCommitRollback(tabId) {
    $("#" + tabId + "  #btnCommit").show();
    $("#" + tabId + "  #btnRollback").show();
    $("#" + tabId + " #txtRowsAffeted").show();

}
function hideCommitRollback(tabId) {
    $("#" + tabId + "  #btnCommit").hide();
    $("#" + tabId + "  #btnRollback").hide();
    $("#" + tabId + " #txtRowsAffeted").hide();

}
// This function returns the selected text from text area. If nothing is selected , it returns all the rows.
var wrapText = function (el) {

    var textArea = $(el);
    startSelection = textArea[0].selectionStart;
    endSelection = textArea[0].selectionEnd;
    var selectedText = textArea.val().substring(startSelection, endSelection);
    if (selectedText !== "") {
        return selectedText;
    } else {
        return textArea.val();
    }
}
/*This function is called onClick of CANCEL button of skipApprovalReason Modal*/
function btnClose() {
    //$("#" + activeTab + " #rdSkipApprovalY").prop('checked', false);
    $('#btnRollbackQuery').off('click')
    $("#infoQueryModal").modal('hide');
    $('#' + activeTab + " #txtquery")[0].setSelectionRange(startSelection, endSelection);
    $('#' + activeTab + " #txtquery").focus();
}

function countDownTimer(tabId) {
    var i = tabId;
    $('#' + i + ' #timerContainer').html("");
    var timerHtml = '';
    var countDId = 'countdown_' + i;
    var btnStopTimer = "btnStopTimer_" + i;
    var btnResetTimer = "btnResetTimer_" + i;

    timerHtml += '<div>';
    timerHtml += '  <div id="' + countDId + '"></div>';
    timerHtml += ' </div>';
    timerHtml += ' <input type="button"  style="display:none" value="Start Timer" id="' + btnStopTimer + '" />';
    timerHtml += ' <input type="button" value="Reset Timer" id="' + btnResetTimer + '" style="display:none" />';
    $('#' + i + ' #timerContainer').append(timerHtml);

    var a = '<script> $(function(){ var totattimeinsec' + i + ';  var fillStylenew' + i + ' = "#8ac575"; var countdown' + i + ';   var flag' + i + ' = false; ' +
                ' var timer' + i + ' = "15:00";   timer' + i + ' = timer' + i + '.split(":");  var totattimeinsec' + i + ' = (parseInt(timer' + i + '[0] * 60)) + parseInt(timer' + i + '[1]); ' +
                ' var pluginName' + i + ' = "countdown360", defaults = { radius: 15.5, strokeStyle: "#477050", strokeWidth: undefined, fillStyle: fillStylenew' + i + ', fontColor: "#477050", fontFamily: "sans-serif", fontSize: undefined, fontWeight: 700, ' +
                ' autostart: false, seconds: parseInt(totattimeinsec' + i + '), label: ["second", "seconds"], startOverAfterAdding: true, onComplete: undefined }; ' +

               ' function Plugin(element, options) { this.element = element; this.settings = $.extend({}, defaults, options); if (!this.settings.fontSize) { this.settings.fontSize = this.settings.radius / 1.2; } if (!this.settings.strokeWidth) ' +
               ' { this.settings.strokeWidth = this.settings.radius / 4; } this._defaults = defaults;  this._name = pluginName' + i + ';     this._init(); } ' +

               ' Plugin.prototype = {extendTimer: function (value) { var seconds = parseInt(value), secondsElapsed = Math.round((new Date().getTime() - this.startedAt.getTime()) / 1000);if ((this._secondsLeft(secondsElapsed) + seconds) <= this.settings.seconds) ' +
               ' {this.startedAt.setSeconds(this.startedAt.getSeconds() + parseInt(value));} }, ' +

               ' addSeconds: function (value) {var secondsElapsed = Math.round((new Date().getTime() - this.startedAt.getTime()) / 1000); if (this.settings.startOverAfterAdding) { ' +
               ' this.settings.seconds = this._secondsLeft(secondsElapsed) + parseInt(value); this.start();} else { this.settings.seconds += parseInt(value); } }, ' +

               ' start: function () {this.startedAt = new Date(); this.interval = setInterval(jQuery.proxy(this._draw, this), 1000); }, ' +

               ' stop: function (cb) { clearInterval(this.interval);if (cb) { cb(); }}, ' +

               ' _init: function () { this.settings.width = (this.settings.radius * 2) + (this.settings.strokeWidth * 2); this.settings.height = this.settings.width; this.settings.arcX = this.settings.radius + this.settings.strokeWidth; ' +
               ' this.settings.arcY = this.settings.arcX; this._initPen(this._getCanvas()); if (this.settings.autostart) { this.start(); }this._drawCountdownShape(Math.PI * 3.5, true); this._drawCountdownLabel(0);  }, ' +

               ' _getCanvas: function () { var $canvas = $(\'<canvas id="countdown360_\' + $(this.element).attr("id") + \'" width="\'+this.settings.width + \'" height="\'+this.settings.height + \'><span id="countdown-text" role="status" aria-live="assertive"></span></canvas>\'); ' +
               ' $(this.element).prepend($canvas[0]); return $canvas[0]; }, ' +

               ' _initPen: function (canvas) { this.pen = canvas.getContext("2d");  this.pen.lineWidth = this.settings.strokeWidth;     this.pen.strokeStyle = this.settings.strokeStyle;  this.pen.fillStyle = this.settings.fillStyle; ' +
               ' this.pen.textAlign = "center"; this.pen.textBaseline = "middle";this.ariaText = $(canvas).children("#countdown-text");    this._clearRect(); }, ' +

               ' _clearRect: function () {this.pen.clearRect(0, 0, this.settings.width, this.settings.height); }, ' +

               ' _secondsLeft: function (secondsElapsed) { return this.settings.seconds - secondsElapsed;     }, ' +

               ' _drawCountdownLabel: function (secondsElapsed) {    this.ariaText.text(secondsLeft); this.pen.font = this.settings.fontWeight + " " + this.settings.fontSize + "px " + this.settings.fontFamily; ' +
               ' var secondsLeft = this._secondsLeft(secondsElapsed), label = secondsLeft === 1 ? this.settings.label[0] : this.settings.label[1], drawLabel = this.settings.label && this.settings.label.length === 2, ' +
               ' x = this.settings.width / 2;     if (drawLabel) { y = this.settings.height / 2 - (this.settings.fontSize / 6.2);       } else {y = this.settings.height / 2;} this.pen.fillStyle = this.settings.fillStyle; ' +
               ' this.pen.fillText(secondsLeft + 1, x, y);   this.pen.fillStyle = this.settings.fontColor; this.pen.fillText(secondsLeft, x, y);if (secondsLeft == 600) { fillStylenew' + i + ' = "#FFA500"; } ' +
               ' if (secondsLeft == 180) { fillStylenew' + i + ' = "#FF0000";}   if(secondsLeft == 0) { $("#' + i + ' #btnRollback").click(); } if (drawLabel) {this.pen.font = "normal small-caps " + (this.settings.fontSize / 3) + "px " + this.settings.fontFamily; ' +
               ' this.pen.fillText(label, this.settings.width / 2, this.settings.height / 2 + (this.settings.fontSize / 2.2));   }    this.settings.fillStyle = fillStylenew' + i + '; }, ' +

               ' _drawCountdownShape: function (endAngle, drawStroke){this.pen.fillStyle = this.settings.fillStyle; this.pen.beginPath(); this.pen.arc(this.settings.arcX, this.settings.arcY, this.settings.radius, Math.PI * 1.5, endAngle, false); ' +
               ' this.pen.fill();if (drawStroke) { this.pen.stroke(); }}, ' +

               ' _draw: function () {var secondsElapsed = Math.round((new Date().getTime() - this.startedAt.getTime()) / 1000), endAngle = (Math.PI * 3.5) - (((Math.PI * 2) / this.settings.seconds) * secondsElapsed); this._clearRect(); ' +
               ' this._drawCountdownShape(Math.PI * 3.5, false); if (secondsElapsed < this.settings.seconds) {this._drawCountdownShape(endAngle, true); this._drawCountdownLabel(secondsElapsed);} else {this._drawCountdownLabel(this.settings.seconds); ' +
               ' this.stop();this.settings.onComplete(); } }}; ' +

               ' $.fn[pluginName' + i + '] = function (options) { var plugin; this.each(function () {  plugin = $.data(this, "plugin_" + pluginName' + i + ');  if (!plugin) {plugin = new Plugin(this, options); $.data(this, "plugin_" + pluginName' + i + ', plugin); ' +
               ' }  });  return plugin; }; ' +
               ' countdown' + i + '  = $("#' + countDId + '").countdown360({ radius: 60,fontColor: "#FFFFFF", autostart: true,onComplete: function () {  } }); ' +
                ' $("#' + btnStopTimer + '").click(function () {  countdown' + i + '.stop(); $("#' + countDId + '").css("display", "none");}); ' +
               ' $("#' + btnResetTimer + '").click( function () {   fillStylenew' + i + '= "#8ac575"; countdown' + i + '.start(); $("#' + countDId + '").css("display", "block");   }); }); </' + 'script> ';

    $('#' + i + ' #timerContainer').append(a);
}



