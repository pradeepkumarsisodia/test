﻿"use strict";
var screenName = Cronus.Screens.SecAnalyticsOverride;

var handsonExcelInput;
var isCheckedBase = false;
var firstRequestSubmitted = false;
var analyticIdArray = [];
var dataSAO = new Array();

$(document).on("ready", function () {
    if (!Cronus.selectedPage(screenName, Cronus.Actions.SecAnalyticsOverride_View)) {
        return;
    }

    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.SecAnalyticsOverride_Submit, screenName) == false) {
        $("#btnSecAnalyticsOverride").attr('disabled', true);
        $("#btnSecAnalyticsOverride").addClass('disabledbtn');

        $("#btnSecAnaSave").attr('disabled', true);
        $("#btnSecAnaSave").addClass('disabledbtn');
    }

    $("#txtPricedate").datepicker({ maxDate: new Date() });
    Cronus.populateCycleDate($("#txtPricedate"));

    //if enter pressed on search box
    $("#txtSsm_id").keypress(function (e) {
        if (e.which == 13) {
            $("#btnSsm_idSearchModelMap").click();
            return false;
        }
    });
    $("#btnSsm_idSearchModelMap").click(function () {
        searchSecAnalytic(handsonTable);
    });

    $('#btnSecAnalyticsOverride').click(function () {
        compareAnalyticsOldValue();
    });

    populateAnalyticIds();
    fetchFiles();
    var ssmidrenderer = function (instance, td, row, col, prop, value, cellProperties) {
        if (value != undefined) {
            var value_str = String(value);
            if (/^[a-zA-Z0-9\s]*$/.test(value_str) == false || value_str.trim().length > 9) {
                td.style.background = 'red';
            }
            $(td).html(value);
        }
        else
            $(td).html('');
    };

    // Prepare Handson Table for Risk Measures Live screen
    $("#tblCusips").html("");
    var dataInput = [[false]];
    var containerInput = document.getElementById('tblCusips');
    var settingInputTable = {
        data: dataInput,
        currentRowClassName: "currentRow",
        currentColClassName: "currentCol",
        renderAllRows: true,
        minSpareRows: 3,
        afterChange: afterHandsonChangeInput,
        minRows: 6,
        height: 200,
        stretchH: 'all',
        className: 'htCenter',
        contextMenu: ['row_above', 'row_below', 'remove_row', 'undo', 'redo'],
        colWidths: [20],
        colHeaders: function (col) {
            switch (col) {
                case 0:
                    var txt = "<input type='checkbox' class='checkerBase' ";
                    txt += isCheckedBase ? 'checked="checked"' : '';
                    txt += ">";
                    return txt;
                case 1:
                    return "SSM ID*";
                case 2:
                    return "ANALYTIC ID*";
                case 3:
                    return "Value*";
                case 4:
                    return "BackUp Metric*";
                case 5:
                    return "Note";
                default:
                    return "UNKNOWN";
            }
        },
        columns: [
        { data: 0, type: 'checkbox' },
        { data: 1, type: 'text', renderer: ssmidrenderer },
        { data: 2, type: 'autocomplete', source: analyticIdArray, strict: true },
        { data: 3, type: 'text' },
        { data: 4, type: 'autocomplete', source: ["Y", "N"], strict: true },
        { data: 5, type: 'text' }
        ]

    };
    var handsonTable = new Handsontable(document.getElementById('tblCusips'), settingInputTable);
    handsonTable.loadData(dataInput);
    handsonExcelInput = handsonTable;

    function searchSecAnalytic(handsonTable) {
        var ssmId = $("#txtSsm_id").val().trim();
        if (ssmId == "") {
            swal("error", "Please enter SSM ID", "error");
            $("#txtSsm_id").focus();
            return;
        }
        if (ssmId != "" && ssmId != null && Cronus.validateCusipList(ssmId, 9) == false) {
            $("#txtSsm_id").focus();
            return;
        }
        else {

            var inputObj = { screenName: screenName, tableName: "SSMIDSearch", data: { ssm_id: ssmId, price_date: $("#txtPricedate").val() } };

            var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, null, true, '#btnSsm_idSearchModelMap');
            $.when(retval.AjaxObj).done(function () {
                var result = retval.AjaxObj.responseJSON;
                if (result.errorMessage == null || result.errorMessage == "") {
                    handsonTable.loadData([["", ""]]);
                    // Add result data in list
                    var rowsData = [];
                    if (result.rows.length > 0) {

                        for (var i = 0; i < result.rows.length; i++)
                            rowsData.push([false, result.rows[i][0], result.rows[i][1], result.rows[i][2], result.rows[i][3], result.rows[i][4]]);
                        handsonTable.loadData(rowsData);
                    }
                    else {
                        rowsData.push([false, "", "", "", "", ""]);
                        handsonTable.loadData(rowsData);

                        swal("Info", "No data found", "error");
                    }
                    $('.checkerBase').attr('checked', false);
                }
            });
        }
    }

    function afterHandsonChangeInput(changes, source) {
        if (source != "loadData") {
            for (var i = 0; i < changes.length; i++) {
                var localData = handsonExcelInput.getData();
                if (localData != undefined && localData[changes[i][0]] != undefined) {
                    if (!isValidRow(changes[i][0]))
                        localData[changes[i][0]][0] = false;
                }
            }
            isCheckedBase = allCheckboxChecked();
            handsonTable.render();
        }
    }

    Handsontable.Dom.addEvent(containerInput, 'mousedown', function (event) {
        if (event.target.nodeName == 'INPUT' && event.target.className == 'checkerBase') {
            isCheckedBase = !event.target.checked;
            SelectAll(handsonTable);
        }
    });

    $(window).bind("beforeunload", function () {

        if (firstRequestSubmitted)
            return "Are you sure you want to leave?";
    });
    //Reset button click function
    $("#btnReset").click(function () {
        isCheckedBase = false;
        $("#txtSsm_id").val('');
        var sampleData = [[false]];
        handsonTable.loadData(sampleData);
        handsonExcelInput = handsonTable;
    });
    $('#btnSecAnaSave').click(function () {
        saveAnalytics(handsonTable, "U", '#btnSecAnaSave');
    });

    $('#btnDelete').click(function () {
        saveAnalytics(handsonTable, "D", '#btnDelete');
    });

    $('#chkBackUpMetric').click(function () {
        var sampleData = [[false]];
        handsonTable.loadData(sampleData);
        handsonExcelInput = handsonTable;
        var data = dataSAO;
        dataSAO = [];
        for (var i = 0; i < data.length-3; i++) {
            var values = data[i];

            dataSAO.push([false, values[1].trim(), values[2].trim().replace(new RegExp("srm", "ig"), "manual"), values[3].trim(), $("#chkBackUpMetric").is(':checked') == true ? 'Y' : 'N']);
        }
        handsonExcelInput.loadData(dataSAO);
        handsonExcelInput.render();

    });
});


function compareAnalyticsOldValue() {

    var localData = handsonExcelInput.getData();
    var anyRowSelected = false;
    var secAnoverTbaMapData = [];
    var priceDate = $("#txtPricedate").val();
    if (priceDate == "") {
        swal("Error", "Please pass price date", "error");
    }
    for (var i = 0; i < localData.length; i++) {
        if (localData[i][0] && localData[i][1] != undefined) {
            anyRowSelected = true;

            if (localData[i][1] == '' || localData[i][2] == '' || localData[i][3] == '' || localData[i][4] == '') {
                swal("Error", "All columns are mendatory in selected row's", "error");
                return;
            }
            if (localData[i][5] == undefined || localData[i][5] == null)
                localData[i][5] = "";
            secAnoverTbaMapData.push({ ssm_id: localData[i][1], analytic_id: localData[i][2], value: localData[i][3], backUp_Metric: localData[i][4], note: localData[i][5], price_date: priceDate });
        }
    }

    if (!anyRowSelected) {
        swal("Error", "Please select row(s)", "error");
        return;
    }

    var inputObj = {
        screenName: screenName,
        functionName: "AnalyticSearch",
        data: secAnoverTbaMapData
    };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, null, true, '#btnSecAnalyticsOverride');
    $.when(retval.AjaxObj).done(function () {
        var dtSecAnalytic;
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            $('#myModal').modal('show');
            dtSecAnalytic = Cronus.refreshDataTable(dtSecAnalytic, $("#dtsecanalyticResults"), result.columns, result.rows);
        }
        else {
            swal("Error", "Invalid Data \n " + result.errorMessage, "error");
        }
    });
}


function fetchFiles() {
    var inputObj = {
        screenName: screenName,
        functionName: "FetchFIles"
    };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, null, true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            if (Cronus.isNotEmptyNullOrUndefined(result.tableName)) {

                var files = result.tableName.split(',');
                $("#divFiles").removeClass('hidden');
                $("#divFiles").html("");

                var html = '<div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><u>';
                html += '<a data-toggle="collapse" href="#" >Sec Analytics files</a></u></h4></div>';
                html += '<div class="panel-body" style="overflow:auto;">';
                html += "<table class='table table-striped table-bordered table-hover' >";
                $.each(files, function (index, value) {
                    var fileTime = value.split('|');
                    var fileName = fileTime[0];
                    var timeStamp = fileTime[1];
                    var filePathUrl = Cronus.GetBaseUrl() + "/Home/Download?filepath=" + fileName;
                    html += '<tr> <td>' + '<a  href="' + filePathUrl + '" >' + fileName + '</a> </td> <td>' + timeStamp + ' </td> </tr> ';
                });
                html += "</table>";
                html += '</div></div>';
                $('#divFiles').append(html);
            } else {
                $("#divFiles").addClass('hidden');
            }
        }
        else {
            swal("Error", "Invalid Data \n " + result.errorMessage, "error");
        }
    });
}

function repopulateExcel(handsonTable) {
    var rows = [];
    var data = handsonExcelInput.getData();
    for (var i = 0; i < data.length - 5; i++) {
        if (data[i][0] == true)
            continue;
        else {
            var rowtmp = [];
            rowtmp.push(false);
            for (var j = 0; j < data[i].length; j++) {
                rowtmp.push(data[i][j + 1]);
            }
            rows.push(rowtmp);
        }
    }
    if (rows.length == 0)
        rows = [[false]];
    handsonTable.loadData(rows);
    handsonExcelInput = handsonTable;
}

function saveAnalytics(handsonTable, action, btn) {

    // Validate all selected rows for cusip and price here.
    var localData = handsonExcelInput.getData();
    var anyRowSelected = false;
    var secAnoverTbaMapData = [];
    var priceDate = $("#txtPricedate").val();
    if (priceDate == "") {
        swal("Error", "Please pass price date", "error");
    }
    for (var i = 0; i < localData.length; i++) {
        if (localData[i][0] && localData[i][1] != undefined) {
            anyRowSelected = true;
            if (localData[i][4] == undefined || localData[i][4] == null)
                localData[i][4] = "";
            secAnoverTbaMapData.push({ ssm_id: localData[i][1], analytic_id: localData[i][2], value: localData[i][3], backUp_Metric: localData[i][4], note: localData[i][5], price_date: priceDate, action: action });
        }
    }

    if (!anyRowSelected) {
        swal("Error", "Please select row(s)", "error");
        return;
    }

    var inputObj = {
        screenName: screenName,
        data: secAnoverTbaMapData
    };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, null, true, btn);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            $('#myModal').modal('hide');
            if (action == "D") {
                repopulateExcel(handsonTable);
            }
            swal("Info", result.message, "success");
            fetchFiles();
        }
    });

}

function isValidRow(row) {

    var cusipCell = handsonExcelInput.getCell(row, 1, false);
    var analyticid = handsonExcelInput.getCell(row, 2, false);
    var localData = handsonExcelInput.getData();
    if (localData[row][1] == undefined || localData[row][1] == "" || localData[row][1] == null ||
    localData[row][2] == undefined || localData[row][2] == "" || localData[row][2] == null ||
    localData[row][3] == undefined || localData[row][3] == "" || localData[row][3] == null ||
    localData[row][4] == undefined || localData[row][4] == "" || localData[row][4] == null ||
    cusipCell.style.background == 'red' || analyticid.style.background == 'red') {
        return false;
    }
    return true;
}


function showFromCalender() {
    $("#txtPricedate").focus();
    return false;
}

function SelectAll(handsonTable) {
    var localData = handsonExcelInput.getData();
    var checked = isCheckedBase;
    for (var i = 0; i < localData.length; i++) {
        if (isValidRow(i))
            localData[i][0] = checked;
    }
    handsonTable.render();
}

function allCheckboxChecked() {
    var localData = handsonExcelInput.getData();
    var isAnyValidRow = false;
    for (var i = 0; i < localData.length; i++) {
        if (isValidRow(i)) {
            isAnyValidRow = true;
            if (localData[i][0] != true)
                return false;
        }
    }
    if (!isAnyValidRow)
        return false;
    return true;
}

function populateAnalyticIds() {
    var inputObj = { screenName: screenName, fieldName: "ANALYTIC_ID" };

    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDropDownData, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            if (result.dropDownData != null && result.dropDownData.length > 0) {
                for (var i = 0; i < result.dropDownData.length; i++) {
                    analyticIdArray.push(result.dropDownData[i].data);
                }
            }
        }
    });
}

function bindDataInHandsonTable(data) {
    //if (data.length > 20) {
    //    swal("error", "Max limt of uploading data is 20 rows.", "error");
    //    return;
    //}
   
    for (var i = 0; i < data.length; i++) {
        var values = data[i].split(',');

        dataSAO.push([false, values[0].trim(), values[1].trim().replace(new RegExp("srm", "ig"), "manual"), values[2].trim(), $("#chkBackUpMetric").is(':checked') == true ? 'Y' : 'N']);
    }
    handsonExcelInput.loadData(dataSAO);
    handsonExcelInput.render();
}

var cusipData = [];
function readDefinitionsFile(input) {
    cusipData = null;
    if (input.files[0].name.indexOf("txt") == -1 && input.files[0].name.indexOf("csv") == -1) {
        swal('error', 'File format should be csv or txt only.', 'error');
        return;
    }
    $("#txtFileName").text(input.files[0].name);
    $("#txtFileName").css('color', '');
    $('#divStatus').css("display", "none");

    if (input.files && input.files[0]) {
        var reader = new window.FileReader();
        $(".blockOverlay").css('display', 'block');
        reader.onload = function (e) {
            try {
                loadFile(e.target.result, ",");

            } catch (err) {
                $(".blockOverlay").css('display', 'none');
                // Clear file browser
                clearFileBrower();
                swal("Error", err, "error");
            }
        };
        reader.readAsText(input.files[0]);
    }
    input = $("#saoRunFile");
    input.replaceWith(input.val('').clone(true));
}

function loadFile(text, seperator) {
    cusipData = text.split(/[\r\n]+/g).filter(function (x) { return x && x.trim(); }); // tolerate both Windows and Unix linebreaks    
    if (cusipData.length <= 0) {

        throw ("File is empty, cannot be uploaded");
    }
    var fileNameWithCusipCount = $("#txtFileName").text() + " ( #cusips : " + cusipData.length + ")";
    $("#txtFileName").text(fileNameWithCusipCount);

    $(".blockOverlay").css('display', 'none');
    // RefreshTable();
    bindDataInHandsonTable(cusipData);
}
function clearFileBrower() {
    $("#txtFileName").text("");
    var input = $("#saoRunFile");
    input.replaceWith(input.val('').clone(true));
    //  lines = [];
    // outputArray = [];

    $(".blockOverlay").css('display', 'none');
}
function openfileuploader() {
    $("#saoRunFile").click();
}
