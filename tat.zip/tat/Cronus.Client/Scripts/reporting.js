﻿"use strict";
var screenName = Cronus.Screens.Reporting;
var ajaxRequest = "";
var dtReport;

$(document).ready(function () {
    if (!Cronus.selectedPage(screenName, Cronus.Actions.Reporting_View)) {
        return;
    }
    //Permission Check
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.Reporting_UnlimitedAccess, screenName) == false) {
        var userName = $("#spnWindowsUsername").text().split("PIMCO")[1];
        $("#txtUserId").val(userName.substr(1, userName.length).toUpperCase());
        $("#txtUserId").attr('disabled', true);
        $("#txtGroupId").attr('disabled', true);
        $("#btnLogView").hide();
    }
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.Reporting_Go, screenName) == false) {
        $("#btnGetReportData").attr('disabled', true);
        $("#btnGetReportData").addClass('disabledbtn');
    }

    $("#txtFromdate,#txtTodate").datepicker({ maxDate: new Date() });
    var oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    $("#txtFromdate").val($.datepicker.formatDate("mm/dd/yy", oneWeekAgo));
    $("#txtTodate").val($.datepicker.formatDate("mm/dd/yy", new Date()));

    Cronus.fetchAutoCompleteData(screenName, "USER", Cronus.RestApi.FetchDropDownData, $('#txtUserId'), $("#hdnUserId"));
    Cronus.fetchAutoCompleteData(screenName, "SCREEN", Cronus.RestApi.FetchDropDownData, $('#txtScreenId'), $("#hdnScreenId"));
    Cronus.fetchAutoCompleteData(screenName, "GROUP", Cronus.RestApi.FetchDropDownData, $('#txtGroupId'), $("#hdnGroupId"));

    $(document).keyup(function (e) {
        if (e.keyCode == 27) {
            stopAjax();
        }
    });
});

$("#btnGetReportData").click(function () {
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.Reporting_Go, screenName))
        GetReportingData();
    return false;
});

$("#btnGetAnaltyticsData").click(function () {
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.Reporting_Go, screenName))
        GetAnalyticsData();
    return false;
});



$("#txtDescription").keypress(function (e) {
    if (e.which == 13) {
        $("#btnGetReportData").click();
        return false;
    }
});
$("#txtScreenId").keypress(function (e) {
    if (e.which == 13) {
        $("#btnGetReportData").click();
        return false;
    }
});
$("#txtGroupId").keypress(function (e) {
    if (e.which == 13) {
        $("#btnGetReportData").click();
        return false;
    }
});
$("#txtUserId").keypress(function (e) {
    if (e.which == 13) {
        $("#btnReportingView").click();
        return false;
    }
});
function showFromCalender() {
    $("#txtFromdate").focus();
    return false;
}
function showToCalender() {
    $("#txtTodate").focus();
    return false;
}
function toggleTab(id, el) {
    $(el).removeClass('disabledbtn');
    $("#" + id).addClass('disabledbtn');
    if (id == "btnReportingView") {
        $("#dvLogView").html('');
        $("#dvLogView").show();
        $("#dvReportingView").hide();
        showCurrentLog();
    } else if (id == "btnLogView") {
        $("#dvReportingView").show();
        $("#dvLogView").hide();
        GetReportingData();
    }
}

function GetReportingData() {
    $("#btnReportingView").removeClass('disabledbtn');
    $("#btnLogView").addClass('disabledbtn');
    $("#dvReportingView").show();
    $("#dvLogView").hide();
    $("#reportingcontainer").html("");

    var dateFrom = $("#txtFromdate");
    var dateTo = $("#txtTodate");
    if (dateFrom.val() == "") {
        appendErrorMessage("Please select from date !!");
        dateFrom.focus();
    }
    else if (dateTo.val() == "") {
        appendErrorMessage("Please select to date !!");
        dateTo.focus();
    }
    else if (Date.parse(dateFrom.val()) > Date.parse(dateTo.val())) {
        appendErrorMessage("From date should be less than To date !!");
        dateTo.focus();
    }
    else {
        var inputObj = { screenName: screenName, tableName: "Reporting",
            data: { userId: $("#txtUserId").val(), groupId: $("#txtGroupId").val()
                , screenId: $("#txtScreenId").val(), description: $("#txtDescription").val()
                , dateFrom: dateFrom.val() + " 00:00:00", dateTo: dateTo.val() + " 23:59:59"
            }
        };

        var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", true);
        $.when(retval.AjaxObj).done(function () {
            var result = retval.AjaxObj.responseJSON;
            if (result.errorMessage == null || result.errorMessage == "") {
                dtReport = Cronus.refreshDataTable(dtReport, $("#dtReportingData"), result.columns, result.rows,null,null,2);
            }
            ajaxRequest = retval.AjaxObj;
        });
    }
}


function GetAnalyticsData() {
    $("#btnReportingView").removeClass('disabledbtn');
    $("#btnLogView").addClass('disabledbtn');
    $("#dvReportingView").show();
    $("#dvLogView").hide();
    Cronus.destroyDataTable(dtReport, "#dtReportingData");

    var dateFrom = $("#txtFromdate");
    var dateTo = $("#txtTodate");
    if (dateFrom.val() == "") {
        appendErrorMessage("Please select from date !!");
        dateFrom.focus();
    }
    else if (dateTo.val() == "") {
        appendErrorMessage("Please select to date !!");
        dateTo.focus();
    }
    else if (Date.parse(dateFrom.val()) > Date.parse(dateTo.val())) {
        appendErrorMessage("From date should be less than To date !!");
        dateTo.focus();
    }
    else {
        var inputObj = { screenName: screenName, tableName: "Analytics",
            data: { userId: $("#txtUserId").val(), groupId: $("#txtGroupId").val()
                , screenId: $("#txtScreenId").val(), description: $("#txtDescription").val()
                , dateFrom: dateFrom.val() + " 00:00:00", dateTo: dateTo.val() + " 23:59:59"
            }
        };

        var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", true);
        $.when(retval.AjaxObj).done(function () {
            var result = retval.AjaxObj.responseJSON;
            if (result.errorMessage == null || result.errorMessage == "") {
                //dtReport = refreshDataTable(dtReport, $("#dtReportingData"), result.columns, result.rows);                                
                drawChart(result.rows);
            }
            ajaxRequest = retval.AjaxObj;
        });
    }
}

function appendErrorMessage(error) {
    swal("Error", error, "error");
}

function showCurrentLog() {
    var top = $('#inputView').height();
    var remainingHeight = parseInt($(window).height() - top - top);
    $('#dvLogView').height(remainingHeight);
    var inputObj = {};
    $("#dvLogView").html("");
    Cronus.destroyDataTable(dtReport, "#dtReportingData");
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.LoadCurrentLogFile, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            $("#dvLogView").append('<span id="spnLogs" style="padding:10px; text-align:left; white-space:pre-line;  word-break: break-all;">'
            + result.replace(new RegExp("Error", "ig"), "<b style=color:red> ERROR </b> ").replace(new RegExp("Info", "ig"), "<b> INFO </b> ") + '</span>');
            var wtf = $("#dvLogView");
            var height = wtf[0].scrollHeight;
            wtf.scrollTop(height);
            $('html, body').scrollTop($(document).height());
            //$('html, body').animate({ scrollTop: $('#dvLogView').offset().top }, 'slow'); //scrollTop($(document).height());
            //            $("#spnLogs").readmore({
            //                speed: 100,
            //                lessLink: '<a href="#"> Read leas </a>'

            //            });
        }
        ajaxRequest = retval.AjaxObj;
    });
}

function stopAjax() {
    ajaxRequest.abort();
    ajaxRequest = "";
}

function clearUserIdTextbox() {
    $("#hdnUserId").val('');
}

function clearGroupIdTextbox() {
    $("#hdnGroupId").val('');
}

function clearScreenIdTextbox(id) {
    $("#hdnScreenId").val(id);
}

var drawChart = function (dataArray) {
    $('#reportingcontainer').highcharts({
        chart: {
            type: 'column'
        },
        title: {
            text: 'Cronus Screen Wise total Usage'
        },
        //            subtitle: {
        //                text: 'Source: <a href="http://en.wikipedia.org/wiki/List_of_cities_proper_by_population">Wikipedia</a>'
        //            },
        xAxis: {
            type: 'category',
            labels: {
                rotation: -60,
                style: {
                    fontSize: '13px',
                    fontFamily: 'Verdana, sans-serif'
                }
            }
        },
        yAxis: {
            min: 0,
            title: {
                text: 'Total Usages'
            }
        },
        legend: {
            enabled: false
        },
        tooltip: {
            pointFormat: 'Screen Usages: <b>{point.y} </b>'
        },
        series: [{
            name: 'Usage',
            data: dataArray,
            dataLabels: {
                enabled: true,
                rotation: -90,
                color: '#FFFFFF',
                align: 'right',
                format: '{point.y}', // one decimal
                y: 10, // 10 pixels down from the top
                style: {
                    fontSize: '13px',
                    fontFamily: 'Verdana, sans-serif'
                }
            }
        }]
    });
}