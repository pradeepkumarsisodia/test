﻿"use strict";
var screenName = Cronus.Screens.RiskAttribution;
var ajaxRequest = "";
var dtReport;
var dt1;
var dt2;
var dt3;

$(document).ready(function () {
    if (!Cronus.selectedPage(screenName, Cronus.Actions.RiskAttribution_View))
        return;

//    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.Reporting_Go, screenName) === false) {
//        $("#btnSearchRiskAttr").attr('disabled', true);
//        $("#btnSearchRiskAttr").addClass('disabledbtn');
//    }

    $("#priceDate, #prevPriceDate").datepicker({ maxDate: new Date() });
    var todayDate = new Date();
    var yesterDayDate = (todayDate.getDate() - 1);
    $("#priceDate").val($.datepicker.formatDate("mm/dd/yy", todayDate));
    //$("#prevPriceDate").val($.datepicker.formatDate("mm/dd/yy", yesterDayDate));
    populateRiskMeasure();
    $(document).keyup(function (e) {
        if (e.keyCode === 27) {
            stopAjax();
        }
    });
    //Cronus.fetchAutoCompleteData(screenName, "USER", Cronus.RestApi.FetchDropDownData, $('#txtUserId'), $("#hdnUserId"));
    //Cronus.fetchAutoCompleteData(screenName, "SCREEN", Cronus.RestApi.FetchDropDownData, $('#txtScreenId'), $("#hdnScreenId"));
    //Cronus.fetchAutoCompleteData(screenName, "GROUP", Cronus.RestApi.FetchDropDownData, $('#txtGroupId'), $("#hdnGroupId"));
});

function populateRiskMeasure() {    
    var inputObj = { screenName: screenName, tableName: "RiskMeasures", data: {} };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;

        if (result.errorMessage === null || result.errorMessage === "") {
            var tables = [];
            for (var i = 0; i < result.rows.length; i++) {
                tables.push(result.rows[i][0]);
            }
            Cronus.populateMultiSelectDropDown("#ddlRiskMeasure", tables);
        }
    });
}

function onPriceDateChange(id) {
    var runId;
    if (id === 'prevPriceDate')
        runId = '#prevRunId';
    else if (id === 'priceDate')
        runId = '#runId';
    else
        return;
    //alert($("" + id + "").val());
    var inputObj = {
        screenName: screenName,
        tableName: "RunIds",
        data: {
            priceDate: $("" + id + "").val()
        }
    };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        console.log(result);
        if (result.errorMessage === null || result.errorMessage === "") {
            $(runId).empty();
            for (var i = 0; i < result.rows.length; i++) {
                $('<option>').val(result.rows[i][0]).text(result.rows[i][0]).appendTo(runId);
            }
        }
    });
}

function searchDayRiskAttr() {
    var inputObj = { screenName: screenName
        , functionName: "Search"
        , data: {} 
        //, data: { SsmId: $("#").val(), AccountNumber: $("#").val(), PriceDate: $("#").val(), PreviousPriceDate: $("#").val(), RunId: $("#").val() }
    };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        console.log(result);
        console.log(result.data1.columns);
        console.log(result.data1.rows);
        dt1 = Cronus.refreshDataTable(dt1, $("#resultView1"), result.data1.columns, result.data1.rows);        
        dt2 = Cronus.refreshDataTable(dt2, $("#resultView2"), result.data2.columns, result.data2.rows);
        dt3 = Cronus.refreshDataTable(dt3, $("#resultView3"), result.data3.columns, result.data3.rows);

        //dt2.fnFilter(ssm_id, 2);
        //dt3.fnFilter(acct_no, 2);
        
    });
}

$("#btnGetReportData").click(function () {
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.RiskAttribution_Search, screenName))
        GetReportingData();
    return false;
});


$("#txtDescription").keypress(function (e) {
    if (e.which == 13) {
        $("#btnGetReportData").click();
        return false;
    }
});
$("#txtScreenId").keypress(function (e) {
    if (e.which == 13) {
        $("#btnGetReportData").click();
        return false;
    }
});
$("#txtGroupId").keypress(function (e) {
    if (e.which == 13) {
        $("#btnGetReportData").click();
        return false;
    }
});
$("#txtUserId").keypress(function (e) {
    if (e.which == 13) {
        $("#btnReportingView").click();
        return false;
    }
});
function showFromCalender() {
    $("#txtFromdate").focus();
    return false;
}
function showToCalender() {
    $("#txtTodate").focus();
    return false;
}


function toggleTab(id, el) {
    $(el).removeClass('disabledbtn');
    $("#" + id).addClass('disabledbtn');
    if (id == "btnDayView") {
        $("#historyViewDiv").show();
        $("#dayViewDiv").hide();
    } else if (id == "btnHistoryView") {
        $("#dayViewDiv").show();
        $("#historyViewDiv").hide();
    }
}


function stopAjax() {
    ajaxRequest.abort();
    ajaxRequest = "";
}