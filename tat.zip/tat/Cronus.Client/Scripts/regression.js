﻿"use strict";
var cronusServerProxy; //it is initialized in the "ready" event handler below.
var feserverProxy = null;
//var chkBoxFields = ['PREFIX', 'CLASS', 'SUBCLASS', 'FREQUENCY_ID', 'STRKEY1', 'STRKEY2', 'STRKEY3', 'STRKEY4', 'STRKEY5', 'NUMKEY1', 'NUMKEY2', 'NUMKEY3', 'NUMKEY4', 'NUMKEY5', 'SUFFIX'];
var chkBoxFields = new Array();
var displayNames = {
    ssmid: 'SSMID',
    price_date: 'Date',
    segmentNO: 'Segment',
    curveType: 'Curve',
    ShockType: 'Shock',
    modelID: 'Model',
    duration: 'Duration',
    convexity: 'Convexity',
    action: 'Action',
    ssmId: 'SSMID',
    price: 'Price',
    paidCashFlow: 'Paid Cash Flow',
    AccruedInterest: 'Accrued Interest',
    NormSpreadToWorst: 'Norm Spread To Worst',
    settlement: 'Settlement',
    pricePerUnit: 'Price Per Unit',
    ddyp: 'DDYP',
    ddy2p: 'DDY2P',


    getDisplayName: function (name) {
        if (this[name] == undefined) return name;
        return this[name];
    }
};


var uistate = {
    id: null,
    results: null,
    type: null,
    model: null,
    risk: null,
    tableDivs: {},
    previousTableDiv: null,

    models: function () {
        return this.results[this.type];
    },
    risks: function () {
        return this.models()[this.model]
    },
    data: function () {
        return this.risks()[this.risk];
    },
    render: function (callback) {
        if (this.data()["header"]) {
            callback();
        }
        else {
            var paths = [
                    "/" + this.type + "/" + this.model + "/" + this.risk + "/header[0:100]"
            ];
            feserverProxy.submitQuery(FeServer.Tasks.JPATH, { "id": uistate.id, "paths": paths }, function (response) {
                var results = response.results;
                console.log(results);
                uistate.results[uistate.type][uistate.model][uistate.risk] = {
                    header: results["payloads"][paths[0]]["data"]
                };
                callback();
            }, null);
        }
    },
    _tables: {},
    table: function () {
        if (this._tables[this.risk] == undefined) {
            console.log('creating table for ' + this.risk);
            this._tables[this.risk] = create_table(this.data(), 'alternative_view');
        }
        else
            console.log('using cached table for ' + this.risk);
        return this._tables[this.risk];
    }
};

$(document).on("ready", function () {
    cronusServerProxy = new CronusServerProxy(Cronus.Screens.Regression, onUpdateStatus);
    feserverProxy = FeServer.createServerProxy("Cronus", $("#spnWindowsUsername").text().split("PIMCO")[1].replace('\\', ''));
    feserverProxy.addEventHandler(FeServer.Events.status, function (e) {

        onUpdateStatus(e.id, e.status);
    });
    if (!Cronus.selectedPage(cronusServerProxy.getScreenName(), Cronus.Actions.Regression_View)) {
        return;
    }


    $(".calender").datepicker({ maxDate: new Date() });

    cronusServerProxy.fetchCycleAndPreviosDate(function (cycleDate) {
        cycleDate = cycleDate.split(' ')[0];
        if (cycleDate !== "") {
            $("#txtPricedate").datepicker('setDate', cycleDate);
        }
    });

    $('#btnRunRiskMeasuresLive').click(function () {
        submitRequest();
    });
    //$('#btnRunRiskMeasuresLiveLog').click(function () {
    //    getLogs();
    //});
    refreshRecent();

    interpretUrlQuery();

    //showResult("100");
    $('input[name=a]').click(function () {
        $('#txtInvocation').val('');
        $('input:checkbox').removeAttr('checked');
        if ($("input[name=a]:checked").val() == 'invocation') {
            $('#invocationModal').modal('show');
        }
        else {
            $('#txtInvocation').val($("input[name=a]:checked").val());

        }
    });
    //$('#txtInvocation').click(function () {
    //    $('#invocationModal').modal('show');
    //});
    $('#invocationModal').on('hidden.bs.modal', function () {
        $(".blockOverlay").css('display', 'block');
        $(".blockOverlay").css('display', 'none');
    });
    bindInvocation();
    createArrtbGrid();


    $("#attributes input:checkbox").click(function () {

        var attrbSelected = $('#txtInvocation').val();
        var val = $("label[for='" + this.id + "']").text().trim();
        if ($(this).is(':checked')) {
            if (attrbSelected == "") {
                attrbSelected += val;
            } else {
                attrbSelected += "," + val;
            }
        }
        else {
            var pattern = new RegExp(',?' + val + '', 'g');
            attrbSelected = $('#txtInvocation').val().replace(pattern, "");
        }

        $('#txtInvocation').val(attrbSelected);
    });

    $('#lnkFeSeverAuditor').click(function () {
        window.open(feserverProxy.absolute());
    });

});

function bindInvocation() {
    $.ajax({
        url: feserverProxy.absolute("/regression.json"),
        type: "GET",
        crossDomain: true,
        async: false,
        success: function (response) {
            var data = $.parseJSON(response);
            $.each(data.models, function (key, value) {
                chkBoxFields.push([key, value.category]);
            });
        },
        error: function (e) {
            console.error(e);
        }

    });
}
function createArrtbGrid() {
    for (var i = 0; i < chkBoxFields.length; i++) {
        //  console.log(data[i]);
        var chkBox = '<label class="checkbox" for="ckbx' + chkBoxFields[i][0] + '">' +
            '<input type="checkbox" id="ckbx' + chkBoxFields[i][0] + '" value = "' + chkBoxFields[i][1] + '">' + chkBoxFields[i][0] +
            '</label>';
        $('#attributes').append(chkBox);
    }
}



function interpretUrlQuery() {
    var queries = (function () {
        var match,
            pl = /\+/g,
            search = /([^&=]+)=?([^&]*)/g,
            decode = function (s) { return decodeURIComponent(s.replace(pl, ' ')); },
            query = window.location.search.substring(1);
        var qs = {};
        while (match = search.exec(query))
            qs[decode(match[1])] = decode(match[2]);
        return qs;
    })();

    console.log(queries);
    if (queries.id != undefined) {
        showResult(queries.id);
    }
}

function refreshRecent() {

    var params = {
        task: "REGRESSION",
        username: null,  //any user,
        view: 'ALL',
        count: 2
    };

    feserverProxy.submitQuery(FeServer.Tasks.HISTORY, params, function (response) {

        var results = response["results"];
        var requestIds = results["history"].map(function (item) { return item.request["id"]; });

        var recentRegressions = $("#recentRegressions");
        $("#recentRegressions > tbody").html(""); //clear only the rows, not headers
        $(results["history"]).each(function () {
            console.log(this);
            recentRegressions.append(makeTrHtml({
                id: this.request.id,
                priceDate: this.request.params["cmd_options"]["price-date"],
                envs: this.request.params["cmd_options"]["envs"],
                status: this.status,
                serverTime: this.request.server_time,
                username: this.request.username

            }));
            //notifyMe: false
            //cronusServerProxy.fetchRegistrations(requestIds, function (notifyMeStatuses) {
            //    var recentRegressions = $("#recentRegressions");
            //    $("#recentRegressions > tbody").html(""); //clear only the rows, not headers
            //    $(results["history"]).each(function () {
            //        console.log(this);
            //        recentRegressions.append(makeTrHtml({
            //            id: this.request.id,
            //            priceDate: this.request.params["cmd_options"]["price-date"],
            //            envs: this.request.params["cmd_options"]["envs"],
            //            status: this.status,
            //            serverTime: this.request.server_time,
            //            username: this.request.username,
            //            notifyMe: notifyMeStatuses[this.request.id]
            //        }));

            //    });

        });
    });
}

function makeTrHtml(req) {
    //status = '<span style="color:red;">' + req.status + '</span>';
    //$(td).html('<a href = "#" onclick="showLog(\'' + value.requestId + '\'); return false;" style ="color:red;">' + value.status + '</a>');
    //$(td).css("text-decoration", "underline");
    var status = undefined;
    if (req.status === "FAILED")
        status = '<a href = "javascript:void(0)" onclick="showLog(\'' + req.id + '\')" style ="color:red;">' + req.status + '</a>';

    else if (req.status === "OK")
        status = '<a style="color:blue;" href="javascript:showResult(\'' + req.id + '\')">' + req.status + '</a>';
    else
        status = '<span id="' + req.id + '">' + req.status + "</span>";

    var notifyMe = '<input type="checkbox" name="notifyme" value="notify" onclick="notify(\'' + req.id + '\', this.checked)"/>';
    if (req.notifyMe === true)
        notifyMe = '<input type="checkbox" name="notifyme" value="notify" onclick="notify(\'' + req.id + '\', this.checked)" checked/>';

    var envDisplayText = function (envs) {
        if (envs) {
            var tokens = [];
            envs.split(',').forEach(function (y) { tokens.push(y.replace(/\b[a-z]/g, function (z) { return z.toUpperCase(); })); });
            return tokens.join(' vs ');
        }
        else {
            return envs;
        }
    };
    return "<tr><td>" + req.priceDate
                                        + '</td><td>' + envDisplayText(req.envs)
                                         + '</td><td>' + req.username
                                        + '</td><td>' + req.serverTime.substring(0, 19)
                                        + '</td><td>' + status
                                        + '</tr>';
    //+ '</td><td style="text-align:center;">' + notifyMe
    //+ '</td></tr>';
}

function notify(requestId, register) {
    console.log("notify: ", requestId, register);
    cronusServerProxy.register(requestId, register);
}

function onUpdateStatus(requestId, status) {

    console.log(requestId, status);
    //  return;

    if (status === 'READY') {
        refreshRecent();
        return;
    }

    var e = $("#" + requestId);
    if (e) {
        //e.html('<span style="color:red;">' + status + '</span>');
        if (status === 'FAILED')
            e.html('<a href = "javascript:void(0);" onclick="showLog(\'' + requestId + '\')" style ="color:red;">' + status + '</a>');
        else if (status === 'OK')
            e.html('<a style="color:blue;" href="showResult(\'' + requestId + '\')">' + status + '</a>');
        else
            e.html(status);
        console.info("status of " + requestId + " updated with " + status);
    }
    else {
        console.error("didn't find any element with id " + requestId);
    }

    if (status == 'OK') {
        showResult(requestId);
    }
}

function showResult(requestId) {

    uistate.id = requestId;

    feserverProxy.submitQuery(FeServer.Tasks.JPATH, { "id": requestId, "paths": ["/diff"] }, function (response) {
        var results = response["results"];
        console.log(response["status"], results["status"]);
        var models = results["payloads"]["/diff"]["object_keys"];
        var paths = [];
        uistate.results = { "diff": {}, "summary": {} };
        for (var i = 0; i < models.length; i++) {
            uistate.results["diff"][models[i]] = {};
            paths.push("/diff/" + models[i]);
        }

        $('#outputElement').html(report_html());

    }, null);

}
function showLog(requestId) {
    // return showResult('0b49de20-a57c-4a46-8158-f0b3222494ea');
    $('#divLog').empty();
    feserverProxy.submitQuery(FeServer.Tasks.LOG, { id: requestId }, function (response) {
        for (var property in response.results.logs) {
            if (response.results.logs[property] != '') {
                var color = '';
                if (response.results.logs[property].toLowerCase().indexOf("error") >= 0 || response.results.logs[property].toLowerCase().indexOf("failed") >= 0)
                    color = 'style = "color:red;"';

                var Id = property.replace(new RegExp("\\.", "ig"), '');
                var html = '<div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><u>'
                html += '<a data-toggle="collapse" href="#' + Id + '" ' + color + '>' + property + '</a></u></h4>'
                html += '</div><div id="' + Id + '" class="panel-collapse collapse">'
                html += '<div class="panel-body" style="overflow:auto;">'
                html += response.results.logs[property].replace(new RegExp('\n', "g"), '</br>')
                    .replace(new RegExp("FAILED", "ig"), "<b style=color:red> FAILED </b> ")
                    .replace(new RegExp("Error", "ig"), "<b> ERROR </b> ")
                    + " </Br> </Br>";
                html += '</div></div></div>'
                $('#divLog').append(html);
            }
        }
        $("#divLog").removeClass('hidden');
    });
}
//function getLogs() {
//    debugger;

//    $("#recentRegressions tr").each(function () {

//        $(this).find('td').each(function () {
//            var logId = $(this).find("span").attr('id');
//            if (logId) {
//                var params = {
//                    id: logId
//                };
//                feserverProxy.submitQuery(FeServer.Tasks.LOG, params, function (response) {
//                    for (var property in response.results.logs) {
//                        if (response.results.logs.hasOwnProperty(property)) {
//                            alert("Log Id : " + logId +"\n" +  response.results.logs[property]);
//                        }
//                    }
//                });
//            }
//        })
//    })
//}

function submitRequest(cusip, price, row) {
    var priceDate = $("#txtPricedate").val();
    var settleDate = $("#txtSettleDate").val();
    var lastBusinessDate = $("#txtLastBusinessDate").val();
    var less10BusinessDate = $("#txtLess10BusinessDate").val();
    var invocationList = $("#txtInvocation").val();




    var pass_opts = "";
    if (less10BusinessDate != "") {
        pass_opts += "less10_business_date:" + less10BusinessDate
    }
    if (lastBusinessDate != "") {
        pass_opts += " last_business_date:" + lastBusinessDate
    }
    if (settleDate != "") {
        pass_opts += " settle_date_3:" + settleDate;
    }

    if ($("input[name=a]:checked").val() == undefined) {
        swal("Error", "Please select Type", "error");
        return;
    }
    if (priceDate == "") {
        swal("Error", "Please pass price date", "error");
        return;
    }
    if ($("input[name=a]:checked").val() == "all-pass" && (less10BusinessDate == '' || lastBusinessDate == '' || settleDate == '')) {
        swal("Error", "Settle Date, Last Business Date and Less 10 Business Date are mandatory for Pass", "error");
        return;
    }
    if ($("input[name=a]:checked").val() == "invocation" && $("#txtInvocation").val() == '') {
        swal("Error", "Please pick once of the invocation from invocation list", "error");
        return;
    }
    if ($("input[name=a]:checked").val() == "invocation" && $("#txtInvocation").val() != '') {
        var isPass = false;
        $("#attributes input[type=checkbox]:checked").each(function (keys, value) {
            // alert(this.id);
            //alert($(this).val());
            if ($(this).val().toLowerCase() == "pass") {
                isPass = true;
            }
        });
        if (isPass == true && (less10BusinessDate == '' || lastBusinessDate == '' || settleDate == '')) {
            swal("Error", "Settle Date, Last Business Date and Less 10 Business Date are mandatory for Pass", "error");
            return;
        }

    }

    var cmdFlag = "";
    var params;
    if ($("input[name=a]:checked").val() == 'all-parc' || $("input[name=a]:checked").val() == 'all-pass') {
        cmdFlag = $("input[name=a]:checked").val();
        if (pass_opts != '') {
            params = {
                "cmd_options": {
                    "price-date": priceDate,
                    "envs": $("#EnvOptions").val(),
                    "pass-opts": pass_opts,
                },
                "cmd_flags": []
            };
        }
        else {
            params = {
                "cmd_options": {
                    "price-date": priceDate,
                    "envs": $("#EnvOptions").val()
                },
                "cmd_flags": []
            };
        }

    }
    else {
        if (pass_opts != '') {
            params = {
                "cmd_options": {
                    "price-date": priceDate,
                    "envs": $("#EnvOptions").val(),
                    "pass-opts": pass_opts,
                    "invocation-ids": invocationList
                },
                "cmd_flags": []
            };
        }
        else {
            params = {
                "cmd_options": {
                    "price-date": priceDate,
                    "envs": $("#EnvOptions").val(),
                    "invocation-ids": invocationList
                },
                "cmd_flags": []
            };
        }
    }

    if (cmdFlag)
        params.cmd_flags.push(cmdFlag);

    feserverProxy.submitAction(FeServer.Tasks.REGRESSION, params, function (id) {
        console.log("id =>", id);

        $("#recentRegressions").prepend(makeTrHtml({
            id: id,
            priceDate: priceDate,
            envs: params.cmd_options.envs,
            status: 'SUBMITTED',
            serverTime: 'Now',
            username: 'None',
            notifyMe: false
        }));
        var trList = $("#recentRegressions tr");
        if (trList.length >= 4)
            trList.last().remove();

    }, null);

}

function groupify(columns) {
    var i = 0;
    var groups = [];
    for (; i < columns.length;) {
        if (columns[i].substr(-4, 4) == "_old") {
            var new_ = columns[i].replace('_old', '_new');
            var diff = columns[i].replace('_old', '_diff');
            if (columns[i + 1] == new_ && columns[i + 2] == diff) {
                groups.push({ name: columns[i].substr(0, columns[i].length - 4), group: true });
                i += 3;
            }
            else {
                groups.push({ name: columns[i], group: false });
                i += 1;
            }
        }
        else {
            groups.push({ name: columns[i], group: false });
            i += 1;
        }
    }
    return groups;
}

function show_models(type) {
    uistate.type = type;
    $('#models').html(""); //reset
    $('#risks').html("");  //reset
    var html = '<option value="def">Select Model</option>';
    for (var model in uistate.models()) {
        html += '<option value="' + model + '">' + model + '</option>';
    }
    $('#models').html(html);
}

var colors = ['#ffffff', '#e2e2ff'];

function make_header(table) {
    var columns = groupify(table['header']);
    var tr1 = "<thead><tr>";
    var tr2 = "<tr>";
    for (var i = 0; i < columns.length; ++i) {
        if (columns[i].group) {
            tr1 += '<th colspan="3" style="border-right:1px solid #dddddd;border-bottom:1px solid #cccccc;border-top:1px solid #000000;text-align:center;padding:2px 4px;background-color:' + colors[i % 2] + ';">' + displayNames.getDisplayName(columns[i].name) + '</th>';
            if (i % 2 == 0) {
                tr2 += '<th style="border-right:1px solid #dddddd;border-bottom:1px solid #000000;text-align:center;padding:2px 4px;background-color:' + colors[i % 2] + ';">Old</th>';
                tr2 += '<th style="border-right:1px solid #dddddd;border-bottom:1px solid #000000;text-align:center;padding:2px 4px;background-color:' + colors[i % 2] + ';">New</th>';
                tr2 += '<th style="border-right:1px solid #dddddd;border-bottom:1px solid #000000;text-align:center;padding:2px 4px;background-color:' + colors[i % 2] + ';">Diff</th>';
            }
            else {
                tr2 += '<th style="border-right:1px solid #cccccc;border-bottom:1px solid #000000;text-align:center;padding:2px 4px;background-color:' + colors[i % 2] + ';">Old</th>';
                tr2 += '<th style="border-right:1px solid #cccccc;border-bottom:1px solid #000000;text-align:center;padding:2px 4px;background-color:' + colors[i % 2] + ';">New</th>';
                tr2 += '<th style="border-right:1px solid #cccccc;border-bottom:1px solid #000000;text-align:center;padding:2px 4px;background-color:' + colors[i % 2] + ';">Diff</th>';
            }
        }
        else {
            tr1 += '<th rowspan="2" style="border-right:1px solid #dddddd;border-bottom:1px solid #000000;border-top:1px solid #000000;text-align:center;padding:2px 4px;background-color:' + colors[i % 2] + ';">' + displayNames.getDisplayName(columns[i].name) + '</th>';
            //   tr2 += '<th style="border:1px solid black;text-align:center;background-color:' + colors[i % 2] + ';">&nbsp;</th>'; ;
        }
    }
    return tr1 + '</tr>' + tr2 + '</tr></thead>';
}

function make_tr(tr, row, header) {
    var i = 0;
    var html = "";
    var bcolor;
    for (var j = 0; j < row.length; ++j) {
        if (i % 2 == 0)
            bcolor = '#dddddd';
        else
            bcolor = '#cccccc';
        if (header[j].substr(-5, 5) == '_diff') {
            if (row[j] <= -1 || row[j] >= 1)
                html += '<td style="border-right:1px solid ' + bcolor + ';border-bottom:1px solid ' + bcolor + ';font-weight:bold;color:red;padding:2px 4px;background-color:' + colors[i % 2] + ';">';
            else
                html += '<td style="border-right:1px solid ' + bcolor + ';border-bottom:1px solid ' + bcolor + ';font-weight:bold;color:blue;padding:2px 4px;background-color:' + colors[i % 2] + ';">';
            html += row[j] + '</td>';
        }
        else
            html += '<td style="border-right:1px solid ' + bcolor + ';border-bottom:1px solid ' + bcolor + ';padding:2px 4px;background-color:' + colors[i % 2] + ';">' + row[j] + '</td>';
        var suffix = header[j].substr(-4, 4);
        if (!(suffix == '_old' || suffix == '_new'))
            i += 1;
    }
    $(tr).html(html);
}

function destroyDataTable(dt, tableElement) {
    if (dt != undefined) {
        dt.fnClearTable();
        dt.fnDestroy();
        if (tableElement != undefined)
            $(tableElement).html('');
    }
    return dt;
}


function lazyLoad() {
    var segmentsManager = new ResultSegmentsManager(cronusServerProxy, uistate.id);

    return function (pageInfo, drawCallback, internals) {

        segmentsManager.getRows(pageInfo.start, pageInfo.start + pageInfo.length, function (rows) {
            drawCallback({ data: rows, recordsTotal: segmentsManager.totalRowCount(), recordsFiltered: segmentsManager.totalRowCount(), draw: pageInfo.draw });
        });
    };
}

function refreshDataTable(dt, tableElement, columns, dataTableArray, fixedLastCols, columndefs) {
    //  Clear contents of dataTables
    var columnsName = [];
    for (var index = 0; index < columns.length; index++) {
        columnsName.push({ title: columns[index] });
    }

    $.extend(true, $.fn.dataTable.defaults, {
        dom: 'Bilfrtip',
        buttons: [
            'copy', 'print', {
                extend: 'csv',
                text: 'Export To Excel'
            }
        ]
    });

    var settings = {

        language: {
            processing: "Loading...",
        },

        processing: true,
        deferRender: true,
        serverSide: true,

        ajax: lazyLoad(),

        scrollX: true,
        //scrollY: 250,
        destroy: true,

        createdRow: function (tr, data, index) {
            make_tr(tr, data, columns);
        }
    };

    if (Cronus.isNotEmptyNullOrUndefined(fixedLastCols)) {
        settings["fixedColumns"] = {
            rightColumns: [fixedLastCols]
        };
    }
    if (Cronus.isNotEmptyNullOrUndefined(columndefs)) {
        settings["columnDefs"] = columndefs;
    }
    $(tableElement).DataTable(settings);

    return $(tableElement).dataTable();
}

function getTable(data) {
    if (uistate.tableDivs[uistate.risk] != undefined) {
        return uistate.tableDivs[uistate.risk];
    }
    var div = document.createElement("div");
    uistate.tableDivs[uistate.risk] = div;

    $("#table-region").append(div);

    var table = document.createElement("table");
    $(div).append(table);

    $(table).html(make_header(data));

    Cronus.refreshDataTable(0, table, data['header'], data['values']);

    return div;
}

function OnRiskSelect() {
    uistate.risk = document.getElementById('risks').value;

    uistate.render(function () {
        var data = uistate.data();
        if (uistate.previousTableDiv != undefined) {
            $(uistate.previousTableDiv).addClass('hidden');
        }
        uistate.previousTableDiv = getTable(data);
        $(uistate.previousTableDiv).removeClass('hidden');
    });

}

function OnModelSelect() {

    uistate.model = document.getElementById('models').value;
    var path = "/" + uistate.type + "/" + uistate.model;

    var type = uistate.type; //the current value needs to be be captured in the lambda below !!!
    var model = uistate.model;

    feserverProxy.submitQuery(FeServer.Tasks.JPATH, { "id": uistate.id, "paths": [path] }, function (response) {
        var results = response.results;
        console.log(results);
        var diff = uistate.results[type];
        path = results["payloads"][path];
        if (path) {
            var risks = path["object_keys"];
            var model_risks = diff[model];
            for (var j = 0; j < risks.length; ++j) {
                model_risks[risks[j]] = {};
            }

            var html = "";
            for (var risk in uistate.risks()) {
                html += '<option value="' + risk + '">' + risk + '</option>';
            }
            //console.log(html);
            $('#risks').html(html);
        }
    }, null);

}

function report_html(models) {
    var html = '<div class="panel-group" id="result">';
    html += '<input type="radio" name="radio_result" style="margin:10px; border-right:1px solid gray;" onclick="javascript:show_models(this.value)" value="diff">Differrence</input>';
    html += '<input type="radio" name="radio_result" style="margin:10px; border-right:1px solid gray;" onclick="javascript:show_models(this.value)" value="summary">Summary</input>';
    html += '<select id="models" style="margin:10px; border-right:1px solid gray;" onchange="OnModelSelect()"></select>';
    html += '<select id="risks" style="margin:10px;" onchange="OnRiskSelect()"></select>';
    html += '<br/><div id="table-region"></div>';
    return html + '</div>';
}

function showFromCalender() {
    $("#txtPricedate").focus();
    return false;
}
function showFromCalenderSettleDate() {
    $("#txtSettleDate").focus();
    return false;
}
function showFromCalenderLastBusinessDate() {
    $("#txtLastBusinessDate").focus();
    return false;
}
function showFromCalenderLess10BusinessDate() {
    $("#txtLess10BusinessDate").focus();
    return false;
}