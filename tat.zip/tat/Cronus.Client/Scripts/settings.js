﻿"use strict";
var screenName = Cronus.Screens.Settings;
var jqXHRData;
var imagePath = "";

$(document).ready(function () {
    if (!Cronus.selectedPage(screenName, Cronus.Actions.Settings_View)) {
        return;
    }
    fetchUserProfile();
    //document.getElementById("profilePicPreview").src = $("#dvphoto img").attr('src');

});

var profilePicData;

$('#PicUpload').fileupload({
    url: '/File/UploadFile',
    dataType: 'json',
    add: function (e, data) {
        jqXHRData = data;
    },
    done: function (event, data) {
        if (data.result.isUploaded) {
            imagePath = data.result.imagePath;
            $('#filelistholder').css('background-image', 'url(' + imagePath + ')');

            var inputObj = { screenName: screenName, data: { ImagePath: imagePath} };
            var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, ".blockOverlay", true); //, "#btnStartUpload"
            $.when(retval.AjaxObj).done(function () {
                var result = retval.AjaxObj.responseJSON;
                if (result.errorMessage == null || result.errorMessage == "") {
                    swal("Info", "Image uploaded successfully", "success");

                }
            });
        }
        else {
            swal("Error", "Upload Failed", "error");
        }
        //Now call ajax to uplaod this file on server
    },
    fail: function (event, data) {
        if (data.files[0].error) {
            swal("Error", data.files[0].error, "error");
        }
    }
});
// ImagePath: imagePath

function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#filelistholder').css('background-image', 'url(' + e.target.result + ')');
        };

        reader.readAsDataURL(input.files[0]);
    }
}

$("#btnStartUpload").on('click', function () {
    if (jqXHRData) {
        //$(".blockOverlay").css('display', 'block');
        jqXHRData.submit();
    }
    return false;
});


function fetchUserProfile() {
    var inputObj = { screenName: screenName };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", false);
    if (retval.Error == false) {
        var result = retval.Result;
        var imagePathUser = result.rows[0][2];
        var defaultImage = getHostName() + "/Images/user.png";

        imagePathUser = getHostName() + imagePathUser;
        if (Cronus.isNotEmptyNullOrUndefined(imagePathUser)) {
            $('#filelistholder').css('background-image', 'url(' + imagePathUser + ')');
        } else {
            $('#filelistholder').css('background-image', 'url(' + defaultImage + ')');
        }
    }
}

function getHostName() {

    var hostaddress = window.location.protocol + '//' + window.location.hostname + (window.location.port ? ':' + window.location.port : '');
    var subhostaddress = "";
    if (window.location.hostname.toLowerCase() == "cronusdelta") {
        subhostaddress = "/cronus-client-delta";
    }
    else if (window.location.hostname.toLowerCase() == "localhost") {
        subhostaddress = "";
    }
    else {
        subhostaddress = "/cronus-client";
    }

    return hostaddress + subhostaddress;
}


function validate(el) {
    var selectedFiles = el.files;
    var oFile = selectedFiles[0];
    var rFilter = /^(image\/bmp|image\/gif|image\/jpeg|image\/png|image\/tiff|image\/jpg)$/i;
    if (!rFilter.test(oFile.type)) {
        swal("Error", "Only image formats are allowed", "error");
        $("#fdProfilePic").val('');
        document.getElementById("profilePicPreview").src = $("#dvphoto img").attr('src');
        return false;
    } else if (oFile.size > 1024000) {
        swal("Error", "Please choose file upto 1000KB", "error");
        $("#fdProfilePic").val('');
        document.getElementById("profilePicPreview").src = $("#dvphoto img").attr('src');
        return false;
    } else {
        //$("#file").val(selectedFiles[0].name);
        if (typeof (window.FileReader) == 'undefined') {

        } else {
            var oFReader = new window.FileReader();
            oFReader.readAsDataURL(document.getElementById("fdProfilePic").files[0]);
            oFReader.onload = function (oFrEvent) {
                profilePicData = oFrEvent.target.result;
                document.getElementById("profilePicPreview").src = oFrEvent.target.result;
            };
        }
        return true;
    }
}
