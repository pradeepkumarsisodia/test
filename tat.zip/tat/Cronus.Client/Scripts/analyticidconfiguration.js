﻿"use strict";
var screenName = Cronus.Screens.AnalyticIdConfiguration;
var IdA = 0;
var IdInvocationMeatData = 0;
var dropDownCache = {};

$(document).on("ready", function () {
    if (!Cronus.selectedPage(screenName, Cronus.Actions.AnalyticIdConfiguration_View)) {
        return;
    }

    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.AnalyticIdConfiguration_Submit, screenName) == false) {
        disableSaveButton();
    }
    $('#btnAddA').click(function () {
        AddDivA();
    });
    $('#btnAddInvocationMetaData').click(function () {
        addInvocationMetadata();
    });
    $('#btnSaveAnalyticIdConfiguration').click(function () {
        SaveData();
    });

    $('#btnSearchAnalyticId').click(function () {
        SearchData();
    });

    $('#btnReset').click(function () {
        reset();

    });
    $("#txtAnalyticId").focusout(function () {
        updateAnalyticId();
    });

    $("#txtSearchAnalyticId").keypress(function (e) {
        if (e.which == 13) {
            $("#btnSearchAnalyticId").click();
            return false;
        }
    });

    $("#btnupdateAanliticId").click(function () {
        if ($("#txtUpdateAnalyticId").val() != "") {
            $("#hdnOldAanlyticId").val($("#txtAnalyticId").val());
            $("#txtAnalyticId").val($("#txtUpdateAnalyticId").val()).focusout();
            $('#divChangeAnalyticId').modal('hide');
        }
    });

    cacheAllData();

    populateDropDownFields("#ddlDataType", "DATA_TYPE");
    //populateDropDownFields("#ddlProviderId", "PROVIDER_ID");
    //populateDropDownFields("#ddlCurveType", "CURVE_TYPE");
    //populateDropDownFields("#ddlProduct", "PRODUCT");
    //populateDropDownFields("#ddlModelOutputType", "MODEL_OUTPUT_TYPE");
    //populateDropDownFields("#ddlScenarioConfigFile", "SCENARIO_CONFIG_FILE");
    //populateDropDownFields("#ddlSensitivityConfigFile", "SENSITIVITY_CONFIG_FILE");
    reset();

    var environment = Cronus.getParameterByName("env");
    if (environment != null) {
        $("#ddlCommanEnviroment").val(environment);
    }

});

function updateAnalyticId() {
    if (Cronus.isNotEmptyNullOrUndefined($("#txtAnalyticId").val())) {
        $("#txtModelField").val($("#txtAnalyticId").val());
        for (var i = 1; i <= IdA; i++)
            bindAnalyticIdStageArray(i);
        for (var i = 1; i <= IdInvocationMeatData; i++)
            bindAnalyticIdStageInvArray(i);
    }
}

function isValidRequest(chBxValue, label) {
    if (Cronus.isNotEmptyNullOrUndefined($("#txtAnalyticId").val()) && !$(chBxValue).prop('checked')) {
        for (var i = 1; i <= IdA; i++) {
            if ($(chBxValue).val().replace("label", $("#txtAnalyticId").val()) == $("#ddlAnalyticIdStage" + i).val()) {
                swal("Error", "Cann't uncheck " + label + " as it is used in risk measures to app table", "error");
                return false;
            }
        }

        for (var i = 1; i <= IdInvocationMeatData; i++) {
            if ($(chBxValue).val().replace("label", $("#txtAnalyticId").val()) == $("#ddlAnalyticIdStageInvocationMetatData" + i).val()) {
                swal("Error", "Cann't uncheck " + label + " as it is used in invocation metadata table", "error");
                return false;
            }
        }
    }
    return true;
}

function SearchData() {
   
    var analyticId = $('#txtSearchAnalyticId').val().trim();
    $('#txtSearchAnalyticId').val(analyticId);

    if (!Cronus.isNotEmptyNullOrUndefined(analyticId)) {
        $("#txtSearchAnalyticId").focus();
        return;
    }
    else {
        reset();
        var analyticIdToStage = "";
        var inputObj = {
            screenName: screenName,
            functionName: "AnalyticIdSearch",
            data: { value: analyticId }
        };
        var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, null, false, '#btnSearchAnalyticId');
        $.when(retval.AjaxObj).done(function () {
            var result = retval.AjaxObj.responseJSON;
            if (result.errorMessage == null || result.errorMessage == "") {
                if (result.data == undefined || result.data == null) {
                    $("#lnkeditanalyticid").css('visibility', 'hidden');
                    swal("Error", "No Data found", "error");
                }
                else {
                    clearData();
                    $("#txtAnalyticId").attr('readonly', true);
                    $("#lnkeditanalyticid").css('visibility', 'visible');

                    $("#txtAnalyticId").val(result.data.analyticId).focusout();
                    $("#txtModelField").val(result.data.modelFieldName);
                    $("#ddlDataType").val(result.data.dataType);
                    /* $("#ddlProviderId").val(result.data.providerId);
                     $("#ddlCurveType").val(result.data.curveType);
                     $("#ddlProduct").val(result.data.product);
                     $("#ddlModelOutputType").val(result.data.modelOutputType);
                     $("#ddlScenarioConfigFile").val(result.data.scenarioConfigFile);
                     $("#ddlSensitivityConfigFile").val(result.data.sensitivityConfigFile);*/
                    $("#txtDescription").val(result.data.description);

                    $("#attributes input[name=labellist]").each(function (keys, value) {
                        var chkid = $(this).val();
                        $.each(result.data.lableList, function (keys, value) {
                            if (chkid.toUpperCase() == value.toUpperCase()) {
                                $("#ckbx" + chkid).attr('checked', false).click();
                            }
                        });
                    });

                    bindDivA(result.data.riskMeasuresToAppList);
                    bindIvocation(result.data.riskMeasuresToInvocationList);
                }
            }
            else {
                disableSaveButton();
                swal("Error", result.errorMessage, "error");
            }
        });
    }
}

function bindDivA(riskMeasuresToAppList) {
    //$("#txtMainTable" + (key + 1)).val(value.mainTable).attr('selected', true).change();;
    $.each(riskMeasuresToAppList, function (key, value) {
        if (IdA <= key) AddDivA();
        $("#ddlAnalyticIdStage" + (key + 1)).val(value.analyticIdToStage);
        $("#txtMainTable" + (key + 1)).val(value.mainTable);
        $("#txtAppField" + (key + 1)).val(value.appField);
        $("#txtDataType" + (key + 1)).val(value.dataType);
        $("#txtLiveTable" + (key + 1)).val(value.liveTable);
        $("#txtModelSumDiff" + (key + 1)).val(value.modelSrmDiffThreshold);
        $("#chkIsApplicable" + (key + 1)).prop('checked', value.isApplicable);
        $("#txtDescription" + (key + 1)).val(value.description);

    });
}

function bindIvocation(riskMeasuresToInvocationList) {
    $.each(riskMeasuresToInvocationList, function (key, value) {
        if (IdInvocationMeatData <= key) addInvocationMetadata();
        $("#ddlAnalyticIdStageInvocationMetatData" + (key + 1)).val(value.analyticIdToStage);
        $("#attributesInvocation" + (key + 1) + " input[name=invoactionlist]").each(function (index, field) {
            var chkid = $(this).val();
            $.each(value.invocationList, function (index1, invId) {
                if (chkid == invId) $("#ckbx" + chkid + (key + 1)).click();
            });
        });
    });
}

function clearData() {
    // dataType = [];
    var ddlselectedEnv = $("#ddlCommanEnviroment").val();
   
    $('select').val('');
    $("input[type=text]").val('');
    $('textarea').val('');
    $("input[type=checkbox]").attr('checked', false);
    //$('#attributes').empty();
    $('#divA').empty();
    $('#divInvocationMetaData').empty();
    IdA = 0;
    IdInvocationMeatData = 0;
    $("#ddlCommanEnviroment").val(ddlselectedEnv);
}

function reset() {
    clearData();
    $('#attributes').empty();
    addLabel();
    AddDivA();
    addInvocationMetadata();
    $("#lnkeditanalyticid").css('visibility', 'hidden');
    $("#txtAnalyticId").attr('readonly', false);
    $("#hdnOldAanlyticId").val("");
}
function SaveData() {
    var errorMessage = "";
    if ($("#txtAnalyticId").val() == '') {
        errorMessage += "Please fill Analytic Id \n";
    }
    if ($("#txtModelField").val() == '') {
        errorMessage += "Please fill Model Field \n";
    }
    if ($("#ddlDataType").val() == '0') {
        errorMessage += "Please Select Data Type \n";
    }

    if (errorMessage != "") {
        swal("Error", errorMessage, "error");
        return false;
    }

    var riskMeasuresToAppList = [];
    for (var i = 1; i <= IdA; i++) {
        if (!$('#chkDeleteRiskMeasuresToApp' + i).is(':checked')) {
            if ($("#ddlAnalyticIdStage" + i).val() != "0") {
                riskMeasuresToAppList.push({
                    analyticIdToStage: $("#ddlAnalyticIdStage" + i).val()
                 , mainTable: $("#txtMainTable" + i).val()
                 , appField: $("#txtAppField" + i).val()
                 , dataType: $("#txtDataType" + i).val()
                 , liveTable: $("#txtLiveTable" + i).val()
                 , modelSrmDiffThreshold: $("#txtModelSumDiff" + i).val()
                 , isApplicable: $("#chkIsApplicable" + i).prop('checked') ? true : false
                 , description: $("#txtDescription" + i).val()
                });
            }
        }
    }

    var labelList = new Array();
    $("#attributes input[name=labellist]:checked").each(function (keys, value) {
        labelList.push($(this).val().toUpperCase());
    });

    var riskMeasuresToInvocationList = [];
    for (var j = 1; j <= IdInvocationMeatData; j++) {
        if (!$('#chkDeleteInvocationMetadata' + j).is(':checked')) {
            if ($("#ddlAnalyticIdStageInvocationMetatData" + j).val() != "0" && $("#txtInvocation" + j).val() != "") {
                riskMeasuresToInvocationList.push({
                    analyticIdToStage: $("#ddlAnalyticIdStageInvocationMetatData" + j).val()
                , invocationList: $("#txtInvocation" + j).val().split(',')
                });
            }
        }
    }
    var ConfigInputData = {
        analyticId: $("#txtAnalyticId").val(),
        previousAnayticId: $("#hdnOldAanlyticId").val(),
        modelFieldName: $("#txtModelField").val(),
        dataType: $("#ddlDataType").val(),
        lableList: labelList,
        /*      providerId: $("#ddlProviderId").val(),
                curveType: $("#ddlCurveType").val(),
                curveId: "",
                product: $("#ddlProduct").val(),
                modelOutputType: $("#ddlModelOutputType").val(),
                scenarioConfigFile: $("#ddlScenarioConfigFile").val(),
                sensitivityConfigFile: $("#ddlSensitivityConfigFile").val(),
          */
        description: $("#txtDescription").val(),
        riskMeasuresToAppList: riskMeasuresToAppList,
        RiskMeasuresToInvocationList: riskMeasuresToInvocationList

    };
    var inputObj = {
        screenName: screenName,
        data: ConfigInputData
    };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, null, true, '#btnSaveAnalyticIdConfiguration');
    $.when(retval.AjaxObj).done(function () {
        var dtSecAnalytic;
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            swal("Info", result.message, "success");
            $("#txtAnalyticId").attr('readonly', false);
            reset();
        }
        else {
            swal("Error", "Invalid Data \n " + result.errorMessage, "error");
            $("#btnSaveAnalyticIdConfiguration").button('reset');
        }
    });
}

function addLabel() {
    var chkBoxFields = [];
    $(dropDownCache["LABEL"]).each(function (index, value) {
        chkBoxFields.push(value);
    });

    createArrtbGrid(chkBoxFields);
}

function createArrtbGrid(chkBoxFields) {
    $(chkBoxFields).each(function (index, value) {
        var chkBox = '<label class="checkbox" for="ckbx' + value + '">' +
            '<input type="checkbox" id="ckbx' + value + '"name = "labellist"  value = "' + value + '">' + value +
            '</label>&nbsp;&nbsp;';
        $('#attributes').append(chkBox);
        $("#ckbx" + value).click(function () {
            if (isValidRequest("#ckbx" + value, value))
                updateAnalyticId();
            else
                $("#ckbx" + value).click();
        });
    });
}

function cacheAllData() {
    var inputObj = { screenName: screenName, functionName: "GetCache", data: { value: "ALL" } };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, null, false, "");
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            $(result.data).each(function (index, pair) {
                if (!(pair.Key in dropDownCache)) dropDownCache[pair.Key] = [];
                dropDownCache[pair.Key].push(pair.Value);
            });
        }
        else {
            swal("Error", result.errorMessage, "error");
        }
    });
    cacheAppFieldData();
    cacheLiveTableData();
}

function cacheAppFieldData() {
    var inputObj = { screenName: screenName, functionName: "GetCache", data: { value: "AppField" } };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, null, false, "");
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            $(result.data).each(function (index, pair) {
                if (!("APP_FIELD" in dropDownCache)) dropDownCache["APP_FIELD"] = [];
                dropDownCache["APP_FIELD"].push({ key: pair.Key, value: pair.Value });
            });
        }
        else {
            swal("Error", result.errorMessage, "error");
        }
    });
}

function cacheLiveTableData() {
    var inputObj = { screenName: screenName, functionName: "GetCache", data: { value: "LiveTable" } };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, null, false, "");
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            $(result.data).each(function (index, pair) {
                if (!("LIVE_TABLE" in dropDownCache)) dropDownCache["LIVE_TABLE"] = [];
                dropDownCache["LIVE_TABLE"].push({ key: pair.Key, value: pair.Value });
            });
        }
        else {
            swal("Error", result.errorMessage, "error");
        }
    });
}

function populateDropDownFields(field, fieldName, data) {
    if (fieldName in dropDownCache) {
        if (data == undefined) {
            $(field).append('<option value="">Select</option>');
            $(dropDownCache[fieldName]).each(function (key, value) {
                $(field).append('<option value="' + value + '">' + value + '</option>');
            });
        }
        else {
            $(field).append('<option value="">Select</option>');
            $(dropDownCache[fieldName]).each(function (index, value) {
                if (value.key == data)
                    $(field).append('<option value="' + value.value + '">' + value.value + '</option>');
            });
        }
    }
}

//function bindAPPField(id, value) {
//    $("#ddlAppField" + id).empty();
//    populateDropDownFields("#ddlAppField" + id, "APP_FIELD", value);
//}

//function bindLiveTable(id, value) {
//    $("#ddlLiveTable" + id).empty();
//    populateDropDownFields("#ddlLiveTable" + id, "LIVE_TABLE", value);

//    $(dropDownCache["LIVE_TABLE"]).each(function (index, pair) {
//        if (pair.key == value)
//            $("#ddlLiveTable" + id).val(pair.value);
//    });
//}

function bindAnalyticIdStageInvArray(id) {
    var AnalyticIdStageArray = [];
    var analyticId = $("#txtAnalyticId").val();
    if (analyticId != "") {
        AnalyticIdStageArray.push(analyticId);
    }
    $("#attributes input[name=labellist]:checked").each(function (keys, value) {
        AnalyticIdStageArray.push($(this).val().replace("label", analyticId));
    });
    var currval = $("#ddlAnalyticIdStageInvocationMetatData" + id).val();
    var selddlInvocation = $("#ddlAnalyticIdStageInvocationMetatData" + id);
    if (selddlInvocation != undefined) {
        selddlInvocation.empty();
        selddlInvocation.append("<option value='0'>Select</option>");
        $.each(AnalyticIdStageArray, function (key, value) {
            selddlInvocation.append("<option value=" + value + " >" + value + "</option>");
        });
    }
    //$("#ddlAnalyticIdStageInvocationMetatData" + id).val(currval);
    $("#ddlAnalyticIdStageInvocationMetatData" + id).val("0");
}

function bindAnalyticIdStageArray(id) {
    var AnalyticIdStageArray = [];
    var analyticId = $("#txtAnalyticId").val();
    if (analyticId != "") {
        AnalyticIdStageArray.push(analyticId);
    }
    $("#attributes input[name=labellist]:checked").each(function (keys, value) {
        AnalyticIdStageArray.push($(this).val().replace("label", analyticId));
    });

    var currval = $("#ddlAnalyticIdStage" + id).val();
    var selddlAnalyticIdStage = $("#ddlAnalyticIdStage" + id);
    if (selddlAnalyticIdStage != undefined) {
        selddlAnalyticIdStage.empty();
        selddlAnalyticIdStage.append("<option value='0'>Select</option>");
        $.each(AnalyticIdStageArray, function (key, value) {
            selddlAnalyticIdStage.append("<option value=" + value + " >" + value + "</option>");
        });
    }
    // $("#ddlAnalyticIdStage" + id).val(currval);
    $("#ddlAnalyticIdStage" + id).val("0");
}

function OpenPopUp(id) {
    $('#attributesInvocation input:checkbox').removeAttr('checked');
    $('#invocationModal' + id).modal('show');
}

function disableSaveButton() {
    $("#btnSaveAnalyticIdConfiguration").attr('disabled', true);
    $("#btnSaveAnalyticIdConfiguration").addClass('disabledbtn');
}

function createArrtbGridNew(id) {

    $(dropDownCache["INVOCATION_ID"]).each(function (index, value) {
        var idfor = "ckbx" + value + id;
        var chkBox = "<label class=checkbox for= " + idfor + "  >    <input type=checkbox id=" + idfor + " name = invoactionlist   value = " + value + " >" + value + "</label> ";
        $("#attributesInvocation" + id).append(chkBox);
    });
}

function AddDivA() {
    IdA = IdA + 1;
    var languages;
    var html = '<div  class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><input type="checkbox" id="chkDeleteRiskMeasuresToApp' + IdA + '" /><span> Delete</span></h4></div>'
    html += '<div id = "div' + IdA + '" class="panel-body" style="overflow:auto;">'
    html += ' <div class="col-lg-12 col-sm-12 col-md-12 form-inline">'
    html += ' <div class="col-lg-3 col-sm-3 col-md-3"><label >Analytic_Id_To_Stage</label></div>'
    html += ' <div class="col-lg-3 col-sm-3 col-md-3"><select class="form-control analyticidstage" style ="width:160px" id="ddlAnalyticIdStage' + IdA + '"  ><option value ="0">Select</option></select></div>'
    html += ' <div class="col-lg-3 col-sm-3 col-md-3"><label >DataType</label></div>'
    html += ' <div class="col-lg-3 col-sm-3 col-md-3"><input type="text"  class="margin-right-20 form-control" placeholder="Data Type" id="txtDataType' + IdA + '"></div>'
    html += ' </div> <br /><br />'
    html += ' <div class="col-lg-12 col-sm-12 col-md-12 form-inline">'
    html += ' <div class="col-lg-3 col-sm-3 col-md-3"><label >Model_Srm_Diff_Threshold</label></div>'
    html += ' <div class="col-lg-3 col-sm-3 col-md-3"> <input class="form-control date-field" type="number" step="0.01" id="txtModelSumDiff' + IdA + '" type="text" value= "0.0001" /></div>'
    html += ' <div class="col-lg-3 col-sm-3 col-md-3"><label >Is_Applicable</label></div>'
    html += ' <div class="col-lg-3 col-sm-3 col-md-3"> <input type ="checkbox" id ="chkIsApplicable' + IdA + '" value="" /></div>'
    html += ' </div> <br /><br />'
    html += ' <div class="col-lg-12 col-sm-12 col-md-12 form-inline">'
    html += ' <div class="col-lg-3 col-sm-3 col-md-3"><label >App_Name</label></div>'
    html += ' <div class="col-lg-9 col-sm-9 col-md-9"><input type="text"  class="margin-right-20 form-control" placeholder="Main Table" style="width:615px;" id="txtMainTable' + IdA + '"><input type="hidden" id ="hdnMaintable' + IdA + '" /></div>'
    html += ' </div> <br /><br />'
    html += ' <div class="col-lg-12 col-sm-12 col-md-12 form-inline">'
    html += ' <div class="col-lg-3 col-sm-3 col-md-3"><label >App_Field</label></div>'
    html += ' <div class="col-lg-9 col-sm-9 col-md-9"><input type="text"  class="margin-right-20 form-control" placeholder="App Field" style="width:615px;" id="txtAppField' + IdA + '"></div>'
    html += ' </div> <br /><br />'
    html += ' <div class="col-lg-12 col-sm-12 col-md-12 form-inline">'
    html += ' <div class="col-lg-3 col-sm-3 col-md-3"><label >Live_Table</label></div>'
    html += ' <div class="col-lg-9 col-sm-9 col-md-9"><input type="text"  class="margin-right-20 form-control" placeholder="Live Table" style="width:615px;" id="txtLiveTable' + IdA + '"></div>'
    html += ' </div> <br /><br />'
    html += ' <div class="col-lg-12 col-sm-12 col-md-12 form-inline">'
    html += ' <div class="col-lg-3 col-sm-3 col-md-3"><label >Description</label></div>'
    html += ' <div class="col-lg-9 col-sm-9 col-md-9"><textarea class="form-control" style="width: 616px" id="txtDescription' + IdA + '"></textarea> </div>'
    html += ' </div> <br /><br />'
    html += ' </div></div>'
    $('#divA').append(html);
    bindAnalyticIdStageArray(IdA);
    populateMainTable(IdA);
}

function addInvocationMetadata() {
    IdInvocationMeatData = IdInvocationMeatData + 1;
    var html = '<div  class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><input type="checkbox" id="chkDeleteInvocationMetadata' + IdA + '" /><span> Delete</span></h4></div>'
    html += '<div id = "div' + IdInvocationMeatData + '" class="panel-body" style="overflow:auto;">'
    html += '<div class="col-lg-12 col-sm-12 col-md-12 form-inline">'
    html += ' <div class="col-lg-3 col-sm-3 col-md-3"><label for="txtPricedate">Analytic_Id</label></div>'
    html += ' <div class="col-lg-9 col-sm-9 col-md-9"><select class="form-control analyticidstage" style ="width:160px" id="ddlAnalyticIdStageInvocationMetatData' + IdInvocationMeatData + '"  ><option value ="0">Select</option></select></div> '
    html += '</div> <br /><br />'
    html += '<div class="col-lg-12 col-sm-12 col-md-12 form-inline">'
    html += ' <div class="col-lg-3 col-sm-3 col-md-3"><label for="txtPricedate">Invocation_Ids</label></div>'
    html += ' <div class="col-lg-9 col-sm-9 col-md-9"><textarea id="txtInvocation' + IdInvocationMeatData + '" onclick="OpenPopUp(' + IdInvocationMeatData + ');"  style= "width:616px" readonly="readonly"></textarea></div></div>'
    html += '</div>'
    html += '</div></div>'
    html += ' <div id="invocationModal' + IdInvocationMeatData + '" class="modal fade" role="dialog"> <div class="modal-dialog" style="width: 40%;"> '
    html += ' <div class="modal-content"><div class="modal-header"><button type="button" class="close" data-dismiss="modal">&times;</button> '
    html += ' <h3 class="modal-title">Invocation</h3> </div> <div class="modal-body"> <div class="form-group">  <input type="button" onclick ="CheckUncheckAll(' + IdInvocationMeatData + ')" class="check" id="btnCheckAll' + IdInvocationMeatData + '" value="check all" />'
    html += ' <div class="checkbox" id="attributesInvocation' + IdInvocationMeatData + '" style ="overflow:scroll; height:300px"> </div> '
    html += ' </div> </div> <div class="modal-footer"> <button type="button" class="btn btn-primary" data-dismiss="modal"> Close</button> </div> </div> </div> </div> '
    html += ' <script> '
    html += ' $(function(){  createArrtbGridNew(' + IdInvocationMeatData + ');   '
    // html += ' $("#btnCheckAll' + IdInvocationMeatData + '").toggle(function(){  $("attributesInvocation' + IdInvocationMeatData + ' input:checkbox").attr("checked","checked"); $(this).val("uncheck all"); },function(){ '
    // html += ' $("attributesInvocation' + IdInvocationMeatData + ' input:checkbox").removeAttr("checked");    $(this).val("check all"); });  '
    html += ' $("#attributesInvocation' + IdInvocationMeatData + ' input:checkbox").click(function () { var attrbSelected = $("#txtInvocation' + IdInvocationMeatData + '").val();  var val = $("label[for= "+this.id+"]").text().trim(); '
    html += ' if ($(this).is(":checked")) { if (attrbSelected == "") { attrbSelected += val; } else { attrbSelected += "," + val; } } '
    html += ' else { var pattern = new RegExp(",?" + val + "", "g");  attrbSelected = $("#txtInvocation' + IdInvocationMeatData + '").val().replace(pattern, ""); }  $("#txtInvocation' + IdInvocationMeatData + '").val(attrbSelected); }); '
    html += ' });</script>'
    $('#divInvocationMetaData').append(html);
    bindAnalyticIdStageInvArray(IdInvocationMeatData);
}
/*Check All*/
function CheckUncheckAll(id) {
    if ($("#btnCheckAll" + id).val() == "check all") {
        $('#attributesInvocation' + id + ' input:checkbox').prop('checked', true);

        $("#btnCheckAll" + id).val('uncheck all')
    } else {
        $('#attributesInvocation' + id + ' input:checkbox').prop('checked', false);
        $("#btnCheckAll" + id).val('check all');
    }

    var attrbSelected = $("#txtInvocation" + id).val();

    $("#attributesInvocation1 input:checkbox").each(function () {
        var val = $("label[for= " + this.id + "]").text().trim();
        if ($(this).is(":checked")) {
            if (attrbSelected == "") {
                attrbSelected += val;
            } else {
                attrbSelected += "," + val;
            }
        }
        else {
            var pattern = new RegExp(",?" + val + "", "g");
            attrbSelected = $("#txtInvocation" + id).val().replace(pattern, "");
        }
        if ($("#btnCheckAll" + id).val() == "check all") {
         
            $("#txtInvocation" + id).val("");
        }
        else {
            $("#txtInvocation" + id).val(attrbSelected);
        }
       

    });
}

/*This function to populate group Responsibilities*/
function populateMainTable(tabId) {
    populateAutoCompleteDropDown(tabId, dropDownCache["MAIN_TABLE"], "#txtMainTable" + tabId, "#txtAppField" + tabId, populateAppField);
    populateAutoCompleteDropDown(tabId, dropDownCache["DATA_TYPE"], "#txtDataType" + tabId, null, null);

}

/*This function to populate team Responsibilities*/
function populateAppField(tabId) {
    var appField = [];
    var liveTable = [];
    var mainTable = $("#txtMainTable" + tabId).val();
    //if ($("#txtMainTable" + tabId).val() != $("#hdnMaintable" + tabId).val()) {
    //    $("#hdnMaintable" + tabId).val($("#txtMainTable" + tabId).val());
    $(dropDownCache["APP_FIELD"]).each(function (keys, values) {
        if (values.key == mainTable) {
            appField.push(values.value);
        }
    });
    $(dropDownCache["LIVE_TABLE"]).each(function (keys, values) {
        if (values.key == mainTable) {
            liveTable.push(values.value);
        }
    });
    populateAutoCompleteDropDown(tabId, appField, "#txtAppField" + tabId, null, null);
    populateAutoCompleteDropDown(tabId, liveTable, "#txtLiveTable" + tabId, null, null);
    //}

}
function populateAutoCompleteDropDown(tabId, dataDict, field, childField, onSelectCallback) {
    if (childField != undefined) {
        $(childField).val('');
        $(childField).autocomplete({ source: [] });
    }

    $(field).val('');
    $(field).autocomplete({ source: [] });
    var autoCompleteArray = [{}];
    if (dataDict != undefined) {
        autoCompleteArray = dataDict;
        $(field).autocomplete({
            lookup: autoCompleteArray,
            minChars: 0,
            onSelect: function (suggestion) {
                if (suggestion.data != -1) {
                    if ($("#txtMainTable" + tabId).val() != $("#hdnMaintable" + tabId).val()) {
                        $("#hdnMaintable" + tabId).val($("#txtMainTable" + tabId).val());
                        if (onSelectCallback != undefined)
                            onSelectCallback(tabId);
                    }
                }
            }
        });
    }
}

function OpenAnalyticIdPopUp() {
    $('#divChangeAnalyticId').modal('show');
}

