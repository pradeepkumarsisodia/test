﻿"use strict";
var screenName = Cronus.Screens.CreditEntityAttributes;
var dtCreditEntity;
var dtAudit;
var dtCusipDetail;
var rowUpdateIndex = -1;
var columnMapping = {};
$(document).ready(function () {
    if (!Cronus.selectedPage(screenName, Cronus.Actions.CreditEntityAttributes_View)) {
        return;
    }

    //Permission Check
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.CreditEntityAttributes_Update, screenName) == false) {
        $("#btnUpdateCreditEntityAtttr").attr('disabled', true);
        $("#btnUpdateCreditEntityAtttr").addClass('disabledbtn');
    }

    $("#btnSearchAttributes").click(function () {
        SearchCreditEntityAttributes();
    });

    $("#btnUpdateCreditEntityAtttr").click(function () {
        updateCreditEntityAtttr();
    });
})

function SearchOnEnterKeyPress(e) {
    if (e.keyCode == 13) {
        $("#btnSearchAttributes").click();
    }
}

function PopulateModel(tableName, creditEntityId) {
    if (creditEntityId == undefined)
        return;
    var inputObj = { screenName: screenName, tableName: tableName, data: { creditEntityId: creditEntityId }
    };

    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            if (result.rows.length > 0) {
                if (result.tableName == "Audit") {
                    $('.bs-audit-modal-lg').modal('show');
                    dtAudit = Cronus.refreshDataTable(dtAudit, $("#dtSelectedIdAuditDetails"), result.columns, result.rows);
                }
                else if (result.tableName == "SsmIdDetail") {
                    $('.bs-SsmIdDetail-modal-lg').modal('show');
                    dtCusipDetail = Cronus.refreshDataTable(dtCusipDetail, $("#dtSsmIdDetail"), result.columns, result.rows);
                }
                else
                    swal("Error", "Wrong TableName " + tableName, "error");
            }
            else {
                swal("Info", "No data found", "success");
            }
        }
    });

}
function AuditCreditEntityAttributes(creditEntityId) {
    PopulateModel("Audit", creditEntityId);
}

function GetSsmIdDetail(creditEntityId) {
    PopulateModel("SsmIdDetail", creditEntityId);
}

function GetCreditEntityAttributeData() {
    var inputObj = { screenName: screenName, tableName: "CreditEntity",
        data: { creditEntityId: $("#txtCredit_entity_id_search").val(), reprCdsIssuerId: $("#txtREPRCDSIssuerID").val()
                , reprCdIsDeliverable: $("#ddlREPR_CD_IS_DELIVERABLE").val(), reprTicker: $("#txtReprTicker").val()
                , reprIssuerId: $("#txtRepr_issuer_id").val(), ultParentIssuerId: $("#txtUPI").val()
                , bloomCorpTicker: $("#txtCORP_TICKER").val(), ssmID: $("#txtSSM_ID").val()
        }
    };

    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            successlistTableData(result.columns, result.rows);
        }
    });

}

function successlistTableData(cols, rows) {
    var columns = cols.slice();
    columns.push('Edit');
    columns.push('Audit');
    var dataTableArray = [];
    for (var i = 0; i < rows.length; i++) {
        var datarow = [];
        // columns.length - 2 because 2 columns we will add dynamically for edit and audit
        for (var j = 0; j < cols.length; j++) {
            datarow.push(rows[i][j]);
        }

        datarow.push("<input type='button' class='btn btn-success dataTable' value='Edit' onclick=fetchMasterTableInfo(" + i + "); />");
        datarow.push("<input type='button' class='btn btn-success dataTable' value='Audit' onClick=AuditCreditEntityAttributes(" + rows[i][0] + "); />");
        dataTableArray.push(datarow);
    }

    dtCreditEntity = Cronus.refreshDataTable(dtCreditEntity, $("#dtcreditEntityAttr"), columns, dataTableArray, 2, [{ orderable: false, targets: -2 }, { orderable: false, targets: -1}]);

    $('#dtcreditEntityAttr tbody').on('dblclick', 'tr', function () {
        var table = $("#dtcreditEntityAttr").DataTable();
        var data = table.row(this).data();
        GetSsmIdDetail(data[0]);
    });

    //populate ColumnMapping map
    for (var j = 0; j < cols.length; j++) {
        columnMapping[cols[j].toLowerCase()] = j;
    }
}


function fetchMasterTableInfo(index) {
    $('.bs-class-modal-lg').modal('show');
    $("#modalTitleUpdate").html("Update Credit Entity Attributes");
    var data = dtCreditEntity.fnGetData(index);
    $.each(columnMapping, function (key, value) {
        if (value != undefined) {
            $("#txt" + key).val(data[columnMapping[key]]);
        }
    });
    rowUpdateIndex = index;
}


function SearchCreditEntityAttributes() {
    if (
        !Cronus.validateForSpecialChars($("#txtCredit_entity_id_search").val()) ||

        !Cronus.validateForSpecialChars($("#txtSSM_ID").val())) {
        return;
    }
    GetCreditEntityAttributeData();
}

function updateCreditEntityAtttr() {

    var inputObj = { screenName: screenName, data: { creditEntityId: $("#txtcredit_entity_id").val(), reprCdsIssuerId: $("#txtrepr_cds_issuer_id").val(), reprCdIsDeliverable: $("#txtrepr_cd_is_deliverable").val(), reprBondRecoveryRate: $("#txtrepr_bond_recovery_rate").val(), primaryCurrency: $("#txtprimary_currency").val(), countryOfExposure: $("#txtcountry_of_exposure").val(), isActive: $("#txtis_active").val()} };

    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, ".blockOverlay", false);
    if (retval.Error == false) {
        swal("Info", "Credit Entity Attributes updated successfully", "success");
        //SearchCreditEntityAttributes();
        //update the row
        if (rowUpdateIndex != -1) {
            $.each(columnMapping, function (key, value) {
                if (value != undefined) {
                    dtCreditEntity.fnUpdate($("#txt" + key).val(), rowUpdateIndex, value);
                }
            });
        }
        $(".close").click();
    }
}