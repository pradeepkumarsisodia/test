﻿"use strict";

var feserverProxy = null;

var jobDetails = ["job-id", "parent-job-id", "run-time", "working-dir", "log-dir", "input-dir", "output-file"];
var jobDetailsHeader = { "job-id": "Job Id", "parent-job-id": "Parent Job Id", "run-time": "Run Time", "working-dir": "Working Directory", "log-dir": "Log Directory", "input-dir": "Input Directory", "output-file": "Output File" };

var unprocessedHeaderDisplayName = {
    "yesterday-unprocesssed": "Yesterday Unprocessed Count",
    "today-unprocesssed": "Today Unprocessed Count"
};

var screenName = Cronus.Screens.ModelSummaryReport;

var dtInvocations;
var subscribedInvocations = {};
var subscribedAllInvocationIds = false;
var cycleDate = "";

$(document).on("ready", function () {
    if (!Cronus.selectedPage(screenName, Cronus.Actions.ModelSummaryReport_View)) {
        return;
    }

    feserverProxy = FeServer.createServerProxy("Cronus", $("#spnWindowsUsername").text().split("PIMCO")[1].replace('\\', ''));
    feserverProxy.addEventHandler(FeServer.Events.status, function (e) {
        console.log(e);
        onUpdateStatus(e.id, e.status);
    });

    Cronus.fetchAutoCompleteData(screenName, "INVOCATION_ID", Cronus.RestApi.FetchDropDownData, $('#txtInvocationId'), null);
    $("#txtInvocationId").keypress(function (e) {
        if (e.which == 13) {
            $("#btnRunModelSummaryReport").click();
            return false;
        }
    });

    Cronus.populateCycleDate($("#txtPricedate"));
    if (!Cronus.Compliance.isActionPermitted(Cronus.Actions.ModelSummaryReport_Run, screenName)) {
        $("#btnRunModelSummaryReport").attr('disabled', true);
        $("#btnRunModelSummaryReport").addClass('disabledbtn');
    }
    if (!Cronus.Compliance.isActionPermitted(Cronus.Actions.ModelSummaryReport_Save, screenName)) {
        $("#btnSusbcribeInvIds").attr('disabled', true);
        $("#btnSusbcribeInvIds").addClass('disabledbtn');
    }
    $('#btnRunModelSummaryReport').click(function () {
        if (Cronus.Compliance.isActionPermitted(Cronus.Actions.ModelSummaryReport_Run, screenName)) {
            $('#btnRunModelSummaryReport').button('loading');
            runModelSummaryReport();

        }
        else {
            swal("Oops", "You don't have permissions!!!", "error");
            $('#btnRunModelSummaryReport').button('reset');
        }
    });

    $('#btnSusbcribeInvIds').click(function () {
        if (Cronus.Compliance.isActionPermitted(Cronus.Actions.ModelSummaryReport_Save, screenName)) {
            $('.bs-subscriptionList-modal-lg').modal('show');
            isSusbcribeAllInvIds();
            getSusbcribeInvIds();
        } else {
            swal("Oops", "You don't have permissions!!!", "error");
        }

    });

    $('input:radio[name="subscribeRadio"]').change(
        function () {
            var rows = dtInvocations.fnGetNodes();
            if (this.checked && this.value === "Subscribe All") {
                for (var i = 0; i < rows.length; i++) {
                    $(rows[i]).find(".subsCheckbox").prop("checked", true);
                    $(rows[i]).find(".subsCheckbox").attr("checked", "checked");
                }
            }
            else if (this.checked && this.value === "UnSubscribe All") {
                for (var i = 0; i < rows.length; i++) {
                    $(rows[i]).find(".subsCheckbox").prop("checked", false);
                    $(rows[i]).find(".subsCheckbox").removeAttr("checked");
                }
            }
        });

    $("#dtSusbscibedInvocationIds").on("change", ".subsCheckbox", function (event) {
        if (this.checked) {
            $(this).attr("checked", "checked");
        } else {
            $(this).removeAttr("checked");
        }
        $('input:radio[name="subscribeRadio"][value="None"]').prop('checked', true);

    });

    $('#btnSavePrefrences').click(function () {
        subscribeInvIds();
    });
    $('#lnkFeSeverAuditor').click(function () {
        window.open(feserverProxy.absolute());
    });
});

function render(table, values) {
    console.log(table, values);
    var html = "";
    for (var key in values) {
        var displayName = key.replace(/-/g, ' ').toLowerCase().replace(/\b[a-z]/g, function (letter) {
            return letter.toUpperCase();
        });
        html += '<tr><td width="30%">' + displayName + '</td><td style="word-break: break-all" width="70%">' + values[key] + '</td></tr>';
    }
    if (html === "") {
        html += '<tr><td> No data found</td></tr>';
    }

    table.html(html);
}

function renderJobDetails(table, values) {
    var html = "";
    for (var key in jobDetails) {
        if (!Cronus.isNotEmptyNullOrUndefined(jobDetailsHeader[jobDetails[key]])) {
            jobDetailsHeader[jobDetails[key]] = jobDetails[key];
        }

        if (Cronus.isNotEmptyNullOrUndefined(values[jobDetails[key]])) {
            html += '<tr><td width="30%">' + jobDetailsHeader[jobDetails[key]] + '</td><td style="word-break: break-all" width="70%">' + values[jobDetails[key]] + '</td></tr>';
        }
        else {
            html += '<tr><td style="word-break: break-all" width="30%">' + jobDetailsHeader[jobDetails[key]] + '</td><td style="word-break: break-all" width="70%"> </td></tr>';
        }
    }
    table.html(html);
}

function renderUnprocessed(table, values) {
    var html = "";
    for (var key in values) {
        console.log(key, unprocessedHeaderDisplayName);
        html += '<tr><td width="30%">'
             + unprocessedHeaderDisplayName[key] + '</td><td width="70%" style="word-break: break-all">' + values[key] + '</td></tr>';
    }
    table.html(html);
}

function renderInputOutput(table, values, values2) {
    console.log(table, values);
    var classificationcolor = values['today-classification-color'] == undefined ? '' : values['today-classification-color'];
    var inputcolor = values['today-input-color'] == undefined ? '' : values['today-input-color'];
    var outputcolor = values['today-output-color'] == undefined ? '' : values['today-output-color'];
    var modelrejectioncolor = values['today-model-rejection-color'] == undefined ? '' : values['today-model-rejection-color'];

    var todaybadrecord = values2['today-unprocesssed'] == undefined ? '' : values2['today-unprocesssed'];
    var yestedaybadrecord = values2['yesterday-unprocesssed'] == undefined ? '' : values2['yesterday-unprocesssed'];

    var html = '<tr><td width="40%">' + '</td><td width="30%"> <b>Yesterday Count</b> </td> <td width="30%"> <b>Today Count</b> </td></tr>';
    html += '<tr><td width="40%">Classification</td><td width="30%"> ' + values['yesterday-classification'] + ' </td> <td width="30%" bgcolor = "' + classificationcolor + '"> ' + values['today-classification'] + ' </td></tr>';
    html += '<tr><td width="40%">Model Input</td><td width="30%"> ' + values['yesterday-input'] + ' </td> <td width="30%" bgcolor = "' + inputcolor + '"> ' + values['today-input'] + ' </td></tr>';
    html += '<tr><td width="40%">Model Output</td><td width="30%"> ' + values['yesterday-output'] + ' </td> <td width="30%" bgcolor = "' + outputcolor + '"> ' + values['today-output'] + ' </td></tr>';
    html += '<tr><td width="40%">Bad records</td><td width="30%"> ' + yestedaybadrecord + ' </td> <td width="30%"> ' + todaybadrecord + ' </td></tr>';
    html += '<tr><td width="40%">Rejection (Model)</td><td width="30%"> ' + values['yesterday-model-rejection'] + ' </td> <td width="30%" bgcolor = "' + modelrejectioncolor + '"> ' + values['today-model-rejection'] + ' </td></tr>';
    html += '<tr><td width="40%">Live analytic_id count</td><td width="30%"> ' + values['yesterday-live-analytic_id-count'] + ' </td> <td width="30%"> ' + values['today-live-analytic_id-count'] + ' </td></tr>';
    html += '<tr><td width="40%">Rejection (SRM)</td><td width="30%"> ' + values['yesterday-srm-rejection'] + ' </td> <td width="30%"> ' + values['today-srm-rejection'] + ' </td></tr>';
    table.html(html);
}

function display(data) {
    $('#reportView').removeClass("hidden");
    $('#subscriptionView').addClass("hidden");
    renderInputOutput($('#ioComparison'), data['input'], data['unprocessed']);
    renderJobDetails($('#jobDetails'), data['job']);
    var values = data['new-security'];
    if (values) {
        var html = "<tr>";
        var headers = values['header'];
        for (var i = 0; i < headers.length; ++i) {
            var displayName = headers[i].replace(/_/g, ' ').toLowerCase().replace(/\b[a-z]/g, function (letter) {
                return letter.toUpperCase();
            });
            html += "<th>" + displayName + "</th>";
        }
        html += "</tr>";
        var rows = values['rows'];
        for (var i = 0; i < rows.length; ++i) {
            html += "<tr>";
            for (var j = 0; j < rows[i].length; ++j)
                html += "<td>" + rows[i][j] + "</td>";
            html += "</tr>";
        }
        $('#new_unprocessed_security').html(html);
    }
    else {
        $('#new_unprocessed_security').html('<tr><td> No new security unprocessed by the model</td></tr>');
    }

    var values = data['rejection'];
    if (values) {
        var html = "<tr>";
        var headers = values['header'];
        for (var i = 0; i < headers.length; ++i) {
            var displayName = headers[i].replace(/_/g, ' ').toLowerCase().replace(/\b[a-z]/g, function (letter) {
                return letter.toUpperCase();
            });
            html += "<th>" + displayName + "</th>";
        }
        html += "</tr>";
        var rows = values['rows'];
        for (var i = 0; i < rows.length; ++i) {
            html += "<tr>";
            for (var j = 0; j < rows[i].length; ++j)
                html += "<td>" + rows[i][j] + "</td>";
            html += "</tr>";
        }
        $('#rejection').html(html);
    }
    else {
        $('#rejection').html('<tr><td> No Rejections to Report</td></tr>');
    }
    //$(".blockOverlay").css("display", "none");
}

var reportView = null;
var reportViewHtml = null;

function onUpdateStatus(requestId, status) {
    console.log(requestId, status);
    //$(".blockOverlay").css("display", "block");
    if (reportView == null) {
        reportView = $('#reportView');
        reportViewHtml = reportView.html();
        reportView.removeClass("hidden");
    }

    if (status == 'OK') {
        reportView.html(reportViewHtml);
        showResult(requestId);
    }

    else if (status == 'FAILED') {

        reportView.html('<a href ="javascript:void(0);" onclick="showLog(\'' + requestId + '\'); return false;" style ="color:red;">' + status + '</a>');

        reportView.css("text-decoration", "underline");
        // reportView.css("color", "red");
    }
    else {
        var color = (status == 'FAILED') ? "#ff0000" : "#000000";
        reportView.html('<span style="color:' + color + '">' + status + '</span>');
        reportView.css("text-decoration", "");
    }

    if (status === 'OK' || status === 'FAILED') {

        $('#btnRunModelSummaryReport').button('reset');
    }
    // $(".blockOverlay").css("display", "none");

}


function showResult(requestId) {

    feserverProxy.submitQuery(FeServer.Tasks.RESULT, { id: requestId }, function (response) {
        console.log(response);
        display(response["results"]['data']);
    }, null);
}
function showLog(requestId) {
    $('#divLog').empty();
    var params = {
        id: requestId
    };
    feserverProxy.submitQuery(FeServer.Tasks.LOG, params, function (response) {

        for (var property in response.results.logs) {
            if (response.results.logs[property] != '') {
                var color = '';
                if (response.results.logs[property].toLowerCase().indexOf("error") >= 0 || response.results.logs[property].toLowerCase().indexOf("failed") >= 0)
                    color = 'style = "color:red;"';

                var Id = property.replace(new RegExp("\\.", "ig"), '');
                var html = '<div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><u>'
                html += '<a data-toggle="collapse" href="#' + Id + '" ' + color + '>' + property + '</a></u></h4>'
                html += '</div><div id="' + Id + '" class="panel-collapse collapse">'
                html += '<div class="panel-body" style="overflow:auto;">'
                html += response.results.logs[property].replace(new RegExp('\n', "g"), '</br>')
                    .replace(new RegExp("FAILED", "ig"), "<b style=color:red> FAILED </b> ")
                    .replace(new RegExp("Error", "ig"), "<b> ERROR </b> ")
                    + " </Br> </Br>";
                html += '</div></div></div>'
                $('#divLog').append(html);
            }
        }
        $("#divLog").removeClass('hidden');
    });
}

function runModelSummaryReport() {
    $("#divLog").addClass('hidden');
    var priceDate = $("#txtPricedate").val();
    if (!Cronus.isNotEmptyNullOrUndefined(priceDate)) {
        swal("Error", "Please pass price date", "error");
        $('#btnRunModelSummaryReport').button('reset');
        return;
    }

    var invocationId = $("#txtInvocationId").val();
    if (!Cronus.isNotEmptyNullOrUndefined(invocationId)) {
        $("#txtInvocationId").focus();
        swal("Error", "Please pass invocation id", "error");
        $('#btnRunModelSummaryReport').button('reset');
        return;
    }

    var params = {
        "cmd_options": {
            "invocation-id": invocationId,
            "price-date": priceDate,
            "mail-id": $("#spnWindowsUsername").html().split('\\')[1]
        },
        "cmd_flags": ["post-results"]
    };

    console.log(params);

    feserverProxy.submitAction(FeServer.Tasks.MODEL_SUMMARY, params, function (id) {
        console.log("submitted: ", id);
        onUpdateStatus(id, 'SUBMITTED');
    }, null);


    if ($('#chkSubscribeCurr').is(':checked')) {
        var invSubs = { InvocationId: invocationId, IsSubscribe: "Y" };
        savePreferences(invSubs);
    }

}

function showFromCalender() {
    $("#txtPricedate").focus();
    return false;
}

function isSusbcribeAllInvIds() {
    var inputObj = { screenName: screenName, tableName: "ALL" };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            subscribedAllInvocationIds = false;
            $('input:radio[name="subscribeRadio"][value="None"]').prop('checked', true);
            for (var i = 0; i < result.rows.length; i++) {
                if (result.rows[i][0] > 0) {
                    subscribedAllInvocationIds = true;
                    $('input:radio[name="subscribeRadio"][value="Subscribe All"]').prop('checked', true);
                }
            }
        }
    });
};

function getSusbcribeInvIds() {
    var inputObj = { screenName: screenName, tableName: "SUBSCRIBE" };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", true);
    subscribedInvocations = {};
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            var dataTableArray = [];
            var datarow;
            for (var i = 0; i < result.rows.length; i++) {
                datarow = [];
                datarow.push(result.rows[i][0]);
                if (result.rows[i][1] == "Y") {
                    datarow.push("<input type='checkbox' class='subsCheckbox' checked='checked' />");
                    subscribedInvocations[result.rows[i][0]] = 1;
                }
                else {
                    datarow.push("<input type='checkbox' class='subsCheckbox' />");
                }
                dataTableArray.push(datarow);
            }
            $('#subscriptionView').removeClass("hidden");
            $('#reportView').addClass("hidden");
            dtInvocations = Cronus.refreshDataTable(dtInvocations, $("#dtSusbscibedInvocationIds"), result.columns, dataTableArray);
        }
    });
};

function subscribeInvIds() {
    var selecteradiodButtonVal = $('input:radio[name="subscribeRadio"]:checked').val();
    if (selecteradiodButtonVal === "Subscribe All") {
        savePreferences([{ InvocationId: "ALL", IsSubscribe: "Y"}]);
        return;
    }
    else if (selecteradiodButtonVal === "UnSubscribe All") {
        savePreferences([{ InvocationId: "ALL", IsSubscribe: "N"}]);
        return;
    }
    else {
        var invSubscriptionArray = [];
        var rows = dtInvocations.fnGetNodes();
        var allChecked = true;
        if (subscribedAllInvocationIds)
            invSubscriptionArray.push({ InvocationId: "ALL", IsSubscribe: "N" });
        for (var i = 0; i < rows.length; i++) {
            var invId = $(rows[i]).find("td:eq(0)").html();
            var checkBoxRow = $(rows[i]).find("td:eq(1)").html();
            var isLoad = $(checkBoxRow).is(":checked");
            if (subscribedAllInvocationIds || (subscribedInvocations[invId] != undefined && !isLoad) || (subscribedInvocations[invId] == undefined && isLoad)) {
                var invSubs = { InvocationId: invId, IsSubscribe: isLoad ? "Y" : "N" };
                invSubscriptionArray.push(invSubs);
                if (!isLoad)
                    allChecked = false;
            }
        }
        if (!subscribedAllInvocationIds || (subscribedAllInvocationIds && !allChecked))
            savePreferences(invSubscriptionArray);
    }
};


function savePreferences(invSubscriptionArray) {
    var inputObj = { screenName: screenName, data: { SubscriptionList: invSubscriptionArray} };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            swal("Info", "Subscription successfully updated", "success");
            getSusbcribeInvIds();
            isSusbcribeAllInvIds();
        }
    });
};