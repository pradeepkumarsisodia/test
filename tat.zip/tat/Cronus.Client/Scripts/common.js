﻿var serviceUrl = "http://localhost:8180/";
// to put in cronus.constants
var url = document.location.host;
var href = document.location.href;
serviceUrl = document.location.href;
//first check if the href has Home keyword
var pos = href.indexOf("Home");
if (pos > 0)
    serviceUrl = document.location.href.substring(0, pos);
serviceUrl = serviceUrl.match(/\/$/) == null ? serviceUrl + "/" : serviceUrl;


$(document).click(function (e) {
    var container = $("#dvlogin");
    var target = $("#dvprofile");
    if ((!target.is(e.target)
        && target.has(e.target).length === 0) && (!container.is(e.target)
        && container.has(e.target).length === 0)) {
        target.removeClass('show');;
        target.addClass('hide');
    }
});

$(document).ready(function () {
    Cronus.populateEnvironmentDropDownCommon();
    var environment = Cronus.getParameterByName("env");
    if (environment != null) {
        $("#ddlCommanEnviroment").val(environment);
        $("#lblCurrEnvCommon").html("Current Environment is " + environment);
        $("#lblCurrEnvCommon").css("color", Cronus.commonEnvColor[environment]);
    }
    else {
        var environment = $("#ddlCommanEnviroment").val();
        $("#lblCurrEnvCommon").html("Current Environment is " + environment);
        $("#lblCurrEnvCommon").css("color", Cronus.commonEnvColor[environment]);
    }
    Cronus.Compliance.getUIPermission();
    var bodyheight = $(window).height();
    var bodywidth = $(window).width();
    $("#dvbody").height(bodyheight - 80);
    $("#dvbody").width(bodywidth - 190);
    $("#dvtabheader").height(bodyheight - 60);
    $("#ulMenu li").click(function () {
        window.location = $(this).find("a").first().attr("href");
        return false;
    });
    Cronus.checkUserExistenceCookie();
});

$(window).resize(function () {
    var bodyheight = $(window).height();
    var bodywidth = $(window).width();
    //$("#dvbody").height(bodyheight - 130);
    $("#dvbody").height(bodyheight - 80);
    $("#dvbody").width(bodywidth - 190);
    $("#dvtabheader").height(bodyheight - 60);
});

if (typeof String.prototype.trim != 'function') { // detect native implementation of trim
    String.prototype.trim = function () {
        return this.replace(/^\s+/, '').replace(/\s+$/, '');
    };
}
if (typeof String.prototype.startsWith != 'function') { // detect native implementation of startswith
    // see below for better implementation!
    String.prototype.startsWith = function (str) {
        return this.indexOf(str) == 0;
    };
}

