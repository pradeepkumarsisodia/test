﻿"use strict";
var screenName = Cronus.Screens.SubstituteCusips;
var handsonExcel;
var dtCusip;

$(document).ready(function () {
    if (!Cronus.selectedPage(screenName, Cronus.Actions.SubstituteCusips_View)) {
        return;
    }

    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.SubstituteCusips_Search, screenName) == false) {
        $("#btnCusipSearch").attr('disabled', true);
        $("#btnCusipSearch").addClass('disabledbtn');
    }
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.SubstituteCusips_Save, screenName) == false) {
        $("#btnSaveSubstCusipBulk").attr('disabled', true);
        $("#btnSaveSubstCusipBulk").addClass('disabledbtn');
    }
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.SubstituteCusips_ShowAll, screenName) == false) {
        $("#chkShowAll").attr('disabled', true);
    }
    $("#btnClearScen").click(function () {
        var sampleData = [["", ""]];
        handsonExcel.loadData(sampleData);
        handsonExcel.render();
         $("#txtNote").val('');
         $("#txtMailRcpnts").val('');
    });
    $("#dvHandsonTable").html("");
    var data = [
    ["", ""]
      ];

    var container = document.getElementById('dvHandsonTable');
    var setting = {
        data: data,
        startRows: 1,
        startCols: 2,
        minSpareCols: 0,
        minSpareRows: 5,
        height: 200,        
        colHeaders: ["Old Cusip*", "New Cusip*"],
        stretchH : "all",       
        currentRowClassName: "currentRow",
        currentColClassName: "currentCol",
        contextMenu: ['row_above', 'row_below', 'remove_row', 'undo', 'redo'],
        maxCols: 2,
    };
    var handsonTable = new Handsontable(container, setting);
    handsonExcel = handsonTable;

    $("#prodEmails").val('');
    var url = document.location.host;
    if (url == "cronus") {
        $("#prodEmails").val('Default Emails: AssetSetup@pimco.com');
    }
    else {
        $("#prodEmails").val('Default Emails: AssetSetup@pimco.com');
    }

    $("#btnSaveSubstCusipBulk").click(function () {
       substitudeCusipBulk(handsonTable);
    });



    $("#btnCusipSearch").click(function () {
        if (Cronus.Compliance.isActionPermitted(Cronus.Actions.SubstituteCusips_Search, screenName)) {
            $("#chkShowAll").prop('checked', false);
            ListCusipsFromDbByQuery();
        }
    });

    $("#txtCusip").keypress(function (e) {
        if (e.which == 13) {
            $("#btnCusipSearch").click();
             return false;
        }
    });

    $("#chkShowAll").click(function () {
        $("#txtCusip").val('');
        if ($("#chkShowAll").is(':checked')) {
            ListAllCusipsFromDB();
        }
        else {
            Cronus.destroyDataTable(dtCusip, "#dtCusipResults");
        }
    });
});

function substitudeCusipBulk(handsonTable) {
    var oldCusipNewCusipArray = [];

    var note = $("#txtNote").val().trim();
    var mailRcpnts = $("#txtMailRcpnts").val();


    var errorfound = false;
    var rowscount = 0;
     var data = handsonExcel.getData();

    for (var j = 0; j < data.length; j++) {
        var oldcusip = data[j][0];
        var newcusip = data[j][1];
        // If both are null thjen continue in the loop
        if (errorfound || (!Cronus.isNotEmptyNullOrUndefined(oldcusip) && (!Cronus.isNotEmptyNullOrUndefined(newcusip))))
            continue;
        errorfound = false;
        rowscount++;
        $("#trheaderCusipUpdate").html('');
        if (!Cronus.isNotEmptyNullOrUndefined(oldcusip)) {
            swal("Error", "Please pass old cusip at row " + rowscount, "error");
            errorfound = true;
        }
        else if (!Cronus.validateCusipList(oldcusip, 9)) {
            errorfound = true;
        }
        if (!Cronus.isNotEmptyNullOrUndefined(newcusip)) {
            swal("Error", "Please pass new cusip at row " + rowscount, "error");
            errorfound = true;
        }
        else if (!Cronus.validateCusipList(newcusip, 9)) {
            errorfound = true;
        }
        else {
            oldCusipNewCusipArray.push({ OldCusip: oldcusip, NewCusip: newcusip, Note :note, MailRecipients:mailRcpnts});
        }
    }

    if (rowscount == 0 && !errorfound && oldCusipNewCusipArray.length == 0) {
        swal("Error", "Please pass old cusip at row 1", "error");
        errorfound = true;
    }
    else if (!errorfound && (note == "" || note == null)) {
        swal("Error", "Please pass note", "error");
        $("#txtNote").focus();
        errorfound = true;
    }
    else if(!errorfound){
        var inputObj = { screenName: screenName, data: oldCusipNewCusipArray };

        var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, null, true,"#btnSaveSubstCusipBulk");
        $.when(retval.AjaxObj).done(function () {
            var result = retval.AjaxObj.responseJSON;
            if (result.errorMessage == null || result.errorMessage == "") {
                swal("Info", result.message, "success");
                $("#txtNote").val('');
                $("#txtMailRcpnts").val('');
                handsonTable.loadData([["", ""]]);
            }
        });
    }
}

function ListAllCusipsFromDB() {
    GetCusipList("");
}

function ListCusipsFromDbByQuery() {
    var cusipList = $("#txtCusip").val();
    if (cusipList == "" || cusipList == null) {
        swal("Error", "Please pass list of cusips saperated by comma [,]", "error");
        $("#txtCusip").focus();
    }
    else if (Cronus.validateCusipList(cusipList, 9)) {
        GetCusipList(cusipList);
    }  
}

function GetCusipList(cusipList) {
    var inputObj = { screenName: screenName, data: { cusips: cusipList } };

    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable,null, true,"#btnCusipSearch");
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
        dtCusip = Cronus.refreshDataTable(dtCusip, $("#dtCusipResults"), result.columns, result.rows);
        }
    });
}
