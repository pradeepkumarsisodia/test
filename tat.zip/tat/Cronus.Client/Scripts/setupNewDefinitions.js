﻿"use strict";
var screenName = Cronus.Screens.TSDefinition;
var chkBoxFields = ['PREFIX', 'CLASS', 'SUBCLASS', 'FREQUENCY_ID', 'STRKEY1', 'STRKEY2', 'STRKEY3', 'STRKEY4', 'STRKEY5', 'NUMKEY1', 'NUMKEY2', 'NUMKEY3', 'NUMKEY4', 'NUMKEY5', 'SUFFIX'];
var csvHeaders = ['PREFIX', 'SID', 'FREQUENCY_ID', 'DESCRIPTION', 'PARENT_ID', 'STRKEY1', 'STRKEY2', 'STRKEY3', 'STRKEY4', 'STRKEY5', 'NUMKEY1', 'NUMKEY2', 'NUMKEY3', 'NUMKEY4', 'NUMKEY5', 'SUFFIX'];
var tableHeaders = ['GROUP_ID', 'SID', 'DESCRIPTION', 'FREQUENCY_ID', 'PARENT_ID', 'STRKEY1', 'STRKEY2', 'STRKEY3', 'STRKEY4', 'STRKEY5', 'NUMKEY1', 'NUMKEY2', 'NUMKEY3', 'NUMKEY4', 'NUMKEY5'];
var numKeysMap = { NUMKEY1: false, NUMKEY2: false, NUMKEY3: false, NUMKEY4: false, NUMKEY5: false };
var frequecyMap = {};
var dtTSDef;
// create an output array of map. This will be sent to server
var outputArray = [];
var lines = [];
var groupclassid = "";
var headers;

$(document).on("ready", function () {
    if (!Cronus.selectedPage(screenName, Cronus.Actions.TSDefinition_View)) {
        return;
    }

    //Permission Check
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.TSDefinition_Submit, screenName) == false) {
        $("#btnSubmitTSDef").attr('disabled', true);
        $("#btnSubmitTSDef").addClass('disabledbtn');
    }

    fetchGroup(screenName, "GroupId", Cronus.RestApi.FetchDropDownData, $('#txtGrpClassId'), $("#hdnGrpClassId"));

    FetchFrequencyMapping();
    $('#btnReset').click(function () {
        resetScreen();
    });

    //Trigger the modal on click of text box
    $('#txtDescriptionDefRdOnly').click(function () {
        $('#descModal').modal('show');
    });

    $('#descModal').on('hidden.bs.modal', function () {
        $('#txtDescriptionDefRdOnly').val($('#txtDescriptionDef').val());
        $(".blockOverlay").css('display', 'block');
        RefreshTable();
        $(".blockOverlay").css('display', 'none');
    });
    $('#btnSubmitTSDef').click(function () {
        if ($('#txtGrpClassId').val() == undefined || $('#txtGrpClassId').val() == "" || $('#txtGrpClassId').val() == null) {
            clearFileBrower();
            $('#txtGrpClassId').focus();
            swal("Error", "groupId-class-subCLass are madatory", "error");
            return;
        }
        submitDefintionData();
    });

    createArrtbGrid();

    $("#attributes input:checkbox").click(function () {
        var attrbSelected = $('#txtDescriptionDef').val();
        var val = $("label[for='" + this.id + "']").text().trim();
        if ($(this).is(':checked')) {
            if (attrbSelected == "")
                attrbSelected += '<' + val + '>';
            else {
                attrbSelected += '_<' + val + '>';
            }
        }
        else {
            var pattern = new RegExp('_?<' + val + '>', 'g');
            attrbSelected = $('#txtDescriptionDef').val().replace(pattern, "");
        }
        $('#txtDescriptionDef').val(attrbSelected);
    });
    dtTSDef = Cronus.refreshDataTable(dtTSDef, $("#dtTSDef"), tableHeaders, []);
    $(".blockOverlay").css('display', 'none');
});

function fetchGroup(screenName, fieldName, restAPI, textElement, hiddenELement) {
    var inputObj = new Object();
    inputObj.screenName = screenName;
    inputObj.fieldName = fieldName;
    inputObj.runEnviroment = $("#ddlCommanEnviroment").val();

    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: serviceUrl + "api/restapi/" + restAPI,
        data: JSON.stringify(inputObj),
        async: false,
        timeout: 1000,
        dataType: "json",
        success: function (result) {
            $(textElement).autocomplete({
                lookup: result.dropDownData,
                minChars: 0,
                onSelect: function (suggestion) {
                    if (suggestion.data != -1) {
                        $(hiddenELement).val(suggestion.data);
                        if (groupclassid != suggestion.data) {
                            RefreshTable();
                            DisableEnableNumkeys();
                            groupclassid = suggestion.data;
                        }
                    }
                }
            });
        }
    });
}

function DisableEnableNumkeys() {
    var grpIdClassSubclass = $('#txtGrpClassId').val();
    var groupId = "";
    var className = "";
    var subClass = "";
    if (grpIdClassSubclass.length > 0) {
        var grpIdClassSubclassArr = grpIdClassSubclass.split('-');
        if (grpIdClassSubclassArr.length < 3)
            return;
        groupId = grpIdClassSubclassArr[0].trim();
        className = grpIdClassSubclassArr[1].trim();
        subClass = grpIdClassSubclassArr[2].trim();
    }
    if (subClass.toUpperCase() == "LEVELS") {
        $.each(numKeysMap, function (index, item) {
            $("#" + index).attr("checked", false);
            $("#" + index).attr("disabled", true);
            numKeysMap[index] = false;
        });
    }
    else {
        $.each(numKeysMap, function (index, item) {
            $("#" + index).attr("disabled", false);
        });
    }
}

function checkNumkeys(el) {
    numKeysMap[el.id] = $(el).is(':checked');
}

function createArrtbGrid() {
    for (var i = 0; i < chkBoxFields.length; i++) {
        //  console.log(data[i]);
        var chkBox = '<label class="checkbox" for="ckbx' + chkBoxFields[i] + '">' +
            '<input type="checkbox" id="ckbx' + chkBoxFields[i] + '">' + chkBoxFields[i] +
            '</label>';
        $('#attributes').append(chkBox);
    }
}

function readDefinitionsFile(input) {
    if ($('#txtGrpClassId').val() == undefined || $('#txtGrpClassId').val() == "" || $('#txtGrpClassId').val() == null) {
        // Clear file browse as well.
        swal("Error", "groupId-class-subCLass are madatory", "error");
        clearFileBrower();
        return;
    }

    $("#txtFileName").text(input.files[0].name);
    if (input.files && input.files[0]) {
        var reader = new window.FileReader();
        $(".blockOverlay").css('display', 'block');
        reader.onload = function (e) {
            try {
                loadFile(e.target.result, ",");
            } catch (err) {
                $(".blockOverlay").css('display', 'none');
                // Clear file browser
                clearFileBrower();
                swal("Error", err, "error");
            }
        };
        reader.readAsText(input.files[0]);
    }
    input = $("#tsDefFile");
    input.replaceWith(input.val('').clone(true));
}

function clearFileBrower() {
    $("#txtFileName").text("");
    var input = $("#tsDefFile");
    input.replaceWith(input.val('').clone(true));
    lines = [];
    outputArray = [];
    dtTSDef.fnClearTable();
    $(".blockOverlay").css('display', 'none');
}

function loadFile(text, seperator) {
    lines = text.split(/[\r\n]+/g); // tolerate both Windows and Unix linebreaks
    headers = lines[0].toUpperCase().split(seperator);

    // check first line has predefined number of columns
    if (headers.length != csvHeaders.length) {
        $(".blockOverlay").css('display', 'none');
        throw ("Some headers are missing in file. Please pass proper file!!!");
    }

    // check if file contains all specified headers
    $.each(csvHeaders, function (index, item) {
        if (headers.indexOf(item) == -1) {
            throw (item + " is not there in headers. Please pass proper file!!!");
        }
    });

    // check if file contains all specified headers
    $.each(headers, function (index, item) {
        if (csvHeaders.indexOf(item) == -1) {
            throw (item + " is extra in headers. Please pass proper file!!!");
        }
    });
    RefreshTable();
}

function RefreshTable() {
    var grpIdClassSubclass = $('#txtGrpClassId').val();
    var groupId = "";
    var className = "";
    var subClass = "";
    if (grpIdClassSubclass.length > 0) {
        var grpIdClassSubclassArr = grpIdClassSubclass.split('-');
        if (grpIdClassSubclassArr.length < 3)
            return;
        groupId = grpIdClassSubclassArr[0].trim();
        className = grpIdClassSubclassArr[1].trim();
        subClass = grpIdClassSubclassArr[2].trim();
    }

    var dataTableArray = [];
    outputArray = [];
    for (var i = 1; i < lines.length; i++) {
        var line = lines[i];
        if (line == "" || line == undefined || line == null)
            continue;
        if (line.match(/^#/))
            continue;

        var data = line.split(',');
        if (data.length == headers.length) {
            var fileDataMap = {};

            for (var j = 0; j < headers.length; j++) {
                var header = headers[j];
                fileDataMap[header] = data[j];
            }

            fileDataMap["GROUP_ID"] = groupId;
            // Populate Description.
            if (fileDataMap["DESCRIPTION"] == "") {
                fileDataMap["DESCRIPTION"] = getDecription(fileDataMap, className, subClass);
            }

            //create data row
            var datarow = [];
            for (var index = 0; index < tableHeaders.length; index++) {
                datarow.push(fileDataMap[tableHeaders[index]]);
            }
            dataTableArray.push(datarow);
            outputArray.push(fileDataMap);
        }
    }
    dtTSDef.fnClearTable();
    if (dataTableArray.length > 0)
        dtTSDef.fnAddData(dataTableArray);
    $(".blockOverlay").css('display', 'none');
}

function getDecription(map, className, subClass) {
    var descTemplate = $('#txtDescriptionDef').val();
    if (descTemplate == null || descTemplate == undefined || descTemplate == "") {
        return "";
    }
    var descriptionGenerated = descTemplate;
    $.each(map, function (key, value) {
        if (key == "FREQUENCY_ID") {
            if (frequecyMap[map[key]] == undefined) {
                frequecyMap[map[key]] = "";
            }
            descriptionGenerated = descriptionGenerated.replace(new RegExp('<' + key + '>', 'g'), frequecyMap[map[key]]);
        }
        else {
            descriptionGenerated = descriptionGenerated.replace(new RegExp('<' + key + '>', 'g'), map[key]);
        }
    });

    descriptionGenerated = descriptionGenerated.replace(new RegExp('<CLASS>', 'g'), className);
    descriptionGenerated = descriptionGenerated.replace(new RegExp('<SUBCLASS>', 'g'), subClass);

    descriptionGenerated = descriptionGenerated.replace(/</g, "");
    descriptionGenerated = descriptionGenerated.replace(/>/g, "");
    return descriptionGenerated;
}


function clearGrpClassIdTextbox() {
    $("#hdnGrpClassId").val('');
}

function checkValue(el, type) {
    if (type == 'group' && $("#hdnGrpClassId").val() == "") {
        $(el).val('');
    }
}

function populateCheckBoxGrid(el, type) {
    if (type == 'group' && $("#hdnGrpClassId").val() == "") {
        $(el).val('');
    }
}
function UncheckAll() {
    $('input[type=checkbox]').each(function () {
        $(this).prop('checked', false);
    });
}

function resetScreen() {
    UncheckAll();
    $('#txtGrpClassId').val("");
    $('#txtDescriptionDefRdOnly').val("");
    $('#txtDescriptionDef').val("");
    clearFileBrower();
}


function FetchFrequencyMapping() {
    var inputObj = { screenName: screenName };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            for (var i = 0; i < result.rows.length; i++) {
                frequecyMap[result.rows[i][0]] = result.rows[i][1];
            }
        }
    });
}

function submitDefintionData() {

    if (outputArray.length == 0) {
        swal("There is no data to submit !!", "", "error");
        return;
    }
    //check if all the numkeys colum which are checked populated in data
    var numKeyChecked = false;

    $.each(numKeysMap, function (key, value) {
        if (value == true) {
            numKeyChecked = true;
        }
    });
    try {
        if (numKeyChecked == true) {
            for (var i = 0; i < outputArray.length; i++) {
                $.each(numKeysMap, function (key, value) {
                    if (outputArray[i][key] == "" && value == true) {
                        throw (key + " is checked but null at row: " + (i + 1));
                    }
                });
            }
        }
    }
    catch (err) {
        swal("Error", err, "error");
        return;
    }
    var inputObj = { screenName: screenName, data: { definitionDataList: outputArray, numKeyChecked: numKeysMap} };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            clearFileBrower();
            resetScreen();
            swal("Info", "Data Inserted successfully in definitions tables", "success");
        }
    });
}
function openfileuploader() {
    $("#tsDefFile").click();
}