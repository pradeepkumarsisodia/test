﻿"use strict";
//var serverProxy = null;
var feserverProxy = null;
var screenName = Cronus.Screens.RiskMeasureLive;
var tableHeadersPortSwaps = ["SSM ID", "DURATION", "OPTION_DELTA"];
var tableHeaderPortStats = ["SSM_ID", "PROVIDER_NO", "DURATION", "CONVEXITY", "PRICE", "PRICE_DATE", "CURVE_TYPE", "OAS", "OAS_IS_INPUT", "YTM", "YTW"];
var tableHeaderKeyRates = ["SSM_ID", "PRICE_DATE", "SETTLE_DATE", "APP_ID", "SEGMENT_NO", "CURVE_TYPE", "SHOCKED_CURVE_TYPE", "OAS", "PRICE_PER_UNIT_PAR", "DDYP", "DDY2P"];

var cycleDate = "";
var handsonExcelInput;
var isCheckedBase = false;
var selectedReqId;
var dtPortSwaps, dtPortStats, dtKeyrates;
var firstRequestSubmitted = false;

$(document).on("ready", function () {
    if (!Cronus.selectedPage(screenName, Cronus.Actions.RiskMeasureLive_View)) {
        return;
    }
    // serverProxy = new ServerProxy(RiskMeasureLive, onUpdateStatus);    
    feserverProxy = FeServer.createServerProxy("Cronus", $("#spnWindowsUsername").text().split("PIMCO")[1].replace('\\', ''));
    feserverProxy.addEventHandler(FeServer.Events.status, function (e) {
        onUpdateStatus(e.id, e.status);
    });

    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.RiskMeasureLive_Run, screenName) == false) {
        $("#btnRunRiskMeasuresLive").attr('disabled', true);
        $("#btnRunRiskMeasuresLive").addClass('disabledbtn');
    }
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.RiskMeasureLive_Load, screenName) == false) {
        //$("#chkPostProcess").attr("disabled", true);
        //$("#chkPostProcess").attr("checked", false);
        $("#chkLoadGRM").attr("disabled", true);
        $("#chkLoadGRM").attr("checked", false);
    }

    $("#txtPricedate").datepicker({ maxDate: new Date() });
    Cronus.populateCycleDate($("#txtPricedate"));

    $('#btnRunRiskMeasuresLive').click(function () {
        clearOutputData();
        runGRM();
    });
    $("#btnClearScen").click(function () {
        var sampleData = [[false]];
        handsonExcelInput.loadData(sampleData);
        handsonExcelInput.render();
    });
   
    var actionrenderer = function (instance, td, row, col, prop, value, cellProperties) {
        if (value == undefined) {
            $(td).html('');
            return;
        }

        $(td).html(value.status);

        if (value.requestId != "")
            $(td).attr('id', value.requestId);
        if (value.status == "WAITING") {
            $(td).css("color", "blue");
        }
        else if (value.status == "OK") {
            $(td).html('<a onclick="showResult(' + row + '); return false;">' + value.status + '</a>');
            $(td).css("text-decoration", "underline");
            $(td).css("color", "green");
            //$(td).css("background-color", "yellow");
            if (selectedReqId == value.requestId)
                $(td).css("background-color", "yellow");
        }
        else if (value.status == 'FAILED') {
            $(td).html('<a href = "javascript:void(0);" onclick="showLog(\'' + value.requestId + '\'); return false;" style ="color:red;">' + value.status + '</a>');
            $(td).css("text-decoration", "underline");
            if (selectedReqId == value.requestId)
                $(td).css("background-color", "yellow");
            //$(td).css("color", "red");
        }
        else {

            $(td).css("color", "black");
        }
        $(td).css("font-weight", "bold");
    };

    var cusiprenderer = function (instance, td, row, col, prop, value, cellProperties) {
        if (value != undefined) {
            var value_str = String(value);
            if (/^[a-zA-Z0-9\s]*$/.test(value_str) == false || value_str.trim().length > 9) {
                td.style.background = 'red';
            }
            $(td).html(value);
        }
        else
            $(td).html('');
    };
    var pricerenderer = function (instance, td, row, col, prop, value, cellProperties) {
        if (value != undefined) {
            if (isNaN(value) || parseInt(value) < 0) {
                td.style.background = 'red';
            }
            $(td).html(value);
        }
        else
            $(td).html('');
    };
    // Prepare Handson Table for Risk Measures Live screen
    $("#tblCusips").html("");
    var dataInput = [[false]];
    var containerInput = document.getElementById('tblCusips');
    var settingInputTable = {
        data: dataInput,
        currentRowClassName: "currentRow",
        currentColClassName: "currentCol",
        renderAllRows: true,
        maxRows: 20,
        minSpareRows: 3,
        afterChange: afterHandsonChangeInput,
        beforeChange: beforeHandsonChangeInput,
        minRows: 6,
        height: 200,
        stretchH: 'all',
        className: 'htCenter',
        contextMenu: ['row_above', 'row_below', 'remove_row', 'undo', 'redo'],
        colWidths: [20],
        colHeaders: function (col) {
            switch (col) {
                case 0:
                    var txt = "<input type='checkbox' class='checkerBase' ";
                    txt += isCheckedBase ? 'checked="checked"' : '';
                    txt += ">";
                    return txt;
                case 1:
                    return "cusip*";
                case 2:
                    return "price";
                case 3:
                    return "status";
                default:
                    return "UNKNOWN";
            }
        },
        columns: [
        { data: 0, type: 'checkbox' },
        { data: 1, type: 'text', renderer: cusiprenderer },
        { data: 2, type: 'numeric', renderer: pricerenderer },
        { data: 3, renderer: actionrenderer }
        ]

    };

    var handsonTable = new Handsontable(document.getElementById('tblCusips'), settingInputTable);
    handsonTable.loadData(dataInput);
    handsonExcelInput = handsonTable;
    handsonTable.updateSettings({
        cells: function (row, col, prop) {
            var cellProperties = {};

            if (col == 1 || col == 2) {
                var rowData = handsonTable.getData()[row];
                if (rowData != undefined && rowData.length >= 3 && rowData[3] != undefined) {
                    if (rowData[3].status != undefined && rowData[3].status != "FAILED" && rowData[3].status != "OK" && rowData[3].status != "")
                        cellProperties.readOnly = true;
                    else
                        cellProperties.readOnly = false;
                }
                else
                    cellProperties.readOnly = false;
            }

            if (col == 3) {
                cellProperties.readOnly = true; // make cell read-only if it is first row or the text reads 'readOnly'
            }

            return cellProperties;
        }

    });

    function afterHandsonChangeInput(changes, source) {
        if (source != "loadData") {
            for (var i = 0; i < changes.length; i++) {
                if ((changes[i][1] == 1 && changes[i][3] != changes[i][2]) ||
                (changes[i][1] == 2 && (changes[i][2] != null && changes[i][3] != changes[i][2]))) {
                    var localData = handsonExcelInput.getData();
                    if (localData != undefined && localData[changes[i][0]] != undefined) {
                        localData[changes[i][0]][3] = undefined;
                        if (!isValidRow(changes[i][0]))
                            localData[changes[i][0]][0] = false;
                    }
                }
            }
            isCheckedBase = allCheckboxChecked();
            handsonTable.render();
        }
    }

    function beforeHandsonChangeInput(changes, source) {
        if (source != "loadData") {
            for (var i = 0; i < changes.length; i++) {
                if (changes[i][1] == 0) {
                    var row = changes[i][0];
                    if (!isValidRow(row) && changes[i][3] == true) {
                        changes.length = 0;
                    }
                }
            }

            handsonTable.render();
        }
    }

    Handsontable.Dom.addEvent(containerInput, 'mousedown', function (event) {
        if (event.target.nodeName == 'INPUT' && event.target.className == 'checkerBase') {
            isCheckedBase = !event.target.checked;
            SelectAll();
        }
    });

    $(window).bind("beforeunload", function () {
        if (firstRequestSubmitted)
            return "Are you sure you want to leave?";
    });

    $('#lnkFeSeverAuditor').click(function () {
        window.open(feserverProxy.absolute());
    });
});

function submitMQData(data, row) {
    var priceDate = $("#txtPricedate").val();
    if (priceDate == "") {
        swal("Error", "Please pass price date", "error");
    }

    var cusipPrices = [];
    for (var i = 0; i < data.length; i++) {
        if (data[i][0] && data[i][1] != undefined) {
            var price = "";
            if (data[i][2] == undefined || data[i][2] == "") {
                price = "";
            }
            else {
                price = data[i][2];
            }
            cusipPrices.push({ "cusip": data[i][1], "price": price });
        }
    }

    var cmd_options = { "data": cusipPrices, "price-date": priceDate }

    var cmd_flags = [];
    if ($('#chkPostProcess').is(':checked')) {
        cmd_flags.push("post-process");
    }
    if ($('#chkLoadGRM').is(':checked')) {
        cmd_flags.push("db-update");
    }
    else {
        cmd_flags.push("skip-classify");
    }

    var params = {
        "cmd_options": cmd_options,
        "cmd_flags": cmd_flags
    };

    feserverProxy.submitAction(FeServer.Tasks.GRM, params, function (id) {
        console.log("submitted GRM action id : " + id);
        for (var i = 0; i < data.length; i++) {
            if (data[i][0] && data[i][1] != undefined) {
                handsonExcelInput.setDataAtCell(i, 3, getStatus("SUBMITTED", id));
            }
        }
    }, null);

}

$("#chkLoadGRM").click(function () {
    if ($("#chkLoadGRM").is(':checked')) {
        $("#chkPostProcess").removeAttr("disabled");
    }
    else {
        $("#chkPostProcess").attr("disabled", true);
        $("#chkPostProcess").attr("checked", false);
    }
});


function onUpdateStatus(requestId, status) {

    console.log(requestId, status);
    //  return;

    var statusData = getStatus(status, requestId);
    var localData = handsonExcelInput.getData();
    //console.log(statusData);
    for (var i = 0; i < localData.length; i++) {
        if (localData[i][3] != undefined && localData[i][3].requestId == requestId) {
            handsonExcelInput.setDataAtCell(i, 3, statusData);
        }
    }
}

// This optional function html-encodes messages for display in the page.
function htmlEncode(value) {
    var encodedValue = $('<div />').text(value).html();
    return encodedValue;
}

function runGRM() {
    // Validate all selected rows for cusip and price here.
    var localData = handsonExcelInput.getData();
    var anyRowSelected = false;

    for (var i = 0; i < localData.length; i++) {
        if (localData[i][0] && localData[i][1] != undefined) {
            anyRowSelected = true;
//            submitMQData(localData[i][1], localData[i][2], i);
            firstRequestSubmitted = true;
        }
        selectedReqId = "";
    }
    
    if (!anyRowSelected) swal("Error", "Please select row(s)", "error");
    else submitMQData(localData);
}

function isValidRow(row) {
    var cusipCell = handsonExcelInput.getCell(row, 1, false);
    var priceCell = handsonExcelInput.getCell(row, 2, false);
    var localData = handsonExcelInput.getData();
    if (localData[row][1] == undefined || localData[row][1] == "" || localData[row][1] == null || cusipCell.style.background == 'red' || priceCell.style.background == 'red') {
        return false;
    }
    return true;
}

function clearOutputData() {
    $('#divLog').empty();
    $("#dtPortStats_wrapper").empty();
    $('#dtPortStats').empty();
    $("#dtPortSwaps_wrapper").empty();
    $("#dtPortSwaps").empty();
    $("#dtKeyrates_wrapper").empty();
    $('#dtKeyrates').empty();
}

function showResult(row) {
    var localData = handsonExcelInput.getData();
    var cusip = localData[row][1];
    var requestId = localData[row][3].requestId;
    
    clearOutputData();
    feserverProxy.submitQuery(FeServer.Tasks.RESULT, { id: requestId }, function (response) {
        console.log(response["status"], response["results"]["status"]);
        dtPortSwaps = Cronus.refreshDataTable(dtPortSwaps, $("#dtPortSwaps"), tableHeadersPortSwaps, response["results"]["data"]["port-swaps"]);
        dtPortStats = Cronus.refreshDataTable(dtPortStats, ("#dtPortStats"), tableHeaderPortStats, response["results"]["data"]["port-stats"]);
        dtKeyrates = Cronus.refreshDataTable(dtKeyrates, $("#dtKeyrates"), tableHeaderKeyRates, response["results"]["data"]["key-rates-stage"]);
        dtPortSwaps.fnFilter(cusip);
        dtPortStats.fnFilter(cusip);
        dtKeyrates.fnFilter(cusip);
        selectedReqId = requestId;
        handsonExcelInput.render();
    }, null);

}

function showLog(requestId) {
    clearOutputData();
    var params = {
        id: requestId
    };
    feserverProxy.submitQuery(FeServer.Tasks.LOG, params, function (response) {
        for (var property in response.results.logs) {
            if (response.results.logs[property] != '') {
                var color = '';
                if (response.results.logs[property].toLowerCase().indexOf("error") >= 0 || response.results.logs[property].toLowerCase().indexOf("failed") >= 0)
                    color = 'style = "color:red;"';

                var Id = property.replace(new RegExp("\\.", "ig"), '');
                var html = '<div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><u>'
                html += '<a data-toggle="collapse" href="#' + Id + '" ' + color + '>' + property + '</a></u></h4>'
                html += '</div><div id="' + Id + '" class="panel-collapse collapse">'
                html += '<div class="panel-body" style="overflow:auto;">'
                html += response.results.logs[property].replace(new RegExp('\n', "g"), '</br>')
                    .replace(new RegExp("FAILED", "ig"), "<b style=color:red> FAILED </b> ")
                    .replace(new RegExp("Error", "ig"), "<b> ERROR </b> ")
                    + " </Br> </Br>";
                html += '</div></div></div>'
                $('#divLog').append(html);
            }
        }
        selectedReqId = requestId;
        handsonExcelInput.render();
        $("#divLog").removeClass('hidden');
    });
}

function showFromCalender() {
    $("#txtPricedate").focus();
    return false;
}

function SelectAll() {
    var localData = handsonExcelInput.getData();
    var checked = isCheckedBase;
    for (var i = 0; i < localData.length; i++) {
        if (isValidRow(i))
            handsonExcelInput.setDataAtCell(i, 0, checked);
    }
}

function allCheckboxChecked() {
    var localData = handsonExcelInput.getData();
    var isAnyValidRow = false;
    for (var i = 0; i < localData.length; i++) {
        if (isValidRow(i)) {
            isAnyValidRow = true;
            if (localData[i][0] != true)
                return false;
        }
    }
    if (!isAnyValidRow)
        return false;
    return true;
}

function getStatus(status, requestId) {
    return { 'status': status, 'requestId': requestId };
}
function bindDataInHandsonTable(data) {
    if (data.length > 20) {
        swal("error", "Max limt of uploading data is 20 rows.", "error");
        return;
    }
    var dataRML = new Array();
    for (var i = 0; i < data.length; i++) {
        var values = data[i].split(',');
        dataRML.push([false, values[0], values[1]]);
    }
    handsonExcelInput.loadData(dataRML);
    handsonExcelInput.render();
}

var cusipData = [];
function readDefinitionsFile(input) {
    cusipData = null;
    if (input.files[0].name.indexOf("txt") == -1 && input.files[0].name.indexOf("csv") == -1) {
        swal('error', 'File format should be csv or txt only.', 'error');
        return;
    }
    $("#txtFileName").text(input.files[0].name);
    $("#txtFileName").css('color', '');
    $('#divStatus').css("display", "none");
    
    if (input.files && input.files[0]) {
        var reader = new window.FileReader();
        $(".blockOverlay").css('display', 'block');
        reader.onload = function (e) {
            try {
                loadFile(e.target.result, ",");

            } catch (err) {
                $(".blockOverlay").css('display', 'none');
                // Clear file browser
                clearFileBrower();
                swal("Error", err, "error");
            }
        };
        reader.readAsText(input.files[0]);
    }
    input = $("#rmlRunFile");
    input.replaceWith(input.val('').clone(true));
}

function loadFile(text, seperator) {
    cusipData = text.split(/[\r\n]+/g).filter(function (x) { return x && x.trim(); }); // tolerate both Windows and Unix linebreaks    
    if (cusipData.length <= 0) {
       
        throw ("File is empty, cannot be uploaded");
    }
    var fileNameWithCusipCount = $("#txtFileName").text() + " ( #cusips : " + cusipData.length + ")";
    $("#txtFileName").text(fileNameWithCusipCount);

    $(".blockOverlay").css('display', 'none');
    // RefreshTable();
    bindDataInHandsonTable(cusipData);
}
function clearFileBrower() {
    $("#txtFileName").text("");
    var input = $("#rmlRunFile");
    input.replaceWith(input.val('').clone(true));
    //  lines = [];
    // outputArray = [];

    $(".blockOverlay").css('display', 'none');
}
function openfileuploader() {
    $("#rmlRunFile").click();
}
