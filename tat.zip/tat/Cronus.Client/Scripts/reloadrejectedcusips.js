﻿"use strict";
var screenName = Cronus.Screens.RejectedCusips;
var selectedCusipWithContext = [];
var cycleDate = "";
var previousDate = "";
var max_length = -1;
var dtRejectionDetail;
var selectedCusipWithAnalyticId = [];
var reloadFlag = false;

$(document).ready(function () {
    if (!Cronus.selectedPage(screenName, Cronus.Actions.RejectedCusips_View)) {
        return;
    }

    //Permission Check
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.RejectedCusips_NotifyForRejection, screenName) == false) {
        $("#btnNotifyRejection").attr('disabled', true);
        $("#btnNotifyRejection").addClass('disabledbtn');
    }
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.RejectedCusips_NotifyForReload, screenName) == false) {
        $("#btnNotifyReload").attr('disabled', true);
        $("#btnNotifyReload").addClass('disabledbtn');
    }
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.RejectedCusips_ShowDetails, screenName) == false) {
        $("#btnShowDetails").attr('disabled', true);
        $("#btnShowDetails").addClass('disabledbtn');
    }
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.RejectedCusips_SearchCurrentNotification, screenName) == false) {
        $("#btnSearchReloadedCusips").attr('disabled', true);
        $("#btnSearchReloadedCusips").addClass('disabledbtn');
    }
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.RejectedCusips_SearchRejectedCusips, screenName) == false) {
        $("#btnSearchRejectedCusips").attr('disabled', true);
        $("#btnSearchRejectedCusips").addClass('disabledbtn');
    }
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.RejectedCusips_ExportToExcel, screenName) == false) {
        $("#btnExportExcelRejectedCusip").attr('disabled', true);
        $("#btnExportExcelRejectedCusip").addClass('disabledbtn');
        $("#btnExportExcelReloadedCusip").attr('disabled', true);
        $("#btnExportExcelReloadedCusip").addClass('disabledbtn');
    }


    hideControls();
    Cronus.fetchAutoCompleteData(screenName, "", Cronus.RestApi.FetchDropDownData, $('#txtSelectContext'));

    ListCycleAndPreviosDate();

    $("#txtdate").datepicker({ maxDate: new Date() });
    $("#txtdate").val($.datepicker.formatDate("mm/dd/yy", new Date()));

    $("#btnSearchRejectedCusips").click(function () {
        SearchRejectedCusips();
    });

    $("#btnSearchReloadedCusips").click(function () {
        SearchReloadedCusips();
    });

    $("#btnNotifyReload").click(function () {
        ReloadRejectedCusips(selectedCusipWithContext);
    });

    $("#btnNotifyRejection").click(function () {
        RejectReloadedCusips(selectedCusipWithContext);
    });

    $("#btnShowDetails").click(function () {
        ListCusipsDetails(selectedCusipWithContext);
    });

    $("#btnExportExcelRejectedCusip").click(function () {
        ExportCusipsData("Y")
    });

    $("#btnExportExcelReloadedCusip").click(function () {
        ExportCusipsData("N")
    });

    $("#chkAllCusips").click(function () {

        var chkBoxes = $("#tblRejectedCusip input:checkbox:gt(0)");
        if (this.checked) {
            for (var i = 0; i < chkBoxes.length; i++)
                chkBoxes[i].checked = true;
        }
        else {
            for (var i = 0; i < chkBoxes.length; i++)
                chkBoxes[i].checked = false;
        }

        // Iterate through each check box
        for (var i = 0; i < chkBoxes.length; i++)
            selectthisCusip(chkBoxes[i]);

        searchAnalyticID();
    });

    $("txtCusips").width(max_length + 244);

});


function searchAnalyticID(el) {
    var cusipContextData = [];
    if ($("#chkAllCusips").is(':checked')) {
        if (selectedCusipWithContext.length > 0) {

            for (var i = 0; i < selectedCusipWithContext.length; i++) {
                var cusipContext = selectedCusipWithContext[i].split(",");
                cusipContextData.push({ cusip: cusipContext[0], context: cusipContext[1] });
            }
        }
    }
    else {
        if ($(el).is(':checked')) {
            var cusip = $(el).attr("cusip");
            var cusipcontext = cusip.split(',');
            cusipContextData.push({ cusip: cusipcontext[0], context: cusipcontext[1] });
        }
        else {
            return;
        }
    }
    var priceDate = $("#txtdate").val();

    var inputObj = { screenName: screenName, data: { cusipContextData: cusipContextData, priceDate: priceDate, reloadFlag: reloadFlag} };

    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.CustomFunction, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {

            if (result.rows.length > 0) {

                $('#UpdateAnalytic').modal('show');
                $("#dtUpdateAnalyticId").html("");
                var numberofheaders = result.columns.length;
                var table = "";
                table += '<thead> <th><input type="checkbox" onchange="CheckAll(this);"  id="chkAllCusipsua" class="all" /> </th>';
                for (var l = 0; l < numberofheaders; l++) {
                    if (l == 0)
                        table += '<th style="line-height:30px">' + result.columns[l] + '</th>';
                    else
                        table += '<th style="line-height:30px">' + result.columns[l] + '</th>';
                }
                table += "</thead>";

                for (var i = 0; i < result.rows.length; i++) {
                    var rowId = i + 1;
                    table += '<tr id=ua' + i + '>';
                    var cusip = result.rows[i][1];
                    var analyticId = result.rows[i][2];
                    table += '<td> <input type="checkbox" class="single" onchange ="selectthisCusipWithAalyticId(this,true);"  id="cusipua_' + i + '" cusipanalytiid="' + cusip + ',' + analyticId + '" /></td>';
                    for (var l = 0; l < numberofheaders; l++) {
                        if (l == 0)
                            table += '<td style="line-height:30px">' + result.rows[i][l].split('T')[0] + '</td>';
                        else
                            table += '<td style="line-height:30px">' + result.rows[i][l] + '</td>'
                    }
                    table += '</tr>';
                }

                $("#dtUpdateAnalyticId").html(table);


                $("#dtUpdateAnalyticId #chkAllCusipsua").attr("checked", true);
                CheckAll("#dtUpdateAnalyticId #chkAllCusipsua");
            }
            //else {
            //    swal("error","No Data Found","error")
            //}
        }
    });


}

function CheckAll(el) {
    var chkBoxes = $("#dtUpdateAnalyticId input:checkbox.single");
    selectedCusipWithAnalyticId = [];
    if ($(el).is(':checked')) {
        for (var i = 0; i < chkBoxes.length; i++) {
            chkBoxes[i].checked = true;
            var flag = false;
            if (chkBoxes.length == (i + 1)) {
                flag = true;
            }
            selectthisCusipWithAalyticId(chkBoxes[i], flag);
        }
    }
    else {
        for (var i = 0; i < chkBoxes.length; i++) {
            chkBoxes[i].checked = false;
            var flag = false;
            if (chkBoxes.length == (i + 1)) {
                flag = true;
            }
            selectthisCusipWithAalyticId(chkBoxes[i], flag);
        }
    }

    // Iterate through each check box

    //for (var i = 0; i < chkBoxes.length; i++) {
    //    var flag = false;
    //    if (chkBoxes.length == (i + 1)) {
    //        flag = true;
    //    }
    //    selectthisCusipWithAalyticId(chkBoxes[i], flag);
    //}
}

function selectthisCusip(el) {
    var cusip = $(el).attr("cusip");
    if ($(el).is(':checked')) {
        selectedCusipWithContext.push(cusip);
    } else {
        selectedCusipWithContext = jQuery.grep(selectedCusipWithContext, function (value) {
            return value != cusip;
        });

        if (selectedCusipWithAnalyticId.length > 0) {
            selectedCusipWithAnalyticId = jQuery.grep(selectedCusipWithAnalyticId, function (value) {
                var mainCusipId = cusip.split(',');
                var childCusipId = value.split(',');
                return childCusipId[0] != mainCusipId[0];
            });
        }
    }
    //check for all checkboxes
    var chkBoxes = $("#tblRejectedCusip input:checkbox:gt(0)");
    // Iterate through each check box
    $("#chkAllCusips").prop("checked", true);
    for (var i = 0; i < chkBoxes.length; i++) {
        if (!chkBoxes[i].checked)
            $("#chkAllCusips").prop("checked", false);
    }
}


function selectthisCusipWithAalyticId(el, flag) {
    var cusip = $(el).attr("cusipanalytiid");
    if ($(el).is(':checked')) {
        selectedCusipWithAnalyticId.push(cusip);
    } else {
        selectedCusipWithAnalyticId = jQuery.grep(selectedCusipWithAnalyticId, function (value) {
            return value != cusip;
        });
    }
    //check for all checkboxes
    if (flag == true) {
        var chkBoxes = $("#dtUpdateAnalyticId input:checkbox.single");
        // Iterate through each check box
        $("#dtUpdateAnalyticId #chkAllCusipsua").prop("checked", true);
        for (var i = 0; i < chkBoxes.length; i++) {
            if (!chkBoxes[i].checked)
                $("#dtUpdateAnalyticId #chkAllCusipsua").prop("checked", false);
        }
    }
}

function showCalender() {
    $("#txtdate").focus();
    return false;
}

function ListCycleAndPreviosDate() {
    var inputObj = { screenName: screenName };

    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchCycleAndPreviosDate, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            if (result.CycleDate != null && result.PreviousDate != null) {
                cycleDate = result.CycleDate.split('T')[0];
                previousDate = result.PreviousDate.split('T')[0];
            }
        }
    });
}

function disableControls() {
    $("#btnNotifyReload,#btnNotifyRejection").attr('disabled', true);
    $("#btnNotifyReload,#btnNotifyRejection").addClass('disabledbtn');
    $("#chkAllCusips").attr('disabled', true);
    $("#chkAllCusips").attr("checked", false);
}

function hideControls() {
    $("#btnNotifyRejection").hide();
    $("#btnNotifyReload").hide();
    $("#btnShowDetails").hide();
    $("#btnExportExcelRejectedCusip").hide();
    $("#btnExportExcelReloadedCusip").hide();
}

function showControls() {
    $("#btnNotifyRejection").show();
    $("#btnNotifyReload").show();
    $("#btnShowDetails").show();
    $("#btnExportExcelRejectedCusip").show();
    $("#btnExportExcelReloadedCusip").show();
}

function SearchRejectedCusips() {
    hideControls();
    disableControls();
    selectedCusipWithContext = [];
    var isError = false;
    var cusipList = $("#txtCusips").val();
    if (!Cronus.validateCusipList(cusipList, 9)) {
        return;
    }

    var context = $("#txtSelectContext").val().split("-")[0].trim();
    if (!Cronus.isNotEmptyNullOrUndefined(context)) {
        context = "";
    }
    var priceDate = $("#txtdate").val();
    reloadFlag = false;

    populateData(cusipList, priceDate, context, reloadFlag);

    if ((Date.parse(priceDate) == Date.parse(previousDate)) || (Date.parse(priceDate) == Date.parse(cycleDate)) || $("#ddlCommanEnviroment").val() === "DELTA" || $("#ddlCommanEnviroment").val() === "DELTA2" ) {
        $("#btnNotifyReload").attr('disabled', false);
        $("#btnNotifyReload").removeClass('disabledbtn');
    }
}

function populateData(cusipList, priceDate, context, reloadFlag) {
    $("#tblRejectedCusip tr:gt(0)").remove();
    var dataObj = [];
    dataObj.push({ cusip: cusipList, priceDate: priceDate, context: context, reloadFlag: reloadFlag, tab: "S" });
    var inputObj = { screenName: screenName, data: dataObj };

    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            if (result.rows.length > 0) {
                showControls();
                if (!reloadFlag) {
                    $("#btnNotifyRejection").hide();
                    $("#btnExportExcelRejectedCusip").hide();
                }
                else {
                    $("#btnNotifyReload").hide();
                    $("#btnExportExcelReloadedCusip").hide();
                }
                $("#chkAllCusips").attr('disabled', false);
            }


            var numberofheaders = result.columns.length;

            for (var i = 0; i < result.rows.length; i++) {
                $("#tblRejectedCusip").append('<tr id=' + i + '></tr>');
                var cusip = result.rows[i][1];
                var context = result.rows[i][2];
                $("#" + i).append('<td> <input type="checkbox" onchange="selectthisCusip(this); searchAnalyticID(this);" id="cusip_' + i + '"   cusip="' + cusip + ',' + context + '"/></td>');
                for (var l = 0; l < numberofheaders; l++) {
                    if (l == 0)
                        $("#" + i).append('<td style="line-height:30px">' + result.rows[i][l].split('T')[0] + '</td>');
                    else
                        $("#" + i).append('<td style="line-height:30px">' + result.rows[i][l] + '</td>');
                }
            }
        }
    });
}

function SearchReloadedCusips() {
    hideControls();
    disableControls();
    selectedCusipWithContext = [];
    var isError = false;
    var cusipList = $("#txtCusips").val();
    if (!Cronus.validateCusipList(cusipList, 9)) {
        return;
    }

    var context = $("#txtSelectContext").val().split("-")[0].trim();
    if (!Cronus.isNotEmptyNullOrUndefined(context)) {
        context = "";
    }

    var priceDate = $("#txtdate").val();
    reloadFlag = true;
    populateData(cusipList, priceDate, context, reloadFlag);

    if ((Date.parse(priceDate) == Date.parse(previousDate)) || (Date.parse(priceDate) == Date.parse(cycleDate)) || $("#ddlCommanEnviroment").val() === "DELTA" || $("#ddlCommanEnviroment").val() === "DELTA2") {
        $("#btnNotifyRejection").attr('disabled', false);
        $("#btnNotifyRejection").removeClass('disabledbtn');
    }
}

function ReloadRejectedCusips(cusipWithContext) {
    if (cusipWithContext.length == 0) {
        swal("Error", "Select atleast 1 or more cusips", "error");
        return false;
    }

    var chkBoxes = $("#tblRejectedCusip input:checked:gt(0)");
    var context = $("#txtSelectContext").val().split("-")[0].trim();
    if (!Cronus.isNotEmptyNullOrUndefined(context)) {
        context = "";
    }
    var priceDate = $("#txtdate").val();
    updateDB(cusipWithContext, priceDate, true);
}

function updateDB(cusipWithContext, priceDate, reloadFlag) {
    var cusipContextData = [];

    for (var i = 0; i < cusipWithContext.length; i++) {
        var cusipContext = cusipWithContext[i].split(",");
        var analyticIds = new Array();

        if (selectedCusipWithAnalyticId.length > 0) {
            $.each(selectedCusipWithAnalyticId, function (key, value) {
                var CusipWithAnalyticId = value.split(',');
                if (CusipWithAnalyticId[0] == cusipContext[0]) {
                    analyticIds.push(CusipWithAnalyticId[1]);
                }

            });
        }
        cusipContextData.push({ cusip: cusipContext[0], context: cusipContext[1], analyticIds: analyticIds });
    }

    var inputObj = { screenName: screenName, data: { priceDate: priceDate, reloadFlag: reloadFlag, cusipContextData: cusipContextData} };

    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            swal("Info", result.message, "success");
            selectedCusipWithContext = [];
            selectedCusipWithAnalyticId = [];

            for (var i = 0; i < cusipWithContext.length; i++) {
                $('input[cusip="' + cusipWithContext[i] + '"]').each(function () {
                    $(this).parent().parent().remove();
                });
            }
            $("#chkAllCusips").attr("checked", false);
        }
    });
}

function RejectReloadedCusips(cusipWithContext) {
    if (cusipWithContext.length == 0) {
        swal("Error", "Select atleast 1 or more cusips", "error");
        return false;
    }
    var chkBoxes = $("#tblRejectedCusip input:checked:gt(0)");

    var context = $("#txtSelectContext").val().split("-")[0].trim();
    if (!Cronus.isNotEmptyNullOrUndefined(context)) {
        context = "";
    }

    var priceDate = $("#txtdate").val();
    updateDB(cusipWithContext, priceDate, false);
}

function ListCusipsDetails(cusipWithContext) {
    if (cusipWithContext.length == 0) {
        swal("Error", "Select atleast 1 or more cusips", "error");
        return false;
    }

    var priceDate = $("#txtdate").val();

    var objList = [];

    for (var i = 0; i < cusipWithContext.length; i++) {
        var cusipContext = cusipWithContext[i].split(",");
        objList.push({ cusip: cusipContext[0], priceDate: priceDate, context: cusipContext[1], tab: "D" });
    }

    var inputObj = { screenName: screenName, data: objList };

    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            if (result.rows.length > 0) {
                $('.bs-rejection-modal-lg').modal('show');
                dtRejectionDetail = Cronus.refreshDataTable(dtRejectionDetail, $("#dtRejectionDetail"), result.columns, result.rows);
            }
        }
    });
}

function ExportCusipsData(reload_flag) {
    var cusipList = $("#txtCusips").val();
    if (!Cronus.validateCusipList(cusipList, 9)) {
        return;
    }
    if (cusipList == null) {
        cusipList = "";
    }

    var context = $("#txtSelectContext").val().split("-")[0].trim();
    if (!Cronus.isNotEmptyNullOrUndefined(context)) {
        context = "";
    }

    var url = document.location.host;

    var href = "../Handlers/ExportReportingData.ashx?reload_flag=" + reload_flag +
        "&reportType=RejectedCusipReporting" +
        "&url=" + url +
        "&context=" + context +
        "&cusipList=" + cusipList +
        "&priceDate=" + $("#txtdate").val() + " 00:00:00" +
        "&runOnEnvironment=" + $("#ddlCommanEnviroment").val();
    window.open(href, '_blank');
}



