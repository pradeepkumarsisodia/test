﻿"use strict";
var screenName = Cronus.Screens.RiskMeasureOverride;
//Headson Tables for each view
var handsonExcelScen;
var handsonExcelBase;
var handsonExcelTrader;
var table;
var submitObj;
var count = 0;

//Providerid mapping
var providerArray = []; // BASE-0200
var providerDictionary = [];    //0200  -> BASE-0200
var providerDictionaryAlias = []; //BASE -> BASE-0200

//Handson Table SelectAll checkbox
var isCheckedTrader = false;
var isCheckedScen = false;
var isCheckedBase = false;

//Handson Table column order *Note --> Do not change the column name as they are used in validation. So be verycareeful in changing name
var traderHeaderArray = ['Cusip', 'ISIN', 'Price', 'Duration', 'Spread Duration', 'OAS'];
var scenHeaderArray = ['Cusip', 'Duration', 'Curve Type', 'Provider Id', 'Backup Metric', 'OAS Is Input', 'Notes', 'Price', 'Price Date', 'Convexity', 'OAS', 'YTM', 'YTW'];
var baseHeaderArray = ['Cusip', 'Duration', 'Delta', 'Backup Metric', 'Notes', 'BUM Code', 'BUM Sub Code', 'Country', 'Code1', 'Code2', 'Code3'];

//PortStats and PortSwap file column order
var portStatsColHeader = ['Cusip', 'Provider Id', 'Duration', 'Convexity', 'Price', 'Price Date', 'Curve Type', 'OAS', 'OAS Is Input', 'YTM', 'YTW'];
var portSwapsColHeader = ['Cusip', 'Duration', 'Delta'];

//Uniq Columns for each view
var traderUniqColumnArray = ['Cusip'];
var scenUniqColumnArray = ['Cusip', 'Provider Id', 'Curve Type', 'OAS Is Input'];
var baseUniqColumnArray = ['Cusip'];

//Mandatory Files
var traderMandatoryArray = ['Cusip/ISIN', 'Duration', 'Spread Duration', 'OAS'];
var scenMandatoryArray = ['Cusip', 'Provider Id', 'Curve Type', 'OAS Is Input', 'Duration'];
var baseMandatoryArray = ['Cusip', 'Duration'];

$(document).ready(function () {
    if (!Cronus.selectedPage(screenName, Cronus.Actions.RiskMeasureOverride_View)) {
        return;
    }
    var isTraderRiskOverrideViewPermitted = Cronus.Compliance.isActionPermitted(Cronus.Actions.RiskMeasureOverride_ViewTraders, screenName);
    var isAnalyticsRiskOverrideViewPermitted = Cronus.Compliance.isActionPermitted(Cronus.Actions.RiskMeasureOverride_ViewAnalytics, screenName);

    //Permission Check
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.RiskMeasureOverride_SubmitBase, screenName) == false) {
        $("#btnDeleteRMBase").attr('disabled', true);
        $("#btnDeleteRMBase").addClass('disabledbtn');
        $("#btnSubmitRMBase").attr('disabled', true);
        $("#btnSubmitRMBase").addClass('disabledbtn');
    }
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.RiskMeasureOverride_SubmitScenarios, screenName) == false) {
        $("#btnDeleteRMScen").attr('disabled', true);
        $("#btnDeleteRMScen").addClass('disabledbtn');
        $("#btnSubmitRMScen").attr('disabled', true);
        $("#btnSubmitRMScen").addClass('disabledbtn');
    }
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.RiskMeasureOverride_SubmitTraders, screenName) == false) {
        $("#btnDeleteRMTrader").attr('disabled', true);
        $("#btnDeleteRMTrader").addClass('disabledbtn');
        $("#btnSubmitRMTrader").attr('disabled', true);
        $("#btnSubmitRMTrader").addClass('disabledbtn');
    }

    //Disable / Enable Analytics / Trader view based on permissions
    if (!isTraderRiskOverrideViewPermitted && !isAnalyticsRiskOverrideViewPermitted) {
        $("#RMOdiv").hide();
    }
    if (!isTraderRiskOverrideViewPermitted || !isAnalyticsRiskOverrideViewPermitted) {
        $("#btnTrader").hide();
        $("#btnAnalytics").hide();
    }
    if (isTraderRiskOverrideViewPermitted) {
        $("#btnTrader").show();
        $("#btnTrader").click();
    }
    if (isAnalyticsRiskOverrideViewPermitted) {
        $("#btnAnalytics").show();
        $("#btnAnalytics").click();
        ListRiskAttributesWithAlias();
    }

    // Prepare Handson Table for Scenario and Base Grid(Analytics View) and trader view
    $("#dvHandsonTableScen").html("");
    $("#dvHandsonTableBase").html("");
    $("#dvHandsonTableTrader").html("");
    var dataTrader = [[false]];
    var dataScen = [[false]];
    var dataBase = [[false]];

    var containerScen = document.getElementById('dvHandsonTableScen');
    var containerBase = document.getElementById('dvHandsonTableBase');
    var containerTrader = document.getElementById('dvHandsonTableTrader');

    var settingScen = {
        data: dataScen,
        afterChange: afterHandsonChangeScen,
        currentRowClassName: "currentRow",
        currentColClassName: "currentCol",
        renderAllRows: true,
        minSpareRows: 5,
        height: 200,
        contextMenu: ['row_above', 'row_below', 'remove_row', 'undo', 'redo'],
        colWidths: [26, 80, 80, 100, 110, 80, 70, 75, 75, 75, 75, 75, 75, 75],
        stretchH: "all",
        colHeaders: function (col) {
            switch (col) {
                case 0:
                    var txt = "<input type='checkbox' class='checkerScen' ";
                    txt += isCheckedScen ? 'checked="checked"' : '';
                    txt += ">";
                    return txt;
                default:
                    var colName = scenHeaderArray[col - 1];
                    for (var i = 0; i < scenMandatoryArray.length; i++) {
                        if (scenMandatoryArray[i] == colName)
                            return colName + "*";
                    }
                    return colName;
            }
        },
        columns: [
        { data: 0, type: 'checkbox' },
        { data: 1 }, { data: 2 },
        { data: 3, type: 'autocomplete', source: ["TREASURY-0", "SWAP-100"], strict: false },
        { data: 4, type: 'autocomplete', source: providerArray, strict: false },
        { data: 5, type: 'autocomplete', source: ["Y", "N"], strict: false },
        { data: 6, type: 'autocomplete', source: ["Y", "N"], strict: false },
        { data: 7 }, { data: 8 }, { data: 9 }, { data: 10 }, { data: 11 }, { data: 12 }, { data: 13 },
        ]
    };

    var settingBase = {
        data: dataBase,
        afterChange: afterHandsonChangeBase,
        currentRowClassName: "currentRow",
        currentColClassName: "currentCol",
        renderAllRows: true,
        contextMenu: ['row_above', 'row_below', 'remove_row', 'undo', 'redo'],
        minSpareRows: 5,
        height: 200,
        colWidths: [26, 80, 80, 55, 80, 90, 70, 90, 65, 50, 50, 50],
        stretchH: "all",
        colHeaders: function (col) {
            switch (col) {
                case 0:
                    var txt = "<input type='checkbox' class='checkerBase' ";
                    txt += isCheckedBase ? 'checked="checked"' : '';
                    txt += ">";
                    return txt;
                default:
                    var colName = baseHeaderArray[col - 1];
                    for (var i = 0; i < baseMandatoryArray.length; i++) {
                        if (baseMandatoryArray[i] == colName)
                            return colName + "*";
                    }
                    return colName;
            }
        },
        columns: [
        { data: 0, type: 'checkbox' },
        { data: 1 }, { data: 2 }, { data: 3 },
        { data: 4, type: 'autocomplete', source: ["Y", "N"], strict: false },
        { data: 5 }, { data: 6 }, { data: 7 }, { data: 8 }, { data: 9 }, { data: 10 }, { data: 11 }
        ],
        onSelection: function (row, col, row2, col2) {
            var meta = this.getCellMeta(row2, col2);

            if (meta.readOnly) {
                this.updateSettings({ fillHandle: false });
            }
            else {
                this.updateSettings({ fillHandle: true });
            }
        },
        cells: function (row, col, prop) {
            var cellProperties = {};

            if (col > 5) {
                cellProperties.readOnly = true; // make cell read-only if it is first row or the text reads 'readOnly'
                cellProperties.renderer = "negativeValueRenderer";
            }

            return cellProperties;
        }
    };

    // Prepare Handson Table Grid for Trader View
    var settingTrader = {
        data: dataTrader,
        afterChange: afterHandsonChangeTrader,
        currentRowClassName: "currentRow",
        currentColClassName: "currentCol",
        renderAllRows: true,
        contextMenu: ['row_above', 'row_below', 'remove_row', 'undo', 'redo'],
        minSpareRows: 5,
        height: 200,
        colWidths: [26],
        stretchH: 'all',
        colHeaders: function (col) {
            switch (col) {
                case 0:
                    var txt = "<input type='checkbox' class='checkerTrader' ";
                    txt += isCheckedTrader ? 'checked="checked"' : '';
                    txt += ">";
                    return txt;
                default:
                    var colName = traderHeaderArray[col - 1];
                    for (var i = 0; i < traderMandatoryArray.length; i++) {
                        if (traderMandatoryArray[i] == colName)
                            return colName + "*";
                    }
                    return colName;
            }
        },
        columns: [
        { data: 0, type: 'checkbox'/*, renderer: customRenderer*/ },
        { data: 1 }, { data: 2 }, { data: 3 }, { data: 4 }, { data: 5 }, { data: 6 },
        ]

    };

    // maps function to lookup string
    Handsontable.renderers.registerRenderer('negativeValueRenderer', negativeValueRenderer);

    var handsonTableScen = new Handsontable(containerScen, settingScen);
    {
        handsonTableScen.loadData(dataScen);
        handsonExcelScen = handsonTableScen;
    }

    var handsonTableBase = new Handsontable(containerBase, settingBase);
    {
        handsonTableBase.loadData(dataBase);
        handsonExcelBase = handsonTableBase;
    }

    var handsonTableTrader = new Handsontable(containerTrader, settingTrader);
    {
        handsonTableTrader.loadData(dataTrader);
        handsonExcelTrader = handsonTableTrader;
    }

    // Used for selecting all rows in handson table    
    Handsontable.Dom.addEvent(containerScen, 'mouseup', function (event) {
        if (event.target.nodeName == 'INPUT' && event.target.className == 'checkerScen') {
            isCheckedScen = !event.target.checked;
            SelectAll(handsonExcelScen, isCheckedScen, scenHeaderArray);
        }
    });

    Handsontable.Dom.addEvent(containerBase, 'mouseup', function (event) {
        if (event.target.nodeName == 'INPUT' && event.target.className == 'checkerBase') {
            isCheckedBase = !event.target.checked;
            SelectAll(handsonExcelBase, isCheckedBase, baseHeaderArray);
        }
    });

    Handsontable.Dom.addEvent(containerTrader, 'mouseup', function (event) {
        if (event.target.nodeName == 'INPUT' && event.target.className == 'checkerTrader') {
            isCheckedTrader = !event.target.checked;
            SelectAll(handsonExcelTrader, isCheckedTrader, traderHeaderArray);
        }
    });

    //AfterChange Function
    function afterHandsonChangeScen(changes, source) {
        if (source != "loadData") {
            isCheckedScen = afterHandsonChangeCommon(changes, handsonTableScen, handsonExcelScen, scenHeaderArray);
            handsonExcelScen.render();
        }
    }
    function afterHandsonChangeBase(changes, source) {
        if (source != "loadData") {
            isCheckedBase = afterHandsonChangeCommon(changes, handsonTableBase, handsonExcelBase, baseHeaderArray);
            handsonExcelBase.render();
        }
    }
    function afterHandsonChangeTrader(changes, source) {
        if (source != "loadData") {
            isCheckedTrader = afterHandsonChangeCommon(changes, handsonTableTrader, handsonExcelTrader, traderHeaderArray);
            handsonTableTrader.render();
        }
    }

    //  Handson Table Grid ends here

    if (window.File && window.FileReader && window.FileList && window.Blob) {
        $("#btnFileSwa").removeAttr('disabled');
        $("#btnFileSwa2").removeAttr('disabled');
    } else {
        $("#btnFileSwa").attr('disabled', 'disabled');
        $("#btnFileSwa2").attr('disabled', 'disabled');
        swal("Error", "File Loading (port_stats, port_swaps) is not fully supported in this browser. Please try IE >= 10 or Chrome or Firefox browsers.", "error");
    }

    //Submit and Delete button click functions
    $("#btnSubmitRMScen").click(function () {
        UpdateRiskMeasuresOverride(handsonTableScen, handsonExcelScen, false, scenHeaderArray, scenMandatoryArray, scenUniqColumnArray, "S");
    });

    $("#btnDeleteRMScen").click(function () {
        UpdateRiskMeasuresOverride(handsonTableScen, handsonExcelScen, true, scenHeaderArray, scenMandatoryArray, scenUniqColumnArray, "S");
    });

    $("#btnSubmitRMBase").click(function () {
        UpdateRiskMeasuresOverride(handsonTableBase, handsonExcelBase, false, baseHeaderArray, baseMandatoryArray, baseUniqColumnArray, "B");
    });

    $("#btnDeleteRMBase").click(function () {
        UpdateRiskMeasuresOverride(handsonTableBase, handsonExcelBase, true, baseHeaderArray, baseMandatoryArray, baseUniqColumnArray, "B");
    });

    $("#btnSubmitRMTrader").click(function () {
        UpdateRiskMeasuresOverride(handsonTableTrader, handsonExcelTrader, false, traderHeaderArray, traderMandatoryArray, traderUniqColumnArray, "T");
    });

    $("#btnDeleteRMTrader").click(function () {
        UpdateRiskMeasuresOverride(handsonTableTrader, handsonExcelTrader, true, traderHeaderArray, traderMandatoryArray, traderUniqColumnArray, "T");
    });

    //Reset button click function
    $("#btnClearScen").click(function () {
        isCheckedScen = false;
        $("#txtSearchScen").val('');
        var sampleData = [[false]];
        handsonTableScen.loadData(sampleData);
        handsonExcelScen = handsonTableScen;
    });

    $("#btnClearBase").click(function () {
        isCheckedBase = false;
        $("#txtSearchBase").val('');
        var sampleData = [[false]];
        handsonTableBase.loadData(sampleData);
        handsonExcelBase = handsonTableBase;
    });

    $("#btnClearTrader").click(function () {
        isCheckedTrader = false;
        $("#txtSearchTrader").val('');
        var sampleData = [[false]];
        handsonTableTrader.loadData(sampleData);
        handsonExcelTrader = handsonTableTrader;
        if ($("#chkIsMortgageSecurity").is(":checked"))
            $("#chkIsMortgageSecurity").click();
        if ($("#chkIsHardOverride").is(":checked"))
            $("#chkIsHardOverride").click();

    });

    // Copy button click function 
    $("#btnCopyScenToBase").click(function () {
        var rowsAdded = CopyScenToBase(handsonExcelScen, handsonExcelBase, handsonTableBase, scenHeaderArray, baseHeaderArray);
        if (rowsAdded > 0) {
            isCheckedBase = false;
            handsonExcelBase.render();
        }
        swal("Info", rowsAdded + " Row(s) added to Base view", "success");
    });

    $("#btnCopyBaseToScen").click(function () {
        var rowsAdded = CopyBaseToScen(handsonExcelBase, handsonExcelScen, handsonTableScen, baseHeaderArray, scenHeaderArray);
        if (rowsAdded > 0) {
            isCheckedScen = false;
            handsonExcelScen.render();
        }
        swal("Info", rowsAdded + " Row(s) added to Scenario view", "success");
    });

    //Search button function
    $("#btnSearchScen").click(function () {
        var value = $("#txtSearchScen").val();
        $("#btnClearScen").click();
        searchCusip(handsonTableScen, handsonExcelScen, value, "S", scenHeaderArray, false);
        $("#txtSearchScen").val(value);
    });

    $("#btnSearchBase").click(function () {
        var value = $("#txtSearchBase").val();
        $("#btnClearBase").click();
        searchCusip(handsonTableBase, handsonExcelBase, value, "B", baseHeaderArray, false);
        $("#txtSearchBase").val(value);
    });

    $("#btnSearchTrader").click(function () {
        var value = $("#txtSearchTrader").val();
        $("#btnClearTrader").click();
        if (value == "" || value == null || value == undefined)
            swal("Error", "Please pass list of Cusip/ISIN saperated by comma(,)", "error");
        else
            searchCusip(handsonTableTrader, handsonExcelTrader, value, "T", traderHeaderArray, true);
        $("#txtSearchTrader").val(value);
    });

    //if enter pressed on search box
    $("#txtSearchScen").keypress(function (e) {
        Cronus.validCommaSeperatedString(e);
        if (e.which == 13) {
            $("#btnSearchScen").click();
            return false;
        }
    });

    $("#txtSearchBase").keypress(function (e) {
        Cronus.validCommaSeperatedString(e);
        if (e.which == 13) {
            $("#btnSearchBase").click();
            return false;
        }
    });
    $("#txtSearchTrader").keypress(function (e) {
        Cronus.validCommaSeperatedString(e);
        if (e.which == 13) {
            $("#btnSearchTrader").click();
            return false;
        }
    });

    $("#btnSubmit").click(function () {

        UpdateData(false, count);

    });
    isCheckedScen = false;
    isCheckedBase = false;
    isCheckedTrader = false;
});
// (document).ready ends here

function searchCusip(handsonTable, handsonExcel, cusipList, tab, headerArray, traderView) {
    if (cusipList == "" || cusipList == null || cusipList == undefined) {
        swal("Error", "Please pass list of Cusips saperated by comma(,)", "error");
        return;
    }

    var inputObj = { screenName: screenName, data: { SSMID: cusipList, TAB: tab } };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            if (result.rows.length > 0) {
                // Add result data in list
                var distinctCusips = {};
                var cusipSearchData = [];
                var mortgageCusip;
                var hardOverride;
                for (var i = 0; i < result.rows.length; i++) {
                    var tmpDic = [];
                    //traders view the cusip coulmn is unique
                    if (traderView == true) {
                        if (distinctCusips[result.rows[i][0]] == undefined)
                            distinctCusips[result.rows[i][0]] = 1;
                        else
                            continue;
                    }
                    //put the return data in a dictionary whose key is columnname and value is columnvalue
                    for (var j = 0; j < result.columns.length; j++) {
                        tmpDic[result.columns[j].toUpperCase()] = result.rows[i][j];
                        if (traderView == true) {
                            //j == 6 means provide_id & j == 7 backup_metrix
                            if (j == 6) {
                                if (mortgageCusip == undefined)
                                    mortgageCusip = result.rows[i][j];
                                else if (mortgageCusip != result.rows[i][j]) {
                                    swal("Error", "Pass only Mortgage cusips or non mortgage cusips", "error");
                                    return;
                                }
                            }
                            if (j == 7) {
                                if (hardOverride == undefined)
                                    hardOverride = result.rows[i][j];
                                else if (hardOverride != result.rows[i][j]) {
                                    swal("Error", "Pass only soft duration cusips or hard duration cusips", "error");
                                    return;
                                }
                            }
                        }

                    }

                    //Validate the column value and put the data in array 
                    //Assumption columnName return by query is _ seperated and handsontable has space seperated
                    var localData = [];
                    //first column is checkbox
                    localData.push(false);
                    for (var j = 0; j < headerArray.length; j++) {
                        var header = headerArray[j].replace(/ /g, '_').toUpperCase();
                        localData.push(validateColumnValue(headerArray[j].toUpperCase(), String(tmpDic[header]).trim()));
                    }
                    cusipSearchData.push(localData);
                }

                handsonTable.loadData(cusipSearchData);
                handsonExcel = handsonTable;
                if (traderView == true) {
                    if (mortgageCusip != "NSPRD")
                        $("#chkIsMortgageSecurity").click();
                    if (hardOverride == "N")
                        $("#chkIsHardOverride").click();
                }
            }
            else {
                swal("Info", "No data found for this cusip", "success");
            }
        }
    });
}

//Submit Button to write Scenario Risk Measures to File on server side
function UpdateRiskMeasuresOverride(handsonTable, handsonExcel, deleteFlag, headerArray, mandatoryArray, uniqArray, view) {
    var data = handsonExcel.getData();
    //validate is all the mandatory field populated
    var errorMessage = "";
    count = 0;
    for (var i = 0; i < data.length - 5; i++) {
        if (data[i][0] == false)
            continue;

        if (errorMessage != "")
            continue;
        var columnValueDic = [];
        //put all the column values in dictionary
        for (var j = 0; j < headerArray.length; j++) {
            columnValueDic[headerArray[j]] = data[i][j + 1];
        }

        //check all mandatory field if deleteFlag is on check uniq fields
        if (deleteFlag) {
            for (var j = 0; j < uniqArray.length; j++) {
                var cols = uniqArray[j].split('/');
                var value = undefined;
                //For trader view cusip or isin is mandatory. to handle, below is the for loop.
                for (var k = 0; k < cols.length; k++) {
                    var tmp = columnValueDic[cols[k]];
                    if (tmp != "" && tmp != null && tmp != undefined)
                        value = tmp;
                }
                if (value == "" || value == null || value == undefined) {
                    errorMessage = "Missing value of " + uniqArray[j] + " of row " + (i + 1);
                    break;
                }

            }
        }
        else {
            for (var j = 0; j < mandatoryArray.length; j++) {
                var cols = mandatoryArray[j].split('/');
                var value = undefined;
                //For trader view cusip or isin is mandatory. to handle, below is the for loop.
                for (var k = 0; k < cols.length; k++) {
                    var tmp = columnValueDic[cols[k]];
                    if (tmp != "" && tmp != null && tmp != undefined)
                        value = tmp;
                }

                if (value == "" || value == null || value == undefined) {
                    errorMessage = "Missing value of " + mandatoryArray[j] + " of row " + (i + 1);
                    break;
                }
            }
        }
        count++;

    }
    if (errorMessage != "") {
        swal("Error", errorMessage + "\n\nMandatory fields: " + mandatoryArray.join(), "error");
        return;
    }
    else if (count == 0) {
        swal("Error", "No row selected", "error");
    }
    else {
        submitObj = new Object;
        submitObj.tab = view;
        submitObj.action = deleteFlag ? "D" : "U";
        var riskMeasure = createObjects(handsonExcel, view, headerArray, deleteFlag);
        if (view == 'B')
            submitObj.baseRiskMeasureObj = riskMeasure;
        else if (view == 'S')
            submitObj.scenarioRiskMeasureObj = riskMeasure;
        else if (view == 'T')
            submitObj.tradersRiskMeasureObj = riskMeasure;

        var inputObj = { screenName: screenName, data: submitObj };
        if (deleteFlag == false) {
            if (view == 'S' || view == 'T') {
                $("#tableConfirmation").html(table);
                $("#divModelConfirmation").modal('show');
            }
            else {
                UpdateData(deleteFlag, count, handsonTable, handsonExcel, headerArray);
            }
        }
        else {
            UpdateData(deleteFlag, count, handsonTable, handsonExcel, headerArray);
        }
    }
}


function UpdateData(deleteFlag, count, handsonTable, handsonExcel, headerArray) {
    $("#divModelConfirmation").modal('hide');
    var inputObj = { screenName: screenName, data: submitObj };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            if (deleteFlag) {
                repopulateExcel(handsonTable, handsonExcel, headerArray);
                swal("Info", "Risk measures deleted successfully for " + count + " selected rows", "success");
            }
            else
                swal("Info", "Risk measures updated successfully for " + count + " selected rows", "success");
        }
    });
}

function createObjects(handsonExcel, view, headerArray, deleteFlag) {
    var inputObjAjax = new Object();
    var RiskMeasureData = [];
    var data = handsonExcel.getData();
    var spreadDuration = "";
    var Duration = "";
    var OAS = "";
    var Convexity = "";
    var YTW = "";
    var YTM = "";
    var Cusip = "";

    var previousCusip = "";
    table = "";
    table += '<table><thead>';
    table += '<th style="line-height:30px">Cusip</th>';
    table += '<th style="line-height:30px">Duration</th>';
    table += '<th style="line-height:30px">OAS</th>';
    table += '<th style="line-height:30px">Spread Duration</th>';
    table += '<th style="line-height:30px">Convexity</th>';
    table += '<th style="line-height:30px">Ytw</th>';
    table += '<th style="line-height:30px">Ytm</th>';
    table += "</thead>";
    var checkedData = new Array();
    for (var i = 0; i < data.length - 5; i++) {
        if (data[i][0] == false)
            continue;
        else {
            checkedData.push(data[i]);
        }
    }

    for (var i = 0; i < checkedData.length ; i++) {
        //if (data[i][0] == false)
        //    continue;
        //else {
        //put all the column values in dictionary
        var columnValueDic = [];

        for (var j = 0; j < headerArray.length; j++) {
            columnValueDic[headerArray[j]] = checkedData[i][j + 1];
        }

        if (view == "S") {
            var inputObj = new Object();
            inputObj.CUSIP = columnValueDic["Cusip"];
            inputObj.DURATION = columnValueDic["Duration"];
            inputObj.OAS = columnValueDic["OAS"];
            inputObj.YTM = columnValueDic["YTM"];
            inputObj.YTW = columnValueDic["YTW"];
            inputObj.CONVEXITY = columnValueDic["Convexity"];
            inputObj.PRICE = columnValueDic["Price"];
            inputObj.PRICE_DATE = columnValueDic["Price Date"];
            inputObj.OAS_IS_INPUT = columnValueDic["OAS Is Input"];
            inputObj.NOTES = columnValueDic["Notes"];
            inputObj.BACKUP_MATRIC = columnValueDic["Backup Metric"];
            inputObj.PROVIDER_ID = columnValueDic["Provider Id"].split("-")[0];
            inputObj.CURVE_TYPE = columnValueDic["Curve Type"].split("-")[1];

            RiskMeasureData.push(inputObj);
        }
        else if (view == "B") {
            var inputObj = new Object();
            inputObj.SSM_ID = columnValueDic["Cusip"];
            inputObj.DURATION = columnValueDic["Duration"];
            inputObj.DELTA = columnValueDic["Delta"];
            inputObj.NOTES = columnValueDic["Notes"];
            inputObj.BACKUP_MATRIC = columnValueDic["Backup Metric"];

            RiskMeasureData.push(inputObj);
        }
        else if (view == "T") {
            var inputObj = new Object();
            inputObj.SSM_ID = columnValueDic["Cusip"];
            inputObj.ISIN = columnValueDic["ISIN"];
            inputObj.DURATION = columnValueDic["Duration"];
            inputObj.SPREAD_DURATION = columnValueDic["Spread Duration"];
            inputObj.OAS = columnValueDic["OAS"];
            inputObj.PRICE = columnValueDic["Price"];
            inputObj.IS_MORTGAGE_SECURITY = $("#chkIsMortgageSecurity").is(':checked') ? "Y" : "N";
            inputObj.HARD_DURATION = $("#chkIsHardOverride").is(':checked') ? "Y" : "N";

            RiskMeasureData.push(inputObj);
        }
        if (view == "S") {
            if (columnValueDic["Provider Id"] != undefined) {
                var providerType = columnValueDic["Provider Id"].split("-")[0]
                if (providerType == "SPRD" || providerType.indexOf("SPRD") > 0) {
                    spreadDuration = columnValueDic["Duration"] == undefined ? '0' : columnValueDic["Duration"];
                }
                else if (providerType == "BASE") {
                    Duration = columnValueDic["Duration"] == undefined ? '0' : columnValueDic["Duration"];
                    OAS = columnValueDic["OAS"] == undefined ? '0' : columnValueDic["OAS"];
                    Convexity = columnValueDic["Convexity"] == undefined ? '0' : columnValueDic["Convexity"];
                    YTW = columnValueDic["YTW"] == undefined ? '0' : columnValueDic["YTW"];
                    YTM = columnValueDic["YTM"] == undefined ? '0' : columnValueDic["YTM"];
                }
               
                Cusip = columnValueDic["Cusip"];

                if (previousCusip == "") {
                    previousCusip = columnValueDic["Cusip"];
                }
                var nextRow = "";
                var nextRowCusip = "";
                if (i != checkedData.length - 1) {
                    nextRow = checkedData[(i + 1)];
                    nextRowCusip = nextRow[1];
                }
                else {
                    nextRowCusip = "";
                }

                if (nextRowCusip != previousCusip) {
                    table += "<tr>";
                    table += '<td style="line-height:30px">' + Cusip + '</td>'
                    table += '<td style="line-height:30px">' + Duration + '</td>'
                    table += '<td style="line-height:30px">' + OAS + '</td>'
                    table += '<td style="line-height:30px">' + spreadDuration + '</td>'
                    table += '<td style="line-height:30px">' + Convexity + '</td>'
                    table += '<td style="line-height:30px">' + YTW + '</td>'
                    table += '<td style="line-height:30px">' + YTM + '</td>'
                    table += "</tr>";

                    Duration = "";
                    OAS = "";
                    Convexity = "";
                    YTW = "";
                    YTM = "";
                    spreadDuration = "";
                    previousCusip = nextRowCusip;
                }

            }
        }
        else if (view == "T") {

            spreadDuration = columnValueDic["Spread Duration"] == undefined ? '0' : columnValueDic["Spread Duration"];
            Duration = columnValueDic["Duration"] == undefined ? '0' : columnValueDic["Duration"];
            OAS = columnValueDic["OAS"] == undefined ? '0' : columnValueDic["OAS"];
            Convexity = columnValueDic["Convexity"] == undefined ? '0' : columnValueDic["Convexity"];
            YTW = columnValueDic["YTW"] == undefined ? '0' : columnValueDic["YTW"];
            YTM = columnValueDic["YTM"] == undefined ? '0' : columnValueDic["YTM"];
            table += "<tr>";
            table += '<td style="line-height:30px">' + columnValueDic["Cusip"] + '</td>'
            table += '<td style="line-height:30px">' + Duration + '</td>'
            table += '<td style="line-height:30px">' + OAS + '</td>'
            table += '<td style="line-height:30px">' + spreadDuration + '</td>'
            table += '<td style="line-height:30px">' + Convexity + '</td>'
            table += '<td style="line-height:30px">' + YTW + '</td>'
            table += '<td style="line-height:30px">' + YTM + '</td>'
            table += "</tr>";
        }
        //}
    }
    table += "</table>";
    if (view == "S")
        inputObjAjax = RiskMeasureData;
    else if (view == "B")
        inputObjAjax = RiskMeasureData;
    else if (view == "T")
        inputObjAjax = RiskMeasureData;
    return inputObjAjax;
}

function repopulateExcel(handsonTable, handsonExcel, headerArray) {
    var rows = [];
    var data = handsonExcel.getData();
    for (var i = 0; i < data.length - 5; i++) {
        if (data[i][0] == true)
            continue;
        else {
            var rowtmp = [];
            rowtmp.push(false);
            for (var j = 0; j < headerArray.length; j++) {
                rowtmp.push(data[i][j + 1]);
            }
            rows.push(rowtmp);
        }
    }
    if (rows.length == 0)
        rows = [[false]];
    handsonTable.loadData(rows);
    handsonExcel = handsonTable;
}

function negativeValueRenderer(instance, td, row, col, prop, value, cellProperties) {
    Handsontable.renderers.TextRenderer.apply(this, arguments);
    if (col > 4) {
        td.style.background = '#EEE';
    }
}

function toggleTab(id, el) {
    $(el).removeClass('disabledbtn');
    $("#" + id).addClass('disabledbtn');
    if (id == "btnAnalytics") {
        $("#RMOdiv").hide();
        $("#TraderDiv").show();
    } else if (id == "btnTrader") {
        $("#TraderDiv").hide();
        $("#RMOdiv").show();
    }
}

function CopyScenToBase(handsonExcelFrom, handsonExcelTo, handsonTableTo, fromHeader, toHeader) {
    //First get the cusip position in FromHeader and ToHeader
    var toCusipPos = 0;
    for (var i = 0; i < toHeader.length; i++) {
        if (toHeader[i] == "Cusip")
            toCusipPos = i;
    }

    //first create dic of key CUSIP-CURVEType and BaseRiskMeasure Row
    var baseRMDic = [];
    var cusipArray = [];
    var fromDic = [];
    var dataFrom = handsonExcelFrom.getData();
    var dataTo = handsonExcelTo.getData();
    for (var i = 0; i < dataFrom.length - 5; i++) {
        if (dataFrom[i][0] == false)
            continue;
        for (var j = 0; j < fromHeader.length; j++)
            fromDic[fromHeader[j]] = dataFrom[i][j + 1];

        var cusip = fromDic["Cusip"];
        if (cusip == "" || cusip == null || cusip == undefined)
            continue;

        //take only those cusips whose provider_id is base and curve type is 0/100
        if (fromDic["Provider Id"] == providerDictionaryAlias["BASE"] &&
			(fromDic["Curve Type"] == "TREASURY-0" || fromDic["Curve Type"] == "SWAP-100")) {
            //check if this cusip exists in handsonExcelTo
            var found = false;
            for (var j = 0; j < dataTo.length - 5; j++) {
                if (dataTo[j][toCusipPos + 1] == cusip) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                var row = [];
                row.push(false);
                for (var j = 0; j < toHeader.length; j++) {
                    var value = undefined;
                    if (toHeader[j] == "Cusip")
                        value = cusip;
                    else if (toHeader[j] == "Duration")
                        value = fromDic["Duration"];
                    else if (toHeader[j] == "Notes")
                        value = fromDic["Notes"];
                    else if (toHeader[j] == "Backup Metric")
                        value = fromDic["Backup Metric"];
                    row.push(value);
                }
                var cusipFound = false;
                for (var l = 0; l < cusipArray.length; l++)
                    if (cusipArray[l] == cusip)
                        cusipFound = true;
                if (!cusipFound)
                    cusipArray.push(cusip);
                baseRMDic[cusip + "-" + fromDic["Curve Type"].split('-')[1]] = row;
            }
        }
    }

    if (cusipArray.length == 0)
        return cusipArray.length;

    //do a ajax call and get the cusips and curve Type
    var inputObj = { screenName: screenName, data: { SSMID: cusipArray.join() }, fieldName: "CURVE_TYPE" };

    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDropDownData, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            var cusipCurveType = [];
            for (var i = 0; i < result.dropDownData.length; i++) {
                var value = result.dropDownData[i].value.split('-')[1];
                var key = result.dropDownData[i].data;
                cusipCurveType[key] = value;
            }

            //iterate through all cusips and update handsonExcelTo
            var finalExcelTo = [];
            for (var i = 0; i < cusipArray.length; i++) {
                if (cusipCurveType[cusipArray[i]] != undefined && baseRMDic[cusipArray[i] + "-" + cusipCurveType[cusipArray[i]]] != undefined)
                    finalExcelTo.push(baseRMDic[cusipArray[i] + "-" + cusipCurveType[cusipArray[i]]]);
                else if (baseRMDic[cusipArray[i] + "-" + "0"] != undefined)
                    finalExcelTo.push(baseRMDic[cusipArray[i] + "-" + "0"]);
                else if (baseRMDic[cusipArray[i] + "-" + "100"] != undefined)
                    finalExcelTo.push(baseRMDic[cusipArray[i] + "-" + "100"]);
            }

            for (var j = 0; j < dataTo.length - 5; j++)
                finalExcelTo.push(dataTo[j]);

            handsonTableTo.loadData(finalExcelTo);
            handsonExcelTo = handsonTableTo;
        }
    });
    return cusipArray.length;
}

function CopyBaseToScen(handsonExcelFrom, handsonExcelTo, handsonTableTo, fromHeader, toHeader) {
    //First get the cusip position in FromHeader and ToHeader
    var toCusipPos;
    var toCurveTypePos;
    var toProIdPos;
    for (var i = 0; i < toHeader.length; i++) {
        if (toHeader[i] == "Cusip")
            toCusipPos = i;
        if (toHeader[i] == "Curve Type")
            toCurveTypePos = i;
        if (toHeader[i] == "Provider Id")
            toProIdPos = i;
    }

    var dataFrom = handsonExcelFrom.getData();
    var dataTo = handsonExcelTo.getData();
    var finalExcelTo = [];
    var processedCusips = [];
    for (var i = dataFrom.length - 5 - 1; i >= 0; i--) {
        if (dataFrom[i][0] == false)
            continue;
        var fromDic = [];
        for (var j = 0; j < fromHeader.length; j++)
            fromDic[fromHeader[j]] = dataFrom[i][j + 1];

        var cusip = fromDic["Cusip"];
        if (cusip == "" || cusip == null || cusip == undefined)
            continue;
        if (processedCusips[cusip] != undefined)
            continue;
        processedCusips[cusip] = 1;
        //check if this cusip exists in handsonExcelTo
        var curveType0 = false;
        var curveType100 = false;
        for (var j = 0; j < dataTo.length - 5; j++) {
            if (dataTo[j][toCusipPos + 1] == cusip && dataTo[j][toProIdPos + 1] == providerDictionaryAlias["BASE"]) {
                if (dataTo[j][toCurveTypePos + 1] == "TREASURY-0")
                    curveType0 = true;
                else if (dataTo[j][toCurveTypePos + 1] == "SWAP-100")
                    curveType100 = true;
                if (curveType0 && curveType100)
                    break;
            }
        }

        if (!curveType0) {
            var row = [];
            row.push(false);
            for (var j = 0; j < toHeader.length; j++) {
                var value = undefined;
                if (toHeader[j] == "Cusip")
                    value = cusip;
                if (toHeader[j] == "Curve Type")
                    value = "TREASURY-0";
                else if (toHeader[j] == "Provider Id")
                    value = providerDictionaryAlias["BASE"];
                else if (toHeader[j] == "Duration")
                    value = fromDic["Duration"];
                else if (toHeader[j] == "Notes")
                    value = fromDic["Notes"];
                else if (toHeader[j] == "Backup Metric")
                    value = fromDic["Backup Metric"];
                row.push(value);
            }
            finalExcelTo.push(row);
        }
        if (!curveType100) {
            var row = [];
            row.push(false);
            for (var j = 0; j < toHeader.length; j++) {
                var value = undefined;
                if (toHeader[j] == "Cusip")
                    value = cusip;
                else if (toHeader[j] == "Curve Type")
                    value = "SWAP-100";
                else if (toHeader[j] == "Provider Id")
                    value = providerDictionaryAlias["BASE"];
                else if (toHeader[j] == "Duration")
                    value = fromDic["Duration"];
                else if (toHeader[j] == "Notes")
                    value = fromDic["Notes"];
                else if (toHeader[j] == "Backup Metric")
                    value = fromDic["Backup Metric"];
                row.push(value);
            }
            finalExcelTo.push(row);
        }
    }
    var rowsAdded = finalExcelTo.length;
    for (var j = 0; j < dataTo.length - 5; j++)
        finalExcelTo.push(dataTo[j]);

    handsonTableTo.loadData(finalExcelTo);
    handsonExcelTo = handsonTableTo;
    handsonExcelTo.render();
    return rowsAdded;
}

function SelectAll(handsonExcel, checked, header) {

    var data = handsonExcel.getData();
    for (var i = 0; i < data.length - 5; i++) {
        var activeRow = false;
        for (var j = 1; j < header.length; j++) {
            if (data[i][j] != null && data[i][j] != "")
                activeRow = true;
        }
        if (!activeRow) {
            data[i][0] = false;
            continue;
        }

        if (data[i][0] == !checked) {
            data[i][0] = checked;
        }
    }
    handsonExcel.loadData(data);
    handsonExcel.render();
}

function validateColumnValue(colHeader, value) {
    if (value == undefined || value == null || value == "")
        return value;
    //cusip and isin should not have special character
    if (colHeader == "CUSIP" || colHeader == "ISIN") {
        if (value.match(/^[a-zA-Z0-9 ]+$/) == null)
            return null;
    }
    else if (colHeader == "PRICE" || colHeader == "DURATION" || colHeader == "SPREAD DURATION" || colHeader == "OAS"
                || colHeader == "DELTA" || colHeader == "YTM" || colHeader == "YTW" || colHeader == "CONVEXITY") {
        if (isNaN(value))
            return null;
    }
    else if (colHeader == "BACKUP METRIC" || colHeader == "OAS IS INPUT") {
        if (value == 1 || value == "y" || value == "Y")
            value = "Y";
        else
            value = "N";
        if (value != "Y" && value != "N" && value != "y" && value != "n")
            return null;
    }
    else if (colHeader == "CURVE TYPE") {
        if (value.trim().match(/^[0]*100$/) != null || value.trim().toUpperCase().match(/^SWAP$/) != null
                    || value.trim().toUpperCase().match(/^SWAP[ ]*-[ ]*100[ ]*$/) != null) {
            //changes.splice(i, 1);
            return "SWAP-100";
        }
        else if (value.trim().match(/^0+$/) != null || value.trim().toUpperCase().match(/^TREASURY$/) != null
                    || value.trim().toUpperCase().match(/^TREASURY[ ]*-[ ]*0+[ ]*$/) != null) {
            return "TREASURY-0";
        }
        else {
            return null;
        }
    }
    else if (colHeader == "PROVIDER ID") {
        if (providerDictionary[value] != undefined) {
            return providerDictionary[value];
        }
        else if (value.indexOf("-") != -1 && providerDictionaryAlias[value.split("-")[0]] != undefined && providerDictionary[value.split("-")[1]] != undefined) {
            return providerDictionaryAlias[value.split("-")[0]];
        }
        else if (providerDictionaryAlias[value] != undefined) {
            return providerDictionaryAlias[value];
        }
        else {
            return null;
        }

    }
    else if (colHeader == "PRICE DATE") {
        return value.split('T')[0];
    }
    return value;
}

function afterHandsonChangeCommon(changes, handsonTable, handsonExcel, headerArray) {
    var localData = handsonExcel.getData();
    for (var i = 0; i < changes.length; i++) {
        if (changes[i][1] != 0 && localData[changes[i][0]][0] == undefined)
            localData[changes[i][0]][0] = false;
        if (changes[i][1] != 0) {
            var colHeader = headerArray[changes[i][1] - 1].toUpperCase();
            localData[changes[i][0]][changes[i][1]] = validateColumnValue(colHeader, changes[i][3].trim());
        }
    }

    var allchecked = true;
    var activeRowCount = 0;
    for (var i = 0; i < localData.length - 5; i++) {
        var activeRow = false;
        for (var j = 0; j < headerArray.length; j++) {
            if (localData[i][j + 1] != null && localData[i][j + 1] != "" && localData[i][j + 1] != undefined)
                activeRow = true;
        }
        if (!activeRow) {
            localData[i][0] = false;
            continue;
        }
        else
            activeRowCount++;
        if (localData[i][0] == false) {
            allchecked = false;
        }
    }
    if (activeRowCount == 0) {
        allchecked = false;
        localData[0][0] == false
    }
    return allchecked;
}

function UploadPortStatsFile() {
    $("#fdTohide1").click();
}

function loadFile(file, text, header, handsonExcel, seperator, columnsCount, fileType) {
    var lines = text.split(/[\r\n]+/g); // tolerate both Windows and Unix linebreaks

    // check first line has 11 columns
    if (lines[0].split(seperator).length != columnsCount) {
        $(".blockOverlay").css('display', 'none');
        swal("Error", "file format is not proper. Please pass a valid " + fileType, "error");
        return;
    }

    if (lines.length > 995) {
        $(".blockOverlay").css('display', 'none');
        swal("Error", "File size " + lines.length + " is greater than 995. It Supports only file size upto 995.", "error");
        return;
    }
    var dataRM = [];
    for (var i = 0; i < lines.length; i++) {
        var RiskMeasureData = [];
        var line = lines[i];
        if (line == "" || line == undefined || line == null)
            continue;
        if (line.match(/^#/))
            continue;

        RiskMeasureData.push(false);
        var riskmeasures = line.split(seperator);
        var dataDic = [];
        for (var j = 0; j < riskmeasures.length; j++)
            dataDic[header[j]] = validateColumnValue(header[j].toUpperCase(), riskmeasures[j]);

        for (var j = 0; j < scenHeaderArray.length; j++)
            RiskMeasureData.push(dataDic[scenHeaderArray[j]]);

        dataRM.push(RiskMeasureData);
        if (i == lines.length - 2) {
            setTimeout(function () {
                $(".blockOverlay").css('display', 'none');
            }, 1000);
        }
    }

    handsonExcel.loadData(dataRM);
    handsonExcel.render();

}

function readPortStatsFile(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        $(".blockOverlay").css('display', 'block');
        reader.onload = function (e) {
            try {
                loadFile(input, e.target.result, portStatsColHeader, handsonExcelScen, " ", 11, "port_stats");
                // resizeSearchDivs();
            } catch (err) {
                swal("Error", "Error while loadig port stats file", "error");
                $(".blockOverlay").css('display', 'none');
            }
        }
        reader.readAsText(input.files[0]);

    }
    else
        RebindExcel();
}


function UploadPortSwapsFile() {
    $("#fdTohide2").click();
}

function readPortSwapsFile(input) {
    if (input.files && input.files[0]) {
        $(".blockOverlay").css('display', 'block');
        var reader = new FileReader();
        reader.onload = function (e) {
            try {
                loadFile(input, e.target.result, portSwapsColHeader, handsonExcelBase, "\t", 2, "port_swaps");
                //  resizeSearchDivs();
            } catch (err) {
                $(".blockOverlay").css('display', 'none');
                swal("Error", "Error while loadig port swap file", "error");
            }
        }
        reader.readAsText(input.files[0]);
    }
    else
        RebindExcel();
}

function ListRiskAttributesWithAlias() {
    var inputObj = { screenName: screenName, fieldName: "PROVIDER_ID" };

    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDropDownData, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            if (result.dropDownData != null && result.dropDownData.length > 0) {

                for (var i = 0; i < result.dropDownData.length; i++) {
                    providerArray.push(result.dropDownData[i].value);
                    var key = result.dropDownData[i].value.split('-')[1];
                    var key2 = result.dropDownData[i].data;
                    var value = result.dropDownData[i].value;

                    providerDictionary[key] = value;
                    providerDictionaryAlias[key2] = value;
                }
            }
        }
    });
}
