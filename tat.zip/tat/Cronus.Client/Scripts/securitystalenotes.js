﻿"use strict";
var screenName = Cronus.Screens.SecurityStaleNotes;
var dt;
var _mode, _selectedId;

$(document).ready(function () {
    if (!Cronus.selectedPage(screenName, Cronus.Actions.SecurityStaleNotes_View)) {
        return;
    }

    $("#addTable").click(function () {
        AddTable();
    });

    $("#btnSaveClass").click(function () {
        UpdateData();
    });

    listTableData();
});

function AddTable() {
    ShowSecNotesPopup(0);
}

function UpdateData() {

    var ssmId = $("#txtSSM_ID").val();
    var appUserId = $("#txtAppUserId").val();
    var code1 = $("#txtCode1").val();
    var code2 = $("#txtCode2").val();
    var code3 = $("#txtCode3").val();
    var risk1 = $("#txtRisk1").val();
    var risk2 = $("#txtRisk2").val();
    var refTag = $("#txtRefTag").val();
    var intexProblems = $("#txtIntext_problems").val();
    var BBProblems = $("#txtBB_problems").val();
    var altSw = $("#txtAlt_sw").val();
    var notes = $("#txtNotes").val();
    var expirationDate = $("#txtExpiration_date").val();

    if (ssmId === "") {
        swal("Please enter ssm id!", "", "error");
        $("#txtSSM_ID").focus();
        return;
    }
    if (ssmId != "" && ssmId != null && Cronus.validateCusipList(ssmId, 9) == false) {
        $("#txtSsm_id").focus();
        return;
    }
    if (appUserId === "") {
        swal("Please enter App user id!", "", "error");
        $("#txtAppUserId").focus();
        return;
    }
    if (notes === "") {
        swal("Please enter notes!", "", "error");
        $("#txtNotes").focus();
        return;
    }
    if (expirationDate === "") {
        swal("Please enter Expiration Date!", "", "error");
        $("#txtExpiration_date").focus();
        return;
    }
    var action = "I";
    if (_mode === 1) {
        action = "U";
    }
    var inputObj = {
        screenName: screenName,

        data: {
            SecNotesData: {
                SSMId: ssmId, AppUserId: appUserId, Code1: code1, Code2: code2, Code3: code3, Risk1: risk1, Risk2: risk2, RefTag: refTag,
                IntexProblems: intexProblems, BBProblems: BBProblems, AltSw: altSw, Notes: notes, ExpirationDate: expirationDate
            }, action: action, tableName: "pm..sec_notes"
        }
    };

    successUpdateMasterTable(inputObj, action);
}


function successUpdateMasterTable(inputObj, action) {
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage === null || result.errorMessage === "") {
            if (action === "I") {
                action = "Insert";
            }
            else if (action === "D") {
                action = "Delete";
            }
            else {
                action = "Update";
            }

            swal("Data " + action + " was successfull", "", "success");
            listTableData();
            $(".bs-class-modal-lg").modal("hide");
        }
    });
}

function ShowSecNotesPopup(mode) {
    _mode = mode;
    if (mode === 0) {
        $("#modalTitle").html("Add new Security Stale notes");
        $("#txtSSM_ID").attr("readonly", false);
        $("#txtAppUserId").attr("readonly", false);
        $("#txtSSM_ID").val("");
        $("#txtAppUserId").val("0");
        $("#txtCode1").val("");
        $("#txtCode2").val("");
        $("#txtCode3").val("");
        $("#txtRisk1").val("");
        $("#txtRisk2").val("");
        $("#txtRefTag").val("");
        $("#txtIntext_problems").val("");
        $("#txtBB_problems").val("");
        $("#txtAlt_sw").val("");
        $("#txtNotes").val("");
        $("#txtExpiration_date").datepicker({
            dateFormat: 'mm-dd-yy'
        }).datepicker('setDate', null);

    } else {
        $("#txtSSM_ID").parent().parent().show();
        $("#txtSSM_ID").attr("readonly", true);
        $("#txtAppUserId").attr("readonly", true);
        $("#modalTitle").html("Update a Security Stale notes");
    }
    $(".bs-class-modal-lg").modal("show");
}

function listTableData() {
    var inputObj = { screenName: screenName };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.FetchDataForTable, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage === null || result.errorMessage === "") {
            successlistTableData(result.columns, result.rows);
        }
    });
}

function successlistTableData(cols, rows) {
    var columns = cols;
    columns.push("Edit");
    columns.push("Delete");
    var dataTableArray = [];
    for (var i = 0; i < rows.length; i++) {
        var datarow = [];
        for (var j = 0; j < columns.length - 2; j++) {
            datarow.push(rows[i][j]);
        }

        datarow.push("<input type='button' class='btn btn-success dataTable' value='Edit' onclick=fetchMasterTableInfo(" + i + "); />");
        datarow.push("<input type='button' class='btn btn-danger dataTable' value='Delete' onclick=deleteEnrty(" + i + "); />");

        dataTableArray.push(datarow);
    }
    dt = Cronus.refreshDataTable(dt, $("#dtMasterTable"), columns, dataTableArray, 2, [{ orderable: false, targets: -2}]);
}

function fetchMasterTableInfo(row) {
    var data = dt.fnGetData();
    successMasterTableInfo(data[row]);
}
function deleteEnrty(row) {
    var data = dt.fnGetData();
    var ssmId = data[row][0];
    var appUserId = data[row][1];
    var action = "D";

    swal({ html: true,
        title: "Data will be deleted for ", text: ssmId + " </br> <b> Do you wish to continue? </b>", type: "warning", showCancelButton: true, confirmButtonColor: "#2e6da4",
        confirmButtonText: "No", cancelButtonText: "Yes", cancelButtonColor: "#2e6da4", closeOnConfirm: true, closeOnCancel: false
    },
     function (isConfirm) {
         if (!isConfirm) {
             swal.close();
             var inputObj = {

                 screenName: screenName,
                 data: {
                     tableName: "pm..sec_notes",
                     SecNotesData: {
                         SSMId: ssmId, AppUserId: appUserId
                     }, action: action
                 }
             };
             successUpdateMasterTable(inputObj, action);
         }
         else { return true; }
         return true;
     });
}


function successMasterTableInfo(data) {
    _selectedId = data[0];
    $("#txtSSM_ID").val(data[0]);
    $("#txtAppUserId").val(data[1]);
    $("#txtCode1").val(data[2]);
    $("#txtCode2").val(data[3]);
    $("#txtCode3").val(data[4]);
    $("#txtRisk1").val(data[5]);
    $("#txtRisk2").val(data[6]);
    $("#txtRefTag").val(data[7]);
    $("#txtIntext_problems").val(data[8]);
    $("#txtBB_problems").val(data[9]);
    $("#txtAlt_sw").val(data[10]);
    $("#txtNotes").val(data[11]);
    var date = new Date(data[14]);
    $("#txtExpiration_date").datepicker({
        dateFormat: 'mm-dd-yy'
    }).datepicker('setDate', date);
    ShowSecNotesPopup(1);
}

function showCalender() {
    $("#txtExpiration_date").datepicker();
    $("#txtExpiration_date").focus();
    return false;
}