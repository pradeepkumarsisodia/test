﻿"use strict";
var feserverProxy = null;
var screenName = Cronus.Screens.OttiRun;
var dataTableArray = [];
var userName = null;
$(document).on("ready", function () {
    if (!Cronus.selectedPage(screenName, Cronus.Actions.OttiRun_View)) {
        return;
    }

    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.OttiRun_Run, screenName) == false) {
        $("#btnOttiRunUpload").attr('disabled', true);
        $("#btnOttiRunUpload").addClass('disabledbtn');
    }
    userName = $("#spnWindowsUsername").text().split("PIMCO")[1].replace('\\', '');
    feserverProxy = FeServer.createServerProxy("Cronus", userName);
    feserverProxy.addEventHandler(FeServer.Events.status, function (e) {
        onUpdateStatus(e.id, e.status);
    });

    $("#txtPricedate").datepicker({ maxDate: -1 });
    Cronus.populatePreviousDate($("#txtPricedate"));
    $("#btnBrwoseFIle").val("Browse Cusip File");
    $('#rdlCusipFile').attr("disabled", true);
    $('#rdlAccountFile').attr("disabled", true);
    $('#rdlCusipFile').prop('checked', false);
    $('#rdlAccountFile').prop('checked', false);
    $('#btnOttiRunUpload').click(function () {
        $("#divLog").empty();
        $("#divLog").addClass('hidden');
        $('#divShowOTTTIFileName').empty();
        $("#divShowOTTTIFileName").addClass('hidden');
        $('table td a').css("background", "");

        if (cusipData == null || cusipData == "") {
            swal("Oops", "Please browse file", "error");
            return;
        }
        $("#txtFileName").css('color', '');
        callFeserver();
        $("#txtFileName").text('');
    });

    $('table').on('click', 'td a', function () {
        $('table td a').css("background", "");
        $(this).css("background", "yellow");
    });
    $('#lnkFeSeverAuditor').click(function () {
        window.open(feserverProxy.absolute());
    });


   
    $('#rdlTypeOTTI').click(function () { $("#btnBrwoseFIle").val("Browse Cusip File"); $('#rdlCusipFile').attr("disabled", true); $('#rdlAccountFile').attr("disabled", true); $('#rdlCusipFile').prop('checked', false); $('#rdlAccountFile').prop('checked', false); showFiles(); });
    $('#rdlTypeFIG').click(function () { $("#btnBrwoseFIle").val("Browse Cusip File"); $('#rdlCusipFile').attr("disabled", true); $('#rdlAccountFile').attr("disabled", true); $('#rdlCusipFile').prop('checked', false); $('#rdlAccountFile').prop('checked', false); showFiles(); });
    $('#rdlTypeCASHFLOW').click(function () { $("#btnBrwoseFIle").val("Browse File"); $('#rdlCusipFile').attr("disabled", false); $('#rdlAccountFile').attr("disabled", false); $('#rdlCusipFile').prop('checked', true); $('#rdlAccountFile').prop('checked', false); showFiles(); });
    
   
    showFiles();
});

function getValue(value) {

    window.open(feserverProxy.absolute(value));
}




function onUpdateStatus(requestId, status) {
    console.log(requestId, status);
    if (status === 'READY') {
        showFiles();
        return;
    }

    var e = $("#" + requestId);
    if (e) {
        if (status === 'FAILED')
            e.html('<a href = "javascript:void(0);" onclick="showLog(\'' + requestId + '\')" style ="color:red;">' + status + '</a>');
        else if (status === 'OK')
            e.html('<a href = "javascript:void(0);" onclick="showResult(\'' + requestId + '\')" style ="color:blue;">' + status + '</a>');
        else
            e.html(status);
        console.info("status of " + requestId + " updated with " + status);
    }
    else {
        console.error("didn't find any element with id " + requestId);
    }
}


function showResult(requestId) {
    $("#divLog").addClass('hidden');
    $("#divShowOTTTIFileName").removeClass('hidden');
    $("#divShowOTTTIFileName").empty()
    feserverProxy.submitQuery(FeServer.Tasks.RESULT, { id: requestId }, function (response) {
        console.log(response["results"]);
        var fileData = response.results.data;
        for (var property in fileData) {
            if (fileData[property] != '') {

                var Id = property.replace(new RegExp("\\.", "ig"), '');
                var html = '<div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><u>'
                html += '<a data-toggle="collapse" href="#" >Output File</a></u></h4></div>'
                html += '<div class="panel-body" style="overflow:auto;">'
                $.each(fileData[property], function (index, value) {
                    html += '<a target="_blank" href="' + feserverProxy.absolute(value) + '" >' + value.substr(value.lastIndexOf('/') + 1, (value.length - value.lastIndexOf('/'))) + '</a>' + ' </Br> ';
                });
                html += '</div></div>'
                console.log(html);
                $('#divShowOTTTIFileName').append(html);

            }
        }
        $('html, body').animate({ scrollTop: $('#divShowOTTTIFileName').offset().top }, 'slow');
    }, null);
}

function showLog(requestId) {

    $("#divShowOTTTIFileName").addClass('hidden');
    $("#divShowOTTTIFileName").empty()
    $('#divLog').empty();

    var logText = "";
    var params = {
        id: requestId
    };
    feserverProxy.submitQuery(FeServer.Tasks.LOG, params, function (response) {
        for (var property in response.results.logs) {


            if (response.results.logs[property] != '') {
                var color = '';
                if (response.results.logs[property].toLowerCase().indexOf("error") >= 0 || response.results.logs[property].toLowerCase().indexOf("failed") >= 0)
                    color = 'style = "color:red;"';

                var Id = property.replace(new RegExp("\\.", "ig"), '');
                var html = '<div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><u>'
                html += '<a data-toggle="collapse" href="#' + Id + '" ' + color + '>' + property + '</a></u></h4>'
                html += '</div><div id="' + Id + '" class="panel-collapse collapse">'
                html += '<div class="panel-body" style="overflow:auto;">'
                html += response.results.logs[property].replace(new RegExp('\n', "g"), '</br>')
                    .replace(new RegExp("FAILED", "ig"), "<b style=color:red> FAILED </b> ")
                    .replace(new RegExp("Error", "ig"), "<b> ERROR </b> ")
                    + " </Br> </Br>";
                html += '</div></div></div>'
                $('#divLog').append(html);
            }
        }

        $("#divLog").removeClass('hidden');
        $('html, body').animate({ scrollTop: $('#divLog').offset().top }, 'slow');
    });
}
function showFromCalender() {
    $("#txtPricedate").focus();

    return false;
}
var cusipData = [];
function readDefinitionsFile(input) {
    cusipData = null;
    $("#txtFileName").text(input.files[0].name);
    $("#txtFileName").css('color', '');
    $('#divStatus').css("display", "none");
    $("#divLog").empty()
    $("#divLog").addClass('hidden');
    $('#divShowOTTTIFileName').empty();
    $("#divShowOTTTIFileName").addClass('hidden');
    $('table td a').css("background", "");
    if (input.files && input.files[0]) {
        var reader = new window.FileReader();
        $(".blockOverlay").css('display', 'block');
        reader.onload = function (e) {
            try {
                loadFile(e.target.result, ",");

            } catch (err) {
                $(".blockOverlay").css('display', 'none');
                // Clear file browser
                clearFileBrower();
                swal("Error", err, "error");
            }
        };
        reader.readAsText(input.files[0]);
    }
    input = $("#ottiRunFile");
    input.replaceWith(input.val('').clone(true));
}


function loadFile(text, seperator) {
    cusipData = text.split(/[\r\n]+/g).filter(function (x) { return x && x.trim(); }); // tolerate both Windows and Unix linebreaks    
    if (cusipData.length <= 0) {
        throw ("File is empty, cannot be uploaded");
    }
    var wrongCusip = "";
    $.each(cusipData, function (keys, value) {
        //alert(value);
        if (value.length < 9) {
            wrongCusip += "\n" + value
        }
    });
    if (wrongCusip != "") {
        swal("error", 'Please verify below cusips: ' + wrongCusip, "error");
    }
    var fileNameWithCusipCount = $("#txtFileName").text() + " ( #cusips : " + cusipData.length + ")";
    $("#txtFileName").text(fileNameWithCusipCount);

    $(".blockOverlay").css('display', 'none');
    // RefreshTable();
}

function showFiles() {
    $("#divLog").empty();
    $("#divLog").addClass('hidden');
    $('#divShowOTTTIFileName').empty();
    $("#divShowOTTTIFileName").addClass('hidden');
    var runTask;
    if ($("#rdlTypeOTTI").is(':checked')) {
        runTask = "OTTI_RUN";
    }
    if ($("#rdlTypeFIG").is(':checked')) {
        runTask = "FIG";
    }
    if ($("#rdlTypeCASHFLOW").is(':checked')) {
        runTask = "CASHFLOW";
    }
    var params = {
        task: runTask,
        username: userName,  //any user,
        view: 'ALL',
        count: 10
    };
    feserverProxy.submitQuery(FeServer.Tasks.HISTORY, params, function (response) {
        if (response.status == "OK") {
            console.log(response["results"]);
            var results = response["results"];
            var requestIds = results["history"].map(function (item) { return item.request["id"]; });
            var recentOttiRun = $("#recentOttiRun");
            $("#recentOttiRun > tbody").html(""); //clear only the rows, not headers
            $(results["history"]).each(function () {
                recentOttiRun.append(makeTrHtml({
                    id: this.request.id,
                    //   cusip: this.request.params["cmd_options"]["f"],
                    priceDate: this.request.params["cmd_options"]["d"], //price-date
                    status: this.status,
                    serverTime: this.request.server_time,
                    username: this.request.username

                }));
            });
        }
    }, null);

}
function makeTrHtml(req) {
    var status = undefined;
    if (req.status === "FAILED")
        status = '<a href = "javascript:void(0);" onclick="showLog(\'' + req.id + '\')" style ="color:red;">' + req.status + '</a>';
    else if (req.status === "OK")
        status = '<a href = "javascript:void(0);" onclick="showResult(\'' + req.id + '\')" style ="color:blue;">' + req.status + '</a>';
    else
        status = '<span id="' + req.id + '">' + req.status + "</span>";

    return "<tr><td>" + req.priceDate
    // + '</td><td>' + req.cusip
                                        + '</td><td>' + req.username
                                        + '</td><td>' + req.serverTime.substring(0, 19)
                                        + '</td><td>' + status
                                        + '</tr>';
}

function callFeserver() {
    debugger;
   
    var runTask ;
    if ($("#rdlTypeOTTI").is(':checked')) {
        var params = {
            "cmd_options": {
                "d": $('#txtPricedate').val(),
                "f": cusipData,
                "m": userName

            }
    , "cmd_flags": []
        };
        runTask = FeServer.Tasks.OTTI_RUN;
    }
    if ($("#rdlTypeFIG").is(':checked')) {
        var params = {
            "cmd_options": {
                "d": $('#txtPricedate').val(),
                "f": cusipData,
                "m": userName

            }
    , "cmd_flags": []
        };
        runTask = FeServer.Tasks.FIG;
    }
    if ($("#rdlTypeCASHFLOW").is(':checked')) {
        var params = {
            "cmd_options": {
                "d": $('#txtPricedate').val(),
                "f": cusipData,
                "m": userName,
                "t": $("#rdlCusipFile").is(':checked') == true ? $("#rdlCusipFile").val() : $("#rdlAccountFile").val()
            }
       , "cmd_flags": []
        };
        runTask = FeServer.Tasks.CASHFLOW;
    }
    feserverProxy.submitAction(runTask, params, function (id) {
        console.log("Submit : " + id);
        $("#recentOttiRun").prepend(makeTrHtml({
            id: id,
            priceDate: $('#txtPricedate').val(),
            //  cusip: cusipData,
            status: 'SUBMITTED',
            serverTime: 'Now',
            username: userName

        }));
        var trList = $("#recentOttiRun tr");
        if (trList.length >= 11)
            trList.last().remove();

    }, null);

    cusipData = null;
}
function clearFileBrower() {
    $("#txtFileName").text("");
    var input = $("#ottiRunFile");
    input.replaceWith(input.val('').clone(true));
  //  lines = [];
   // outputArray = [];

    $(".blockOverlay").css('display', 'none');
}

function openfileuploader() {
    $("#ottiRunFile").click();
}