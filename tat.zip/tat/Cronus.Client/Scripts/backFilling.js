﻿var screenName = Cronus.Screens.BackFilling;
var dtBackFillingData;
var feserverProxy = null;

// create an output array of map. This will be sent to server
var dataTableArray = [];
var columns = [];
var fileName = "";

$(document).on("ready", function () {
    if (!Cronus.selectedPage(screenName, Cronus.Actions.BackFilling_View)) {
        return;
    }

    //Permission Check
    if (Cronus.Compliance.isActionPermitted(Cronus.Actions.BackFilling_Save, screenName) == false) {
        $("#btnsubmitBackFillingData").attr('disabled', true);
        $("#btnsubmitBackFillingData").addClass('disabledbtn');
    }

    // Initialize FeServerProxy with client name and user name
    feserverProxy = FeServer.createServerProxy("Cronus", $("#spnWindowsUsername").text().split("PIMCO")[1].replace('\\', ''));
    feserverProxy.addEventHandler(FeServer.Events.status, function (e) {
        console.log(e);
        onUpdateStatus(e.id, e.status);
        $("#outputView").css("display", "none");
        if (e.message) {
            $("#outputView").css("display", "block");
            console.log(feserverProxy.decode(e.message));
            $("#outputView").html(feserverProxy.decode(e.message));
        }
    });

    $('#btnReset').click(function () {
        resetScreen();
    });

    $('#btnsubmitBackFillingData').click(function () {
        submitBackFillingData();
    });

    /*Initialization for Script View */
    $("#txtFromdate,#txtTodate").datepicker({ maxDate: new Date(), dateFormat: "yy/mm/dd" });
    var oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

    $("#txtFromdate").val($.datepicker.formatDate("yy/mm/dd", oneWeekAgo));
    $("#txtTodate").val($.datepicker.formatDate("yy/mm/dd", new Date()));

    $('#btnSubmitData').click(function () {
        submitBackFillingScriptData();
    });
    $('#lnkFeSeverAuditor').click(function () {
        window.open(feserverProxy.absolute());
    });
});

function onUpdateStatus(requestId, status) {

    console.log(requestId, status);
    $("#actionStatus").html(status);
    $("#actionStatus").css("text-decoration", "");
    if (status == "OK") {
        $("#actionStatus").css("color", "#008800");
    }
    if (status == "FAILED") {
        $("#actionStatus").html('<a href = "javascript:void(0);" onclick="showLog(\'' + requestId + '\'); return false;"  style ="color:red;">' + status + '</a>');
        $("#actionStatus").css("text-decoration", "underline");
        // $("#actionStatus").css("color", "#aa0000");
    }

    //var statusData = getStatus(status, requestId);

}
function showLog(requestId) {
    $('#divLog').empty();
    var logText = "";
    var params = {
        id: requestId
    };
    feserverProxy.submitQuery(FeServer.Tasks.LOG, params, function (response) {
        for (var property in response.results.logs) {


            if (response.results.logs[property] != '') {
                var color = '';
                if (response.results.logs[property].toLowerCase().indexOf("error") >= 0 || response.results.logs[property].toLowerCase().indexOf("failed") >= 0)
                    color = 'style = "color:red;"';

                var Id = property.replace(new RegExp("\\.", "ig"), '');
                var html = '<div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title"><u>'
                html += '<a data-toggle="collapse" href="#' + Id + '" ' + color + '>' + property + '</a></u></h4>'
                html += '</div><div id="' + Id + '" class="panel-collapse collapse">'
                html += '<div class="panel-body" style="overflow:auto;">'
                html += response.results.logs[property].replace(new RegExp('\n', "g"), '</br>')
                    .replace(new RegExp("FAILED", "ig"), "<b style=color:red> FAILED </b> ")
                    .replace(new RegExp("Error", "ig"), "<b> ERROR </b> ")
                    + " </Br> </Br>";
                html += '</div></div></div>'
                $('#divLog').append(html);
            }
        }

        $("#divLog").removeClass('hidden');
    });
}
function appendErrorMessage(error) {
    swal("Error", error, "error");
}
var submitBackFillingScriptData = function () {
    $("#outputView").html("");
    $("#divLog").addClass('hidden');
    var groupIds = $("#txtGroupIds").val().trim();
    var defIds = $("#txtDefIds").val().trim();
    var fromDate = $("#txtFromdate").val();
    var toDate = $("#txtTodate").val();
    if (!Cronus.isNotEmptyNullOrUndefined(groupIds)) {
        appendErrorMessage("Please Pass Comma [,] separated list of Group Ids!!");
        $("#txtGroupIds").focus();
        return;
    }
    else if (!Cronus.isNotEmptyNullOrUndefined(defIds)) {
        appendErrorMessage("Please Pass Comma [,] separated list of Def Ids!!");
        $("#txtDefIds").focus();
        return;
    }
    else if (!Cronus.isNotEmptyNullOrUndefined(fromDate)) {
        appendErrorMessage("Please select from date !!");
        $("#txtFromdate").focus();
        return;
    }

    else if (Cronus.isNotEmptyNullOrUndefined(toDate) && (Date.parse(fromDate) > Date.parse(toDate))) {
        appendErrorMessage("From date should be less than To date !!");
        $("#txtTodate").focus();
        return;
    }
    feserverProxy.submit
    toDate = toDate || undefined; //make undefined if undefined/null/empty
    //note that undefined keys are NOT serialized by JSON, so the server will not receive even the key.

    var params = {
        "cmd_options": {
            "group-ids": groupIds,
            "def-ids": defIds,
            "from-date": fromDate,
            "to-date": toDate
        },
        "cmd_flags": []
    };
    feserverProxy.submitAction(FeServer.Tasks.TS_BACKFILLER, params, function (id) {
        console.log("submitted TIME_SERIES_BACKFILLING action id : " + id);
        swal("Info", "Request Submitted successfully", "success");
    },
    function (error) {
        console.error("submission error : ", error);
    });

};


function toggleTab(id, el) {
    $(el).removeClass('disabledbtn');
    $("#" + id).addClass('disabledbtn');
    if (id == "btnAnalytics") {
        $("#ExcelView").hide();
        $("#ScriptView").show();
    } else if (id == "btnTrader") {
        $("#ScriptView").hide();
        $("#ExcelView").show();
    }
}

function readDefinitionsFile(input) {
    fileName = input.files[0].name;
    $("#txtFileName").text(input.files[0].name);
    if (input.files && input.files[0]) {
        var reader = new window.FileReader();
        $(".blockOverlay").css('display', 'block');
        reader.onload = function (e) {
            try {
                loadFile(e.target.result, ",");
            } catch (err) {
                $(".blockOverlay").css('display', 'none');
                // Clear file browser
                clearFileBrower();
                swal("Error", err, "error");
                Cronus.destroyDataTable(dtBackFillingData, $("#dtBackFillingData"));
            }
        };
        reader.readAsText(input.files[0]);
    }
    input = $("#tsDefFile");
    input.replaceWith(input.val('').clone(true));
}

function clearFileBrower() {
    $("#txtFileName").text("");
    var input = $("#tsDefFile");
    input.replaceWith(input.val('').clone(true));
    lines = [];
    if (dtBackFillingData != undefined)
        dtBackFillingData.fnClearTable();

    $(".blockOverlay").css('display', 'none');
}

function loadFile(text, seperator) {    
    var lines = [];
    lines = text.split(/[\r\n]+/g); // tolerate both Windows and Unix linebreaks    
    if (lines.length < 2) {
        throw ("No data in file");
    }

    columns = [];
    var headers = lines[0].split(seperator);
    var firstDataRow = lines[1].split(seperator);
    for (var index = 0; index < firstDataRow.length; index++) {
        if (Cronus.isNotEmptyNullOrUndefined(firstDataRow[index])) {
            if (!Cronus.isNotEmptyNullOrUndefined(headers[index]))
                columns.push("AsofDate");
            else {
                if (/^[0-9]*$/.test(headers[index]))
                    columns.push(headers[index]);
                else {
                    throw ("Wrong format");
                }
            }
        }
    }

    //read the file and get all the data.
    dataTableArray = [];
    for (var i = 1; i < lines.length; i++) {
        var line = lines[i];
        if (!Cronus.isNotEmptyNullOrUndefined(line))
            continue;
        if (line.match(/^#/))
            continue;
        var lineData = line.split(seperator);

        //create data row
        var datarow = [];
        var lastIndex = undefined;
        var status = "";
        for (var index = 0; index < lineData.length; index++) {
            if (lineData[index] == "") { //Remove this condition
                if (lastIndex == undefined)
                    lastIndex = index;

                if (lastIndex == (index - 1)) {
                    if (lineData[index] != "") {
                        lastIndex = undefined;
                        throw ("Wrong data/Invalid format at row " + (i + 1));
                    }
                }
            }
            if (lastIndex == (index - 1)) {
                if (lineData[index] != "") {
                    lastIndex == undefined;
                    throw ("Wrong data/Invalid format at row " + (i + 1));
                }

            }

            if (index == 0) {
                var date = lineData[index].split('-');
                if (date[2].length < 4) {
                    throw ("Wrong data/Invalid date format at row " + (i + 1));
                }
            }
            datarow.push(lineData[index]);

        }
        if (datarow.length != columns.length) {
            throw ("Wrong data/Invalid format at row " + (i + 1));
        }


        // push data in final array
        dataTableArray.push(datarow);
    }

    dtBackFillingData = Cronus.refreshDataTable(dtBackFillingData, $("#dtBackFillingData"), columns, []);
    dtBackFillingData.fnClearTable();
    if (dataTableArray.length > 0)
        dtBackFillingData.fnAddData(dataTableArray);

    //    $.each(dataTableArray, function (index, array) {
    //        $.each(defIdArr, function (i, defId) {
    //            defIdMap[defId][array[i * 2]] = array[i * 2 + 1];
    //        });
    //    })    

    $(".blockOverlay").css('display', 'none');
    // RefreshTable();
}

function resetScreen() {
    clearFileBrower();
}

function submitBackFillingData() {
    var inputObj = { screenName: screenName, data: { DefinitionDataList: dataTableArray, Columns: columns, FileName: fileName, Tab: "E" } };
    var retval = Cronus.ajaxCall(inputObj, Cronus.RestApi.UpdateDB, ".blockOverlay", true);
    $.when(retval.AjaxObj).done(function () {
        var result = retval.AjaxObj.responseJSON;
        if (result.errorMessage == null || result.errorMessage == "") {
            clearFileBrower();
            resetScreen();
            swal("Info", "Data Inserted successfully in definitions tables", "success");
        }
    });
}
function openfileuploader() {
    $("#tsDefFile").click();
}

function showFromCalender() {
    $("#txtFromdate").focus();
    return false;
}
function showToCalender() {
    $("#txtTodate").focus();
    return false;
}


//var submitBackFillingScriptData = function() {
//    var groupIds = $("#txtGroupIds").val().trim();
//    var defIds = $("#txtDefIds").val().trim();
//     var dateFrom = $("#txtFromdate");
//    var dateTo = $("#txtTodate");
//    if (dateFrom.val() === "") {
//        appendErrorMessage("Please select from date !!");
//        dateFrom.focus();
//    }
//    else if (dateTo.val() === "") {
//        appendErrorMessage("Please select to date !!");
//        dateTo.focus();
//    }
//    else if (Date.parse(dateFrom.val()) > Date.parse(dateTo.val())) {
//        appendErrorMessage("From date should be less than To date !!");
//        dateTo.focus();
//    }

//    var inputObj = { screenName: screenName, data: { Tab: "S", GroupIds: groupIds, DefIds: defIds,
//        FromDate: dateFrom.val() + " 00:00:00", ToDate: dateTo.val() + " 23:59:59"
//    }
//    };
//    var retval = ajaxCall(inputObj, UpdateDB, ".blockOverlay", true);
//    $.when(retval.AjaxObj).done(function () {
//        var result = retval.AjaxObj.responseJSON;
//        if (result.errorMessage == null || result.errorMessage == "") {
//            clearFileBrower();
//            resetScreen();
//            swal("Info", "Data Inserted successfully in definitions tables", "success");
//        }
//    });
//};