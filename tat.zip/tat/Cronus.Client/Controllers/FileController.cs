﻿using System;
using System.Web;
using System.Web.Mvc;
using System.IO;

namespace Cronus.Client.Controllers
{
    public class FileController : Controller
    {
        #region Actions

        /// <summary>
        /// Uploads the file.
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public virtual ActionResult UploadFile()
        {
            HttpPostedFileBase myFile = Request.Files["MyFile"];
            bool isUploaded = false;
            string message = "File upload failed";
            string fileGuid = "";
            if (myFile != null && myFile.ContentLength != 0)
            {
                var pathForSaving = Server.MapPath("/Images/Uploads/ProfilePicture/");
                if (this.CreateFolderIfNeeded(pathForSaving))
                {
                    try
                    {

                        var filearray = myFile.FileName.Split('.');
                        var ext = filearray[filearray.Length - 1];
                        fileGuid = Guid.NewGuid() + "." + ext;
                        var path = Path.Combine(pathForSaving, fileGuid);
                        myFile.SaveAs(path);
                        //myFile.SaveAs(Path.Combine(pathForSaving, myFile.FileName));
                        isUploaded = true;
                        message = "File uploaded successfully!";
                        //WebClient wc = new WebClient();                        
                    }
                    catch (Exception ex)
                    {
                        message = string.Format("File upload failed: {0}", ex.Message);
                    }
                }
            }
            return Json(new { isUploaded = isUploaded, message = message, imagePath = "/Images/Uploads/ProfilePicture/" + fileGuid }, "text/html");
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Creates the folder if needed.
        /// </summary>
        /// <param name="path">The path.</param>
        /// <returns></returns>
        private bool CreateFolderIfNeeded(string path)
        {
            bool result = true;
            if (!Directory.Exists(path))
            {
                try
                {
                    Directory.CreateDirectory(path);
                }
                catch (Exception)
                {
                    /*TODO: You must process this exception.*/
                    result = false;
                }
            }
            return result;
        }

        #endregion
    }
}
