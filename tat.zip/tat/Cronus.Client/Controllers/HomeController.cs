﻿using System.Web.Mvc;
using log4net;
using System.Web.WebPages;
using System;
using System.IO;

public static class FeServerUrl
{
    private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
    public static string Get(string relativeUrl, WebPageRenderingBase page)
    {
        var feserverUrl = string.Empty;
        string environment = page.Request.QueryString["env"];
        try
        {
            feserverUrl = Cronus.Bll.CronusBaseBll.FetchFeSeverUrl(environment);
            feserverUrl = feserverUrl + relativeUrl;
        }
        catch (Exception ex)
        {
        }
        return feserverUrl;
    }
}

namespace Cronus.Client.Controllers
{
    public class HomeController : Controller
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        #region Cronus
        public ActionResult Home()
        {
            ViewBag.HomeScreen = true;
            return View();
        }

        public ActionResult RiskMeasureOverride()
        {
            return View();
        }

        public ActionResult StaleRiskMeasures()
        {
            return View();
        }

        public ActionResult SubstituteCusips()
        {
            return View();
        }

        public ActionResult ImportToDatabase()
        {
            return View();
        }
        public ActionResult RejectedCusips()
        {
            return View();
        }

        public ActionResult Reporting()
        {
            return View();
        }

        public ActionResult Dashboard()
        {
            return View();
        }

        public ActionResult QueryBuilder()
        {

            return View();
        }
        public ActionResult QueryExecuter()
        {
            return View();
        }
        public ActionResult UserManagement()
        {
            return View();
        }

        public ActionResult Settings()
        {
            return View();
        }

        public ActionResult AgencyModelMap()
        {
            return View();
        }

        public ActionResult ModelSummaryReport()
        {
            return View();
        }

        public ActionResult CreditEntityAttributes()
        {
            return View();
        }
        public ActionResult Regression()
        {
            return View();
        }

        public ActionResult RiskAttribution()
        {
            return View();
        }
        #endregion cronus

        #region GRM
        public ActionResult RiskMeasuresLive()
        {
            return View();
        }
        #endregion

        #region Time Series
        public ActionResult SetupNewDefinitions()
        {
            return View();
        }

        public ActionResult ManageMasterTables()
        {
            return View();
        }

        public ActionResult BackFilling()
        {
            return View();
        }

        #endregion


        public ActionResult SecAnalyticsOverride()
        {
            return View();
        }
        public ActionResult OTTIRun()
        {
            return View();
        }
        public ActionResult AnalyticIdConfiguration()
        {
            return View();
        }

        public ActionResult SecurityStaleNotes()
        {
            return View();
        }

        public ActionResult CronusHelp()
        {
            return View();
        }

        public ActionResult Download(string filePath)
        {
            byte[] fileBytes = System.IO.File.ReadAllBytes(filePath);
            string fileName = Path.GetFileName(filePath);
            return File(fileBytes, System.Net.Mime.MediaTypeNames.Application.Octet, fileName);
        }

        public ActionResult DataManipulation()
        {
            return View();
        }

    }
}
