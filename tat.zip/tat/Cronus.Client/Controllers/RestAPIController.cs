﻿using System;
using System.Linq;
using System.Web.Http;
using log4net;
using Cronus.BO;
using Cronus.Bll;
using Cronus.Bll.Helper;

namespace Cronus.Client.Controllers
{

    public class RestAPIController : ApiController
    {        
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        
        public RestAPIController()
        {

        }
        #region Generic APIs
        internal string ParseUserName(string userName)
        {
            var part = userName.Split(new string[] { @"\" }, StringSplitOptions.RemoveEmptyEntries).LastOrDefault();
            return part != null ? part.ToUpperInvariant() : string.Empty;
        }
        #endregion Generic APIs

        #region log file APIs

        public string LoadCurrentLogFile()
        {
            return CronusBll.LoadCurrentLogFile();
        }

        #endregion


        //[HttpGet]
        public ResponseBO FetchResults(ResultMessageBO req)
        {
            ResponseBO retval = null;

            try
            {
                var startTime = DateTime.Now;
                var user = ParseUserName(User.Identity.Name);
                if (string.IsNullOrEmpty(req.screenName))
                    throw new Exception("Invalid Request as Screen Name missing");

                Log.InfoFormat("Request From User {0} for Screen {1}", user, req.screenName);

                retval = CronusBllFactory.GetInstance().GetBll(req.screenName, user, Request.RequestUri.DnsSafeHost, req.runEnviroment).FetchResults(req);

                Log.InfoFormat("ProcessTime {0} for request From User {1} for Screen {2}", (DateTime.Now - startTime), user, req.screenName);
            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                if (retval == null)
                    retval = new ResponseBO();
                retval.errorMessage = ex.Message;
            }
            return retval;

        }

        public UserInformation FetchUserInformation(RequestBO req)
        {
            return CronusBaseBll.FetchUserInformation(ParseUserName(User.Identity.Name), Request.RequestUri.DnsSafeHost, req.runEnviroment);
        }

        public ResponseBO FetchActionsForUser(RequestBO req)
        {
            //return CronusBaseBll.FetchActionsForUser(ParseUserName(User.Identity.Name), Request.RequestUri.DnsSafeHost, req.runEnviroment);
            return Utility.FetchActionsForUser(ParseUserName(User.Identity.Name), Request.RequestUri.DnsSafeHost, req.runEnviroment);
           
        }

        public ResponseBO FetchCycleAndPreviosDate(RequestBO req)
        {
            ResponseBO retval = null;

            try
            {
                var startTime = DateTime.Now;
                var user = ParseUserName(User.Identity.Name);
                if (string.IsNullOrEmpty(req.screenName))
                    throw new Exception("Invalid Request as Screen Name missing");

                Log.InfoFormat("Request From User {0} for Screen {1}", user, req.screenName);

                retval = CronusBllFactory.GetInstance().GetBll(req.screenName, user, Request.RequestUri.DnsSafeHost, req.runEnviroment).FetchCycleAndPreviosDate();

                Log.InfoFormat("ProcessTime {0} for request From User {1} for Screen {2}", (DateTime.Now - startTime), user, req.screenName);
            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                if (retval == null)
                    retval = new ResponseBO();
                retval.errorMessage = ex.Message;
            }
            return retval;
        }

        public ResponseBO UpdateDB(RequestBO req)
        {
            ResponseBO retval = null;
            try
            {
                var startTime = DateTime.Now;
                var user = ParseUserName(User.Identity.Name);
                if (string.IsNullOrEmpty(req.screenName))
                    throw new Exception("Invalid Request as Screen Name missing");

                Log.InfoFormat("Request From User {0} for Screen {1}", user, req.screenName);

                retval = CronusBllFactory.GetInstance().GetBll(req.screenName, user, Request.RequestUri.DnsSafeHost, req.runEnviroment).UpdateDB(req);

                Log.InfoFormat("ProcessTime {0} for request From User {1} for Screen {2}", (DateTime.Now - startTime), user, req.screenName);
            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                if (retval == null)
                    retval = new ResponseBO();
                retval.errorMessage = ex.Message;
            }
            return retval;
        }

        public ResponseBO FetchDropDownData(DropDownRequestBO req)
        {
            ResponseBO retval = null;
            try
            {
                var startTime = DateTime.Now;
                var user = ParseUserName(User.Identity.Name);
                if (string.IsNullOrEmpty(req.screenName))
                    throw new Exception("Invalid Request as Screen Name missing");

                Log.InfoFormat("Request From User {0} for Screen {1}", user, req.screenName);

                retval = CronusBllFactory.GetInstance().GetBll(req.screenName, user, Request.RequestUri.DnsSafeHost, req.runEnviroment).FetchDropDownData(req);

                Log.InfoFormat("ProcessTime {0} for request From User {1} for Screen {2}", (DateTime.Now - startTime), user, req.screenName);
            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                if (retval == null)
                    retval = new ResponseBO();
                retval.errorMessage = ex.Message;
            }
            return retval;
        }

        public ResponseBO FetchDataForTable(TableDataRequestBO req)
        {
            ResponseBO retval = null;
            try
            {
                var startTime = DateTime.Now;
                var user = ParseUserName(User.Identity.Name);
                if (string.IsNullOrEmpty(req.screenName))
                    throw new Exception("Invalid Request as Screen Name missing");

                Log.InfoFormat("Request From User {0} for Screen {1}", user, req.screenName);

                retval = CronusBllFactory.GetInstance().GetBll(req.screenName, user, Request.RequestUri.DnsSafeHost, req.runEnviroment).FetchDataForTable(req);

                Log.InfoFormat("ProcessTime {0} for request From User {1} for Screen {2}", (DateTime.Now - startTime), user, req.screenName);
            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                if (retval == null)
                    retval = new ResponseBO();
                retval.errorMessage = ex.Message;
            }
            return retval;
        }

        public ResponseBO FetchDataForQB(TableDataRequestBO req)
        {
            ResponseBO retval = null;
            try
            {
                var startTime = DateTime.Now;
                var user = ParseUserName(User.Identity.Name);
                if (string.IsNullOrEmpty(req.screenName))
                    throw new Exception("Invalid Request as Screen Name missing");

                Log.InfoFormat("Request From User {0} for Screen {1}", user, req.screenName);
                
                retval = CronusBllFactory.GetInstance().GetBll(req.screenName, user, Request.RequestUri.DnsSafeHost, req.runEnviroment).FetchDataForQB(req);

                Log.InfoFormat("ProcessTime {0} for request From User {1} for Screen {2}", (DateTime.Now - startTime), user, req.screenName);
            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                if (retval == null)
                    retval = new ResponseBO();
                retval.errorMessage = ex.Message;
            }
            return retval;
        }

        //Can we used for Ok/Commit
        public ResponseBO Commit(RequestBO req)
        {
            ResponseBO retval = null;
            try
            {
                var startTime = DateTime.Now;
                var user = ParseUserName(User.Identity.Name);
                if (string.IsNullOrEmpty(req.screenName))
                    throw new Exception("Invalid Request as Screen Name missing");

                Log.InfoFormat("Request From User {0} for Screen {1}", user, req.screenName);

                retval = CronusBllFactory.GetInstance().GetBll(req.screenName, user, Request.RequestUri.DnsSafeHost, req.runEnviroment).Commit(req);

                Log.InfoFormat("ProcessTime {0} for request From User {1} for Screen {2}", (DateTime.Now - startTime), user, req.screenName);
            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                if (retval == null)
                    retval = new ResponseBO();
                retval.errorMessage = ex.Message;
            }
            return retval;
        }

        //Can we used for Cancel/Rollback
        public ResponseBO Rollback(RequestBO req)
        {
            ResponseBO retval = null;
            try
            {
                var startTime = DateTime.Now;
                var user = ParseUserName(User.Identity.Name);
                if (string.IsNullOrEmpty(req.screenName))
                    throw new Exception("Invalid Request as Screen Name missing");

                Log.InfoFormat("Request From User {0} for Screen {1}", user, req.screenName);

                retval = CronusBllFactory.GetInstance().GetBll(req.screenName, user, Request.RequestUri.DnsSafeHost, req.runEnviroment).Rollback(req);

                Log.InfoFormat("ProcessTime {0} for request From User {1} for Screen {2}", (DateTime.Now - startTime), user, req.screenName);
            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                if (retval == null)
                    retval = new ResponseBO();
                retval.errorMessage = ex.Message;
            }
            return retval;
        }

        //Can we used for Cancel/Rollback
        public ResponseBO CancelAjax(RequestBO req)
        {
            ResponseBO retval = null;
            try
            {
                var startTime = DateTime.Now;
                var user = ParseUserName(User.Identity.Name);
                if (string.IsNullOrEmpty(req.screenName))
                    throw new Exception("Invalid Request as Screen Name missing");

                Log.InfoFormat("Request From User {0} for Screen {1}", user, req.screenName);

                retval = CronusBllFactory.GetInstance().GetBll(req.screenName, user, Request.RequestUri.DnsSafeHost, req.runEnviroment).CancelAjax(req);

                Log.InfoFormat("ProcessTime {0} for request From User {1} for Screen {2}", (DateTime.Now - startTime), user, req.screenName);
            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                if (retval == null)
                    retval = new ResponseBO();
                retval.errorMessage = ex.Message;
            }
            return retval;
        }

        //Custom ajax call
        public ResponseBO CustomFunction(CustomFunctionBO req)
        {
            ResponseBO retval = null;
            try
            {
                var startTime = DateTime.Now;
                var user = ParseUserName(User.Identity.Name);
                if (string.IsNullOrEmpty(req.screenName))
                    throw new Exception("Invalid Request as Screen Name missing");

                Log.InfoFormat("Request From User {0} for Screen {1}", user, req.screenName);

                retval = CronusBllFactory.GetInstance().GetBll(req.screenName, user, Request.RequestUri.DnsSafeHost, req.runEnviroment).CustomFunction(req);

                Log.InfoFormat("ProcessTime {0} for request From User {1} for Screen {2}", (DateTime.Now - startTime), user, req.screenName);
            }
            catch (Exception ex)
            {
                Log.Error(string.Format("Exception: {0}", ex.Message), ex);
                if (retval == null)
                    retval = new ResponseBO();
                retval.errorMessage = ex.Message;
            }
            return retval;
        }
        [HttpGet]
        public string health()
        {
            return "{'status':'HEALTHY'}";
        }
    }
}
