﻿using System.Web;
namespace Cronus.Web.Models
{
    public class FileUploadModel
    {
        public HttpPostedFileBase MyFile { get; set; }
    }
}