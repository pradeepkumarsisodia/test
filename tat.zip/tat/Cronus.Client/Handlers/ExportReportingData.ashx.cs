﻿using System;
using System.IO;
using System.Web;
using ClosedXML.Excel;
using Cronus.Client.Controllers;

namespace Cronus.Client.Handlers
{
    /// <summary>
    /// Summary description for ExportReport
    /// </summary>
    public class ExportReportingData : IHttpHandler
    {
        public void ProcessRequest(HttpContext context)
        {
            var excelType = context.Request["reportType"];
            //if (excelType == "reporting")
            //{
            //    var db = new RestAPIController();
            //    var a = Convert.ToDateTime(context.Request["dateFrom"]);
            //    var b = Convert.ToDateTime(context.Request["dateTo"]);
            //    var c = context.Request["oracleDb"];
            //    var d = Convert.ToInt32(context.Request["currentPage"]);
            //    var e = Convert.ToInt32(context.Request["pageSize"]);
            //    var f = context.Request["sortType"];
            //    var g = Convert.ToInt32(context.Request["columnIndex"]);
            //    var h = Convert.ToBoolean(context.Request["isFilterType"]);
            //    var i = context.Request["userId"];
            //    var j = context.Request["screenId"];
            //    var k = context.Request["description"];

            //    string sheetName = "Reporting_" + DateTime.Now.ToShortDateString().Replace('/', '-') + " " + DateTime.Now.ToShortTimeString().Replace(':', '-');
            //    var wb = new XLWorkbook();
            //    var users = wb.Worksheets.Add(sheetName);


            //    users.Cell(1, 1).InsertTable(Cronus.Bll.CronusBll.ExportReportingData(a, b, c, d, e, f, g, h, i, j, k));


            //    context.Response.Clear();
            //    context.Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            //    context.Response.AddHeader("content-disposition",
            //                               String.Format(@"attachment;filename={0}.xlsx", sheetName.Replace(" ", "_")));

            //    using (var memoryStream = new MemoryStream())
            //    {
            //        wb.SaveAs(memoryStream);
            //        memoryStream.WriteTo(context.Response.OutputStream);
            //        memoryStream.Close();
            //    }

            //    context.Response.Flush();

            //    context.Response.End();
            //}
            //else
            if (excelType == "RejectedCusipReporting")
            {
                var db = new RestAPIController();
                var a = context.Request["reload_flag"];
                //var b = db.SetSybaseDB();
                var b = context.Request["url"];
                var c = context.Request["context"];
                var d = context.Request["cusipList"];
                var e = context.Request["priceDate"];
                var i = context.Request["userId"];
                var j = context.Request["runOnEnvironment"];
                // b = db.SetSybaseDB();

                string sheetName = "Cusips_" + DateTime.Now.ToShortDateString().Replace('/', '-') + " " + DateTime.Now.ToShortTimeString().Replace(':', '-');
                var wb = new XLWorkbook();
                var users = wb.Worksheets.Add(sheetName);
                users.Cell(1, 1).InsertTable(Cronus.Bll.CronusBll.ExportRejectedCusipData(i, a, b, c, d, e, j));


                context.Response.Clear();
                context.Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                context.Response.AddHeader("content-disposition",
                                           String.Format(@"attachment;filename={0}.xlsx", sheetName.Replace(" ", "_")));

                using (var memoryStream = new MemoryStream())
                {
                    wb.SaveAs(memoryStream);
                    memoryStream.WriteTo(context.Response.OutputStream);
                    memoryStream.Close();
                }

                context.Response.Flush();
                context.Response.End();
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}